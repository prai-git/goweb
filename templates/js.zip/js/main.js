/*************************************************************************************************************
 * 
 * main object of application in which contains all the sub name-spacing,methods and properties.
 * 
 * updated uglify command can be find in XGPCOM-8466
 * 
  uglifyjs js/common-util.js js/fileFormatExt.js js/init.js js/main.js js/enum/PrintProductType.js js/enum/ApplicationConstants.js js/elements.js js/view.js js/products.js 
  js/mainScreen.js js/events.js js/canvas.js js/shapes.js js/undoManager.js js/preview.js js/message.js js/utility.js js/request.js js/dialog.js js/ruler.js 
  js/visualAids.js js/helper.js js/img-lib.js js/shapelib.js js/cropImage.js js/crop.js js/key.js js/saveDesign.js js/updateFD.js js/customize.js js/importSvg.js
  js/toSVGCustomize.js js/activity.js js/myUploadImage.js js/uploadImage.js js/templateDataTransfer.js --compress --mangle --source-map url=app.js.map --output app.js
 **********************************************************************************************************/
var FQD= FQD || {};

FQD.init=function(){
	FQD.initElement();
	FQD.utility.init(); 
	FQD.dialog.init(); 
	FQD.events.init();
	FQD.initKeyboard();
	
}

function rgbToHex(r, g, b) {
    if (r > 255 || g > 255 || b > 255)
        throw "Invalid color component";
    return ((r << 16) | (g << 8) | b).toString(16);
}


function newControls(control, ctx, methodName, left, top) {
	  if (!this.isControlVisible(control)) {
	        return;
	      }
	      var size = this.cornerSize;
	      this.transparentCorners || ctx.clearRect(left, top, size, size);
	      ctx.beginPath();
	      ctx.arc(left + size/2, top + size/2, size/2, 0, 2 * Math.PI, false);
	      ctx.strokeStyle = '#54c2f9';
	      ctx.fillStyle = '#00aaff';
	      ctx.fill();
	      ctx.stroke();
	}

	fabric.Object.prototype._drawControl = newControls;
	fabric.Object.prototype.cornerSize = 12;


/**
 * Item name is non-unique
 */
fabric.Canvas.prototype.getItemsByName = function(name) {
  var objectList = [],
      objects = this.getObjects();

  for (var i = 0, len = this.size(); i < len; i++) {
    if (objects[i].name && objects[i].name === name) {
      objectList.push(objects[i]);
    }
  }

  return objectList;
};

fabric.Canvas.prototype.getAbsoluteCoords = function(object) {
    return {
      left: object.left + this._offset.left,
      top: object.top + this._offset.top
    };
  }

String.prototype.reverse = function () {
    return this.split('').reverse().join('');
};

String.prototype.replaceLast = function (what, replacement) {
    return this.reverse().replace(new RegExp(what.reverse()), replacement.reverse()).reverse();
};
String.prototype.includes = function (str) {
	  var returnValue = false;

	  if (this.indexOf(str) !== -1) {
	    returnValue = true;
	  }

	  return returnValue;
	}

/**
 * Item name is unique
 */
fabric.Canvas.prototype.getItemByName = function(name) {
  var object = null,
      objects = this.getObjects();

  for (var i = 0, len = this.size(); i < len; i++) {
    if (objects[i].name && objects[i].name === name) {
      object = objects[i];
      break;
    }
  }

  return object;
};


function setIconPosition(canvas,obj,element) {
	if(element && obj && canvas){
	    var absCoords = canvas.getAbsoluteCoords(obj);
	    var xArray = [obj.oCoords.tl.x, obj.oCoords.tr.x, obj.oCoords.bl.x, obj.oCoords.br.x];
	    var yArray = [obj.oCoords.tl.y, obj.oCoords.tr.y, obj.oCoords.bl.y, obj.oCoords.br.y];
	   
	    var l = (((xArray.min()+xArray.max())/2) - element.width()/2-10)  + 'px';
	    var t = (((yArray.min()+yArray.max())/2)- element.height()/2-10) + 'px';
	    element.css({left:l,top:t});
	}
  }

function showImageWarnings(elm){
	elm.find(".warningMsgContainer").show();
}
function hideImageWarnings(elm){
	elm.find(".warningMsgContainer").hide();
}

FQD.setLayoutAndTheme=function(newLayout,newTheme){
	var layoutCss=document.getElementById('layout'),
		themeCss=document.getElementById('theme'),
		oldLayout =layoutCss.getAttribute("href"),
		oldTheme = themeCss.getAttribute("href");
		oldLayout=oldLayout.slice(0,oldLayout.lastIndexOf("/")+1);
		oldTheme=oldTheme.slice(0,oldTheme.lastIndexOf("/")+1);
		
		if(config.theme != newTheme){
			themeCss.setAttribute("href",oldTheme+newTheme+".css");
			config.theme=newTheme;
		}
		if(config.layout != newLayout){
			layoutCss.setAttribute("href",oldLayout+newLayout+".css");
			config.layout=newLayout;
			if(newLayout == "medium"){
				FQD.canvas.setZoom(0.4);
				jQuery("#right-bar, #enter-text, #bg-properties").removeAttr("style");
			}else{
				FQD.canvas.setZoom(1);
			}
		}
}

fabric.Textbox.prototype._wrapLine = function(ctx, text, lineIndex) {
	var lineWidth        = 0,
	    lines            = [],
	    line             = '',
	    words            = text.split(' '),
	    word             = '',
	    letter           = '',
	    offset           = 0,
	    infix            = ' ',
	    infix1            = '',
	    wordWidth        = 0,
	    infixWidth       = 0,
	    letterWidth      = 0,
	    largestWordWidth = 0;

	for (var i = 0; i < words.length; i++) {
	    word = words[i];
	    wordWidth = this._measureText(ctx, word, lineIndex, offset);
	    lineWidth += infixWidth;

	    // Break Words if wordWidth is greater than textbox width
	    if (this.breakWords && wordWidth > this.width) {
	        line += infix1;
	        var wordLetters = word.split('');
	        while (wordLetters.length) {
	            letterWidth = this._getWidthOfChar(ctx, wordLetters[0], lineIndex, offset);
	            if (lineWidth + letterWidth > this.width) {
	                lines.push(line);
	                line = '';
	                lineWidth = 0;
	            }
	            line += wordLetters.shift();
	            offset++;
	            lineWidth += letterWidth;
	        }
	        word = '';
	    } else {
	        lineWidth += wordWidth;
	    }

	    if (lineWidth >= this.width && line !== '') {
	        lines.push(line);
	        line = '';
	        lineWidth = wordWidth;
	    }

	    if (line !== '' || i === 1) {
	        line += infix;
	    }
	    line += word;
	    offset += word.length;
	    infixWidth = this._measureText(ctx, infix, lineIndex, offset);
	    offset++;

	    // keep track of largest word
	    if (wordWidth > largestWordWidth && !this.breakWords) {
	        largestWordWidth = wordWidth;
	    }
	}

	i && lines.push(line);

	if (largestWordWidth > this.dynamicMinWidth) {
	        this.dynamicMinWidth = largestWordWidth;
	    }

	    return lines;
	};
// to get minimum and maximum value of an Array
Array.prototype.max = function() {
	  return Math.max.apply(null, this);
	};

Array.prototype.min = function() {
	  return Math.min.apply(null, this);
	};
	
function serializeXMLNode(xmlNode) {
	    if (typeof window.XMLSerializer != "undefined") {
	        return (new window.XMLSerializer()).serializeToString(xmlNode);
	    } else if (typeof xmlNode.xml != "undefined") {
	        return xmlNode.xml;
	    }
	    return "";
	}
function getScript(src){
		var script = document.createElement( "script" );
		script.type = "text/javascript";
		script.src = staticContentBaseUrl+src;
		jQuery("body").append(script);
	}
function getCursorPos(input) {
    if ("selectionStart" in input && document.activeElement == input) {
        return {
            start: input.selectionStart,
            end: input.selectionEnd
        };
    }
    else if (input.createTextRange) {
        var sel = document.selection.createRange();
        if (sel.parentElement() === input) {
            var rng = input.createTextRange();
            rng.moveToBookmark(sel.getBookmark());
            for (var len = 0;
                     rng.compareEndPoints("EndToStart", rng) > 0;
                     rng.moveEnd("character", -1)) {
                len++;
            }
            rng.setEndPoint("StartToStart", input.createTextRange());
            for (var pos = { start: 0, end: len };
                     rng.compareEndPoints("EndToStart", rng) > 0;
                     rng.moveEnd("character", -1)) {
                pos.start++;
                pos.end++;
            }
            return pos;
        }
    }
    return -1;
}
function setCursorPos(input, start, end) {
    if (arguments.length < 3) end = start;
    if ("selectionStart" in input) {
        setTimeout(function() {
            input.selectionStart = start;
            input.selectionEnd = end;
        }, 1);
    }
    else if (input.createTextRange) {
        var rng = input.createTextRange();
        rng.moveStart("character", start);
        rng.collapse();
        rng.moveEnd("character", end - start);
        rng.select();
    }
}
function setTextAreaCursor(textarea){
	var is_chrome = /chrome/.test( navigator.userAgent.toLowerCase() );
	if(is_chrome){
		window.setTimeout(function() {
			setCursorAtTheEnd(textarea);
	    }, 1);
	}else{
		setCursorAtTheEnd(textarea);
	}
}
function setCursorAtTheEnd(el,aEvent) {
	if (typeof el.selectionStart == "number") {
        el.selectionStart = el.selectionEnd = el.value.length;
    } else if (typeof el.createTextRange != "undefined") {
        el.focus();
        var range = el.createTextRange();
        range.collapse(false);
        range.select();
    }
}
FQD.setCanvasArea=function(canvas){
	canvas.backgroundColor="transparent";
	var productWidth=Math.floor(config.canvasWidth),
		productHeight=Math.floor(config.canvasHeight),
		cw=canvas.width,
		ch=canvas.height;
	
	var canvasArea = new fabric.Rect({
        left:0,
        top: 0,
        width: productWidth,
        height: productHeight,
        fill: '#ffffff',
        strokeWidth: FQD.products.hasTemplateOverlay()? 0.5: 0,
        stroke: "#000000",
        selectable: false,
        evented : false,
        alwaysNotselectable:true,
        objectCaching: false,
        id:"canvasArea",
        name:"canvasArea"
    });
    canvas.centerObject(canvasArea);
	canvas.add(canvasArea);
	canvasArea.sendToBack();
	canvas.renderAll();
	config.canvasOrigin={
		x0:roundTo(canvasArea.getLeft(), 2),
		y0:roundTo(canvasArea.getTop(), 2),
		x1:canvasArea.getLeft()+canvasArea.getWidth(),
		y1:canvasArea.getTop()+canvasArea.getHeight(),
		width:canvasArea.getWidth(),
		height:canvasArea.getHeight()
	 }
	FQD.drawOverlay(canvas);
}


FQD.drawOverlay=function(canvas){
	var productWidth=config.canvasWidth,
	productHeight=config.canvasHeight,
	cw=canvas.width,
	ch=canvas.height,
	overlayColor=config.overlayBgColor,
	canvasOrigin=config.canvasOrigin;
	var overlayStrokeWidth=1.8;
	if(config.overlayOpacity != 1){
		overlayStrokeWidth = 0.05;
	}
	
	var topOverlay = new fabric.Rect({
        originX: 'left',
        originY: 'top',
        left: -cw*50,
        top: -cw*100,
        width: cw*100,
        height: (canvasOrigin.y0)+cw*100,
        fill: overlayColor, 
        strokeWidth: overlayStrokeWidth,
        selectable: false,
        objectCaching:false,
        evented : false,
        stroke:overlayColor,
        excludeFromExport:true,
        opacity:config.overlayOpacity,
        id:"removeFromPreview",
        alwaysNotselectable:true,
        topOverlay:"topOverlay",
        name:"overlayElm"
    });
	var rightOverlay = new fabric.Rect({
        originX: 'left',
        originY: 'top',
        left: canvasOrigin.x0+canvasOrigin.width,
        top: canvasOrigin.y0-0.1,
        width: cw*100,
        height:canvasOrigin.height+0.15,
        fill: overlayColor, 
        strokeWidth: overlayStrokeWidth,
        stroke:overlayColor,
        selectable: false,
        objectCaching:false,
        evented : false,
        opacity:config.overlayOpacity,
        id:"removeFromPreview",
        excludeFromExport:true,
        alwaysNotselectable:true,
        rightOverlay:"rightOverlay",
        name:"overlayElm"
    });
	var leftOverlayRect = new fabric.Rect({
        originX: 'left',
        originY: 'top',
        left: -cw*100,
        top: canvasOrigin.y0-0.1,
        width: canvasOrigin.x0+cw*100,
        height:canvasOrigin.height+0.15,
        fill: overlayColor, 
        strokeWidth: overlayStrokeWidth,
        stroke:overlayColor,
        selectable: false,
        objectCaching:false,
        evented : false,
        opacity:config.overlayOpacity,
        id:"removeFromPreview",
        excludeFromExport:true,
        alwaysNotselectable:true,
        leftOverlayRect:"leftOverlayRect",
        name:"overlayElm"
    });
	var bottomOverlayRect = new fabric.Rect({
    	originX: 'left',
        originY: 'top',
        left: -cw*50,
        top: ch-canvasOrigin.y0,
        width: cw*100,
        height: (canvasOrigin.y0)+cw*100,
        fill: overlayColor, 
        strokeWidth: overlayStrokeWidth,
        stroke:overlayColor,
        selectable: false,
        evented : false,
        objectCaching:false,
        opacity:config.overlayOpacity,
        id:"removeFromPreview",
        excludeFromExport:true,
        alwaysNotselectable:true,
        bottomOverlayRect:"bottomOverlayRect",
        name:"overlayElm"
    });
	
    canvas.add(topOverlay);
    canvas.add(rightOverlay);
    canvas.add(leftOverlayRect);
    canvas.add(bottomOverlayRect);
    topOverlay.bringToFront();
    rightOverlay.bringToFront();
    leftOverlayRect.bringToFront();
    bottomOverlayRect.bringToFront();
    canvas.renderAll();
}

FQD.allOverlayOnTop=function(){
	FQD.canvas.pages.forEach(function(canvas){
		var items =canvas.getItemsByName("overlayElm"); 
		items.forEach(function(obj){
			obj.bringToFront();
		});
		
		var grids = canvas.getItemsByName("grid"); 
		grids.forEach(function(obj){
			obj.bringToFront();
		});
		
		var bgMask=canvas.getItemByName("bgMask");
		if(bgMask){
			bgMask.sendToBack();
		}
		
		var bgImage=canvas.getItemByName("bgElement");
		if(bgImage){
			bgImage.sendToBack();
		}
		
		var canArea=canvas.getItemByName("canvasArea");
		if(canArea){
			canArea.sendToBack();
		}
		canvas.renderAll();
	});
}


FQD.removeOverlay=function(canvas,removeBg){
	var items =canvas.getItemsByName("overlayElm"); 
	items.forEach(function(obj){
		obj.remove();
	});
	
	var bgMask=canvas.getItemByName("bgMask");
	if(bgMask){
		bgMask.remove();
	}
	
	if(removeBg !=false){
		var bgImage=canvas.getItemByName("bgElement");
		if(bgImage){
			bgImage.remove();
		}
	}
	
	var canArea=canvas.getItemByName("canvasArea");
	if(canArea){
		canArea.remove();
	}
}


FQD.excludeFromExport=function(name,boolean){
	var canvas=FQD.canvas.pages[config.activeCanvas];
	if(canvas){
		var items = canvas.getItemsByName(name); 
		items.forEach(function(obj){
			obj.excludeFromExport=boolean;
	 });
	}
	
}

FQD.previewMode=function(elm){
	var mode=elm.checked;
	FQD.canvas.pages.forEach(function(canvas){
		var items =canvas.getItemsByName("overlayElm"); 
		items.forEach(function(obj){
			if(!obj.trimZone && !obj.safeZone){
				if(mode){
					config.overlayOpacity=1;
					jQuery(elm).parent().attr("title","Show Overflow");
					jQuery("p.tooltip").text("Show Overflow");
					obj.setOpacity(1);
					jQuery(".switch-button-button").addClass("switch-checked-button");
					obj.setStrokeWidth(1.8);
				}
				else{
					config.overlayOpacity=0.4;
					jQuery(elm).parent().attr("title",resourcesData.hideOverFlow);
					jQuery("p.tooltip").text(resourcesData.hideOverFlow)
					obj.setOpacity(0.4);
					jQuery(".switch-button-button").removeClass("switch-checked-button");
					obj.setStrokeWidth(0.05);
				}
			}
		});
		
		for(var i = 0; i < FQD.canvas.noPrintElms.length; i++){
			FQD.canvas.noPrintElms[i].opacity = config.overlayOpacity;
		}
		
		canvas.renderAll();
	});
}

FQD.setCanvasAreaBackgroundColor=function(canvas,color){
	canvas.getItemByName("canvasArea").setFill(color);
	canvas.renderAll();
}


FQD.initializecanvas={
		createSVGOverlay:function(canvas){
			if(FQD.products.hasTemplateOverlay())
			{
				var canvasId = parseInt((canvas.lowerCanvasEl.id).toString().replace("c", ""));
				var svgPath = config.resourcePath+'images/svg/'+ FQD.products.getTemplateOverlayPath(canvasId+1) +'.svg';
				var group = [];
				var partsArr = [];
				
				FQD.canvas.overlayScaleX = config.canvasWidth/(config.canvasOriginalWidth/(config.productDetails.dpi/72));
				FQD.canvas.overlayScaleY = config.canvasHeight/(config.canvasOriginalHeight/(config.productDetails.dpi/72));
				
				fabric.loadSVGFromURL(svgPath, 
						function(objects, options)
						{
							loadedObjects = new fabric.Group(group);
							loadedObjects.set({
												left: 0,
												top: 0,
												scaleX:config.canvasWidth/(config.canvasOriginalWidth/(config.productDetails.dpi/72)),
												scaleY:config.canvasHeight/(config.canvasOriginalHeight/(config.productDetails.dpi/72)),
												id:"removeFromPreview",
												name:"svgOverlay",
												selectable: false,
												objectCaching:false,
												excludeFromExport:true,
												evented : false,	
												alwaysNotselectable:true
											 });
							canvas.centerObject(loadedObjects);
							FQD.canvas.svgOverlayElms[canvasId] = loadedObjects;
							
							if(FQD.PrintProductType.isEventTicket())
								FQD.initializecanvas.setEventTicketOptios();
							
							if(FQD.PrintProductType.isFolder())
								FQD.initializecanvas.setSlitsOptions();
							
							canvas.setOverlayImage(loadedObjects,
									function()
									{
										canvas.renderAll.bind(canvas);
										config.svgOverCount -= 1;
										if(config.svgOverCount == 0){
											FQD.visualAids.applyChangedSetting();
											if(config.hasReloadData)
												FQD.utility.reloadRefreshData();
										}
											
									});
							canvas.renderAll();
						},
						
						function(item, object){
							group.push(object);
							partsArr[object.id] = object
							FQD.canvas.svgOverlayElmParts[canvasId] = partsArr;
							var id = object.id;
							if(id.toLowerCase() == "outeroverlay"){
								object.fill = config.overlayBgColor;
								object.stroke = "#000000";
								object.opacity = config.overlayOpacity;
								FQD.canvas.noPrintElms.push(object);
							}
							else if(id.toLowerCase() == "bgmask"){
								object.fill = config.overlayBgColor;
								object.opacity = 1;
								FQD.initializecanvas.addBackgroundMask(canvas, object);
								group.pop();
							}else if(id.toLowerCase() == "safe"){
								object.visible = $('#btnSafe').prop('checked');
								object.visible = object.visible == undefined? true: object.visible;
							}
							else if(id.toLowerCase() == "trim"){
								object.visible = $('#btnTrim').prop('checked');
								object.visible = object.visible == undefined? true: object.visible;
							}
							
						});
				
			}
		},
		
		resetSVGOverlay:function(canvas){
			if(!FQD.products.hasTemplateOverlay())
				return;
			
			var canvasId = parseInt((canvas.lowerCanvasEl.id).toString().replace("c", ""));
			canvas.setOverlayImage(FQD.canvas.svgOverlayElms[canvasId], canvas.renderAll.bind(canvas));
			canvas.renderAll();
			
			//Check for Background Mask
			var partsArr = FQD.canvas.svgOverlayElmParts[canvasId];
			if(partsArr != undefined && partsArr["BGMask"] != undefined)
				FQD.initializecanvas.addBackgroundMask(canvas, partsArr["BGMask"]);
		},
		
		addBackgroundMask:function(canvas, bgmask){
			bgmask.id = "removeFromPreview";
			bgmask.name = "bgMask";
			bgmask.scaleX = FQD.canvas.overlayScaleX;
			bgmask.scaleY = FQD.canvas.overlayScaleY;
			bgmask.left = 0;
			bgmask.top = 0;
			bgmask.stroke = "#000000";
			bgmask.selectable = false;
			bgmask.objectCaching = false;
			bgmask.excludeFromExport = true;
			bgmask.evented = false;
			bgmask.alwaysNotselectable = true;
			
			canvas.add(bgmask);
			canvas.centerObject(bgmask);
			canvas.renderAll();
			
			FQD.allOverlayOnTop();
			canvas.renderAll();
		},
		
		drawBleedSafeZone:function(canvas)
		{
			if(!FQD.products.hasTemplateOverlay())
			{
				var zoneGap = FQD.canvas.getCanvasZonesGap(0);
				
				var bleed_L = zoneGap.bleedZone.bleedLeft;
				var bleed_B = zoneGap.bleedZone.bleedBottom;
				var bleed_R = zoneGap.bleedZone.bleedRight;
				var bleed_T = zoneGap.bleedZone.bleedTop;
				
				var safe_L = zoneGap.safeZone.safeLeft;
				var safe_B = zoneGap.safeZone.safeBottom;
				var safe_R = zoneGap.safeZone.safeRight;
				var safe_T = zoneGap.safeZone.safeTop;
				
				//FIND TRIM ZONE RADIUS FOR ROUND CORNER OPTION
		    	var radius = szRadius = 0; 
		    	if(config.isPageRoundCorner == "true")
		    	{
				    config.isPageRoundCorner = "true";
					var roundCorner;
					if(config.productDetails.trimZoneCornerRadius != undefined && config.productDetails.trimZoneCornerRadius > 0){
						roundCorner = config.productDetails.trimZoneCornerRadius;
						roundCorner += (roundCorner/2);
					}else if(config.productDetails.radius == 0){
						roundCorner = config.productDetails.cornerRadius;
					}else{
						roundCorner = config.productDetails.radius;
					}
					
					radius = parseInt(roundCorner)*(350/72)+"";
					radius = radius*config.objScaleWidthMultiplier;
					
					if(config.productDetails.safeZoneCornerRadius != undefined && config.productDetails.safeZoneCornerRadius > 0){
						szRadius = config.productDetails.safeZoneCornerRadius;
						szRadius += (szRadius/2);
					}else {
						szRadius = 0;
					}
					
					szRadius = parseInt(szRadius)*(350/72)+"";
					szRadius = szRadius*config.objScaleWidthMultiplier;
		    	}
		    	
				var trimZone = new fabric.Rect({
			        originX: 'left',
			        originY: 'top',
			        left: config.canvasOrigin.x0+bleed_L,
			        top: config.canvasOrigin.y0+bleed_T,
			        width: config.canvasWidth -(bleed_L + bleed_R),
			        height: config.canvasHeight -(bleed_T + bleed_B),
			        fill: 'transparent', 
			        strokeWidth: 1,
			        stroke:"#DC007E",
			        rx: radius,
			        ry: radius,
			        trimZone:"bleedZone",
			        id:"removeFromPreview",
			        selectable: false,
			        objectCaching:false,
			        excludeFromExport:true,
			        evented : false,
			        alwaysNotselectable:true,
			        name:"overlayElm"
			    });
				
				var safeZone = new fabric.Rect({
			        originX: 'left',
			        originY: 'top',
			        left: config.canvasOrigin.x0+safe_L,
			        top: config.canvasOrigin.y0+safe_T,
			        width: config.canvasWidth-(safe_L + safe_R),
			        height:config.canvasHeight-(safe_T + safe_B),
			        fill: 'transparent', 
			        strokeWidth: 1,
			        stroke:"#37A0E7",
			        safeZone:"safeZone",
			        id:"removeFromPreview",
			        rx: szRadius,
			        ry: szRadius,
			        selectable: false,
			        objectCaching:false,
			        excludeFromExport:true,
			        evented : false,
			        alwaysNotselectable:true,
			        name:"overlayElm"
			    });
			    
	
		    	canvas.add(trimZone);
		    	canvas.add(safeZone);
		    	trimZone.bringToFront();
		    	safeZone.bringToFront();
		    	canvas.renderAll();

			}

			if(config.holeOptionId > 0){
				FQD.initializecanvas.drawHole(canvas);
			}
			
			if(config.foldingId > 0){
				FQD.initializecanvas.drawFoldLine(canvas);
			}
			
			if(FQD.utility.getParameter("debug") != 1 || !isTestingOrStaging){
				FQD.elements.divAdminTools.remove();
			}
			if(config.isWindowResized || config.changeCornerOption || config.changePageOption){
				FQD.visualAids.addScissors(false);
				FQD.visualAids.addScissors($('#visualAids').prop('checked'));
				setTimeout(function(){ 
					config.isWindowResized=false;
					config.changeCornerOption=false;
					config.changePageOption=false;
				}, 500);

			}
		},
		
		removeTrimSafeZone:function(){
			jQuery(".trimZone, .safeZone").remove();
		},
		
		drawHole:function(canvas)
		{
			var holeW = FQD.canvas.holeSize;
			var holeH = FQD.canvas.holeSize;
			
			//Draw Hole
		    var hole = new fabric.Circle({originX: 'left', originY: 'top',
										  left: config.canvasOrigin.x0,
										  top: config.canvasOrigin.y0,				
										  radius: holeW/2 * config.scaleMultiplier,
										  strokeWidth:0,
										  fill : "#FF0000",
										  hole:"hole",
										  name:"overlayElm",
									      id:"removeFromPreview",
									      rx: 0, ry: 0,
									      selectable: false, 
									      objectCaching: false, 
									      excludeFromExport: true, 
									      evented: false,
									      alwaysNotselectable:true
										});
		    
		    canvas.add(hole);
		    hole.bringToFront();
	    	canvas.renderAll();
	    	
	    	if(FQD.PrintProductType.isFoldedHangTag()){
	    		//Draw folded page Hole
			    hole = new fabric.Circle({originX: 'left', originY: 'top',
											  left: config.canvasOrigin.x0,
											  top: config.canvasOrigin.y0,				
											  radius: holeW/2 * config.scaleMultiplier,
											  strokeWidth:0,
											  fill : "#FF0000",
											  foldpagehole:"foldpagehole",
											  name:"overlayElm",
										      id:"removeFromPreview",
										      rx: 0, ry: 0,
										      selectable: false, 
										      objectCaching: false, 
										      excludeFromExport: true, 
										      evented: false,
										      alwaysNotselectable:true
											});
			    
			    canvas.add(hole);
			    hole.bringToFront();
		    	canvas.renderAll();
	    	}
	    	
	    	FQD.canvas.changeHolePosition();
		},
		
		drawFoldLine:function(canvas)
		{
			var lines = [];
			var canvasId = parseInt((canvas.lowerCanvasEl.id).toString().replace("c", ""));
			var absFolding = 0;
			var isVerticalFold = false;  
			var isBack = canvasId == 0? false: true;
			var startX, startY, endX, endY =  0;
			var foldBuffer = 27 * config.scaleMultiplier;
			
			for(var i = 0; i < config.productDetails.foldingOptions.length; i++){
				if(config.productDetails.foldingOptions[i].id == config.foldingId){
					lines = config.productDetails.foldingOptions[i].lines;
					break;
				}
			}
			
			for(i = 0; i < lines.length; i++){
				isVerticalFold = (lines[i].orientation == FQD.PrintProductType.VERTICAL)? true: false;
				
				if(isBack && !isVerticalFold)
					absFolding = Math.abs(((lines[i].position + config.bleedMargin.bleedLeft)*config.scaleMultiplier) - config.canvasWidth);
				else
					absFolding = (lines[i].position + config.bleedMargin.bleedLeft)*config.scaleMultiplier;
				
				if(isVerticalFold){
					startX = config.canvasOrigin.x0;
					startY = config.canvasOrigin.y0 + absFolding; 
					endX = config.canvasOrigin.x0 + config.canvasWidth;
					endY = startY;
				}
				else{
					startX = config.canvasOrigin.x0 + absFolding; 
					startY = config.canvasOrigin.y0;
					endX = startX;
					endY =  config.canvasOrigin.y0 + config.canvasHeight;
				}
				
				var points = [startX, startY, endX, endY];
				var line = new fabric.Line(points, 
						{originX: 'left', originY: 'top',
						 strokeWidth : 1,
						 stroke : "#7F7F7F",
						 foldline:"foldline",
						 name:"overlayElm",
						 selectable: false, 
					     objectCaching: false, 
					     excludeFromExport: true, 
					     evented: false,
					     alwaysNotselectable:true
				});
				canvas.add(line);
				
				if(config.productDetails.foldLineGutter != undefined){
					if(isVerticalFold)
						points = [startX, startY-foldBuffer, endX, endY-foldBuffer];
					else
						points = [startX-foldBuffer, startY, endX-foldBuffer, endY];
					
					var dashline = new fabric.Line(points, 
							{originX: 'left', originY: 'top',
							 strokeWidth : 0.5,
							 stroke : "#006699",
							 foldline:"foldDashline",
							 name:"overlayElm",
							 id:"removeFromPreview",
							 strokeDashArray: [5, 5],
							 selectable: false, 
						     objectCaching: false, 
						     excludeFromExport: true, 
						     evented: false,
						     alwaysNotselectable:true
					});
					canvas.add(dashline);
					
					if(isVerticalFold)
						points = [startX, startY+foldBuffer, endX, endY+foldBuffer];
					else
						points = [startX+foldBuffer, startY, endX+foldBuffer, endY];
					
					dashline = new fabric.Line(points, 
							{originX: 'left', originY: 'top',
							 strokeWidth : 0.5,
							 stroke : "#006699",
							 foldline:"foldDashline",
							 name:"overlayElm",
							 id:"removeFromPreview",
							 strokeDashArray: [5, 5],
							 selectable: false, 
						     objectCaching: false, 
						     excludeFromExport: true, 
						     evented: false,
						     alwaysNotselectable:true
					});
					canvas.add(dashline);
				}
			}
		},
		
		setSlitsOptions:function(){
			var i = 0;
			while(i < 2){
				if(FQD.canvas.svgOverlayElmParts[i] != undefined){
					if(FQD.canvas.svgOverlayElmParts[i]["slit_right"] != undefined)
						FQD.canvas.svgOverlayElmParts[i]["slit_right"].opacity = (config.slitId == FQD.PrintProductType.SLIT_BOTH_SIDES || config.slitId == FQD.PrintProductType.SLIT_RIGHT_SIDE)? 1: 0;
					
					if(FQD.canvas.svgOverlayElmParts[i]["slit_left"] != undefined)
						FQD.canvas.svgOverlayElmParts[i]["slit_left"].opacity = (config.slitId == FQD.PrintProductType.SLIT_BOTH_SIDES || config.slitId == FQD.PrintProductType.SLIT_LEFT_SIDE)? 1: 0;;
				}
				i++;
			}
		},
		
		setEventTicketOptios:function(){
			if(config.perforationAndNumberingId == FQD.PrintProductType.PERFORATION_ONLY){
				var i = 0;
				while(i < 2){
					if(FQD.canvas.svgOverlayElmParts[i] != undefined){
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftTop"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftCenter"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftBottom"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintTop"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintCenter"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintBottom"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["PerforatLine"].opacity = 1;
					}
					i++;
				}
			}
			else if(config.perforationAndNumberingId == FQD.PrintProductType.PERFORATION_AND_NUMBERING_FRONT_ONLY){
				var i = 0;
				while(i < 2){
					if(FQD.canvas.svgOverlayElmParts[i] != undefined){
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftTop"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_TOP? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftCenter"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_CENTER? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftBottom"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_BOTTOM? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintTop"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_TOP? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintCenter"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_CENTER? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintBottom"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_BOTTOM? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["PerforatLine"].opacity = 1;
					}
					i++;
				}
			}
			else if(config.perforationAndNumberingId == FQD.PrintProductType.PERFORATION_AND_NUMBERING_BACK_ONLY){
				var i = 0;
				while(i < 2){
					if(FQD.canvas.svgOverlayElmParts[i] != undefined){
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftTop"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_TOP? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftCenter"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_CENTER? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftBottom"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_BOTTOM? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintTop"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_TOP? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintCenter"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_CENTER? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintBottom"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_BOTTOM? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["PerforatLine"].opacity = 1;
					}
					i++;
				}
			}
			else if(config.perforationAndNumberingId == FQD.PrintProductType.NUMBERING_FRONT_ONLY){
				var i = 0;
				while(i < 2){
					if(FQD.canvas.svgOverlayElmParts[i] != undefined){
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftTop"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftCenter"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftBottom"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintTop"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_TOP? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintCenter"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_CENTER? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintBottom"].opacity = (i == 0? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_BOTTOM? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["PerforatLine"].opacity = 0;
					}
					i++;
				}
			}
			else if(config.perforationAndNumberingId == FQD.PrintProductType.NUMBERING_BACK_ONLY){
				var i = 0;
				while(i < 2){
					if(FQD.canvas.svgOverlayElmParts[i] != undefined){
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftTop"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftCenter"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintLeftBottom"].opacity = 0;
						FQD.canvas.svgOverlayElmParts[i]["noPrintTop"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_TOP? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintCenter"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_CENTER? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["noPrintBottom"].opacity = (i == 1? (config.numberingPositionId == FQD.PrintProductType.NUMBERING_POSITION_BOTTOM? 1: 0): 0);
						FQD.canvas.svgOverlayElmParts[i]["PerforatLine"].opacity = 0;
					}
					i++;
				}
			}
		},
		
		disableInputs:function(){
			FQD.elements.objectAngle.attr("disabled","disabled");
			FQD.elements.objectXpos.attr("disabled","disabled");
			FQD.elements.objectYpos.attr("disabled","disabled");
			FQD.elements.objectWidth.attr("disabled","disabled");
			FQD.elements.objectHeight.attr("disabled","disabled");
			jQuery("#applyobj, #constrainBtn").addClass("disabled");
		},
	}