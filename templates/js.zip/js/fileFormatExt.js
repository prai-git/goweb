var allowedPrintMimeTypes  = ["image/png", "image/tiff", "image/jpeg", "image/gif", "image/x-ms-bmp", "application/pdf", "application/postscript", "image/vnd.adobe.photoshop"];
var allowedMimeTypes = ["application/msword", "application/msword", "image/png", "image/tiff", "image/jpeg", "image/gif", "image/x-ms-bmp", "application/pdf", "application/postscript", "application/postscript", "image/vnd.adobe.photoshop", "image/svg+xml", "text/plain", "application/xml", "application/octet-stream", "application/x-zip", "application/x-gzip", "application/x-7z-compressed", "application/x-tar",  "application/x-rar-compressed"];
var allowedFileExtentions = ['jpg', 'jpeg', 'eps', 'png', 'tif', 'tiff','ai','psd','pdf','doc','docx','zip','ppt','pptx','rar','gz','tar','7z','gif','bmp','gzip'];
var allowedPrintFileExtentions = ['jpg', 'jpeg', 'eps', 'png', 'tif', 'tiff','ai','psd','pdf','gif','bmp'];

var printFileExtentions = ['.jpg', '.jpeg', '.eps', '.png', '.tif', '.tiff','.ai','.psd','.gif','.bmp', '.pdf'];
var allSupportedFileExtentions = ['.jpg', '.jpeg', '.eps', '.png', '.tif', '.tiff','.ai','.psd','.pdf','.doc','.docx','.zip','.ppt','.pptx','.rar','.gz','.tar','.7z','.gif','.bmp','.gzip'];

function hasValidPrintFileExtention(file){
	return validateFileExtention(file, allowedPrintFileExtentions)
}


function hasValidFileExtention(file,  isPrintable){
	if(isPrintable == true){
		return validateFileExtention(file, allowedPrintFileExtentions);
	}
	
	return validateFileExtention(file, allowedFileExtentions);
	
}


function hasValidPrintMimeType(file){
	return validateMimeType(file, allowedPrintMimeTypes);
}


function hasValidMimeType(file){
	return validateMimeType(file, allowedMimeTypes);
}


function validateFileExtention(file, list){
	
	var ext = file.name.substr(file.name.lastIndexOf('.')+1);
 	ext=ext.toLowerCase();
 	
 	if (list.indexOf(ext) >= 0) {
		return true
	 }
 	
 	
 	return false;
}


function validateMimeType(file, list){
	
	if ( window.FileReader && window.File && window.FileList && window.Blob )
	{
		if (list.indexOf(file.type) < 0) {
			return true; 
		 } 
	} 
	
	// this is returning true in all case. Currently browser does not support mimetype.
	return true;
}

