/********************************************************************
 * 
 * templateLoaderCallback is the function which can be used intimate when template is loaded.
 * 
 * 
 ********************************************************************/
FQD.templateDataTransfer={
		nonTextElm:[[],[]],
		textElm:[[],[]],
		templateLoaderCallback:function(){
			 var id=setInterval(function(){
				 var isLoaded=FQD.templateDataTransfer.isTemplateLoaded();
				 if(isLoaded){
					 clearInterval(id);
				 }
				 
			 }, 10);
		},
	   isTemplateLoaded:function(){
		   var isLoaded=false;

			    if(config.isProcessCompleted){
			    	isLoaded=true;
			    }

		   return isLoaded;
	   },
	   elementsCountInTemplate:function(jsonData,pageNo){
		   if (jsonData.pages == 'undefined' || jsonData.length > 0) {
			    for(var i=0;i<jsonData.length;i++){
			    	var count=0;
			    	var json=JSON.parse(jsonData[i]);
			    	if(json.objects){
					    count= json.objects.length;
			    	}
				    if(json.backgroundImage){
				    	count++;
				    }
				    
				    config.templateJsonElementsCount[i]=count;
			    }
			    
		   }
		   if(pageNo){
			   return config.templateJsonElementsCount[pageNo-1];
		   }else{
			   if(FQD.canvas.pages.length==1){
				   return config.templateJsonElementsCount[0];
			   }else{
				   return (config.templateJsonElementsCount[0]+config.templateJsonElementsCount[1]);
			   }
		   }
		
	   },
	   elementsCountForActivePage:function(jsonData){
		   if (jsonData) {
			   var count=0;
			   var json=JSON.parse(jsonData);
			   if(json.objects){
				    count= json.objects.length;
		    	}
			   if(json.backgroundImage){
			    	count++;
			    }
			   
			   }
		   
		   return count;
	
		
	   },
	   transferTextOnly:function(withFont){
		   FQD.templateDataTransfer.getTemplateJSONData(FQD.templateDataTransfer.templateId);
		   var id=setInterval(function(){
				 var isLoaded=FQD.templateDataTransfer.isTemplateLoaded();
				 if(isLoaded){
					 clearInterval(id);
					 FQD.templateDataTransfer.transferChanges("text",withFont);
				 }
				 
			 }, 10);
	   },

		transferCompleteDataWithBinding:function(withFont){
			 FQD.templateDataTransfer.getTemplateJSONData(FQD.templateDataTransfer.templateId);
			 var id=setInterval(function(){
				 var isLoaded=FQD.templateDataTransfer.isTemplateLoaded();
				 
				 if(isLoaded){
					 clearInterval(id);
					 FQD.templateDataTransfer.transferChangesWithBinding(withFont);
				 }
				 
			 }, 10);
		},
		transferWithoutTextElement:function(){
			 FQD.templateDataTransfer.getTemplateJSONData(FQD.templateDataTransfer.templateId);
			 var id=setInterval(function(){
				 var isLoaded=FQD.templateDataTransfer.isTemplateLoaded();
				 
				 if(isLoaded){
					 clearInterval(id);
					 for(var i=0;i<FQD.canvas.pages.length;i++)
						{
							 for(var j=0;j<FQD.templateDataTransfer.nonTextElm[i].length;j++){
								 	if(FQD.templateDataTransfer.nonTextElm[i][j].isModified){
								 		 FQD.canvas.pages[i].add(FQD.templateDataTransfer.nonTextElm[i][j]);	
								 	}
							    }	

						}
					
					 config.isProcessCompleted=false;
				 }
				 
			 }, 10);
		},
		transferChangesWithBinding:function(withFont){

			
			for(var i=0;i<FQD.canvas.pages.length;i++)
			{
			  
				
				 for(var j=0;j<FQD.templateDataTransfer.nonTextElm[i].length;j++){
					 	if(FQD.templateDataTransfer.nonTextElm[i][j].isModified){
					 		 FQD.canvas.pages[i].add(FQD.templateDataTransfer.nonTextElm[i][j]);	
					 	}
					 
				 }
			}
			
			 FQD.templateDataTransfer.transferChanges("text",withFont);
			
	},
		canvasElementsChanged:function(templateApplyOnActivePage){
			var isCanvasChanged=false;
			FQD.templateDataTransfer.pages=[[],[]];
			FQD.templateDataTransfer.textElm=[[],[]];
			FQD.templateDataTransfer.nonTextElm=[[],[]];
			
			

				for(var i=0;i<FQD.canvas.pages.length;i++){
					var objs=FQD.canvas.pages[i].getObjects();
					for(var j=0;j<objs.length;j++){
						if(!objs[j].name){
							if(objs[j].isModified){
								isCanvasChanged=true;
							}
							if(objs[j].type=="textbox"){
							 FQD.templateDataTransfer.textElm[i].push(objs[j]);
							}else{
								FQD.templateDataTransfer.nonTextElm[i].push(objs[j]);	
							}
						}
						
					}
				}
                if(templateApplyOnActivePage){
                	var objs=FQD.canvas.pages[config.activeCanvas].getObjects();
                	isCanvasChanged=false;
    				for(var j=0;j<objs.length;j++){
    					if(!objs[j].name){
    						if(objs[j].isModified){
    							isCanvasChanged=true;
    						}
    						
    					}
    					
    				}
                }

			

			if(config.isAnyRecentTextElementDeleted){
				isCanvasChanged=true;
			}
			return isCanvasChanged;
			
		},
		close:function(){
			 if(config.transferTemplateDialog){
				 jQuery("#templateDataTransfer").dialog("close");
			}
		},
		getTemplateJSON:function(id,templateApplyOnActivePage,pageNo){
			config.isProcessCompleted=false;
			 
			 var isdataChanged=FQD.templateDataTransfer.canvasElementsChanged(templateApplyOnActivePage);
			 
			 if(config.templateOnActiveCanvas){
				 templateApplyOnActivePage= config.templateOnActiveCanvas.templateApplyOnActivePage;
				 pageNo= config.templateOnActiveCanvas.pageNo;
				 
			 }else{
				 config.templateOnActiveCanvas={};
				 config.templateOnActiveCanvas.templateApplyOnActivePage=templateApplyOnActivePage;
				 config.templateOnActiveCanvas.pageNo=pageNo;
				 
			 }

			 
			 if(isdataChanged){
				 FQD.templateDataTransfer.templateId=id;
				 if(config.transferTemplateDialog){
					 $("#templateDataTransfer").dialog({
							width : 700,
							height : 160,
							modal : true,
							resizable: false,
							dialogClass: "templateDataTransfer",
							closeOnEscape: config.autoSave? false: true,
							close : function() {
							}
					  });
					   $("#textContent").prop("checked",true);
					   $("#textFontStyling").prop("checked",false);
					   $("#restDesignElement").prop("checked",true);
					   $("#textFontStyling").prop("disabled",false);
				 }else{
					 FQD.templateDataTransfer.submit();
				 }
			 }else{
				 FQD.templateDataTransfer.getTemplateJSONData(id,templateApplyOnActivePage,pageNo);
				 
			 }
			FQD.canvas.setCanvasSelectionTrue();	
			
		},
		transferChanges:function(type,withFont){
		
			
			
			if(type=="text"){
				
					 
					for(var i=0;i<FQD.templateDataTransfer.textElm.length;i++){
						
						for(var j=0;j<FQD.templateDataTransfer.textElm[i].length;j++){
							 
							  if(FQD.templateDataTransfer.textElm[i][j].isModified){
								
								  for(var k=0;k<FQD.canvas.pages.length;k++){
								       
									  var elms=FQD.canvas.pages[k].getObjects();
									    
									   	for(var l=0;l<elms.length;l++){
									        
									   		 if(elms[l].type=="textbox"){
									   			var TgtPlaceHolder=elms[l].placeHolderContent.toLowerCase().replace(/ /g,"");
										   		var srcPlaceHolder=null;
										   		var srcOrgTemplate;
							                    if(FQD.templateDataTransfer.textElm[i][j].placeHolderContent){
								 			    	var srcPlaceHolder=FQD.templateDataTransfer.textElm[i][j].placeHolderContent.toLowerCase().replace(/ /g,"");
							                    }
							 			    	
							 			    	if((srcPlaceHolder==TgtPlaceHolder)){
	
							 			    			elms[l].text=FQD.templateDataTransfer.textElm[i][j].text;
							 			    			elms[l].isModified=true;
							 			    			FQD.templateDataTransfer.textElm[i][j].isUsed=true;
							 			    			if(withFont){
								 			    			elms[l].fontFamily=FQD.templateDataTransfer.textElm[i][j].fontFamily;
								 			    			elms[l].fontSize=FQD.templateDataTransfer.textElm[i][j].fontSize;
								 			    			elms[l].fontStyle=FQD.templateDataTransfer.textElm[i][j].fontStyle;
								 			    			elms[l].fontWeight=FQD.templateDataTransfer.textElm[i][j].fontWeight;
								 			    			elms[l].fill=FQD.templateDataTransfer.textElm[i][j].fill;
								 			    			elms[l].textDecoration=FQD.templateDataTransfer.textElm[i][j].textDecoration;
								 			    		}

							 			    		FQD.canvas.pages[k].renderAll();
							 			    	}
									   		 }
									   	
									    }
									    
									    
								  }
								   
							  }
							
						}
					}
					
					for(var i=0;i<FQD.canvas.pages.length;i++)
					{
					  for(var j=0;j<FQD.templateDataTransfer.textElm[i].length;j++){
						  
						  if(FQD.templateDataTransfer.textElm[i][j].isModified && !FQD.templateDataTransfer.textElm[i][j].isUsed){
			 			    	FQD.canvas.pages[i].add(FQD.templateDataTransfer.textElm[i][j]);
		                    }
					  }    		
	                    
					    FQD.canvas.pages[i].renderAll();
					   
					}
					 
					FQD.templateDataTransfer.removeDeletedElement();
				
			}else{
				
				for(var i=0;i<FQD.canvas.pages.length;i++)
				{
				  for(var j=0;j<FQD.templateDataTransfer.textElm[i].length;j++){
					  
					  if(FQD.templateDataTransfer.textElm[i][j].isModified){
					 		 FQD.canvas.pages[i].add(FQD.templateDataTransfer.textElm[i][j]);	
					 	}			    	
				    }    		
				
				if(type!="text"){
					 for(var j=0;j<FQD.templateDataTransfer.nonTextElm[i].length;j++){
						 
						 	if(FQD.templateDataTransfer.nonTextElm[i][j].isModified){
						 		 FQD.canvas.pages[i].add(FQD.templateDataTransfer.nonTextElm[i][j]);	
						 	}
						 
					    }	
		    	}
				 
					
				   
				}
			}
			
			FQD.templateDataTransfer.removeDeletedElement();
            delete config.isAnyRecentTextElementDeleted;
			config.isProcessCompleted=false;
			FQD.templateDataTransfer.close();
			
		},
		
		clearAndStartOver:function(){
			 FQD.templateDataTransfer.getTemplateJSONData(FQD.templateDataTransfer.templateId);
			 FQD.templateDataTransfer.close();
		},
		
	    getTemplateJSONData :function(id){
	    	if(id==undefined || id <=0) {
	    		alert(resourcesData.internalServerError);
	    		return;
	    	}
	    	 var templateApplyOnActivePage,pageNo;
	    	 if(config.templateOnActiveCanvas){
	    		 templateApplyOnActivePage= config.templateOnActiveCanvas.templateApplyOnActivePage;
	    		 pageNo= config.templateOnActiveCanvas.pageNo;
	    	 }
			 var timeout=5000;
			 FQD.message.hideWarning();
			 FQD.undoManager.loader=true;
			 FQD.elements.divLoadingQd.show();
		     FQD.elements.divLoaderContainer.show();
			 if(templateApplyOnActivePage){
				 config.templateApplyOnActivePage=templateApplyOnActivePage;
			 }
		     if(!config.templateApplyOnActivePage){
		    	 config.productDetails.printJob.designerTemplateId = config.productDetails.printJob.designerTemplate2Id = id; 
		     }else{
		    	 if(config.activeCanvas == 0)
		    		config.productDetails.printJob.designerTemplateId = id;
		    	 else
		    		 config.productDetails.printJob.designerTemplate2Id = id;
		     }
		     
		     jQuery.ajax({
				 	mimeType: 'text/plain; charset=x-user-defined',	
				 	url: FQD.imgLib.templateJsonUrl+id+"&cid="+config.cid,
					type:'GET',
					success: function(data){
						if(data.trim()==""){
				    		alert(resourcesData.internalServerError);
							FQD.elements.divLoadingQd.hide();
					    	FQD.elements.divLoaderContainer.hide();
				    		return;
						}
						data=decodeURIComponent(data);
						data=JSON.parse(data);
						config.isLoadTemplate="true";
						config.currentDPI=data.currentDPI;
						if(templateApplyOnActivePage){
							FQD.templateDataTransfer.importOnActivePage(data.convertedJSON,pageNo,parseInt(data.roundCornerValue.trim()));
						}else{
							FQD.importJson(data.convertedJSON,parseInt(data.roundCornerValue.trim()));
						}
						delete config.templateOnActiveCanvas;
						delete config.templateApplyOnActivePage;
				    	FQD.events.tabs(0);
					},
					error:function(){
			    		alert(resourcesData.internalServerError);
						FQD.elements.divLoadingQd.hide();
				    	FQD.elements.divLoaderContainer.hide();
				    	FQD.undoManager.loader=false;
					}
			});
	   },
	   submit:function(){
		   
		   var checkbox1= $("#textContent").prop("checked");
		   var checkbox2= $("#textFontStyling").prop("checked");
		   var checkbox3= $("#restDesignElement").prop("checked");
		   
		   if(checkbox1 && !checkbox2 && !checkbox3){
			   FQD.templateDataTransfer.transferTextOnly(false);
		   }
		   if(checkbox1 && checkbox2 && !checkbox3){
			   FQD.templateDataTransfer.transferTextOnly(true);
		   }
		   if(!checkbox1 && !checkbox2 && !checkbox3){
			   FQD.templateDataTransfer.clearAndStartOver();
		   }
		   if(checkbox1 && checkbox2 && checkbox3){
			   FQD.templateDataTransfer.transferCompleteDataWithBinding(true);
		   }
		   if(checkbox1 && !checkbox2 && checkbox3){
			   FQD.templateDataTransfer.transferCompleteDataWithBinding(false);
		   }
		   if(!checkbox1 && !checkbox2 && checkbox3){
			   FQD.templateDataTransfer.transferWithoutTextElement();
		   }
		   FQD.templateDataTransfer.close();
	   },
	   
	   handleChange:function(checkbox){
		   if(checkbox.id=="textContent"){
			   if(!checkbox.checked){
				   $("#textFontStyling").prop("checked",false);
				   $("#textFontStyling").prop("disabled",true);
				   
			   }
			   else{
				   $("#textFontStyling").prop("disabled",false);
			   }
		   }
		   if(checkbox.id=="textFontStyling"){
			   
		   }
		   if(checkbox.id=="restDesignElement"){
			   
		   }
	   },
	   removeDeletedElement:function(){
			for(var i=0;i<FQD.canvas.pages.length;i++){
				var objs=FQD.canvas.pages[i].getObjects();
				for(var j=0;j<objs.length;j++){
					var isDeleted=FQD.templateDataTransfer.isElementDeleted(objs[j]);
					if(isDeleted){
						FQD.canvas.pages[i].remove(objs[j]);
						FQD.canvas.pages[i].renderAll();
					}
				}
				
			}
	   },
	   
	   isElementDeleted:function(obj){
		   var isDeleted=false;
		   var srcPlaceHolderContent=obj.placeHolderContent;
	 
		   if(srcPlaceHolderContent){
			  	var srcPlaceHolder=obj.placeHolderContent.toLowerCase().replace(/ /g,"");
			    var srcOrgTemplate=obj.originalTemplateContent.toLowerCase().replace(/ /g,"");
			    
			   for(var i=0;i<config.templateDeletedTextElements.length;i++){
			    	var targetPlaceHolderContent=config.templateDeletedTextElements[i].placeHolderContent;
 			    	var TgtPlaceHolder=config.templateDeletedTextElements[i].placeHolderContent.toLowerCase().replace(/ /g,"");
 			    	var TgtOrgTemplate=config.templateDeletedTextElements[i].originalTemplateContent.toLowerCase().replace(/ /g,"");
				     if(targetPlaceHolderContent){
				    		if((srcPlaceHolder==TgtPlaceHolder)){
				    			isDeleted=true;
				    			break;
				    		}
				     }
			   }
		   }
         return isDeleted;
	   },
	   importOnActivePage:function(data,pageNo,isRound){
		   config.isProcessCompleted=false;
		   data=data[pageNo-1];
		   config.importActivePage=config.activeCanvas;	   
		   try {
			   var jsonData;
			    var count=0;
			    var pageCount = 0;
			    var multi=config.objScaleWidthMultiplier;
				var canvas = FQD.canvas.pages[config.activeCanvas];
				var elementCount=FQD.templateDataTransfer.elementsCountForActivePage(data);
				if (urlPrefix != "") {
					data = data.replace(/\/seam\/resource/g, urlPrefix
							+ "/seam/resource");
					data = data.replace(/\/common\/resource/g, urlPrefix
							+ "/common/resource");

				}
				 var json=JSON.parse(data);
				canvas.templateBgColor=json.background;
				 json.background='transparent';
				 if(json.backgroundImage){
					 json.backgroundImage.name="bgElement";
					 json.backgroundImage.alwaysNotselectable= true;
					 json.backgroundImage.objectCaching= false;
					 json.backgroundImage.selectable= false;
					 if(json.objects==undefined){
						 json.objects=[];
					 }
					 json.objects.unshift(json.backgroundImage);
					 delete json.backgroundImage;
				 }
				 json=FQD.imgLib.updateHDImageOnJson(json);
				 canvas.loadFromJSON(json,function() {
					    FQD.canvas.setElementAsperCanvas(canvas);
					   FQD.setCanvasAreaBackgroundColor(canvas,canvas.templateBgColor);
					   FQD.initializecanvas.createSVGOverlay(canvas);
					   setTimeout(function(){ FQD.canvas.addNewText(); }, 2000);
						FQD.utility.refreshTimeout(2000);
						},
					function(o, object) {
						if(object){
							if(object.name != "bgElement" && object.id != "backgroundImage" && object.type!="textbox"){
			   				    object.scaleX = object.scaleX*multi;
								object.scaleY = object.scaleY*multi;
							}else{
								object.width *= multi;
								object.height *= multi;
							}
							
							object.left = config.canvasOrigin.x0+object.left*multi;
							object.top = config.canvasOrigin.y0+object.top*multi;
							
							object.objectCaching = false;
							object.templateObject = true;
							
							
							if(object.isObjectLocked){
								object.hasBorders = false;
								object.selectable = false;
							}
							
							object.isObjectLocked = object.isObjectLocked != undefined? object.isObjectLocked.toString(): "false";
							
							
							if(object.type == "textbox") {
								object.fontSize=object.fontSize*multi;
								var lineHeight = object.lineHeight;
								if (lineHeight < 1) {
									//object.lineHeight = 1.16;
								}
								FQD.shapes.setTextAddedAlignProperties(object);
								object.toSVG = FQD.toSVGCustomize.toSVG;
								object.placeHolderTextValue = object.text;
							}
							
							if(object.type == "image" && object.cropped == "true"){
								var urlCropParam = object.src.split("&crop=")[1];
								if(urlCropParam){
									urlCropParam = urlCropParam.split("&");
									if (urlCropParam.length > 1) 
									{
										var cropParamArr = urlCropParam[0].split(":");
										if (cropParamArr.length >= 4) 
										{
											object.cropStartX = cropParamArr[0];
											object.cropStartY = cropParamArr[1];
											object.orgWidth = cropParamArr[2];
											object.orgHeight = cropParamArr[3];
										}
									}
								 }
								}

							
							if (object.isHidden == "true") {
								object.setOpacity(object.initialOpacity);
								delete object.isHidden;
							}
							
							if(isRound != undefined && isRound == 0 && config.isPageRoundCorner == "true"){
								if(object.name == "bgElement" && object.id == "backgroundImage"){
									var extraBleed = FQD.canvas.getExtraBleedDifference();
									object.width += (extraBleed.left + extraBleed.right);
									object.height += (extraBleed.top + extraBleed.bottom);
								}
								else
									FQD.helper.adjustTemplateObjects(object);
							}
							
						}
						
						count++;

						if(count>=elementCount){
							config.isProcessCompleted=true;
								
								if( config.importActivePage==1){
									$("#pageBackBtn").click();
								}						
								
						}
					});
				
		   } catch (e) {
				alert(fqdInvalidJsonData + "\n" + e);
				FQD.elements.divLoadingQd.hide();
				FQD.elements.divLoaderContainer.hide();
			}
	   }


		
};

function loadLocaleData(){
	var targetedElementsTitle,targetedElementsText,targetedElementsPlaceholder,targetedElementsValue,targetedElementsOptions,key,jsonData,children,childElementCountlanguageKeyValue;
	jsonData = resourcesData; 
	targetedElementsTitle = document.querySelectorAll('[data-title]');
	targetedElementsText = document.querySelectorAll('[data-text]');
	targetedElementsPlaceholder = document.querySelectorAll('[data-placeholder]');
	targetedElementsValue = document.querySelectorAll('[data-value]');
	targetedElementsOptions = document.querySelectorAll('[data-option]');
	var children = [];
	
	
	jQuery.each(targetedElementsTitle, function(index,element){
		key = element.getAttribute('data-title');
		element.title = resourcesData[key]; 
	});
	
	jQuery.each(targetedElementsText, function(index,element){
		key = element.getAttribute('data-text');
		
		if(element.childNodes.length > 0 && element.childElementCount >0){ // added loop to make sure elements with only line breaks are not considered for replacing child text.
			var hasLineBreak = false;
			for(var i=0;i<element.childNodes.length; i++){
				if(element.childNodes[i].nodeName === "BR" && hasLineBreak === false){
					hasLineBreak = true;
				}
			}
			jQuery.each(element.childNodes, function(index,childNode){
				if (hasLineBreak === false && childNode.nodeType === 3 && childNode.parentNode.getAttribute('data-text') === key) {
					languageKeyValue = childNode.nodeValue.replace(childNode.nodeValue.trim(),resourcesData[key]);
					childNode.nodeValue = childNode.nodeValue.substring(0, childNode.nodeValue.indexOf(childNode.nodeValue.trim())) + languageKeyValue;
				}
			});
		}else{
			element.innerHTML = resourcesData[key];
		}
	});
	
	jQuery.each(targetedElementsPlaceholder, function(index,element){
		key = element.getAttribute('data-placeholder');
		element.placeholder = resourcesData[key];
	});
	
	jQuery.each(targetedElementsValue, function(index,element){
		key = element.getAttribute('data-value');
		element.value = resourcesData[key];
	});
		
	jQuery.each(targetedElementsOptions, function(index,element){
		key = element.getAttribute('data-option');
		element.text = resourcesData[key];
	});
	userWarningMsg = resourcesData.userWarning1.replace(/#{purge}/g , purge);
	 $('#userWarning').html(userWarningMsg);
}
















