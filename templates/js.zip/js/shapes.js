/*******************************************************************************
 * 
 * Responsible for drawing shapes
 * 
 ******************************************************************************/
FQD.shapes = {};

FQD.shapes.shadowObject = null;
FQD.shapes.isScaling = false;
FQD.shapes.constrainScale = true;
FQD.shapes.mutlipleSelect = false;

FQD.shapes.rect = function(origX, origY, pointerX, pointerY, rounded) {
	var radius = rounded? 40: 0;
	
	var rect = new fabric.Rect({
		left : origX,
		top : origY,
		width : pointerX - origX,
		height : pointerY - origY,
		rx:radius,
		ry:radius,
		strokeWidth : FQD.shapes.defaultStrokWidth(),
		selectable : false,
		hasControls : false,
		hasBorders : false,
		evented : false,
		stroke : config.strokeColor,
		fill : config.fillColor,
		objectCaching : false
	});

	return rect;
}
FQD.shapes.circle = function(origX, origY, pointerX, pointerY) {
	var circle = new fabric.Circle({
		left : pointerX,
		top : pointerY,
		radius : 1,
		strokeWidth : FQD.shapes.defaultStrokWidth(),
		stroke : config.strokeColor,
		fill : config.fillColor,
		selectable : false,
		hasControls : false,
		hasBorders : false,
		evented : false,
		originX : 'center',
		originY : 'center',
		objectCaching : false
	});
	return circle;
}
FQD.shapes.text = function(origX, origY, pointerX, pointerY) {
	var text = new fabric.Textbox(config.textPlaceHolder, {
		fontFamily : 'gp-arial',
		fontSize : 30*config.objScaleWidthMultiplier,
		fontWeight : 400,
		fill : config.txtColor,
		fontStyle : 'normal',
		top : pointerY,
		selectable : true,
		left : pointerX,
		width : 250*config.objScaleWidthMultiplier,
		height : 200*config.objScaleWidthMultiplier,
		cursorWidth : 1,
		breakWords : true,
		id : FQD.canvas.setTextBoxId(),
		objectCaching : false
	});
	text.toSVG = FQD.toSVGCustomize.toSVG;
	text.isModified=true;
	return text;
}

FQD.shapes.newText = function(s) {
	var canvas=FQD.canvas.pages[config.activeCanvas];
	var pos = FQD.canvas.getNearCenterRandomPosition();
	var xValue = pos.leftPos;
	var yValue = pos.topPos;
	
	var text = new fabric.Textbox(config.textPlaceHolder, {
		fontFamily : 'gp-arial',
		fontSize : s*config.objScaleWidthMultiplier,
		fontWeight : 400,
		fill : config.txtColor,
		fontStyle : 'normal',
		left : xValue,
		top : 0,
		opacity:0,
		selectable : true,
		width : 400*config.objScaleWidthMultiplier,
		height : 200*config.objScaleWidthMultiplier,
		cursorWidth : 1,
		breakWords : true,
		id : FQD.canvas.setTextBoxId(),
		objectCaching : false,
		previewOnly : true
	});
	text.toSVG = FQD.toSVGCustomize.toSVG;
	  text.setFontFamily("gp_arial");
	  text.placeHolderTextValue=config.textPlaceHolder;
	  jQuery('#select').trigger("click");
	  text.isModified=true;
	  FQD.shapes.addElementOnCanvas(text, canvas, yValue);
	  FQD.canvas.addNewText();
	  config.origText="";		    	  
	  fabric.util.clearFabricFontCache();
	  FQD.allOverlayOnTop();
}
FQD.shapes.line = function(origX, origY, pointerX, pointerY) {
	var points = [ pointerX, pointerY, pointerX, pointerY ];
	var line = new fabric.Line(points, {
		strokeWidth : FQD.shapes.defaultStrokWidth(),
		stroke : config.strokeColor,
		fill : config.fillColor,
		originX : 'left',
		selectable : false,
		hasControls : false,
		hasBorders : false,
		evented : false,
		originY : 'top',
		objectCaching : false
	});

	return line;

}

FQD.shapes.defaultStrokWidth = function(){
	var strokeWid = 4*config.scaleMultiplier;
	return strokeWid < 1? 1: strokeWid;
}

FQD.shapes.loadPlaceHoldersImage = function(name) {
	var img = new Image();
	img.crossOrigin = "anonymous"; // This enables CORS
	img.onload = function() {
		if (name == "image") {
			config.imgElement = img;
		} else {
			config.clipArtElement = img;
		}
	}
	img.src = config.resourcePath + "images/" + name + ".svg";
}

FQD.shapes.addElementOnCanvas=function(elm, canvas, topVal){
	topVal = (topVal == undefined)? (canvas.getHeight()/2): topVal;
	elm.animate({top: topVal, opacity: 10 }, {
	      duration: 1000,
	      onChange: canvas.renderAll.bind(canvas),
	      easing: fabric.util.ease["easeOutQuint"]
	    });
	canvas.add(elm);
	setTimeout(function(){FQD.undoManager.saveHistory(true);},1000)
}

FQD.shapes.loadPlaceHoldersImage("image");
FQD.shapes.loadPlaceHoldersImage("clipart");

FQD.shapes.placeHolders = function(name) {
	var img = new Image();
	img.crossOrigin = "anonymous"; // This enables CORS
	img.onload = function() {
		
		var pos = FQD.canvas.getDefaultPosition(300, 250);
		
		var image = new fabric.Image(img);
		image.set({
			originX : 'left',
			originY : 'top',
			left : pos.leftPosition,
			top : pos.topPosition,
			opacity : 0.7,
			width:292*config.objScaleWidthMultiplier,
			height:258*config.objScaleWidthMultiplier,
			selectable : true,
			id : "placeHolders"
		});
		if (name == "image") {
			image.set("imgPlaceholder", true);

		} else {
			image.set("clipartPlaceholder", true);
		}
        if(FQD.canvas.pages[config.activeCanvas]){
    		FQD.canvas.pages[config.activeCanvas].add(image);
    		//FQD.canvas.pages[config.activeCanvas].centerObject(image);
    		image.setCoords();
        }

		FQD.allOverlayOnTop();
		if(FQD.canvas.pages[config.activeCanvas]){
			FQD.canvas.pages[config.activeCanvas].renderAll();
		}

		FQD.undoManager.saveHistory(true);
	}
	img.src = config.resourcePath + "images/" + locale + "-" + name + ".svg";
}

FQD.shapes.textSelectedFlag = function() {
	var i = 0, len = FQD.canvas.getActiveObjects()._objects.length;

	for (i; i < len; i++) {
		if (FQD.canvas.getActiveObjects()._objects[i].type == "textbox") {
			return true;
		}
	}
	return false;
}

FQD.shapes.shadow = {
	color : '#0000ff',
	blur : 10,
	offsetX : 0,
	offsetY : 0,
	opacity : 0.5,
	fillShadow : true,
	strokeShadow : true
}

FQD.shapes.addAndRemoveShadow = function(target) {
	FQD.shapes.removeShadow();
	if(target != undefined){
		if (FQD.canvas.getActiveObjects()._objects && target !== null
				&& target._objects == undefined
				&& FQD.elements.selObjAlign.val() == "alignToItem") {
			target.setShadow(FQD.shapes.shadow);
			FQD.shapes.shadowObject = target;
		}
	}
	else{
		//console.log("target is empty!");
	}
}

FQD.shapes.removeShadow = function() {
	if (FQD.canvas.pages[config.activeCanvas]) {
		if (FQD.canvas.pages[config.activeCanvas].getObjects()) {
			FQD.canvas.pages[config.activeCanvas].getObjects().forEach(
					function(obj) {
						obj.setShadow(null);
					});
		}
	}

	if (FQD.shapes.shadowObject != null) {
		FQD.shapes.shadowObject.setShadow(null);
		FQD.canvas.pages[config.activeCanvas].renderAll();
	}

	FQD.shapes.shadowObject = null;
}

FQD.shapes.setObjectProperties = function(prop, value, element) {
	var obj = FQD.canvas.getActiveObjects();
	if (FQD.canvas.pages[config.activeCanvas].getActiveObject()
			&& FQD.canvas.getActiveObjects().isObjectLocked=="true") {
		return;
	}
	if (!obj && element) {
		obj = element;
	}

	if (obj) {
		if (!obj._objects) {
			if (obj.type == "textbox") {
				config.objectCachedProperties.Text[prop] = value;
			} else {
				 if(prop == "strokeWidth"){
					 config.objectCachedProperties.Shapes[prop] = value * config.scaleMultiplier;
				  }else{
					  config.objectCachedProperties.Shapes[prop] = value;
				  }
			}
		}

		switch (prop) {
		case "fill":
				obj.setFill(value);
			break;
		case "textBgColor":
				if(obj._objects){
					for (var i = 0; i < obj._objects.length; i++){
						if(obj._objects[i].type == "textbox"){
							obj._objects[i].setTextBackgroundColor(value);
						}
					}
				}else if(obj.type == "textbox"){
					obj.setTextBackgroundColor(value);
				}
			break;

		case "strokeColor":
			if (obj._objects) {
				var i = 0, len = obj._objects.length;
				for (i; i < len; i++) {
					if (obj._objects[i].type != "textbox") {
						obj._objects[i].setStroke(value);

					}
				}
			} else {
				obj.setStroke(value);
			}
			break;

		case "strokeWidth":
			if (obj._objects) {
				var i = 0, len = obj._objects.length;
				for (i; i < len; i++) {
					if (obj._objects[i].type != "textbox" && obj._objects[i].type != "image") 
					{
						if (obj._objects[i].type == "line" && value == 0){
							obj._objects[i].setStrokeWidth(FQD.shapes.defaultStrokWidth());
						} else {
							var lastStrokeWidth = obj._objects[i].strokeWidth;
							var currentStrokeWidht = value * config.scaleMultiplier; 
							obj._objects[i].setStrokeWidth(currentStrokeWidht);
							
							if(obj._objects[i].type != "circle") {
								obj._objects[i].left = obj._objects[i].left + ((lastStrokeWidth-currentStrokeWidht))/2;
								obj._objects[i].top = obj._objects[i].top + ((lastStrokeWidth-currentStrokeWidht))/2;
								obj._objects[i].setCoords();
							}
							
							if(obj._objects[i].strokeDashArray != null && obj._objects[i].strokeDashArray != "" && obj._objects[i].strokeDashArray != undefined && currentStrokeWidht != lastStrokeWidth) 
							{
								var strokeArray = obj._objects[i].strokeDashArray;
								var newStrokeArray = strokeArray.map(function(element) {
									return (element/lastStrokeWidth)*(currentStrokeWidht) * config.scaleMultiplier;
								});
								obj.setStrokeDashArray(newStrokeArray);
								config.objectCachedProperties.Shapes.strokeStyle = newStrokeArray;
							}
						}

					}
				}
			} else {
				if (obj.type == "line" && value == 0) {
					obj.setStrokeWidth(FQD.shapes.defaultStrokWidth());
					$("#strokeWidth").val(1);
				} else {
					var lastStrokeWidth = obj.strokeWidth;
					var currentStrokeWidht = value * config.scaleMultiplier; 
					obj.setStrokeWidth(currentStrokeWidht);
					
					if(obj.type != "circle") {
						obj.left = obj.left + ((lastStrokeWidth-currentStrokeWidht))/2;
						obj.top = obj.top + ((lastStrokeWidth-currentStrokeWidht))/2;
						obj.setCoords();
					}
					
					
					if(obj != null && obj.strokeDashArray != null && obj.strokeDashArray != "" && obj.strokeDashArray != undefined && currentStrokeWidht != lastStrokeWidth) 
					{
						var strokeArray = obj.strokeDashArray;
						var newStrokeArray = strokeArray.map(function(element) {
							return (element/lastStrokeWidth)*(currentStrokeWidht) * config.scaleMultiplier;
						});
						obj.setStrokeDashArray(newStrokeArray);
						config.objectCachedProperties.Shapes.strokeStyle = newStrokeArray;
					}
				}

			}
			break;
		case "roundedRadius":
			if(obj._objects){
				for (i = 0; i < obj._objects.length; i++){
					if(obj._objects[i].rx > 0)
						obj._objects[i].rx = obj._objects[i].ry = value;
				}
			}else if(obj.rx > 0){
				obj.rx = obj.ry = value;
			}
			break;
		case "fontSize":
			FQD.shapes.setTextElementsProperties("fontSize", value, element);
			break;
		case "lineHeight":
			FQD.shapes.setTextElementsProperties("lineHeight", value, element);
			break;
		case "fontWeight":
			if (value == "bold") {
				FQD.elements.bold.addClass("textPropSelected");
				obj.set({
					fontWeight : 'bold'
				});
			} else {
				FQD.elements.bold.removeClass("textPropSelected");
				obj.set({
					fontWeight : ''
				});
			}

			break;

		case "fontStyle":

			if (value == "italic") {
				FQD.elements.italic.addClass("textPropSelected");
				obj.set({
					fontStyle : 'italic'
				});
			} else {
				FQD.elements.italic.removeClass("textPropSelected");
				obj.set({
					fontStyle : ''
				});
			}
			break;

		case "textAlign":

			if (value == "right") {
				FQD.elements.italic.addClass("textPropSelected");
				FQD.shapes.setTextElementsProperties("textAlign", "right", obj);
			} else if (value == "center") {
				FQD.elements.italic.removeClass("textPropSelected");
				FQD.shapes
						.setTextElementsProperties("textAlign", "center", obj);
			} else {
				FQD.shapes.setTextElementsProperties("textAlign", "left", obj);
			}
			break;

		case "strokeStyle":
			if (typeof value != "object") {
				value = JSON.parse(value);
			}
			FQD.elements.selStroke.blur();
			
			if (obj._objects) {
				var i = 0, len = obj._objects.length;
				for (i; i < len; i++) {
					if (obj._objects[i].type != "textbox") {
						obj._objects[i].setStrokeDashArray(value);
						obj._objects[i].strokeArray=value;
					}
				}
			} else {
				var wMultiplier = 1;
				if(FQD.canvas.pages[config.activeCanvas].getActiveObject() != null) wMultiplier = FQD.canvas.pages[config.activeCanvas].getActiveObject().strokeWidth/4;
				if(value != null) {
					var newStrokeArray = value.map(function(element) {
						return element*wMultiplier;
					});
					obj.setStrokeDashArray(newStrokeArray);
					obj.strokeArray=value;
					config.objectCachedProperties.Shapes.strokeStyle = newStrokeArray;
				} else {
					obj.setStrokeDashArray(value);
					obj.strokeArray=value;
				}
			}
			break;

		case "fontFamily":
			FQD.shapes.setTextElementsProperties("fontFamily", value, element);
			FQD.utility.showHideBoldItalic(value);
			if( config.nonBoldItalicFontList.lastIndexOf(value) != -1 ) {
				FQD.elements.italic.removeClass("textPropSelected");
				FQD.elements.bold.removeClass("textPropSelected");
				obj.set({
					fontStyle : '',
					fontWeight : ''
				});
			}
			break;

		case "opacity":
			if (obj._objects) {
				var i = 0, len = obj._objects.length;
				for (i; i < len; i++) {
					obj._objects[i].setOpacity(value);
				}
			} else {
				obj.setOpacity(value);
			}
			break;
		}

		FQD.canvas.pages[config.activeCanvas].renderAll();
		if (!config.down) {
			if(prop !== "fill" && prop !== "strokeColor"){
				FQD.undoManager.saveHistory(true);
			}
		}
	}
}

FQD.shapes.setTextElementsProperties = function(prop, value, element) {
	var obj = FQD.canvas.getActiveObjects();
	if (!obj && element) {
		obj = element;
	}
	if (obj._objects) {
		var i = 0, len = obj._objects.length;
		for (i; i < len; i++) {
			if (obj._objects[i].type == "textbox") {
				obj._objects[i].set(prop, value);
				if (prop == "textAlign") {
					FQD.shapes.setTextAddedAlignProperties(obj._objects[i])
				}
			}
		}
	} else if (obj.type == "textbox") {
		obj.set(prop, value);
		if (prop == "textAlign") {
			FQD.shapes.setTextAddedAlignProperties(obj);
		}
	}

	FQD.canvas.resetActiveGroupTransfromTool();
}

FQD.shapes.setTextAddedAlignProperties = function(tElement) {
	// code comment for this function because as per Ink-Space no need to
	// require addition properties attached with Text element.
	/*
	 * if(tElement.getTextAlign() == "right"){
	 * tElement.set("text-anchor",'end'); tElement.set("text-align",'end'); }
	 * else if(tElement.getTextAlign() == "center"){
	 * tElement.set("text-anchor",'middle');
	 * tElement.set("text-align",'center'); } else{
	 * tElement.set("text-anchor",''); tElement.set("text-align",''); }
	 */
}

FQD.shapes.setTextElmTopFromAD = function(tElement) 
{
	console.log("FQD.shapes.setTextElmTopFromAD");
	var _topPaddingGap = ((tElement.fontSize * 72) / parseInt(config.productDetails.dpi)) * 0.42;
	tElement.top += ((24 -_topPaddingGap) * config.scaleMultiplier);
	
	if(tElement.fontFamily == "gp_courier"){
		tElement.top -= (tElement.fontSize * config.scaleMultiplier * 0.185);
	}
}

FQD.shapes.addSymboleInTextElement = function(textElement, symboleChar,
		addToPos) {
	if (textElement.getText() == config.textPlaceHolder) {
		textElement.setText(symboleChar);
	} else {
		textElement.insertChar(symboleChar, false);
	}

	FQD.canvas.UpdateTextField(textElement.id, textElement.getText());
	FQD.canvas.pages[config.activeCanvas].renderAll();
	FQD.message.objectOutsideSafeAndTrimZone();
	FQD.canvas.resetActiveGroupTransfromTool();
}

FQD.shapes.showEditProperties = function() {
	FQD.elements.anchorDelete.addClass("disabled");
	//jQuery("#elemet-editor-container").hide();
	//jQuery(".ef-ruler .ruler-wrap-top,.ruler-corner").css("margin-top","0px");
	jQuery(".ef-ruler .ruler-wrap-top,.ruler-corner").css("margin-top",jQuery("#elemet-editor-container").height()+"px");
	config.activElm=false;
	if (FQD.canvas.pages[config.activeCanvas] == undefined) {
		return;
	}
	jQuery("#eyeDropper").removeClass("disabled");
	var activeObject = FQD.canvas.getActiveObjects();
	var multipleState = false;
	jQuery("#right-bar").show();
	if (activeObject) {
		config.activElm=activeObject;
		
		var isLocked = activeObject.isObjectLocked;
		if (isLocked == "true") {
			FQD.shapes.showHideCanvasProperties();
			return;
		}

		jQuery("#depth-properties").show();
		jQuery(".button-menu").hide();
		jQuery("#bgPropertiesContainer").hide();
		if (activeObject.type == "group") {
			var elms = activeObject._objects;
			var shapeCnt = 0, textCnt = 0, lineCnt = 0, element;
			for (var i = 0; i < elms.length; i++) {
				element = elms[i];
				if (element.type == "rect" || element.type == "circle" || element.type == "ellipse" || element.type == "path")
					shapeCnt++;
				else if (element.type == "line")
					lineCnt++;
				else if (element.type == "textbox")
					textCnt++;
			}

			FQD.shapes.mutlipleSelect = true;

			if ((shapeCnt + lineCnt) === elms.length) {
				FQD.shapes.showShapeProperties(lineCnt > 0 ? true : false);
				FQD.shapes.enableDisableShapeProperties(elms[0]);
			} else if (textCnt === elms.length) {
				FQD.shapes.showTextProperties();
				FQD.shapes.enableDisableTextPropertyIcons(elms[0]);
				var id = elms[0].id;
				$("#" + id).css('border-width', '2px');
			} else {
				multipleState = true;
			}
		} else if (activeObject.type == "rect" || activeObject.type == "circle" || activeObject.type == "ellipse" || activeObject.type == "path") {
			FQD.shapes.showShapeProperties(false, (activeObject.rx > 0? true: false));
			FQD.shapes.enableDisableShapeProperties(activeObject);
		} else if (activeObject.type == "line") {
			FQD.shapes.showShapeProperties(true, false);
			FQD.shapes.enableDisableShapeProperties(activeObject);
		} else if (activeObject.type == "textbox") {
			FQD.shapes.showTextProperties();
			FQD.shapes.enableDisableTextPropertyIcons(activeObject);
			var id = activeObject.id;
			$("#" + id).css('border-width', '2px');
		} else if (activeObject.type == "image"
				|| activeObject.type == "cropzoomimage") {
			if (activeObject.imgPlaceholder || activeObject.clipartPlaceholder) {
				jQuery("#crop-photo,#divImageEffects").hide();
			}else{
				jQuery("#crop-photo,#divImageEffects").show();
			}
			jQuery("#shape-properties").hide();
			jQuery("#common-properties").show();
			jQuery(".button-menu").hide();
			jQuery("#text-properties").hide();
			jQuery("#image-properties").show();
			jQuery("#stroke-slider").show();
			jQuery("#strokeWidth").show();
			jQuery("#strokeWidth").next("span").show();
			jQuery("#strokeWidthProp,#colorWithPickerProp").hide();

			if (activeObject.flipX) {
				jQuery("#chkFlipH").prop("checked", true);
			} else {
				jQuery("#chkFlipH").prop("checked", false);
			}
			if (activeObject.flipY) {
				jQuery("#chkFlipV").prop("checked", true);
			} else {
				jQuery("#chkFlipV").prop("checked", false);
			}

			if (activeObject._originalElement) {
				var src = activeObject._originalElement.currentSrc;
				if (src.indexOf("imageEffectType") > 0) {
					src = src.slice(src.lastIndexOf("=") + 1);
					jQuery("#selImageEffects").val(src);
				} else {
					jQuery("#selImageEffects").val("NONE");
				}
			}
			FQD.shapes.updateCommonProperties(activeObject);
		}

		jQuery("#opacity-properties").show();
		var resMenu=jQuery("#res-menu");
		if(resMenu.hasClass("active") && resMenu.css("display") == "block" && activeObject.type != "image"){
			resMenu.removeClass("active")
			responsiveMenu(resMenu);
		}
	} else if (!FQD.canvas.getActiveObjects()) {
		if (config.selectedTool == "select") {
			FQD.shapes.showHideCanvasProperties();
		}
		$('#new-text-field textarea').css('border-width', '1px');
	}

	if (FQD.canvas.getActiveObjects()) {
		FQD.elements.anchorDelete.removeClass("disabled");
		if (!multipleState) {
			jQuery("#stroke-slider").slider({
				disabled : false
			});
			FQD.elements.spanRoundedRadiusSlider.slider({disabled:false});
			jQuery("#disabledColorPicker").hide();
		} else {
			FQD.shapes.showHideCanvasProperties();
			// FQD.shapes.updateCommonProperties(elms[0]);
		}
		jQuery("#colorWithPickerProp,#applyobj, #constrainBtn").removeClass(
				"disabled");
	}else{
		jQuery("#colorWithPickerProp,#strokeWidthProp,#colorWithPickerProp,#common-properties,#opacity-properties").hide();
		jQuery("#bgPropertiesContainer").show();
	}

	FQD.shapes.mutlipleSelect = false;
}

FQD.shapes.showShapeProperties = function(hasLine, hasRoundedRect) {
	jQuery("#shape-properties").show();
	jQuery(".button-menu").hide();
	jQuery("#text-properties").hide();
	jQuery("#image-properties").hide();
	jQuery("#common-properties").show();
	jQuery("label[for='strokeP']").show();
	jQuery("label[for='strokeP']").next().next("span.jPicker").show();
	jQuery("label[for='strokeWidth']").show();
	jQuery("#stroke-slider").show();
	jQuery("#strokeWidth").show();
	jQuery("#strokeWidth").next("span").show();
	jQuery("#strokeWidthProp").show();
	FQD.elements.divRoundedRadius.hide();
	jQuery("#colorWithPickerProp").show();
	
	if (hasLine) {
		jQuery("#colorWithPickerProp").hide();
	}else if(hasRoundedRect){
		FQD.elements.divRoundedRadius.show();
	}
}

FQD.shapes.showTextProperties = function() {
	jQuery("#strokeWidthProp").hide();
	jQuery("#strokeStyle").hide();
	jQuery("#shape-properties").hide();
	jQuery(".button-menu").hide();
	jQuery("#text-properties,#colorWithPickerProp").show();
	jQuery("#image-properties").hide();
	jQuery("#common-properties").show();
	jQuery("label[for='strokeWidth']").hide();
	jQuery("#stroke-slider").hide();
	jQuery("#strokeWidth").hide();
	jQuery("#strokeWidth").next("span").hide();
	$('#new-text-field textarea').css('border-width', '1px');
}

FQD.shapes.showHideCanvasProperties = function()
{
	if(config.warning == "true"){
		config.warning = "false";
	}
	
	jQuery("#shape-properties").hide();
	jQuery(".button-menu").hide();
	jQuery("#text-properties").hide();
	jQuery("#image-properties").hide();
	jQuery("#common-properties").show();
	jQuery("label[for='strokeWidth']").show();
	jQuery("#stroke-slider").show();
	jQuery("#strokeWidth,#colorWithPickerProp").show();
	jQuery("#strokeWidth").next("span").show();
	jQuery("#strokeWidth").val(0);
	jQuery("#opacity").val(100);
	jQuery("#corner").val(0);

	jQuery("#corner-slider").slider({
		value : 0,
		disabled : true
	});

	if (!FQD.canvas.getActiveObjects()) {
		jQuery("#stroke-slider").slider({
			value : 0,
			disabled : true
		});
		FQD.elements.spanRoundedRadiusSlider.slider({value:0, disabled:true});
		jQuery("#opacity-slider").slider({
			value : 100,
			disabled : true
		});
	} else {
		jQuery("#stroke-slider").slider({
			disabled : true
		});
		FQD.elements.spanRoundedRadiusSlider.slider({disabled : true});
		jQuery("#opacity-slider").slider({
			disabled : false
		});
	}

	jQuery("#disabledColorPicker").show();
	jQuery("#objInfo input").val("").attr("disabled", "disabled");
	jQuery("#applyobj, #constrainBtn").addClass("disabled");
	FQD.elements.divAlignTools.find("a").addClass("disabled");
	FQD.elements.divAlignTools.find("a").removeClass("activeAlign");
}

FQD.shapes.enableDisableShapeProperties = function(obj) {
	if(obj != undefined){
		var fill = obj.getFill(), 
		    strokeWidth = obj.getStrokeWidth(), 
		    strokeColor = obj.getStroke(), 
		    strokeStyle = obj.getStrokeDashArray();
		
		if(obj.strokeArray){
			strokeStyle = obj.strokeArray;
		}

		config.objectCachedProperties.Shapes.fill = fill;
		config.objectCachedProperties.Shapes.strokeWidth = strokeWidth;
		config.objectCachedProperties.Shapes.strokeColor = strokeColor;
		config.objectCachedProperties.Shapes.strokeStyle = strokeStyle;
		
		if (strokeColor == "#null" || strokeColor == "hsla(0, 0%, 100%, 0)") {
			strokeColor = null;
		}
		if (strokeColor.indexOf("rgb") != -1) {
			strokeColor = FQD.shapes.hexToRGB(strokeColor);
			FQD.elements.inputStrokeP.spectrum("set",strokeColor);	
		} else {
			FQD.elements.inputStrokeP.spectrum("set",strokeColor);
		}
		if (fill == "#null" || fill == "hsla(0, 0%, 100%, 0)") {
			fill = null;
		}
		if (fill.indexOf("rgb") != -1) {
			fill = FQD.shapes.hexToRGB(fill);
			FQD.elements.inputColorP.spectrum("set",fill);
		
		} else {
			FQD.elements.inputColorP.spectrum("set",fill);
		}
		var points = ((strokeWidth/config.objScaleWidthMultiplier) * 72) / parseInt(config.productDetails.dpi);
		
		if(obj.templateObject && config.currentDPI){
			 points = ((strokeWidth/config.scaleMultiplier) * config.currentDPI) / parseInt(config.productDetails.dpi);
		}
		
		points = (points > 0 && points < 1)? 1: points;
		
		Math.round(points) >10 ? FQD.elements.inpStrokeWidth.val(10) : FQD.elements.inpStrokeWidth.val(Math.round(points));
		FQD.elements.spanRoundedRadiusSlider.slider({
			disabled : false,
			value : obj.rx
		});
		FQD.elements.inpRoundedRadius.val(Math.ceil(obj.rx));
		
		if(strokeStyle === null || strokeStyle.toString() === "") {
			FQD.elements.selStroke.val("null");
		} else {
			FQD.elements.selStroke.val("[" + strokeStyle.toString() + "]");
		}

		FQD.shapes.updateCommonProperties(obj);
	}
	else{
		//console.log("obj is empty!");
	}
}

FQD.shapes.updateCommonProperties = function(element) {
	var opacity = element.getOpacity();

	FQD.elements.spanOpacitySlider.slider({
		disabled : false,
		value : opacity * 100
	});
	FQD.elements.inpOpacity.val(parseInt(opacity * 100));
}

FQD.shapes.hexToRGB = function(color) {
	if (color.indexOf("b(") != -1){
		var x = color.split("rgb(");
		var y = x[1].split(")");
		var z = y[0].split(",");
		return {
			r : z[0],
			g : z[1],
			b : z[2]
		};
	}
	else if(color.indexOf("a(") != -1){
		var x = color.split("rgba(");
		var y = x[1].split(")");
		var z = y[0].split(",");
		return {
			r : z[0],
			g : z[1],
			b : z[2],
			a : z[3]
		};
	}
}

FQD.shapes.enableDisableTextPropertyIcons = function(obj) {
	var textAlign = obj.getTextAlign(), fontWeight = obj.getFontWeight(), fontStyle = obj
			.getFontStyle(), fontSize = obj.getFontSize(),lineHeight = obj.getLineHeight(), fontFamily = obj
			.getFontFamily(), textDecoration = obj.getTextDecoration();
	fill = obj.getFill();

	config.objectCachedProperties.Text.textAlign = textAlign;
	config.objectCachedProperties.Text.fontWeight = fontWeight;
	config.objectCachedProperties.Text.fontStyle = fontStyle;
	config.objectCachedProperties.Text.fontSize = fontSize;
	config.objectCachedProperties.Text.lineHeight = lineHeight;
	config.objectCachedProperties.Text.fontFamily = fontFamily;
	config.objectCachedProperties.Text.textDecoration = textDecoration;
	config.objectCachedProperties.Text.fill = fill;

	var changeFont = fontFamily.replace("gp-", "").replace("gp_", "");
	changeFont = changeFont.charAt(0).toUpperCase()
			+ changeFont.slice(1).toLowerCase();

	jQuery("#selected-font").html(changeFont).css("font-family",
			fontFamily.replace("-", "_"));
	FQD.utility.showHideBoldItalic(fontFamily);
	if(!FQD.canvas.getActiveObjects()._objects){
		FQD.elements.spanFontSlider.slider({
			disabled : false,
			value : fontSize
		});
    }
	if(!FQD.canvas.getActiveObjects()._objects){
		if(!!FQD.canvas.getActiveObjects().minLineHeight){
			jQuery('#align-justify-slider').slider('option', 'min', FQD.canvas.getActiveObjects().minLineHeight);
			jQuery('#align-justify-slider').slider('option', 'max', FQD.canvas.getActiveObjects().minLineHeight + 10);
		}else{
			jQuery('#align-justify-slider').slider('option', 'min', 1.16);
			jQuery('#align-justify-slider').slider('option', 'max', 11.16);
		}
		FQD.elements.spanAlignJustifySlider.slider({
			disabled : false,
			value : lineHeight
		});
    }
    
	var points = (fontSize * 72) / parseInt(config.productDetails.dpi);
	FQD.elements.inpFontSize.val(points.toFixed(0));

	var lineHeightPoints = lineHeight;
	FQD.elements.inpLineSpace.val(lineHeightPoints);
	
	FQD.elements.inputColorP.spectrum("set",fill);
	//FQD.elements.inputColorP[0].color.active.val('hex', fill);
	FQD.elements.inputColorP.val(fill.replace("#", ""));
	
	
	if(obj.type === "textbox"){
		var textBgColor = config.fillColor;
		if(obj.textBackgroundColor){
			textBgColor=obj.textBackgroundColor;
		}
		FQD.elements.inputTextBgColorP.spectrum("set",textBgColor);
		FQD.elements.inputTextBgColorP.val(textBgColor.replace("#", ""));
	}

	jQuery('#textStyleProp li').removeClass("textPropSelected");
	jQuery("#selected-align i").html("format_align_left");

	if (textAlign == "left") {
		jQuery("#selected-align i").html("format_align_left");
	} else if (textAlign == "right") {
		jQuery("#selected-align i").html("format_align_right");
	} else {
		jQuery("#selected-align i").html("format_align_center");
	}

	if (fontWeight == "bold") {
		FQD.elements.bold.addClass("textPropSelected");
	}
	if (fontStyle == "italic") {
		FQD.elements.italic.addClass("textPropSelected");
	}
	if (textDecoration == "underline") {
		FQD.elements.underline.addClass("textPropSelected");
	}
	if (textDecoration == "line-through") {
		FQD.elements.lineThrough.addClass("textPropSelected");
	}

	FQD.shapes.updateCommonProperties(obj);
}

FQD.shapes.commiteScaleValues = function(element) {
	element.set("lastScaleX", element.getScaleX());
	element.set("lastScaleY", element.getScaleY());
}

FQD.shapes.hasImageScaleWarning = function(element, groupScaleX, groupScaleY) {
	groupScaleX = (groupScaleX == undefined) ? 0
			: ((groupScaleX > 0) ? (groupScaleX - 1) : 0);
	groupScaleY = (groupScaleY == undefined) ? 0
			: ((groupScaleY > 0) ? (groupScaleY - 1) : 0);
	var elmSX = element.getScaleX() + groupScaleX;
	var elmSY = element.getScaleY() + groupScaleY;
	var width;
	var height;
	if (element.cropped == "true") {
		width = element.orgWidth;
		height = element.orgHeight;
	} else {
		width = element.originalWidth;
		height = element.originalHeight;
	}
	if (!element.scaled
			&& ((element.width * elmSX > width) || (element.height * elmSY > height))) {
		return true;
	}

	FQD.shapes.commiteScaleValues(element);
	return false;
}

FQD.shapes.selectedElementWidth = function() {
	var element = FQD.canvas.getActiveObjects();
	if (config.unit == "px") {
		var ratio = 72 / config.dpi;
		return ((element.getWidth() * ratio).toFixed(0));
	} else
		return (FQD.utility
				.changeObjUnit("px", config.unit, element.getWidth())
				.toFixed(3));
}

FQD.shapes.selectedElementHeight = function() {
	var element = FQD.canvas.getActiveObjects();
	if (config.unit == "px") {
		var ratio = 72 / config.dpi;
		return ((element.getHeight() * ratio).toFixed(0));
	} else
		return (FQD.utility.changeObjUnit("px", config.unit, element
				.getHeight()).toFixed(3));
}

FQD.shapes.getMaxSizeFromActiveGroup = function(){
	var maxW = maxH = 0;
	var crlMaxW = crlMaxH = crlHGap = crlVGap = 0;
	var elpRect;
	var obj = FQD.canvas.getActiveObjects();
	
	for(var i = 0; i < obj._objects.length; i++)
	{
		if(obj._objects[i].type == "circle"){
			elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]); 
			maxW = (elpRect.width > maxW)? elpRect.width: maxW;
			maxH = (elpRect.height > maxW)? elpRect.height: maxW;
			
			if(elpRect.width > crlMaxW){
				crlMaxW = elpRect.width;
				minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
				maxX = Math.max(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
				crlHGap = ((maxX - minX) - crlMaxW) / 2;
				crlHGap -= obj._objects[i].strokeWidth / 2;
			}
			
			if(elpRect.height > crlMaxH){
				crlMaxH = elpRect.height;
				minY = Math.min(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
				maxY = Math.max(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
				crlVGap = ((maxY - minY) - crlMaxH) / 2;
				crlVGap -= obj._objects[i].strokeWidth / 2;
			}
			
		}else{
			if(obj._objects[i].angle == 0){
				maxW = (obj._objects[i].getWidth() > maxW)? obj._objects[i].getWidth(): maxW;
				maxH = (obj._objects[i].getHeight() > maxW)? obj._objects[i].getHeight(): maxW;
			}else{
				minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
				maxX = Math.max(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
				minY = Math.min(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
				maxY = Math.max(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
				
				maxW = ((maxX - minX) > maxW)? (maxX - minX): maxW;
				maxH = ((maxY - minY) > maxW)? (maxY - minY): maxW;
			}
		}
	}
	
	return {width: maxW, height:maxH, leftOffset:crlHGap, topOffset:crlVGap};
}

FQD.shapes.getEllipseBoundingBox = function(obj){
	var rx = obj.width * obj.scaleX;
	var ry = obj.height * obj.scaleY;
	var cx = obj.left;
	var cy = obj.top;
	
	var angle = obj.angle * Math.PI / 180;
	var a = rx * Math.cos(angle);
	var b = ry * Math.sin(angle);
	var c = rx * Math.sin(angle);
	var d = ry * Math.cos(angle);
	
	var w = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
	var h = Math.sqrt(Math.pow(c, 2) + Math.pow(d, 2));
	    
	var _x = cx - w * 0.5;
	var _y = cy - h * 0.5;
	
	return ({x: _x, y:_y, width:w, height:h});
}

