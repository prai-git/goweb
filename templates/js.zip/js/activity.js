
FQD.activity={};

FQD.activity.init=function(){
}
var keepAliveTimer = null;
var autoSaveTimer = null;

FQD.activity.resetKeepAliveTimer=function(){
	config.TimeoutDialog.keepAlive();
	}

FQD.activity.startKeepAliveTimer=function()
{
	if(config.productDetails.adminOpenedSavedDesign)
		return;
	
	var keepaliveTime = config.productDetails.keepAliveIntervalSeconds;
	keepaliveTime = keepaliveTime == undefined? (5*60): keepaliveTime;
	keepAliveTimer = setInterval(onKeepAliveTimer, keepaliveTime*1000);
}

onKeepAliveTimer=function(){
	 jQuery.ajax({
			mimeType: 'text/plain; charset=x-user-defined',
			url : FQD.preview.url,
		    type: "GET",
		    data : "QDAction=37&cid="+config.cid+"&random="+Math.random(),
		    success: function(data)
		    {	
		    },
		    error: function (jqXHR, textStatus, errorThrown)
		    {
		    },
		    xhrFields:{
		        withCredentials: true
		     }
		});
}

FQD.activity.removeAutoSaveTimer=function(){
	if(autoSaveTimer != null){
		clearInterval(autoSaveTimer);
		autoSaveTimer = null;
	}
}

FQD.activity.startAutoSave=function()
{
	FQD.activity.removeAutoSaveTimer();
	
	if(config.applicationSettings.showLoginAutoSavePopup == false || config.orderItemRedesignMode || config.productDetails.adminOpenedSavedDesign)
		return;
	
	if(config.IsUserLoggedIn && !config.productDetails.isProductSaved){
		autoSaveTimer = setInterval(onAutoSaveTimer, config.productDetails.loggedInAutoSaveIntervalSeconds*1000);
	}
	else{
		autoSaveTimer = setInterval(onAutoSaveTimer, config.productDetails.autoSaveIntervalSeconds*1000);
	}
	
}

onAutoSaveTimer=function()
{   
	
	if($(".timeout-dialog").length==1){
		return;
	}
	if(config.isApplicationError){
		return;
	}
	
	if(FQD.canvas.isCanvasEmpty() || config.hasPreviewState){
		return;
	}
		
	if(!config.IsUserLoggedIn || (config.IsUserLoggedIn && !config.productDetails.isProductSaved))  
	{
		FQD.activity.removeAutoSaveTimer();
		config.autoSave = true;
		FQD.helper.isUserLoggedIn('promptDesignName');
	}
	else if(config.IsUserLoggedIn && config.productDetails.isProductSaved && (config.currentDesignId || config.productDetails.designId))
	{
		config.autoSaveProgress = true;
		if(config.currentDesignId){
	 		  FQD.saveDesign.saveDesign(config.currentDesignId, true);  
	 	}else{
	 		  FQD.saveDesign.saveDesign(config.productDetails.designId, true); 
	 	}
	}
}