
var myUploads={
		jsonUrl:urlPrefix+"/UserImageJsonAction",
		deleteImgArray:[],
		userLoggedIn:false,
		folderAction:"",  
		selectDropImage:"",
		showItemsPerPage:25,
		pageNumber:1,
		searchString:"",
		init:function(){
			
			jQuery("#qd-wrapper").delegate("#myUp","click", function(event) {
				isSessionChanged(function(){
				myUploads.searchString="";
				if(!jQuery(this).hasClass("current")){
					myUploads.pageNumber=1;
					myUploads.getImgCategory();
				}
				jQuery("button").each(function(){
					jQuery(this).html(jQuery(this).html().toLowerCase());
					jQuery(this).css("text-transform","capitalize");
				});
				jQuery("#showView").show();
				});
			});
			
			jQuery("#qd-wrapper").delegate("#usedBGImage","click", function(event) {
				jQuery("#showView").hide();
			});
			
			jQuery("#qd-wrapper").delegate("#selectAll","click", function(event) {
				myUploads.selectAll();
			});
			
			jQuery("#qd-wrapper").delegate("#selectNone","click", function(event) {
				myUploads.selectNone();
			});

			jQuery("#qd-wrapper").delegate("#showView","click", function(event) {
				if(jQuery("#showView").hasClass("list")){
					jQuery(this).removeClass("list");
					jQuery(this).attr("title",imgGridView);
					jQuery("#messages ul li, #tab-2 #filesUploaded ul li").removeClass("list-view");
				}else{
					jQuery(this).addClass("list");
					jQuery(this).attr("title",imgListView);
					jQuery("#messages ul li, #tab-2 #filesUploaded ul li").addClass("list-view");
				}	
		     });
			
			jQuery("#editImgInfo input[type='text'], #editImgInfo textarea, #modelWindow input[type='text'], #modelWindow textarea").keydown(function(e){
			});
			
			
			jQuery("#qd-wrapper").delegate("#saveBtn","click", function(event) {
				if(jQuery("#folderName").val() !=""){
					if(folderAction=="newFolder"){
						myUploads.sendFolderRequest({
								"requestCode":5,
								"parentFolderId":jQuery("#parentCategory").val(),
								"folderName":jQuery("#folderName").val()
							});
					}else{
						myUploads.sendFolderRequest({
								"requestCode":6,
								"parentFolderId":jQuery("#parentCategory").val(),
								"folderName":jQuery("#folderName").val(),
								"folderId":jQuery("li.selectedFolder a").attr("id")
							});
					}
				}
			});
			jQuery("#qd-wrapper").delegate("#infoSaveBtn","click", function(event) {

				var editImage=myUploads.sendFolderRequest({
								"requestCode":12,
								"selectedFileDescriptorId":jQuery("#previewInfoImg").attr("filedescriptorid"),
								"fileName":jQuery("#fileName").val(),
								"imageCategoryId":jQuery("#imgCategory").val(),
								"keywords":jQuery("#keywords").val()
							},"editImgInfo");
				if(editImage!=="error"){
					jQuery("#editImgInfo").fadeOut();
				}
				
			
			});
			jQuery("#qd-wrapper").delegate("#deleteBtn","click", function(event) {

				if (confirm(jQuery("#confirmDeleteImageFolder").html())) {
					myUploads.sendFolderRequest({"requestCode":7,"folderId":jQuery("li.selectedFolder a").attr("id")}, "deleteFolder");
				}
			
			});
			jQuery("#qd-wrapper").delegate("#moveBtn","click", function(event) {
				
				if (confirm(confirmMove.substring(confirmMove.indexOf("'")+1,confirmMove.lastIndexOf("?")+1))) {
					myUploads.sendFolderRequest({"requestCode":8,"selectedImages":myUploads.deleteImgArray,"folderId":jQuery("#parentCategory").val()},"move");
				}
		  });
           jQuery("#qd-wrapper").delegate("#searchBtn","click", function(event) {
				
				if((jQuery("#fileUploadWrapper #searchText").val()).length >= 3){
					jQuery("#imgCategories").find("li.selectedFolder").removeClass("selectedFolder");
					myUploads.searchString=jQuery("#fileUploadWrapper #searchText").val();
					myUploads.pageNumber=1;
					myUploads.sendFolderRequest({"requestCode":10,"itemsPerPage":myUploads.showItemsPerPage,"pageNumber":myUploads.pageNumber,"searchString":myUploads.searchString},"search");
				}else{
					myUploads.searchString="";
				}
			});
           jQuery("#qd-wrapper").delegate("#searchText","change paste keyup", function(event) {
				var len=(jQuery(this).val()).length;
			    if(len >= 3){
			    	jQuery("#searchBtn").prop("disabled", false);
			    }else{
			    	jQuery("#searchBtn").prop("disabled", true);
			    }
			});

           jQuery("#qd-wrapper").delegate("#clearBtn","click", function(event) {
				jQuery("#fileUploadWrapper #searchText").val("");
				myUploads.searchString="";
				jQuery("#-1").click();
			});
			
			
			jQuery("#qd-wrapper").delegate("#editFolder, #newFolder, #moveSelected","click", function(event) {
				var id=jQuery("li.selectedFolder a").attr("id");
				folderAction=jQuery(this).attr("id");
				if(jQuery(this).attr("id")=="newFolder"){
					myUploads.editFolders(newFolderText,"-1");
				}
				else if(jQuery(this).attr("id")=="editFolder"){
					myUploads.editFolders(editFolderText ,id);
				}
				else{
					 myUploads.deleteImgArray.length=0;
					 jQuery.each(jQuery("input[type='checkbox'].checked"),function(){
						 myUploads.deleteImgArray.push(jQuery(this).parent().find("img").attr("id"));
					 });
					if(myUploads.deleteImgArray.length > 0){
						myUploads.editFolders("Move",id);
					}else{
						gotError(noItemMessage);
					}
				}
			});
			
			
			jQuery("#qd-wrapper").delegate("#closeWindow, .cancelBtn","click", function(event) {

				if(jQuery(this).attr("id") != "deleteBtn"){
					closeWindow();
				}
			
			});
			
			jQuery("#qd-wrapper").delegate("#deleteSelected","click", function(event) {
				 myUploads.deleteImgArray.length=0;
				 jQuery.each(jQuery("input[type='checkbox'].checked"),function(){
					 myUploads.deleteImgArray.push(jQuery(this).parent().find("img").attr("fileDescriptorId"));
				 });
				 myUploads.deleteImg("filesUploaded");
			 });
			 
			 jQuery("#insertToCanvas").click(function(){
				 var chkLen=jQuery("#fileUploadWrapper div.current").find("input[type='checkbox'].checked").length;
					if(chkLen == 1){ 
						myUploads.sendIopRequest(jQuery("input[type='checkbox'].checked").parent().find("img").attr("fileDescriptorId"));
					}else{
						if(chkLen > 1){
							gotError(onlyOneImageMessage);
							return;
						}
						gotError(noItemMessage);
					}
				});
			 jQuery("#infoDeletelBtn").click(function(){
				 myUploads.deleteImgArray.length=0;
				 myUploads.deleteImgArray.push(jQuery("#previewInfoImg").attr("fileDescriptorId"));
				 myUploads.deleteImg("filesUploaded");
			 });
		},
		
		applyOnCanvas:function(that){
				var img=jQuery(that).find("img");
				FQD.imgLib.setSelectedImg(img);
		},
		sendIopRequest:function(filedescriptorid){
			var random=Math.random();
			jQuery.ajax({
		        type: 'post',
		        mimeType: 'text/plain; charset=x-user-defined',
		        url: myUploads.jsonUrl,
		        data: {"requestCode":11,"selectedFileDescriptorId":filedescriptorid,"random":random} ,
		        dataType: 'json',
		        success: function (data) {
		        	if(data.responseCode==0){
		        	}
		        },
		        error:function(jqXHR, textStatus, errorThrown){
		        	console.log(textStatus, errorThrown);
		        	gotError(serverError);
		        },
			    xhrFields:{
			        withCredentials: true
			     }
		 });
		},
		buildTree:function(obj,element) {
			jQuery("#imgCategories").html("");
		    var ul = jQuery('<ul class="categoryList"></ul>');
		    var li;
			jQuery.each(obj,function(i,data){
				if(data.subFolder != undefined && data.subFolder.length > 0){
					 li = jQuery('<li class="ulCategory"><span class="collapse" onclick="myUploads.categorySlide(this);"></span><a href="javascript:void(0)" title="'+HTMLEncode(data.name)+' "id="'+data.id+'" onclick="myUploads.categorySlide(this);">'+HTMLEncode(data.name)+'</a></li>');
				}else{
					li = jQuery('<li class="ulCategory"><span></span><a href="javascript:void(0)" title="'+HTMLEncode(data.name)+'" id="'+data.id+'" onclick="myUploads.categorySlide(this);">'+HTMLEncode(data.name)+'</a></li>');
				}
				 ul.append(li);
		        if (typeof(data.subFolder)=="object") {
		        	myUploads.buildTree(data.subFolder,ul);
		        }
		        if(element){
		        	element.append(ul);
		        }else{
		        	 jQuery("#imgCategories").append(ul);
		        }
			});
			jQuery("#-1").click();
		},
		categorySlide:function(current){
			myUploads.searchString="";
			if(current.tagName=="A"){
				if( !jQuery(current).hasClass("selectedFolder") ){
			 		jQuery("#editFolder").prop("disable",false).show();
			 		if(jQuery(current).attr("id")=="-1"){
						jQuery("#editFolder").prop("disable",true).hide();
					}
			 		jQuery("#imgCategories").find("li").removeClass("selectedFolder");
			 		jQuery(current).parent("li").addClass("selectedFolder");
			 		myUploads.pageNumber=1;
					myUploads.getSelectedImg("filesUploaded");
					if(current.id != "-1" && jQuery("#imgCategories li").length == 2){
						jQuery("#moveSelected").prop("disabled",true).hide();
					}else{
						jQuery("#moveSelected").prop("disabled",false).show();
					}
			 	}
			}else{
				if(current.className=="collapse"){
					current.className="expand"
					jQuery(current).parent().next("ul.categoryList").slideDown("fast");
				}else{
						current.className="collapse"
						jQuery(current).parent().next("ul.categoryList").slideUp("fast");
				}
			}
		},
		getImgCategory:function(){
			jQuery("#appButtons").hide();
			jQuery("#searchBox").css("visibility","hidden");
			jQuery("#ajaxLoader").show();
			var random=Math.random();
			 jQuery.ajax({
			        type: 'post',
			        mimeType: 'text/plain; charset=UTF-8',
			        url: myUploads.jsonUrl,
			        data: {"requestCode":0,"random":random, "savedDesignUserId":config.productDetails.savedDesignUserId} ,
			        dataType: 'json',
			        success: function (data) {
			        	if(data.isUserLoggedIn==true){
			        		myUploads.userLoggedIn=true;
		        			jQuery("#appButtons").show();
		        			jQuery("#searchBox").css("visibility","visible");
		        		}
				        	if(data.categories.length > 0 && data.categories != undefined){
				        		myUploads.buildTree(data.categories);
				        	}
			        	jQuery("#ajaxLoader").hide();
			        },
			        error:function(jqXHR, textStatus, errorThrown){
			        	console.log(textStatus, errorThrown);
			        	gotError(serverError);
			        },
				    xhrFields:{
				        withCredentials: true
				     }
			 });
		},
		getSelectedImg:function(containerName){
			 var random=Math.random();
			jQuery("#loginText").hide();
			var rCode=1;
			if(containerName=="recentImages"){
					rCode=3;
					myUploads.showItemsPerPage=35;
				}else{
					myUploads.showItemsPerPage=25;
				}
			jQuery("#ajaxLoader").show();
			
			if(myUploads.searchString.length > 0){
				param={"requestCode":10,"itemsPerPage":myUploads.showItemsPerPage,"pageNumber":myUploads.pageNumber,"searchString":myUploads.searchString,"random":random,"cid":config.cid}
			}
			else{
				if(rCode == 1)
					param={"requestCode":rCode,"categoryId":jQuery("li.selectedFolder a").attr("id"),"itemsPerPage":myUploads.showItemsPerPage,"pageNumber":myUploads.pageNumber,"random":random,"sizeId":config.productDetails.productSize,"cid":config.cid, "savedDesignUserId":config.productDetails.savedDesignUserId}
				else
					param={"requestCode":rCode,"categoryId":jQuery("li.selectedFolder a").attr("id"),"itemsPerPage":myUploads.showItemsPerPage,"pageNumber":myUploads.pageNumber,"random":random,"sizeId":config.productDetails.productSize,"cid":config.cid}
			}
			
			if(config.productDetails.productType){
				param.productTypeId=config.productDetails.productType;
			}
			if(config.productDetails.productSize){
				param.productSizeId=config.productDetails.productSize;
			}
			
			
			jQuery.ajax({
				mimeType: 'text/plain; charset=x-user-defined',
		        type: 'post',
		        url: myUploads.jsonUrl,
		        data:param,
		        dataType: 'json',
		        success: function (data) {
		        	myUploads.imageTemplate(containerName,data);
		        	if(!myUploads.userLoggedIn && containerName == "filesUploaded"){
		        		jQuery("#loginText").show();
		        	}
		        	
		        	if(!config.isRGBPopupOpen && numberOfUploadFiles > 1 && data.images.length >= numberOfUploadFiles){  
		        		for(var i = 0; i < numberOfUploadFiles; i++){
		        			if(data.images[0].fileFormat == "SRGB" || data.images[0].fileFormat == "RGB"){
		        				config.isRGBPopupOpen = true;
		        			}
		        		}
		        	} 
		        	
		        	/**** commented as per XGPCOMQD-1826
		        	if(config.isRGBPopupOpen){
	        			standardPopup(FQD.message.msgRGBWarning, 'Ok', '', '', function(){config.isRGBPopupOpen = false;}, null, null);
	        		}*/
		        	
		        	if(numberOfUploadFiles == 1 && config.placerHolderObject.elm && containerName == "recentImages"){
		        		jQuery("#recentImages").find("li:first").trigger("dblclick");
		        	}
		        	numberOfUploadFiles=null;
		        },
		        error:function(jqXHR, textStatus, errorThrown){
		        	numberOfUploadFiles=null;
		        	console.log(textStatus, errorThrown);
		        	gotError(serverError);
		        },
			    xhrFields:{
			        withCredentials: true
			     }
		 });
		},
		imageTemplate:function(containerName,data){
			var elm="";
			jQuery("#"+containerName).html("");
        	if(data.images !=undefined){
	        	if(data.images.length > 0 && data.images != undefined){
	        		elm+="<ul>";
	        		jQuery.each(data.images,function(i,data){
	        			if(data.id == undefined){
	        				data.id= "useruploaded"+Math.floor(Math.random() * 1000);
	        			}
	        			var heg = config.productDetails.adminOpenedSavedDesign? 78: 100;
	        			var ext = data.displayName.substring(data.displayName.lastIndexOf(".")+1,data.displayName.length).toUpperCase();
	        			elm+='<li onclick="myUploads.inputCheck(this,'+containerName+')"); ondblclick="myUploads.applyOnCanvas(this);" style="height:'+heg+'px;">\
	        					<div class="img-tool" style="display:flex; justify-content:center; align-items:center;">\
	        						<img onerror="imgError(this);" id="'+data.id+'" style="margin-top:-3px;" draggable="true" ondragstart="FQD.imgLib.onDragStartHandler(event)" useruploaded="true" fileType="'+data.fileType+'" widthInches="'+data.widthInches+'" heightInches="'+data.heightInches+'" originalWidth="'+data.width+'" originalHeight="'+data.height+'" dim="'+data.dimentions+'" errors="'+data.errors[0]+'" format="'+data.fileFormat+'" imgDpi="'+data.dpi+'" key="' +data.keywords+'" fileDescriptorId="'+data.fileDescriptorId+'" rel="'+urlPrefix+data.previewUrl+'"title="'+data.displayName+'" src="'+urlPrefix+data.thumbnailUrl+'"/>\
	        						<span class="extTag '+ext+'" style="width: 35px;">'+ext+'</span>\
	        						<div class="display-list-view">\
	        							<h4>'+imageInfoTitle+'</h4>\
	        							<p><span class="display-name" title="'+data.displayName+'">'+data.displayName+'</span>('+data.fileFormat+')</p>\
	        							<p class="time" title="'+data.fileSize+'">'+data.fileSize+'</p>\
	        							<p class="clear dim" title="'+data.dimentions+'">'+data.dimentions+'</p>\
	        							<p class="time" title="'+data.createTime+'">'+data.createTime+'</p>\
	        						</div>\
	        						<div class="clear"></div>\
	        					</div>';
			        			if(containerName=="filesUploaded" && myUploads.userLoggedIn==true ){
			        				elm+='<input type="checkbox"class="check fl" /><span class="edit fl" onclick="myUploads.getImgInfo(event,this)" style="visibility:hidden;"></span>';
			        			}else{
			        				elm+='<input type="checkbox"class="check fl" style="display:none;" />';
			        			}
	        			if(!config.productDetails.adminOpenedSavedDesign)
	        				elm+='<span class="delete fl" onclick="myUploads.deleteSelectedImage(event,this);"></span>';
	        			elm+='</li>';
	        		});
	        		elm+='</ul>';
	        	}
	        	jQuery("#"+containerName).html(elm);
        	}
        	if(jQuery("#showView").hasClass("list")){
        		jQuery("#"+containerName).find("ul li").addClass("list-view");
			}
        	jQuery("#ajaxLoader").hide();
        	if(data.totalNumberOfItems != undefined){
        		myUploads.pagination(data.totalNumberOfItems,myUploads.showItemsPerPage);
        	}
        	
        	var chkLen = jQuery("#fileUploadWrapper div.current").find("input[type='checkbox'].checked").length;
			 if(chkLen <= 0){
				 $("#btnInsertImg").prop('disabled', true);
				 $("#applyBg").prop('disabled', true);
			 }
		},
		
		usedBackgroundImages:function()
		{
			var elm="";
			var dataArr = config.productDetails.backgroundUsedImages;
			
			jQuery("#tab-3 #filesUploaded").html("");
			
        	if(dataArr != undefined && dataArr.length > 0)
			{
        		elm+="<ul>";
        		jQuery.each(dataArr, function(i, data)
        		{
        			elm+='<li style="height:78px;">\
        					<div class="img-tool" style="display:flex; justify-content:center; align-items:center;">\
        						<img onerror="imgError(this);" id="bgimage_'+i+'" style="margin-top:-3px;" src="'+urlPrefix+data.thumbnailUrl+'"/>\
        						<div class="display-list-view">\
        							<p class="display-name" title="'+data.fileName+'">'+data.fileName+'</p>';
        							
        							if(data.parentCategory != undefined)
        								elm += '<p class="display-name" title="'+data.parentCategory+'">'+data.parentCategory+'</p>';
        			
				        			if(data.subCategory != undefined)
										elm += '<p class="display-name" title="'+data.subCategory+'">'+data.subCategory+'</p>';
				        	
				        		elm += '</div>\
        						<div class="clear"></div>\
        					</div>';
        			elm+='</li>';
        		});
        		elm+='</ul>';
        		
        		jQuery("#tab-3 #filesUploaded").html(elm);
        	}
        	
        	jQuery("#tab-3 #filesUploaded").find("ul li").addClass("list-view");
        	
        	jQuery("#ajaxLoader").hide();
		},
		
		inputCheck:function(current,containerName){
				if(!jQuery(current).hasClass("selected")) {
					jQuery(current).siblings().removeClass("selected");
					 jQuery(containerName).find("input").removeClass("checked").prop("checked",false);
					jQuery(current).find("input").addClass("checked").prop("checked",true);
					 jQuery(current).addClass("selected");
					 	var img=jQuery(current).find("img");
						FQD.imgLib.selectedImg=img.attr("rel");
						FQD.imgLib.selectedImgOriginalHeight=img.attr("originalHeight");
						FQD.imgLib.selectedImgOriginalWidth=img.attr("originalWidth");
						FQD.imgLib.isUserUploaded=img.attr("useruploaded");
						FQD.imgLib.filedescriptorid=img.attr("filedescriptorid");
				} else {
					if(jQuery(containerName).attr("id") == "recentImages"){
						 jQuery(containerName).find("li").removeClass("selected");
						 jQuery(containerName).find("input").removeClass("checked").prop("checked",false);
					 }
					 if(jQuery(current).hasClass("selected")){
						 jQuery(current).find("input").removeClass("checked").prop("checked",false);
						 jQuery(current).removeClass("selected");
					 }
				}
				 
				 var chkLen = jQuery("#fileUploadWrapper div.current").find("input[type='checkbox'].checked").length;
				 if(chkLen > 0){
					 $("#btnInsertImg").prop('disabled', false);
					 $("#applyBg").prop('disabled', false);
				 } else {
					 $("#btnInsertImg").prop('disabled', true);
					 $("#applyBg").prop('disabled', true);
				 }
		},
		deleteSelectedImage:function(event,current){			
			event.stopPropagation();
			 myUploads.deleteImgArray.length=0;
			 var id=jQuery(current).parent().find("img").attr("fileDescriptorId");
			 myUploads.deleteImgArray.push(id);
			 myUploads.deleteImg(jQuery(current).parent().parent().parent().attr("id"));
		},
		getImgInfo:function(event,current){
				event.stopPropagation();
				 var imgSrc=jQuery(current).parent().find("img").attr("rel"),
				 fid=jQuery(current).parent().find("img").attr("fileDescriptorId"),
				 name=jQuery(current).parent().find("img").attr("title"),
				 dim=jQuery(current).parent().find("img").attr("dim"),
				 key=jQuery(current).parent().find("img").attr("key"),
				 format=jQuery(current).parent().find("img").attr("format");
				 errors=jQuery(current).parent().find("img").attr("errors");
				 jQuery("#imgErrors").show();
				 if(errors == "undefined"){
					 jQuery("#imgErrors").hide();
					 jQuery("#previewInfoImg").height("345");
				 }else{
					 jQuery("#imgErrors").show();
					 jQuery("span#errors").html(errors);
					 jQuery("#previewInfoImg").height("300");
				 }
				 
				 jQuery("#editImgInfo").find("img#previewInfoImg").attr("src",imgSrc);
				 jQuery("#editImgInfo").find("img#previewInfoImg").attr("fileDescriptorId",fid);
				 
				 jQuery("#editImgInfo").find("input#fileName").val(name);
				 jQuery("#editImgInfo").find("#keywords").val(key);
				 jQuery("#editImgInfo").find("#fileFormat").html(format);
				 jQuery("#editImgInfo").find("#dimensions").html(dim);
				 myUploads.editFolders("editImgInfo","-1");
				 jQuery("#editImgInfo").fadeIn("fast");
				 
		},
		selectAll:function(){
			jQuery("#filesUploaded").find("input[type='checkbox']").prop("checked",true).addClass("checked");
			jQuery("#filesUploaded").find("input[type='checkbox']").parent().addClass("selected");
		},
		selectNone:function(){
			jQuery("#filesUploaded").find("input[type='checkbox']").prop("checked",false).removeClass("checked");
			jQuery("#filesUploaded").find("input[type='checkbox']").parent().removeClass("selected");
		},
		deleteImg:function(deleteDivName){
			var deleteImageUseOnCanvas=false;
			if(myUploads.deleteImgArray.length == 0){ 
				gotError(deleteMessage);
				return;
			}
			var arr=myUploads.getCanvasImageArr();
			var imgArr=myUploads.deleteImgArray;
			if(arr.length == 0){
				arr = FQD.undoManager.removeDeletedImage('undoItems',imgArr);
			}
			if(arr.length == 0){
				arr = FQD.undoManager.removeDeletedImage('redoItems',imgArr);
			}
			
			for(var i=0;i<imgArr.length;i++){
				var index=arr.indexOf(imgArr[i]);
				if(index!=-1){
					deleteImageUseOnCanvas=true;
					var ind=myUploads.deleteImgArray.indexOf(imgArr[i]);
					myUploads.deleteImgArray.splice(ind,1);
				}
			}
			customAlertBox("confirm", 'Cancel','Ok',conformFileDelete,function(result){
				if (result) { 				
				  if(myUploads.deleteImgArray.length==0){
					  gotError(uploadInUse);
					  return;
				  }
				   var random=Math.random();
				   FQD.activity.resetKeepAliveTimer();
					jQuery.ajax({
				        type: 'post',
				        mimeType: 'text/plain; charset=x-user-defined',
				        url: myUploads.jsonUrl,
				        data: {"requestCode":2,"fileDescriotirIds":myUploads.deleteImgArray,"random":random} ,
				        dataType: 'json',
				        success: function (data) {
				        	if(data.responseCode==0)
				        	{
				        		myUploads.deleteImgArray.length=0;
				        		FQD.activity.resetKeepAliveTimer();
				        		jQuery.ajax({
							        type: 'GET',
							        mimeType: 'text/plain; charset=x-user-defined',
							        url: FQD.helper.qdAction+"?cid="+config.cid,
							        data: "QDAction=32",
							        dataType: 'text',
							        success: function (data) {
							        	if(deleteImageUseOnCanvas||data.trim()=="null"){
							        		gotError(uploadInUse);
							        	}
							        	if(data.trim()!=""){
							        		gotError(data);
							        	}
							        	
							        	myUploads.getSelectedImg(deleteDivName);
							        },
							        error:function(jqXHR, textStatus, errorThrown){
							        	console.log("data");
							        },
								    xhrFields:{
								        withCredentials: true
								     }
							 });
				        		
				        	}else{
				        		alert(data.responseMessage);
				        	}
				        },
				        error:function(jqXHR, textStatus, errorThrown){
				        	console.log(textStatus, errorThrown);
				        	gotError(serverError);
				        },
					    xhrFields:{
					        withCredentials: true
					     }
				 });
		    } 
			});
		},
		editFolders:function(actionName,catId){
			var getId=jQuery("li.selectedFolder").parent().prev("li.ulCategory").find("a").attr("id");
			var elm="";
			jQuery("#headText").text(actionName);
			if(catId == "-1"){
				jQuery("#folderName").val("");
				jQuery("#deleteBtn").hide();
			}else{
				jQuery("#deleteBtn").show();
				jQuery("#folderName").val(jQuery("#"+catId).text());
			}
			if(actionName == "Move"){
				var elm="";
				jQuery("#modelContent p:first").hide();
				jQuery("#modelContent p").eq(1).find("label").text(moveToLabel + ":");
				jQuery("#deleteBtn").hide();
				jQuery("#moveBtn").show();
				jQuery("#saveBtn").hide();
			}else{
				jQuery("#modelContent p").show();
				jQuery("#modelContent p").eq(1).find("label").text(parentCategoryLabel + ":");
				elm='<option value="-1">--'+none+'--</option>';
				jQuery("#moveBtn").hide();
				jQuery("#saveBtn").show();
			}
			jQuery("#ajaxLoader").show();
			var random=Math.random();
			jQuery.ajax({
		        type: 'post',
		        mimeType: 'text/plain; charset=x-user-defined',
		        url: myUploads.jsonUrl,
		        data: {"requestCode":4,"categoryId":catId,"random":random},
		        dataType: 'json',
		        success: function (data) {
			        	if(data.categoryItems.length > 0 && data.categoryItems != undefined){
			        		jQuery.each(data.categoryItems,function(i,data){
			        			elm+='<option value="'+data.id+'">'+HTMLEncode(data.fullyQualifiedName)+'</option>';
			        		});
			        	}
			        	if(actionName=="editImgInfo"){
			        		jQuery("#imgCategory").html(elm);
			        		jQuery("#ajaxLoader").hide();
			        		 myUploads.imageInfo.find("select#imgCategory").val(jQuery("li.selectedFolder a").attr("id"));
			        	}else{
				        	jQuery("#parentCategory").html(elm);
				        	jQuery("#ajaxLoader").hide();
							if(getId==undefined){
								if(actionName == "Move"){
								// do nothing	
								} else {
									jQuery("#parentCategory").val("-1");
								}
							}else{
								jQuery("#parentCategory").val(getId);
							}
				        	modelWindow();
			        	}
		        },
		        error:function(jqXHR, textStatus, errorThrown){
		        	console.log(textStatus, errorThrown);
		        	gotError(serverError);
		        },
			    xhrFields:{
			        withCredentials: true
			     }
		 });
		},
		sendFolderRequest:function(param,action){
			if(((param.requestCode==5)&&(param.folderName.trim()==""))||((param.requestCode==12)&&(param.fileName.trim()=="")))
				{
					    gotError(invalidInput);
					    return "error";
				}
			jQuery.ajax({
		        type: 'post',
		        mimeType: 'text/plain; charset=x-user-defined',
		        url: myUploads.jsonUrl,
		        data: param,
		        dataType: 'json',
		        success: function (data) {
			        	if(data.responseCode==0){
			        		if(action=="move" || action == "editImgInfo" ){
			        			myUploads.getSelectedImg("filesUploaded");
			        		}
			        		else{
			        			myUploads.getImgCategory();
			        		}
			        	}else{
			        		if(action=="move" || action == "deleteFolder") {
			        			myUploads.getSelectedImg("filesUploaded");
		        			}
			        		if(action !="search"){
			        			gotError(data.responseMessage);
			        		}
			        	}
			        	if(action=="search"){
		        			myUploads.imageTemplate("filesUploaded",data);
		        		}
			        	closeWindow();
		        },
		        error:function(jqXHR, textStatus, errorThrown){
		        	console.log(textStatus, errorThrown);
		        	gotError(serverError);
		        },
			    xhrFields:{
			        withCredentials: true
			     }
		 });
		},
		getCanvasImageArr:function(){
		    var canvasImageArr=[];
			for(var i=0;i<FQD.canvas.pages.length;i++){
				var canvas=FQD.canvas.pages[i];
				var bg=	FQD.canvas.pages[i].backgroundImage;
				if(bg && bg!=""){
					var fd=bg.filedescriptorid;
					 if(fd && fd!=""){
						 canvasImageArr.push(fd);
					 }
				}
				var obj=FQD.canvas.pages[i].getObjects();
				 if(obj.length>0){
					 for(var j=0;j<obj.length;j++){
						 if(obj[j].type=="image"){
							 var fd=obj[j].filedescriptorid;
							 if(fd && fd!=""){
								 canvasImageArr.push(fd);
							 }
							 
						 }
					 }
				 }
			}
			return canvasImageArr;
		}
}

function modelWindow(){
	var w=jQuery("#modelWindow").width();
	var h=jQuery("#modelWindow").height();
	jQuery("#modelWindow").css("top","25%");
	jQuery("#modelWindow").css("margin-left",-(w/2)+"px");
	jQuery("#modelWindow").css("margin-top",-(h/2)+"px");
	jQuery("#modelWrapper").fadeIn("fast");
	jQuery("#modelWindow").fadeIn("fast");
}

function imgError(image) {
    image.onerror = "";
    image.src = errorImf;
    return true;
}

function dropComplete(event,elm) {
	event.preventDefault();
	elm.css("background-color","transparent");
	if(!elm.parent().hasClass("selectedFolder")){
		if(myUploads.selectDropImage.length > 0 && myUploads.selectDropImage != "undefined"){
			myUploads.deleteImgArray.length=0;
			myUploads.deleteImgArray.push(myUploads.selectDropImage);
			myUploads.sendFolderRequest({"requestCode":8,"selectedImages":myUploads.deleteImgArray,"folderId":elm.attr("id")},"move");
		}
	}
	event.stopPropagation();
   return false;
}

function dragInitialize(event,fd) {
		event.preventDefault();
		event.stopPropagation();
	   return true;
}

function parseDeleteResponse(data){
	if(data!=undefined && data.length > 0){
		if(myUploads.deleteImgArray.length == 1){
			gotError(data,true);// if used image in any design template
			if(myUploads.userLoggedIn){
				sendDeignNameRequest(myUploads.deleteImgArray[0]); // to get desgin name list of used image
			}
		}else{
			gotError(data);
		}
	}else{
		myUploads.imageInfo.hide();
	}
	refreshRecent();
	myUploads.deleteImgArray.length=0;
}
function refreshRecent(){
	if(config.productDetails.adminOpenedSavedDesign){
		if(!jQuery("#myUp").hasClass("current")){
			jQuery("#myUp").trigger("click");
		}
		else if(jQuery("#myUp").hasClass("current")){
			myUploads.getSelectedImg("filesUploaded");
		}
	}
	else if(jQuery("#upFiles").hasClass("current")){
		myUploads.getSelectedImg("recentImages");
	}else{
		myUploads.getSelectedImg("filesUploaded");
	}
	jQuery("#searchText").val("");
}
function closeWindow(){
	jQuery("#modelWrapper").fadeOut("fast");
	jQuery("#modelWindow").fadeOut("fast");
}
function gotError(message,closeBtn){
	jQuery("#ajaxLoader, #responseMessage, #iopCanvasRenderMessage").hide();
	jQuery("#fileUploadWrapper").append('<div id="gotError"><span class="errorIcon">!</span><div style="padding-left:15px;">'+message+'</div></div>');
	jQuery("#gotError").slideDown("fast");
	if(closeBtn && myUploads.userLoggedIn){
		jQuery("#gotError").append("<span id='closeMsg' onclick='closeMessage()'>X</span>");
	}else{
		setTimeout(function() {jQuery("#gotError").fadeOut("fast",function(){jQuery(this).remove();})}, 5000);
	}
}

function sendDeignNameRequest(){
	jQuery("#designNamesContent").remove();
	var content="<div id='designNamesContent'>";
	var random=Math.random();
	jQuery.ajax({
        type: 'post',
        mimeType: 'text/plain; charset=x-user-defined',
        url: myUploads.jsonUrl,
        data: {"requestCode":13,"fileDescriptorId":myUploads.deleteImgArray[0],"random":random} ,
        dataType: 'json',
        success: function (data) {
        	if(data.responseCode == 0 && data.savedDesignsList.length > 0){
        		content+='<h4>'+data.designTitleLabel+'</h4>';
        		content+='<ul>'
        		jQuery.each(data.savedDesignsList,function(k,d){
        			content+='<li>'+d+'</li>';
        		});
        		content+='</ul></div>';
        	}else{
        		setTimeout(function() {jQuery("#gotError").fadeOut("fast",function(){jQuery(this).remove();})}, 5000);
        	}
        	jQuery("#gotError").append(content);
        }
 });
		
}


function closeMessage(){
	jQuery("#gotError").fadeOut("fast",function(){jQuery(this).remove()});
}

function HTMLEncode(str){
	  var i = str.length,
	      aRet = [];

	  while (i--) {
	    var iC = str[i].charCodeAt();
	    if (iC < 65 || iC > 127 || (iC>90 && iC<97)) {
	      aRet[i] = '&#'+iC+';';
	    } else {
	      aRet[i] = str[i];
	    }
	   }
	  return aRet.join('');    
	}

jQuery(document).ready(function(){
	
	myUploads.init();
	
	jQuery("#qd-wrapper").delegate("#imgCategories a","dragover", function(event) {
		event.preventDefault();
		if(jQuery(this).attr("id") != "-1"){
			jQuery(this).css("background-color","#b5d0f9");
		}
	});
	jQuery("#qd-wrapper").delegate("#filesUploaded img","dragstart", function(event) {
		myUploads.selectDropImage=jQuery(this).attr("id");
		
	});
	jQuery("#qd-wrapper").delegate("#imgCategories a","drop", function(event) {
			dropComplete(event,jQuery(this));
	});
	jQuery("#qd-wrapper").delegate("#imgCategories a","dragleave", function(event) {
		jQuery(this).css("background-color","transparent");
	});
	
	
});
myUploads.pagination=function(numOfItems,showItems){
	 jQuery(".page_navigation_bottom").html("");
	 if(numOfItems==0){numOfItems=1;}
	 var page="";
	 page+='<span class="start">&laquo; '+startPage+'</span><span class="prev">&laquo; '+prevPage+'</span><div class="allpages">';
	 var i=0;
		for(i;i<numOfItems/showItems;i++){
		 page+='<span class="'+(i+1)+'">'+(i+1)+'</span>';
	 }

	 page+='</div><span class="next">'+nextPage+' &raquo;</span><span class="last">'+lastPage+' &raquo;</a>';
	 jQuery(".page_navigation").html(page);
	 jQuery("span.selectedPage").html(numOfItems);
	 jQuery("span.totalPages").html(jQuery(".allpages span").length);
	 jQuery(".start,.prev").addClass("disabled");
	jQuery(".allpages span").hide();
	myUploads.selectPage(myUploads.pageNumber-1, ".page_navigation");
	jQuery(".page_navigation_bottom").html( jQuery(".page_navigation").html());
}

myUploads.selectPage=function(ind, pageClass){
		if(jQuery(pageClass+" .allpages span").eq(ind).hasClass("selected") == false){
			jQuery(".selectedPage").html(jQuery(this).html());
			jQuery(pageClass+" .allpages span").removeClass("selected");
			jQuery(pageClass+" .allpages span").eq(ind).addClass("selected");
			if(ind==0){
				jQuery(pageClass).find(".prev,.start,.next,.last").addClass("disabled");
				if(jQuery(pageClass+" .allpages span").length > 1){
					jQuery(pageClass).find(".next,.last").removeClass("disabled");
				}
				jQuery(".customize").show();
			}
			else if(ind==jQuery(pageClass+" .allpages span:last").index()){
				jQuery(pageClass).find(".next,.last").addClass("disabled");
				 jQuery(pageClass).find(".prev,.start").removeClass("disabled");
			}
			else {
				jQuery(pageClass).find(".prev,.start,.next,.last").removeClass("disabled");
			}
			jQuery(pageClass+" allpages span").hide();
			
				for(var i=0;i<5;i++){
					if(ind%4==0){jQuery(pageClass+" .allpages span").eq(ind+i).show();}
					if(ind%4==1){
						if(i<4){jQuery(pageClass+" .allpages span").eq(ind+i).show();}
						if(i<=1){jQuery(pageClass+" .allpages span").eq(ind-i).show();}
					}
					if(ind%4==2){
						if(i<3){jQuery(pageClass+" .allpages span").eq(ind+i).show();}
						if(i<=2){jQuery(pageClass+" .allpages span").eq(ind-i).show();}
					}
					if(ind%4==3){
						if(i<2){jQuery(pageClass+" .allpages span").eq(ind+i).show();}
						if(i<=3){jQuery(pageClass+" .allpages span").eq(ind-i).show();}
					}
					if(ind%4==4){
						if(i<1){jQuery(pageClass+" .allpages span").eq(ind+i).show();}
						if(i<=4){jQuery(pageClass+" .allpages span").eq(ind-i).show();}
					}
				 }
		}
}

jQuery(document).ready(function(){
		jQuery("#img-lib").delegate(".page_navigation .allpages span","click",function(){
			var ind=jQuery(this).index();
			if(jQuery(this).hasClass("selected") == false){
				myUploads.pageNumber=ind+1;
				refreshRecent();
			}
		});
		jQuery("#img-lib").delegate(".page_navigation .next","click",function(){
			if(jQuery(this).hasClass("disabled") == false){  
				var ind=jQuery(".allpages span.selected").index();
				if(ind !=jQuery(".allpages span:last").index()){
					jQuery(".allpages span").eq(ind+1).click();
				}
			}
		});
		jQuery("#img-lib").delegate(".page_navigation .prev","click",function(){
			if(jQuery(this).hasClass("disabled") == false){
				var ind=jQuery(".allpages span.selected").index();
				if(ind !=jQuery(".allpages span:first").index()){
					jQuery(".allpages span").eq(ind-1).click();
				}
			}
		});
		jQuery("#img-lib").delegate(".page_navigation .start","click",function(){
			jQuery(".allpages span:first").click();
		});
		jQuery("#img-lib ").delegate(".page_navigation .last","click",function(){
			jQuery(".allpages span:last").click();
		});
		
		jQuery('#qd-wrapper').delegate('ul.upload-tabs li','click',function(){
			var tab_id = jQuery(this).attr('data-tab');
	
			jQuery('#qd-wrapper ul.upload-tabs li').removeClass('current');
			jQuery('.tab-content').removeClass('current');
	
			jQuery(this).addClass('current');
			jQuery("#"+tab_id).addClass('current');
		});
		
		// to render in html and avoid printing the html tags from the tempFilesUserWarning string coming from message.txt
		var tempFilesUserWarning = jQuery("#userWarning").text();		
		jQuery("#userWarning").html(tempFilesUserWarning);
});
