FQD.PrintProductType={};

FQD.PrintProductType.BUSINESS_CARD 			= 1;
FQD.PrintProductType.POSTCARD 				= 2;
FQD.PrintProductType.BOOKMARK 				= 3;
FQD.PrintProductType.FLYER 					= 4;
FQD.PrintProductType.BROCHURE 				= 5;
FQD.PrintProductType.CATALOG 				= 6;
FQD.PrintProductType.STICKER 				= 7;
FQD.PrintProductType.POSTER 				= 8;
FQD.PrintProductType.ENVELOPE 				= 9;
FQD.PrintProductType.LETTERHEAD 			= 10;
FQD.PrintProductType.FOLDED_BUSINESS_CARD 	= 11;
FQD.PrintProductType.GREETING_CARD 			= 12;
FQD.PrintProductType.NOTEPAD				= 13;
FQD.PrintProductType.FOLDER 				= 15;
FQD.PrintProductType.BANNER 				= 16;	
FQD.PrintProductType.WIDE_POSTER 			= 17;
FQD.PrintProductType.WINDOW_CLING 			= 18;
FQD.PrintProductType.WINDOW_DECAL 			= 19;
FQD.PrintProductType.HANG_TAG 				= 20;
FQD.PrintProductType.TABLE_TENT 			= 21;
FQD.PrintProductType.EVENT_TICKET 			= 22;
FQD.PrintProductType.PHOTO_BOOK 			= 23;
FQD.PrintProductType.FOLDED_HANG_TAG 		= 24;	
FQD.PrintProductType.BOOKLET				= 25;
FQD.PrintProductType.CD_PACKAGE				= 26;
FQD.PrintProductType.CLUB_FLYER				= 27;
FQD.PrintProductType.COLLECTORS_CARD		= 28;
FQD.PrintProductType.DOOR_HANGER			= 29;
FQD.PrintProductType.DVD_PACKAGE			= 30;
FQD.PrintProductType.MINI_MENU				= 31;
FQD.PrintProductType.RACKCARD				= 32;
FQD.PrintProductType.ROLODEX				= 33;
FQD.PrintProductType.TENT_CARD				= 34;
FQD.PrintProductType.RIP_BUSINESS_CARD		= 35;
FQD.PrintProductType.ROLL_LABEL				= 36;
FQD.PrintProductType.YARD_SIGN				= 37;
FQD.PrintProductType.STAGGERED_CUT_FLYER	= 38;
FQD.PrintProductType.SPECIAL_SHAPE 			= 39;	
FQD.PrintProductType.PHOTO_BOOK_LAYOUT		= 40;
FQD.PrintProductType.T_SHIRT				= 10001;
FQD.PrintProductType.GENERIC_PRODUCT	    = 10000;
FQD.PrintProductType.ALUMINUM_BOARDS    	= 10017;
FQD.PrintProductType.CARDBOARDS 			= 10016;
FQD.PrintProductType.CORRUGATED_BOARDS		= 10015;
FQD.PrintProductType.FOAM_BOARDS 			= 10013;
FQD.PrintProductType.PVC_BOARDS 			= 10014;
FQD.PrintProductType.METAL_WALL_PRINTS 		= 10008;


FQD.PrintProductType.YARD_SIGN_RECTANGLE	= 0;
FQD.PrintProductType.YARD_SIGN_SQUARE		= 374;
FQD.PrintProductType.YARD_SIGN_ARROW		= 515;
FQD.PrintProductType.YARD_SIGN_CIRCLE		= 708;
FQD.PrintProductType.YARD_SIGN_OVAL			= 709;
FQD.PrintProductType.YARD_SIGN_OCTAGONE		= 710;
FQD.PrintProductType.YARD_SIGN_STAR			= 711;
FQD.PrintProductType.YARD_SIGN_HOUSE		= 712;
FQD.PrintProductType.YARD_SIGN_APARTMENT	= 713;

//Brochures
FQD.PrintProductType.IN_12_0x9_0 			= 172;
FQD.PrintProductType.IN_11_0x8_5			= 127;
FQD.PrintProductType.IN_14_0x7_0			= 721;
			
FQD.PrintProductType.CIRCLE					= 1;
FQD.PrintProductType.OVAL					= 2;
FQD.PrintProductType.STARBURST				= 3;
FQD.PrintProductType.ROUNDED_SQUARE			= 4;
FQD.PrintProductType.ROUNDED_RECTANGLE		= 5;
FQD.PrintProductType.HALF_CIRCLE			= 6;
FQD.PrintProductType.LEAF					= 7;
FQD.PrintProductType.WINK					= 8;
FQD.PrintProductType.SQUARE					= 9;

FQD.PrintProductType.HOLE_POSITION_TOP_LEFT 	= 12;
FQD.PrintProductType.HOLE_POSITION_TOP_CENTER 	= 13;
FQD.PrintProductType.HOLE_POSITION_TOP_RIGHT 	= 14;

FQD.PrintProductType.POCKET_RIGHT 	= 1;
FQD.PrintProductType.POCKET_LEFT 	= 2;
FQD.PrintProductType.POCKET_DOUBLE 	= 3;

FQD.PrintProductType.HALF_FOLD							= 1;
FQD.PrintProductType.Z_FOLD								= 2;
FQD.PrintProductType.TRI_FOLD							= 3;
FQD.PrintProductType.DOUBLE_PARALLEL_FOLD				= 4;
FQD.PrintProductType.OPEN_GATE_FOLD						= 5;
FQD.PrintProductType.CLOSED_GATE_FOLD					= 6;
FQD.PrintProductType.ACCORDION_4PANEL					= 7;
FQD.PrintProductType.ACCORDION_5PANEL					= 8;
FQD.PrintProductType.ROLL_FOLD_4PANEL					= 9;
FQD.PrintProductType.ROLL_FOLD_5PANEL					= 10;
FQD.PrintProductType.HALF_FOLD_THEN_VERTICAL_HALF_FOLD	= 11;
FQD.PrintProductType.HALF_FOLD_THEN_VERTICAL_TRI_FOLD	= 12;
FQD.PrintProductType.VERTICAL_HALF_FOLD					= 13;
FQD.PrintProductType.DOUBLE_PARALLEL_REVERSE_FOLD		= 14;

FQD.PrintProductType.PERFORATION_ONLY = 15;
FQD.PrintProductType.NUMBERING_FRONT_ONLY = 16;
FQD.PrintProductType.NUMBERING_BACK_ONLY = 17;
FQD.PrintProductType.PERFORATION_AND_NUMBERING_FRONT_ONLY = 18;
FQD.PrintProductType.PERFORATION_AND_NUMBERING_BACK_ONLY = 19;
FQD.PrintProductType.NUMBERING_COLOR_BLACK = 20;
FQD.PrintProductType.NUMBERING_COLOR_WHITE = 21;
FQD.PrintProductType.NUMBERING_COLOR_RED = 22;
FQD.PrintProductType.NUMBERING_POSITION_TOP = 23;
FQD.PrintProductType.NUMBERING_POSITION_CENTER = 24;
FQD.PrintProductType.NUMBERING_POSITION_BOTTOM = 25;

FQD.PrintProductType.SLIT_WITHOUT 		= 27;
FQD.PrintProductType.SLIT_BOTH_SIDES 	= 28;
FQD.PrintProductType.SLIT_LEFT_SIDE 	= 29;
FQD.PrintProductType.SLIT_RIGHT_SIDE 	= 30;

FQD.PrintProductType.CLOCKWISE = 1;
FQD.PrintProductType.ANTI_CLOCKWISE = 0;
FQD.PrintProductType.HORIZONTAL = 0;
FQD.PrintProductType.VERTICAL = 1;

FQD.PrintProductType.isSpecialShape = function(){
	return (config.productTypeId == FQD.PrintProductType.SPECIAL_SHAPE)? true: false;
}

FQD.PrintProductType.isDoorHanger = function(){
	return (config.productTypeId == FQD.PrintProductType.DOOR_HANGER)? true: false;
}

FQD.PrintProductType.isRIPBusinessCard = function(){
	return (config.productTypeId == FQD.PrintProductType.RIP_BUSINESS_CARD)? true: false;
}

FQD.PrintProductType.isYardSign = function(){
	return (config.productTypeId == FQD.PrintProductType.YARD_SIGN)? true: false;
}

FQD.PrintProductType.isEnvelope = function(){
	return (config.productTypeId == FQD.PrintProductType.ENVELOPE)? true: false;
}

FQD.PrintProductType.isEventTicket = function(){
	return (config.productTypeId == FQD.PrintProductType.EVENT_TICKET)? true: false;
}

FQD.PrintProductType.isCDPackage = function(){
	return (config.productTypeId == FQD.PrintProductType.CD_PACKAGE)? true: false;
}

FQD.PrintProductType.isDVDPackage = function(){
	return (config.productTypeId == FQD.PrintProductType.DVD_PACKAGE)? true: false;
}

FQD.PrintProductType.isFoldedBusinessCard = function(){
	return (config.productTypeId == FQD.PrintProductType.FOLDED_BUSINESS_CARD)? true: false;
}

FQD.PrintProductType.isFoldedHangTag = function(){
	return (config.productTypeId == FQD.PrintProductType.FOLDED_HANG_TAG)? true: false;
}

FQD.PrintProductType.isGreetingCard = function(){
	return (config.productTypeId == FQD.PrintProductType.GREETING_CARD)? true: false;
}

FQD.PrintProductType.isFolder = function(){
	return (config.productTypeId == FQD.PrintProductType.FOLDER)? true: false;
}

FQD.PrintProductType.isGenericProduct = function(){
	return (config.productTypeId >= FQD.PrintProductType.GENERIC_PRODUCT)? true: false;
}

FQD.PrintProductType.isFoldedProduct = function(){
	return (config.productTypeId == FQD.PrintProductType.BROCHURE ||
			config.productTypeId == FQD.PrintProductType.FOLDER ||
			config.productTypeId == FQD.PrintProductType.FOLDED_BUSINESS_CARD ||
			config.productTypeId == FQD.PrintProductType.FOLDED_HANG_TAG ||
			config.productTypeId == FQD.PrintProductType.GREETING_CARD ||
			config.productTypeId == FQD.PrintProductType.MINI_MENU);
}

FQD.PrintProductType.isRectangularProduct = function() {
	var isRectangularProduct = true;

	switch (config.productTypeId) {
	case FQD.PrintProductType.ENVELOPE:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.FOLDER:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.ROLODEX:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.ROLL_LABEL:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.YARD_SIGN:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.SPECIAL_SHAPE:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.ALUMINUM_BOARDS:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.CARDBOARDS:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.CORRUGATED_BOARDS:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.FOAM_BOARDS:
		isRectangularProduct = false;
		break;
	case FQD.PrintProductType.PVC_BOARDS:
		isRectangularProduct = false;
		break;
	default:
		isRectangularProduct = true;
		break;
	}
     return isRectangularProduct;
}
