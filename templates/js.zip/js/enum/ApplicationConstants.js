FQD.ApplicationConstants={};

FQD.ApplicationConstants.HORIZONTAL = "horizontal";
FQD.ApplicationConstants.VERTICAL = "vertical";
FQD.ApplicationConstants.SQUARE = "square";

