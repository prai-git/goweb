FQD.undoManager={};
FQD.undoManager.loader=false;
FQD.undoManager.undoItems=[];
FQD.undoManager.redoItems=[];

FQD.undoManager.saveHistory=function(save){
	if(save){
		var h=	{	
					id:config.activeCanvas.toString(),
					data:[]
				}
		
		for(i=0;i<config.pageNumber.length;i++){
				h.data.push(JSON.stringify(FQD.canvas.pages[i].toJSON(config.newProperties)));
		}

		
		var lastItem = FQD.undoManager.undoItems[FQD.undoManager.undoItems.length - 1];
		if(FQD.undoManager.undoItems.length == 0){
			FQD.undoManager.undoItems.push(h);
		}else if(lastItem){
			if(JSON.stringify(h.data) !== JSON.stringify(lastItem.data)){

				FQD.undoManager.undoItems.push(h);
			}
		}
		FQD.excludeFromExport("overlayElm",true);
	}
	FQD.elements.anchorUndo.removeClass("disabled");
}

FQD.undoManager.clearHistory=function(save){
	if(save){
		FQD.elements.anchorUndo.addClass("disabled");
		FQD.elements.anchorRedo.addClass("disabled");
		FQD.undoManager.undoItems.length=0;
		FQD.undoManager.redoItems.length=0;
	}
}

FQD.undoManager.removeDeletedImage=function(item,deletedImgIdList){
	var deletedImageUndoAndRedo=[];
	jQuery.each(FQD.undoManager[item],function(i,d){
		jQuery.each(d.data,function(j,k){
			var data = JSON.parse(k);
			jQuery.each(data.objects,function(ind,obj){
				if(obj.type == 'image' && obj.userUploaded == 'true'){
					var imgId=obj.filedescriptorid;
					   //imgId= imgId.slice(imgId.indexOf('_')+1, imgId.lastIndexOf("_"));
					   if(deletedImgIdList){
						   jQuery.each(deletedImgIdList,function(i,deletedId){
							   if(deletedId == imgId && deletedImageUndoAndRedo.indexOf(deletedId) < 0){
								   deletedImageUndoAndRedo.push(deletedId);
							   }
						   }); 
					 }
				}
			});
			
		});
	});
 return deletedImageUndoAndRedo;
	
}

FQD.undoManager.undo=function(){
	jQuery(".warning-msg").remove();
		  if(FQD.undoManager.undoItems.length > 0){
			  FQD.undoManager.loader=true;
			  FQD.elements.divLoadingQd.show();
			  FQD.elements.divLoaderContainer.show();
			  FQD.visualAids.drawGrid(config.gridSize,false);
			  var last,lastItem,firstItem,count=0;
			   last = FQD.undoManager.undoItems.pop();
	           FQD.undoManager.redoItems.push(last);
	           lastItem = FQD.undoManager.undoItems[FQD.undoManager.undoItems.length - 1];
	           if (lastItem !== undefined){
	        	   for(var i = 0; i < lastItem.data.length; i++){
	        		   FQD.canvas.pages[i].backgroundImage=0;
		        	   FQD.canvas.pages[i].selection=true;
		        	   FQD.undoManager.loadCanvasFromJSON(lastItem.data[i], FQD.canvas.pages[i]);
	        	   }

	        	   FQD.events.tabs(lastItem.id);
	        	   FQD.utility.setBackgroundRightProperties(lastItem.data[lastItem.id]);
	           }else{
	        		  FQD.canvas.resetCanvas();
	        		  FQD.elements.anchorUndo.addClass("disabled");
	        		  FQD.elements.divLoadingQd.hide();
	   			      FQD.elements.divLoaderContainer.hide();
	   			      FQD.undoManager.loader=false;
	           }
	           FQD.elements.anchorRedo.removeClass("disabled");
	           FQD.visualAids.drawGrid(config.gridSize,jQuery('#btnGrid').prop("checked"));
		  }
   		  
		  FQD.initializecanvas.disableInputs();
		  FQD.canvas.setCanvasSelectionTrue();
		  FQD.shapes.showEditProperties();
		  setTimeout(function(){ 
			  FQD.canvas.addNewText(); 
		  }, 100);
   	   
			FQD.visualAids.addScissors(false);
			FQD.visualAids.addScissors($('#visualAids').prop('checked'));  
}

FQD.undoManager.redo=function(){
	jQuery(".warning-msg").remove();
	  if(FQD.undoManager.redoItems.length > 0){
		  FQD.undoManager.loader=true;
		  FQD.elements.divLoadingQd.show();
		  FQD.elements.divLoaderContainer.show();
		  FQD.visualAids.drawGrid(config.gridSize,false);
		  var last,lastItem,firstItem;
		   last = FQD.undoManager.redoItems.pop();
           FQD.undoManager.undoItems.push(last);
           if (last !== undefined) {
        	   for(var i = 0; i < last.data.length; i++){
        		   FQD.canvas.pages[i].backgroundImage=0;
	        	   FQD.canvas.pages[i].selection=true;
	        	   FQD.undoManager.loadCanvasFromJSON(last.data[i], FQD.canvas.pages[i]);
        	   }
        	   FQD.events.tabs(last.id);
        	   FQD.utility.setBackgroundRightProperties(last.data[last.id]);
           }else{
        	   FQD.elements.divLoadingQd.hide();
    		   FQD.elements.divLoaderContainer.hide();
    		   FQD.undoManager.loader=false;
           }
           if(FQD.undoManager.redoItems.length == 0){
        	   FQD.elements.anchorRedo.addClass("disabled");
           }
           FQD.elements.anchorUndo.removeClass("disabled");
           FQD.visualAids.drawGrid(config.gridSize,jQuery('#btnGrid').prop("checked"));
	  }
	  
	  FQD.initializecanvas.disableInputs();
	  FQD.canvas.setCanvasSelectionTrue();
	  FQD.shapes.showEditProperties();
	  setTimeout(function(){ FQD.canvas.addNewText(); }, 100);
	  
		FQD.visualAids.addScissors(false);
		FQD.visualAids.addScissors($('#visualAids').prop('checked'));
}

FQD.undoManager.loadCanvasFromJSON=function(jsonData, canvas){
	
	var isUserUploaded=false;
	
	jsonData=FQD.imgLib.updateHDImageOnJson(jsonData);
	
	canvas.loadFromJSON(jsonData,function(){
				FQD.canvas.setElementAsperCanvas(canvas);
				FQD.initializecanvas.resetSVGOverlay(canvas);
				canvas.renderAll.bind(canvas);
				if(isUserUploaded){
					FQD.utility.unloadStoreDesign();
				}
				FQD.elements.divLoadingQd.hide();
				FQD.elements.divLoaderContainer.hide();
				FQD.undoManager.loader=false;
			},
			
			function(o, object){
			   if(object && object.type == "image" && !object.clipartPlaceholder == true){
					   if(object.id == "placeHolders"){
						   object._element=config.imgElement;
						   object.crossOrigin="anonymous";
					   }
					   if(object.userUploaded == "true"){
						   isUserUploaded=true;
					   }
			   }
			   if(object && object.type == "textbox") {
					object.toSVG = FQD.toSVGCustomize.toSVG;
			   }
			   if(object && !object.isObjectLocked){
				   object.selectable=true;
				   object.hasControls=true;
				   object.hasBorders=true;
				   object.evented=true;
				   object.setShadow(null);
				}
				if(object && object.alwaysNotselectable){
					object.selectable=false;
					object.hasControls=false;
					object.hasBorders=false;
					object.evented=false;
				}
				if(object && object.overlayElm){
					object.bringToFront();
				}
				config.loadElmCount++;
			}
	   );
}





