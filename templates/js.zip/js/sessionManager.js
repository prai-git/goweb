
var pageTitleNotification = (function (window, document) {

    var configuration = {
        currentTitle: document.title,
        interval: null
    };

    var on = function (notificationText, intervalSpeed) {
        if (!configuration.interval) {
        	configuration.currentTitle = document.title;
        	configuration.interval = window.setInterval(function() {
                document.title = (configuration.currentTitle === document.title)
                    ? notificationText
                    : configuration.currentTitle;
            }, (intervalSpeed) ? intervalSpeed : 1000);
        }
    };

    var off = function () {
        window.clearInterval(configuration.interval);
        configuration.interval = null;
        document.title = configuration.currentTitle;
    };

    return {
        on: on,
        off: off
    };

})(window, document); 


String.prototype.format = function() {
  var s = this,
      i = arguments.length;

  while (i--) {
    s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
  }
  return s;
};

!function($) {
  $.timeoutDialog = function(options) {


	  config.sessionSettings=options;

    var TimeoutDialog = {
      init: function () {
        this.setupDialogTimer();
      }, 

      setupDialogTimer: function() {
          var self = this;
          config.Timer = setTimeout(function() {
        	  self.setupDialog();

          }, ((config.sessionSettings.timeout - config.sessionSettings.countdown) * 1000));

        },

      setupDialog: function() {
        var self = this;
        self.destroyDialog();

        
        if(!config.IsUserLoggedIn){
        	
        	var title=config.sessionSettings.title+" ( "+config.sessionSettings.countdown+" "+resourcesData.sessionTimerUnit+" )";
        	 $('<div id="timeout-dialog">' +
                     '<p id="timeout-message">' + config.sessionSettings.message + '</p>' + 
                     '<p id="timeout-question">' + config.sessionSettings.question + '</p>' +
                   '</div>')
                 .appendTo('body')
                 .dialog({
                   modal: true,
                   width: 'auto',
                   minHeight: 'auto',
                   zIndex: 10000,
                   closeOnEscape: false,
                   draggable: false,
                   resizable: false,
                   dialogClass: 'timeout-dialog',
                   title: title,
                   buttons : {
                     'keep-alive-button' : { 
                       text: config.sessionSettings.extendMySession,
                       id: "timeout-keep-signin-btn",
                       click: function() {
                         self.keepAlive();
                       }
                     }
                   }
                 });
        	
        }
        else{

        	
            $('<div id="timeout-dialog">' +
                    '<p id="timeout-message">' + config.sessionSettings.LoggedInmessage.format('<span id="timeout-countdown">' + config.sessionSettings.countdown + '</span>') + '</p>' + 
                    '<p id="timeout-question">' + config.sessionSettings.loggedInQuestion + '</p>' +
                  '</div>')
                .appendTo('body')
                .dialog({
                  modal: true,
                  width: 'auto',
                  minHeight: 'auto',
                  zIndex: 10000,
                  closeOnEscape: false,
                  draggable: false,
                  resizable: false,
                  dialogClass: 'timeout-dialog',
                  title: config.sessionSettings.title,
                  buttons : {
                    'keep-alive-button' : { 
                      text: config.sessionSettings.keep_alive_button_text,
                      id: "timeout-keep-signin-btn1",
                      dialogClass:"tatti",
                      click: function() {
                        self.keepAlive();
                      }
                    },
                    'sign-out-button' : {
                      text: config.sessionSettings.sign_out_button_text,
                      id: "timeout-sign-out-button",
                      click: function() {
                        self.signOut(true,this);
                      }
                    }
                  }
                });
        }


        self.startCountdown();
      },

      destroyDialog: function(elm) {
        if ($("#timeout-dialog").length) {
          $(elm).dialog("close");
          $('#timeout-dialog').remove();
        }
      },

      startCountdown: function() {
        var self = this,
            counter = config.sessionSettings.countdown;

        config.countdown = window.setInterval(function() {
          counter -= 1;
          pageTitleNotification.on(config.sessionSettings.title, 1000);
          if(!config.IsUserLoggedIn){
              var title=config.sessionSettings.title+" ( "+counter+" "+resourcesData.sessionTimerUnit+" )";
              
              $(".timeout-dialog .ui-dialog-titlebar .ui-dialog-title").html(title);
          }else{
        	  $("#timeout-countdown").html(counter);
          }


          if (counter <= 0) {
            window.clearInterval(config.countdown);
            self.signOut(false);
          }

        }, 1000);
      },

      keepAlive: function() {
          
          $.get(config.sessionSettings.keep_alive_url, function(data) {
            });
          
          var self = this;
          this.destroyDialog();
          window.clearInterval(config.countdown);
          delete config.countdown;
          clearTimeout(config.Timer);
          delete config.Timer;
          pageTitleNotification.off();
          self.setupDialogTimer();

        
      },

      signOut: function(is_forced,elm) {
          var self = this;
          this.destroyDialog();

          if (config.sessionSettings.logout_url != null) {
          	var url=config.sessionSettings.logout_url+"?originalSessionId="+gInfo.session_id;
          	if (is_forced) {
          		//do nothing
          	} else {
          		url = url + "&logoutOnlyIfSessionAboutToExpire=true";
          	}
              $.post(url, function(data){
                  self.redirectLogout(is_forced);
              });
          }
          else {
              self.redirectLogout(is_forced);
          }
        }, 

      redirectLogout: function(is_forced){
          var target = config.sessionSettings.logout_redirect_url;
          TimeoutDialog.sessionExpired = true;
          window.location = target;
        }
    };
    config.TimeoutDialog=TimeoutDialog;
    TimeoutDialog.init();
   
  };
}(window.jQuery);

jQuery.timeoutDialog({
	   timeout:sessionTimeOut-sessionLatency, 
	   countdown: sessionCountdown, 
	   logout_redirect_url:"http://"+domainName, 
	   logout_url:"/Logout",
	   keep_alive_url: "/KeepAlive",
	   title : resourcesData.sessionExpireMessageTitle,
	   message : resourcesData.sessionExpireMessage,
	   question: resourcesData.sessionExpireQuestion,
	   keep_alive_button_text: resourcesData.yesKeepMeLoggedIn,
	   extendMySession:resourcesData.extendMySession,
	   sign_out_button_text: resourcesData.noKeepMeLoggedOut,
	   LoggedInmessage:resourcesData.loggedInSessionExpireMessage,
	   loggedInQuestion:resourcesData.loggedInSessionExpireQuestion,
	   dialog_width:500,
	   dialog_width1:560
	  });