var orderMarkedAsProblemWarning = true;
var languageClick = false;
var gInfo = {remote_ip:"",appHost:"",appWorker:"",appMode:"",appRole:""};
jQuery("html").click(function(e) {
	if(e.target.id == "languageSelect" || jQuery(e.target).parent().attr("id") == "languageSelect") {
		jQuery("#languageSelect").children("div").toggle(150);
		languageClick ? languageClick = false : languageClick = true;
	} else if(languageClick) {
		jQuery("#languageSelect").children("div").toggle(150);
		languageClick = false;
	}
});

sfHover = function() {
	if(jQuery("#nav").children("li")) {
		var sfEls = jQuery("#nav").children("li");
		var removeHeaderHover = $("midOuterWrapper");
		for (var i = 0; i < sfEls.length; i++) {
			sfEls[i].onmouseover = function() {
				this.className += " sfhover";
				$("subnav").style.display = "block";
			};
			sfEls[i].onmouseout = function() {
				this.className = this.className.replace(new RegExp(" sfhover\\b"), "");
			};
			removeHeaderHover.onmouseover = function() {
				$("subnav").style.display = "none";
			};
		}
	}
};
if (window.attachEvent) window.attachEvent("onload", sfHover);

var checkCoatingStatus = true;
function toggleOptions() {
	if(checkCoatingStatus == false) {
		document.getElementById("coatingContainer").style.display = "block";
		$src('coatingToggle', '/common/images/coating-hide-icon.gif');
		checkCoatingStatus = true;
	} else {
		checkCoatingStatus = false;
		document.getElementById("coatingContainer").style.display = "none";
		$src('coatingToggle', '/common/images/coating-expand-icon.gif');
	}
}

/*
 * re-renders a pages fixed height for pages with a variable height
 */

function updateRenderedHeight() {
	var isMSIE = /*@cc_on!@*/false;

	if(isMSIE && BrowserDetect.version < 9) {
		newHeight = $('col1').offsetHeight + 30;
		if($('col3').offsetHeight > newHeight && $('col3').offsetHeight > 640 && $('col3').display != "hidden") {
			newHeight = $('col3').offsetHeight;
		}
		else {
			if(newHeight > 640) {
				$('midOuterWrapper').style.height = newHeight + 'px';
			}
			else {
				$('midOuterWrapper').style.height = '640px';
			}
		}
		$('midOuterWrapper').style.paddingRight = '0px';
	}
}

function enableElements() {
	for (var i = 0; i < arguments.length; i++) {
		var element = $(arguments[i]);
		if (element != null) {
			element.disabled = false;
		}
	}
}

function disableElements() {
	for (var i = 0; i < arguments.length; i++) {
		var element = $(arguments[i]);
		if (element != null) {
			element.disabled = true;
		}
	}
}

function disableSelectElements() {
	for (var i = 0; i < arguments.length; i++) {
		var element = $(arguments[i]);
		if (element != null) {
			trLength = element.childNodes[0].childNodes.length;
			for (var j = 0; j < trLength; j++) {
				document.getElementById(element.id + ':' + j).disabled = true;
			}
		}
	}
}

function trimString(stringToTrim) {
	if(stringToTrim != null) {
		return stringToTrim.replace(/^\s+|\s+$/g,"");
	}
}

/*
 * userInitials is between 2 and 5 characters
 */
function validateTermsAndInitials(agreedToEULA, userInitials) {
	if(agreedToEULA == null || userInitials == null) {
		return false;
	}
	if(userInitials.value == null) {
		return false;
	}

	userInitialsLength = trimString(userInitials.value).length;
	if(agreedToEULA.checked && userInitialsLength >= 2 && userInitialsLength <= 5) {
		return true;
	}

	return false;
}

/*
 * creates an img tag for tooltips
 */
function appendImgTagForTooltip(url, item) {
	if(url == null) {
		return;
	}

	var fullPath = window.staticContentBaseUrl + url;

	var img=document.createElement("img");
	img.setAttribute('src', fullPath);
	img.setAttribute('alt', 'tooltip');
	var parent = document.getElementById(item);
	parent.appendChild(img);

}

/*
 * helper functions for static content pages
 */

function $background(id, url){
	if($(id)){
		$(id).style.backgroundImage = 'url('+window.staticContentBaseUrl + url+')';
	}
}

function $multipleBackground(className,url) {
	if(jQuery("." + className)) {
		jQuery("." + className).css("background-image",'url('+window.staticContentBaseUrl + url+')');
	}
}

function $src(id, url){
	if($(id)){
		$(id).src = window.staticContentBaseUrl + url;
	}
}

function $href(id, url){
	if($(id)){
		$(id).href = window.staticContentBaseUrl + url;
	}
}

function $unsecureHref(id, url){
	if($(id)){
		$(id).href = '//' + location.host + url;
	}
}

function $multipleSrc(name, url){
	var elements = document.getElementsByName(name);
	if(elements != null){
		for(var i=0; i< elements.length; i++){
			elements[i].src = window.staticContentBaseUrl + url;
		}
	}
}

function $multipleSrcClass(className,url) {
	if(jQuery("." + className)) {
		jQuery("." + className).attr("src",window.staticContentBaseUrl + url);
	}
}

function $multipleHrefAppend(name){
	var elements = document.getElementsByName(name);
	if(elements != null){
		for(var i=0; i< elements.length; i++){
			elements[i].href = window.staticContentBaseUrl + elements[i].rel;
		}
	}
}

function getEncodedPrintJob(printJob){
	return window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(JSON.stringify(printJob))));
}

function getRandom(max, min){
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getUUID() {
	return generateRandomStr() + generateRandomStr() + '-' + generateRandomStr() + '-' + generateRandomStr() + '-' +generateRandomStr() + '-' + generateRandomStr() + generateRandomStr() + generateRandomStr();
}

function generateRandomStr() {
   return Math.floor((1 + Math.random()) * 0x10000)
    .toString(16)
    .substring(1);
}
	

function roundTo(val, dec){
	var result = Math.round(val*Math.pow(10,dec))/Math.pow(10,dec);
	return result;
}

function getMinimum(vals){
	return Math.min.apply(Math, vals);
}

function getMaximum(vals){
	return Math.max.apply(Math, vals);
}

function equalHeight(group) {
   tallest = 0;
   group.each(function() {
	  thisHeight = $(this).height();
	  if(thisHeight > tallest) {
		 tallest = thisHeight;
	  }
   });
   group.height(tallest);
}

function equalHeight(group) {
   tallest = 0;
   group.each(function() {
	  thisHeight = jQuery(this).height();
	  group.height(thisHeight);
	  if(thisHeight > tallest) {
		 tallest = thisHeight;
	  }
   });
   group.height(tallest);
}

var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
		
		if((document.all && window.ActiveXObject && navigator.userAgent.toLowerCase().indexOf("msie") > -1 && navigator.userAgent.toLowerCase().indexOf("opera") == -1) || (navigator.userAgent.toLowerCase().indexOf("like gecko") > -1 && navigator.userAgent.toLowerCase().indexOf("11.") > -1)){
			this.browser="Explorer";
		}
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++) {
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{   string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{	   // for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{	   // for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]

};
BrowserDetect.init();

function isCookieSettingTargeting() {
	return window.isCookiePrivacyPolicyEnabled && window.cookiePrivacySetting == 'TARGETING';
}

function isCookieSettingFunctional() {
	window.isCookiePrivacyPolicyEnabled && window.cookiePrivacySetting == 'FUNCTIONAL';
}

function isCookieSettingStrictlyNecessary() {
	window.isCookiePrivacyPolicyEnabled && window.cookiePrivacySetting == 'STRICTLY_NECESSARY';
}

function filterOptionCheck(obj , isMSIE) {
	if(obj.val() == '' || obj.val() == 'null' || obj.val() == null) {
		obj.removeClass('filterOptionInUse');

	} else {
		obj.addClass('filterOptionInUse');

		if (isMSIE) {
			if (obj[0].nodeName.toLowerCase() === 'select') {
				obj.addClass('filterOptionInUseIE');
			}
		}
	}
}

function initializeFilter() {

	var isMSIE = BrowserDetect.browser.toLowerCase() == 'explorer' && BrowserDetect.version < 8;

	var applyFilterButton = jQuery("#listFilterForm input.applyFilterButton");

	// This will loop through all select boxes and update the look of the filters that are changed
	jQuery("#listFilterForm select").each(function(){
		filterOptionCheck(jQuery(this), isMSIE);
	});

	jQuery("#listFilterForm textarea").each(function(){
		filterOptionCheck(jQuery(this), isMSIE);
	});

	// This will loop through all input boxes and update the look of the filters that are changed
	jQuery("#listFilterForm input[type=text]").each(function(){
		filterOptionCheck(jQuery(this), isMSIE);
	});

	// This will add a change event on all select boxes of the filter so that as the user changes filter options,
	// the select style will change.
	jQuery("#listFilterForm select").change(function(){
		filterOptionCheck(jQuery(this), isMSIE);
		filterOptionCheck(applyFilterButton, isMSIE);
	});

	jQuery("#listFilterForm input[type=text]").change(function(){
		filterOptionCheck(jQuery(this), isMSIE);
		filterOptionCheck(applyFilterButton, isMSIE);
	});

	jQuery("#listFilterForm select.filterListSelectOneMenu").change(function(){
		filterOptionCheck(applyFilterButton, isMSIE);
	});
	
	jQuery("#listFilterForm textarea").change(function(){
		filterOptionCheck(jQuery(this), isMSIE);
	});

}

function updateApplyFilterButton(){

	var applyFilterButton = jQuery('#listFilterForm input.applyFilterButton');
	applyFilterButton.removeClass('filterOptionInUse filterOptionInUseIE');

}

function generateCustomProduct(productJSON) {
	startConversation();

	var jsonText = JSON.stringify(productJSON);

	generatePrintOrderItem(jsonText);
}

var winPrint = false;

/*Partial printing of the designing instructions page*/
function printSegment(myDiv) {
	jQuery('.headerText').hide();
	var content = jQuery(myDiv.parentNode).find('#popupWrapper');
	winPrint = window.open();
	
	if(BrowserDetect.browser.toLowerCase() === 'safari' || BrowserDetect.browser.toLowerCase() === 'explorer') {	
		
		var elem = jQuery(content).find("div#tempPrintWrapper");
		if(elem) {
			elem.remove();
		}
		
		jQuery(content).append('<div id="tempPrintWrapper" style="margin-top: 20px;">' + 
								'<input type="button" value="Print" style="width: 150px;margin: 0 5px;" onClick="window.print()" />' + 
								'<input type="button" value="Close" style="width: 150px;margin: 0 5px;" onClick="window.close()" />' + 
								'</div>');
		winPrint.document.write(content.html());

		if(BrowserDetect.browser.toLowerCase() === 'explorer') {
			winPrint.location.reload();
		}

	} else {
		winPrint.document.write(content.html());
		winPrint.print();                                             // Print preview
		winPrint.close();
	}
	jQuery(content).find("div#tempPrintWrapper").css('display', 'none');
	jQuery('.headerText').show();
	return false;
}


function hidePrintModalPanel(component, errorMessage) {
	if(BrowserDetect.browser.toLowerCase() === 'chrome' && winPrint && !winPrint.closed){  //checks to see if window is open
		alert(errorMessage);
		winPrint.focus();
		return true;
	} else {
		component.hide();
	}
	return true;
}

/*testimonal name check*/
function testimonialNameCheck(elem,errMessage1,errMessage2) {
	var name = elem.value;
	
	if(name) {
		//space, special chars and number check, basically only letters 
		if(name.charCodeAt(0) < 65 || name.charCodeAt(0) > 122) {
			elem.value = "";
			alert(errMessage1);
			return false;
		}
		if(name.charCodeAt(0) > 90 && name.charCodeAt(0) < 97) {
			elem.value = "";
			alert(errMessage1);
			return false;
		}
		//length check
		if(jQuery.trim(name).length < 2) {
			elem.value = "";
			alert(errMessage2);
			return false;
		}
	}
}

/*General filter validaion*/
function filterValidation(entityName) {
	if(entityName === 'AbstractOrderItem') {
		var createDate = jQuery("input[id*='createTimeStartCalendarInputDate']").val();
		if(!createDate || createDate.length < 1) {
			alert('Create Time Start is required field for filter!');
			return false;
		}		
	}
	
	return true;
}

function holidayValidation(errMessage) {
	var holidayName = jQuery("[id *= 'holidayNameDecorationInputText']").val();
	var holidayDate = jQuery("[id *= 'holidayDateCalendarInputDate']").val();
	var holidayIsEnabled = jQuery("[id *= 'countryHolidayEnabledSelectBooleanCheckbox']").prop('checked');
	
	if(holidayName && holidayName.length > 2 && holidayDate && holidayDate.length > 0) {
		return true;
	}
	
	alert(errMessage);
	
	return false;
}

/*Special char validation on Company input*/
function checkSpecialChars(input) {
	if(!input) return;
	
	var companyName = jQuery(input).val();
	if(!companyName) return;
	
	var noSpeciaCharCompanyName = companyName.replace(/[^\w\s]/gi, '');
	jQuery(input).val(noSpeciaCharCompanyName);
}

/*Order page buttons alignment fixxer*/
function fixWhiteSpace() {
	var num = 0;
	var isMSIE = BrowserDetect.browser.toLowerCase() == 'explorer' && BrowserDetect.version < 11;
	
	if(isMSIE){
		jQuery('#mainPanel li').each(function(index, elem) {
			if(jQuery(elem).children().length == 0 && jQuery(elem).text() == '' ) {
				jQuery(elem).remove();
				num++;
			}
		});
	}else{
	    jQuery('#mainPanel li').each(function(index, elem) {
		    if(jQuery(elem).children().length == 0 && jQuery(elem).text().trim() == '' ) {// if only is white space
			    jQuery(elem).remove();
			    num++;
		    }
	    });
	}
}

jQuery( window ).resize( function() {
  config.isWindowResized=true;
  var isToolOn = jQuery('#fb_screenshot').length;
    if( isToolOn == 1 )
      {
        jQuery('#fb_screenshot').remove();
          jQuery( window ).unbind( "scroll" );
        return;
      }
});

//feedback tool START

function gpFeedback(gInfo) {
	var appHost='',appWorker='',remote_ip='',appMode='',appRole='',version='',session_id='';
	if(gInfo.appHost)
	  {
		appHost=gInfo.appHost;
     }
	if(gInfo.appWorker)
	  {
		appWorker=gInfo.appWorker;
     }
	if(gInfo.remote_ip)
	  {
		remote_ip=gInfo.remote_ip;
    }
	if(gInfo.appMode)
	  {
		appMode=gInfo.appMode;
    }
	if(gInfo.appRole)
	  {
		appRole=gInfo.appRole;
    }
	if(gInfo.version)
	  {
		version=gInfo.version;
    }
	if(gInfo.session_id)
	  {
		session_id=gInfo.session_id;
    }
	
	var isToolOn=jQuery('#fb_screenshot').length;
    if( isToolOn == 1 )
    {
        jQuery('#fb_screenshot').remove();
          jQuery( window ).unbind( "scroll" );
        return;
    }
	
    jQuery( "body" ).append("<div id='fb_screenshot'> <iframe id='fb_main' frameBorder='0' wmode='Opaque' allowTransparency='true'></iframe></div>");
	
	scrollX = window.pageXOffset, scrollY = window.window.pageYOffset;
	
    jQuery( window ).scroll(function(){
        window.scrollTo(scrollX, scrollY);
    });
    
	jQuery('#fb_screenshot').css({
        'position' : 'fixed',
        left : '0px',
        top : '0px',
        height:'100%',
        width:'100%',
        'z-index': '2147483646'
    });
    
	jQuery('#fb_main').css({
        height:'100%',
        width:'100%'
    });
	
	$src('fb_main','/templates/gp_feedback/Feedback.html?'+appHost+'&'+appWorker+'&'+remote_ip+'&'+appMode+'&'+appRole+'&'+version+'&'+session_id);
	
	
	//Create IE + others compatible event handler
	var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
	var eventer = window[eventMethod];
	var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";

	// Listen to message from child window
	eventer(messageEvent,function(e) {
	  jQuery('#fb_screenshot').remove();
	},false);
	
	return; 
}
var customAlerCallback;
function customAlertBox(boxType,cancelBtn,okBtn,message,callback){
	customAlerCallback=callback;
	var box='<div class="customAlertBox customAlertBoxWrapper"></div>\
			 <div class="customAlertBox customAlertBoxElements">\
			 <div style="padding:20px;">'+message+'</div>\
			 <div class="customAlertBoxFooter">\
			 <button id="customCancelBtn" onclick="removeCustomAlertBox(false);">'+cancelBtn+'</button>\
			 <button id="customOkBtn" onclick="removeCustomAlertBox(true);">'+okBtn+'</button></div>\
		     </div>';
	jQuery("body").append(box);
	if(boxType == "alert"){
		jQuery("#customCancelBtn").remove();
	}
	var w=jQuery(".customAlertBoxElements").width(),
	h=jQuery(".customAlertBoxElements").height();
	jQuery(".customAlertBoxElements").css({
		marginLeft:-(w/2)+"px"
	});
}
function removeCustomAlertBox(btn){
	if(typeof customAlerCallback === 'function'){
		customAlerCallback(btn);
    }
	jQuery(".customAlertBox").remove();
}

var customAlerCallback1, customAlerCallback2, customAlerCallback3;
function standardPopup(message, lblButton1, lblButton2, lblButton3, callback1, callback2, callback3){
	if(message == "alert"){
		jQuery("#customCancelBtn").remove();
	}
	customAlerCallback1=callback1;
	customAlerCallback2=callback2;
	customAlerCallback3=callback3;
	var box='<div class="customAlertBox customAlertBoxWrapper"></div>\
			 <div class="customAlertBox customAlertBoxElements">\
			 <div style="padding:20px;">'+message+'</div>\
			 <div class="customAlertBoxFooter">\
			 <button id="button1" onclick="closeStandardPopup(1);">'+lblButton1+'</button>\
			 <button id="button2" onclick="closeStandardPopup(2);">'+lblButton2+'</button>\
			 <button id="button3" onclick="closeStandardPopup(3);">'+lblButton3+'</button></div>\
		     </div>';
	jQuery("body").append(box);
	
	if(lblButton2 == '' || lblButton2 == null)
		jQuery("#button2").remove();
	if(lblButton3 == '' || lblButton3 == null)
		jQuery("#button3").remove();
	
	var w = jQuery(".customAlertBoxElements").width(),
	    h = jQuery(".customAlertBoxElements").height();
	
	jQuery(".customAlertBoxElements").css({
		marginLeft:-(w/2)+"px"
	});
}
function closeStandardPopup(callback){
	if(callback == 1 && typeof customAlerCallback1 === 'function'){
		customAlerCallback1();
    }
	if(callback == 2 && typeof customAlerCallback2 === 'function'){
		customAlerCallback2();
    }
	if(callback == 3 && typeof customAlerCallback3 === 'function'){
		customAlerCallback3();
    }
	jQuery(".customAlertBox").remove();
}

jQuery(document).ready(function() {
	serverInfoValue     = document.lastChild.nodeValue;
	if(serverInfoValue) {
		serverInfo       = serverInfoValue.match(/Host:.*?\[(.*?)\] Worker:.*?\[(.*?)\] Remote IP:.*?\[(.*?)\] Mode:.*?\[(.*?)\] Role:.*?\[(.*?)\] Version:.*?\[(.*?)\] (Session ID:.*?\[(.*?)\])?/i);
		if(serverInfo) {
			gInfo.appHost    = serverInfo[1].toLowerCase();
			gInfo.appWorker  = serverInfo[2].toLowerCase();
			gInfo.remote_ip  = serverInfo[3].toLowerCase();
			gInfo.appMode    = serverInfo[4].toLowerCase();
			gInfo.appRole    = serverInfo[5].toLowerCase();
			gInfo.version    = serverInfo[6];
			gInfo.session_id = null;
			
			if(serverInfo[7]) {
				sessionInfo = serverInfo[7].match(/Session ID:.*\[(.*?)\]/i);
				if(sessionInfo) {
					gInfo.session_id = sessionInfo[1];
				}
			}
			
			pageBody        = document.body;
			urlHost         = window.location.host;
			
			if( urlHost.indexOf('sandbox') != -1 ) {
				gInfo.appMode = 'sandbox';
			}
			
			if(gInfo.appMode == 'testing' || gInfo.appMode == 'staging' || gInfo.appMode == 'sandbox') {
				if( gInfo.appRole == 'anonymous' ) {
					// top left
					topLeftATag = document.createElement('a');
					topLeftATag.setAttribute('href','javascript:void(0);');
					topLeftATag.setAttribute('onclick','gpFeedback('+JSON.stringify(gInfo)+'); return false;');
					topLeftATag.setAttribute('style','position:fixed; left:0px; top:0px; text-decoration:none; z-index:2147483647');
					
					topLeftImgTag = document.createElement('img');
					topLeftImgTag.setAttribute('id','topLeftImgTag');
					topLeftImgTag.setAttribute('style','position:relative; border:0px;');
					
					topLeftATag.appendChild(topLeftImgTag);
					
					// top right
			
					topRightATag = document.createElement('a');
					topRightATag.setAttribute('href','javascript:void(0);');
					topRightATag.setAttribute('onclick','gpFeedback('+JSON.stringify(gInfo)+'); return false;');
					topRightATag.setAttribute('style','position:fixed; right:0px; top:0px; text-decoration:none; z-index:2147483647');
					
					topRightImgTag = document.createElement('img');
					topRightImgTag.setAttribute('id','topRightImgTag');
					topRightImgTag.setAttribute('style','position:relative; border:0px;');
					
					topRightATag.appendChild(topRightImgTag);
			
					// bottom left
					bottomLeftATag = document.createElement('a');
					bottomLeftATag.setAttribute('href','javascript:void(0);');
					bottomLeftATag.setAttribute('onclick','gpFeedback('+JSON.stringify(gInfo)+'); return false;');
					bottomLeftATag.setAttribute('style','position:fixed; left:0px; bottom:0px; text-decoration:none; z-index:2147483647');
					
					bottomLeftImgTag = document.createElement('img');
					bottomLeftImgTag.setAttribute('id','bottomLeftImgTag');
					bottomLeftImgTag.setAttribute('style','position:relative; border:0px;');
					
					bottomLeftATag.appendChild(bottomLeftImgTag);
				}
				// bottom right
				bottomRightATag = document.createElement('a');
				bottomRightATag.setAttribute('href','javascript:void(0);');
				bottomRightATag.setAttribute('onclick','gpFeedback('+JSON.stringify(gInfo)+'); return false;');
				bottomRightATag.setAttribute('style','position:fixed; right:0px; bottom:0px; text-decoration:none; z-index:2147483647');
		
				bottomRightImgTag = document.createElement('img');
				bottomRightImgTag.setAttribute('id','bottomRightImgTag');
				bottomRightImgTag.setAttribute('style','position:relative; border:0px;');
				
				bottomRightATag.appendChild(bottomRightImgTag);
				
				// add all to body
				if( gInfo.appRole == 'anonymous' ) {
					pageBody.appendChild(topLeftATag);
					pageBody.appendChild(topRightATag);
					pageBody.appendChild(bottomLeftATag);
					pageBody.appendChild(bottomRightATag);
				} else {	
					pageBody.appendChild(bottomRightATag);
				}
				
				if( gInfo.appRole == 'anonymous' ) {
					$src( 'topLeftImgTag'     , '/common/images/release/'+ gInfo.appMode +'_s01_tl.png' );
					$src( 'topRightImgTag'    , '/common/images/release/'+ gInfo.appMode +'_s01_tr.png' );
					$src( 'bottomLeftImgTag'  , '/common/images/release/'+ gInfo.appMode +'_s01_bl.png' );
					$src( 'bottomRightImgTag' , '/common/images/release/'+ gInfo.appMode +'_s01_br.png' );
				} else {
					$src( 'bottomRightImgTag' , '/common/images/release/'+ gInfo.appMode +'_s01_br.png' );
				}
			}
		}
	}
	
});


// feedback tool END