/*******************************************************
 * 
 * Responsible for initializing application
 * 
 ****************************************************/
jQuery(document).ready(function(){
	FQD.init();
});