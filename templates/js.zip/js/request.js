FQD.request={};
FQD.request.getData=function(param,method,dType,url ,sucessCallback,errorCallback){
    jQuery.ajax({
    	mimeType: 'text/plain; charset=UTF-8',
        type: method,
        url: url,
        dataType: dType,
        data:param,
        success: sucessCallback,
        error: errorCallback,
        xhrFields:{
	        withCredentials: true
	     }
    });
}

// example to get data

/*FQD.request.getData({"responseCode":0},"post","json","/CountryJsonAction",function(data){
	console.log(data);
});*/
	