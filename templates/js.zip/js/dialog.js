/**
 * 
 */
FQD.dialog={
	init:function(){
	},
	
	wizard:[],
	
	loadPageSelectionDialog: function()
	{
		FQD.dialog.wizard.push("#frontBackSelection");
		FQD.view.getView(FQD.elements.frontBackSelection, "documentSettings/pageOptionsView.html", FQD.dialog.loadPageSelectionData);
		
		if(config.productDetails.roundCorners != undefined){
			FQD.dialog.wizard.push("#frontBackCornerOptions");
			FQD.view.getView(FQD.elements.frontBackCornerOptions, "documentSettings/cornerOptionsView.html", FQD.dialog.loadPageSelectionCornerOptionData);
		}
		
		if(config.productDetails.holePositionOptions != undefined){
			FQD.dialog.wizard.push("#holeOptions");
			FQD.view.getView(FQD.elements.holeOptions, "documentSettings/holeOptionsView.html", FQD.dialog.loadHoleOptionData);
		}
		
		if(config.productDetails.perforationAndNumberingOptions != undefined){
			FQD.dialog.wizard.push("#perforationOptions");
			FQD.view.getView(FQD.elements.perforationOptions, "documentSettings/perforationOptionsView.html", FQD.dialog.loadPerforationOptionData);
		}
		
		if(config.productDetails.foldingOptions != undefined){
			if(config.productDetails.foldingOptions.length == 1 || FQD.PrintProductType.isFoldedBusinessCard() || FQD.PrintProductType.isFoldedHangTag() || FQD.PrintProductType.isGreetingCard()){
				config.foldingId = parseInt(config.productDetails.foldingOptions[0].id);
				config.productDetails.printJob.options.printProductFoldingId = config.foldingId;
			}
			else{
				FQD.dialog.wizard.push("#foldingOptions");
				FQD.view.getView(FQD.elements.foldingOptions, "documentSettings/foldingOptionsView.html", FQD.dialog.loadFoldingOptionData);
			}
		}
		
		if(config.productDetails.pocketOptions != undefined){
			FQD.dialog.wizard.push("#pocketOptions");
			FQD.view.getView(FQD.elements.pocketOptions, "documentSettings/pocketOptionsView.html", FQD.dialog.loadPocketOptionsData);
		}
	},
		
	loadPageSelectionData:function()
	{
		if(config.productDetails.action == "3" || 
		   config.productDetails.action == "5" ||
		   config.productDetails.action == "6" ||
		   config.productDetails.action == "7")
		{
	    	return;
	    }
		
		var numPages = -1;
		var selected;
		var folderPath = config.resourcePath + config.productIconPath;
		var frontString = resourcesData.lbl_front;
		var backString = resourcesData.lbl_front_and_back;
		
	    FQD.dialog.setProductDescription();
	    $('#fqdMsgPageChoice').html(fqdMsgPageChoice);
	    
	    if(config.productDetails.pages != null && config.productDetails.pages.length > 0)
	    	numPages = (config.productDetails.pages.length > 1)? config.productDetails.pages.length: config.productDetails.pages[0];
	    
	    loadLocaleData();
	    
	    if(config.productDetails.pages.length == 1){
	    	FQD.dialog.setPagesOptions(numPages);
	    	FQD.dialog.gotoNextWizard();
	    	
	    	if(FQD.PrintProductType.isFoldedProduct())
	    		frontString = resourcesData.lbl_outside_and_inside;
	    }
	    else if(config.productDetails.pages.length == 2){
	    	var selectorData = FQD.products.getTwoPageData();
		    
		    $("#innerWindowFrontBack .front").css('background', 'url(' + folderPath + selectorData.frontOff+') no-repeat');
			$("#innerWindowFrontBack .frontBack").css('background', 'url(' + folderPath + selectorData.frontBackOff+') no-repeat');
			$("#innerWindowFrontBack .front").hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + selectorData.frontOn+') no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + selectorData.frontOff+') no-repeat');
					}
			);
			
			$("#innerWindowFrontBack .front").click(
					function(){
						$(this).css('background', 'url(' + folderPath + selectorData.frontOn+') no-repeat');
						$("#innerWindowFrontBack .frontBack").css('background', 'url(' + folderPath + selectorData.frontBackOff+') no-repeat');
						$(this).addClass("selected");
						$("#innerWindowFrontBack .frontBack").removeClass("selected");
					}
			);
			
			
			$("#innerWindowFrontBack .frontBack").hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + selectorData.frontBackOn+') no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + selectorData.frontBackOff+') no-repeat');
					}
			);  
			
			$("#innerWindowFrontBack .frontBack").click(
					function(){
						$(this).css('background', 'url(' + folderPath + selectorData.frontBackOn+') no-repeat');
						$("#innerWindowFrontBack .front").css('background', 'url(' + folderPath + selectorData.frontOff+') no-repeat');
						$(this).addClass("selected");
						$("#innerWindowFrontBack .front").removeClass("selected");
					}
			);
			
			$('#frontBackCancel').click(function(){
		    	history.go(-1);
		    });
			
			 $('#frontBackNext').click(
					 function(){
						 var selected = $('#innerWindowFrontBack .selected');
						 if(selected.length > 0)
						 {   
							 
							 var val = selected.attr("val");
							 FQD.dialog.setPagesOptions(val);
							 FQD.dialog.gotoNextWizard();
						 }
						 else{
							// alert(fqdSelectOption);
							 standardPopup(fqdSelectOption, 'Ok', '', '', function(){});

						 }
					 }
			 );
			 FQD.elements.frontBackSelection.show();
			 
			 if(FQD.PrintProductType.isFoldedProduct()){
				 if(FQD.PrintProductType.isFolder()){
					 frontString = resourcesData.lbl_outside_pocket_only;
					 backString = resourcesData.lbl_outside_pocket_and_inside;
				 }else{
					 frontString = resourcesData.lbl_outside_only;
					 backString = resourcesData.lbl_outside_and_inside;
				 }
			 }
	    }
	    
	    $("#frontOptBtnLbl")[0].innerHTML = frontString;
	    $("#frontBackOptBtnLbl")[0].innerHTML = backString;
	},
	
	loadPageSelectionCornerOptionData:function()
	{	
		FQD.dialog.setProductDescription();
		$('#fqdCornerOptionMessage').html(fqdCornerOptionMessage);
	    $('#fqdSquareCornerWarningMessage').html(fqdSquareCornerWarningMessage);
	    
	    var folderPath = config.resourcePath + config.productIconPath;
		var imgSquareOff = folderPath + "square-off.png";
		var imgRoundOff  = folderPath + "round-off.png";
		var imgSquareOn  = folderPath + "square-on.png";
		var imgRoundOn   = folderPath + "round-on.png";
		
		loadLocaleData();
		
		$("#innerWindowCornerOptionFrontBack .front").css('background', 'url(' + imgSquareOff + ') no-repeat');
		$("#innerWindowCornerOptionFrontBack .frontBack").css('background', 'url(' + imgRoundOff + ') no-repeat');
		
		$("#innerWindowCornerOptionFrontBack .front").hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + imgSquareOn +') no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + imgSquareOff +') no-repeat');
				}
		);
		
		$("#innerWindowCornerOptionFrontBack .front").click(
				function(){
					$(this).css('background', 'url(' + imgSquareOn + ') no-repeat');
					$("#innerWindowCornerOptionFrontBack .frontBack").css('background', 'url(' + imgRoundOff + ') no-repeat');
					$(this).addClass("selected");
					$("#innerWindowCornerOptionFrontBack .frontBack").removeClass("selected");
					$("#fqdSquareCornerWarningMessage").css("visibility","hidden");
				}
		);
		
		$("#innerWindowCornerOptionFrontBack .frontBack").hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + imgRoundOn +') no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + imgRoundOff +') no-repeat');
				}
		);
		$("#innerWindowCornerOptionFrontBack .frontBack").click(
				function(){
					$(this).css('background', 'url(' + imgRoundOn + ') no-repeat');
					$("#innerWindowCornerOptionFrontBack .front").css('background', 'url(' + imgSquareOff + ') no-repeat');
					$(this).addClass("selected");
					$("#innerWindowCornerOptionFrontBack .front").removeClass("selected");
					$("#fqdSquareCornerWarningMessage").css("visibility","visible");
					
				}
		);
		
		$('#innerWindowCornerOptionFrontBack #frontBackCancel').click(function(){
	    	history.go(-1);
	    });
		
		$('#innerWindowCornerOptionFrontBack #frontBackNext').click(
				function(){
					var selected = $('#innerWindowCornerOptionFrontBack .selected');
					if(selected.length > 0)
					{
						var val = selected.attr("val");
						config.isPageRoundCorner = (val == "2")? "true": "false";
						config.productDetails.printJob.options.roundCorners = (config.isPageRoundCorner == "true")? config.productDetails.roundCorners.id: 0;
						FQD.dialog.gotoNextWizard();
					}
					else{
						// alert(fqdSelectOption);
						 standardPopup(fqdSelectOption, 'Ok', '', '', function(){});
					}
				}
		);
	},
	
	loadHoleOptionData:function(){
		FQD.dialog.setProductDescription();
		$('#fqdMsgHoleChoice').html(fqdMsgHoleChoice);
		
		var xpos = 0;
		var len = config.productDetails.holePositionOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		
		for(var i = 0; i < len; i++){
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.left = xpos+"px";
			
			xpos += 100;
			
			var selectorData = FQD.products.getHolePositionData(config.productDetails.holePositionOptions[i].id);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			
			if(config.holeOptionId == config.productDetails.holePositionOptions[i].id){
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
				$(iconDiv).addClass("selected");
			}else{
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			}
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = config.productDetails.holePositionOptions[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.holeOptionId = parseInt(config.productDetails.holePositionOptions[parseInt(this.id)].id);
						config.productDetails.printJob.options.holePosition = config.holeOptionId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
					}
			);
			
			jQuery("#innerWindowHoleOptions #optionsBar").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#innerWindowHoleOptions #optionsBar").append(clearDiv);
			}
			
			var btnBarWidth = (110 * len) + 10;
			jQuery("#innerWindowHoleOptions #optionsBar").css('width', btnBarWidth+'px');
		}
		
		$('#frontBackCancel').click(function(){
	    	history.go(-1);
	    });
		
		 $('#innerWindowHoleOptions #frontBackNext').click(
				 function(){
					 if(config.holeOptionId > 0)
						 FQD.dialog.gotoNextWizard();
					 else
						// alert(fqdSelectOption);
						 standardPopup(fqdSelectOption, 'Ok', '', '', function(){});
				 }
		 );
	},
	
	loadPerforationOptionData:function(){
		FQD.dialog.setProductDescription();
		$('#fqdMsgPerforationChoice').html(fqdMsgPerforationChoice);
		loadLocaleData();
		var xpos = 0;
		var len = config.productDetails.numberingPositionOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options2 = [];
		var flag = true;
		
		for(var i = 0; i < len; i++){
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.left = xpos+"px";
			xpos += 100;
			
			var selectorData = FQD.products.getNumberPositionData(config.productDetails.numberingPositionOptions[i].id);
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = config.productDetails.numberingPositionOptions[i].displayName;
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options2.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options2[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options2[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.numberingPositionId = parseInt(config.productDetails.numberingPositionOptions[parseInt(this.id)].id);
						config.productDetails.printJob.options.numberingPosition = config.numberingPositionId;
						$(this).css('background', 'url(' + folderPath + options2[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options2.length;j++){
							if(options2[j].icon.id != this.id){
								$(options2[j].icon).css('background', 'url(' + folderPath + options2[j].data.iconOff+') center  no-repeat');
								$(options2[j].icon).removeClass("selected");
							}
						}
					}
			);
			
			jQuery("#innerWindowPerforationOptions #optionsBar2").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#innerWindowPerforationOptions #optionsBar2").append(clearDiv);
			}
			
			var btnBarWidth = (110 * len) + 10;
			jQuery("#innerWindowPerforationOptions #optionsBar2").css('width', btnBarWidth+'px');
			jQuery("#innerWindowPerforationOptions").css('height', '490px');
			config.productDetails.printJob.options.numberingPosition = config.productDetails.numberingPositionOptions[0].id
		}
		
		var xpos = 0;
		var len = config.productDetails.perforationAndNumberingOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		
		for(var i = 0; i < len; i++){
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.left = xpos+"px";
			
			xpos += 100;
			
			var selectorData = FQD.products.getPerforationData(config.productDetails.perforationAndNumberingOptions[i].id);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = config.productDetails.perforationAndNumberingOptions[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.perforationAndNumberingId = parseInt(config.productDetails.perforationAndNumberingOptions[parseInt(this.id)].id);
						config.productDetails.printJob.options.perforationAndNumbering = config.perforationAndNumberingId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
						setNumberingPositionVisibilty(config.perforationAndNumberingId == FQD.PrintProductType.PERFORATION_ONLY);
						
						if(config.perforationAndNumberingId != FQD.PrintProductType.PERFORATION_ONLY && flag){
							config.numberingPositionId = config.productDetails.printJob.options.numberingPosition;
							$(options2[0].icon).css('background', 'url(' + folderPath + options2[0].data.iconOn+') center  no-repeat');
							$(options2[0].icon).addClass("selected");
							flag = false;
						}
					}
			);
			
			jQuery("#innerWindowPerforationOptions #optionsBar").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#innerWindowPerforationOptions #optionsBar").append(clearDiv);
			}
			
			var btnBarWidth = (110 * len) + 10;
			jQuery("#innerWindowPerforationOptions #optionsBar").css('width', btnBarWidth+'px');
		}
		
		function setNumberingPositionVisibilty(f){
			if(!f){
				jQuery("#innerWindowPerforationOptions #tlNumPos").show();
				jQuery("#innerWindowPerforationOptions #optionsBar2").show();
			}else{
				jQuery("#innerWindowPerforationOptions #tlNumPos").hide();
				jQuery("#innerWindowPerforationOptions #optionsBar2").hide();
			}
		}
		
		$('#innerWindowPerforationOptions #frontBackCancel').click(function(){
	    	history.go(-1);
	    });
		
		$('#innerWindowPerforationOptions #frontBackNext').click(
				function(){
					if(config.perforationAndNumberingId > 0){
						if(config.perforationAndNumberingId == FQD.PrintProductType.PERFORATION_ONLY){
							config.numberingPositionId = config.productDetails.printJob.options.numberingPosition;
							config.productDetails.printJob.options.numberingPosition = null;
							FQD.dialog.gotoNextWizard();
						}else if(config.numberingPositionId > 0)
							FQD.dialog.gotoNextWizard();
						else
							 standardPopup(fqdSelectOption, 'Ok', '', '', function(){});
					} 
					else
						 standardPopup(fqdSelectOption, 'Ok', '', '', function(){});
					
					if(config.productDetails.numberingColorOptions.length > 0)
						config.productDetails.printJob.options.numberingColor = config.productDetails.numberingColorOptions[0].id;
				 }
		);
	},
	
	loadFoldingOptionData:function(){
		FQD.dialog.setProductDescription();
		$('#fqdMsgFoldChoice').html(fqdMsgFoldChoice);
		
		var xpos = 0;
		var len = config.productDetails.foldingOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		
		for(var i = 0; i < len; i++){
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.padding = "5px";
			optDiv.style.width = "75px";
			
			var selectorData = FQD.products.getFoldingOptionsData(config.productDetails.foldingOptions[i].id);
			loadLocaleData();
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			$(iconLblDiv).css("width", "76px");
			iconLblDiv.innerHTML = config.productDetails.foldingOptions[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.foldingId = parseInt(config.productDetails.foldingOptions[parseInt(this.id)].id);
						config.productDetails.printJob.options.printProductFoldingId = config.foldingId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
						
						FQD.mainScreen.applyFoldChange(config.foldingId);
					}
			);
			
			jQuery("#innerWindowFoldingOptions #optionsBar").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#innerWindowFoldingOptions #optionsBar").append(clearDiv);
			}
			
			var btnBarWidth = (85*len);
			if(btnBarWidth >= 510)
				jQuery("#innerWindowFoldingOptions #optionsBar").css('margin-left', '85px');
			else
				jQuery("#innerWindowFoldingOptions #optionsBar").css('margin-left', (680-btnBarWidth)/2+'px');
		}
		
		$('#innerWindowFoldingOptions #frontBackCancel').click(function(){
	    	history.go(-1);
	    });
		
		$('#innerWindowFoldingOptions #frontBackNext').click(
				 function(){
					 if(config.foldingId > 0)
						 FQD.dialog.gotoNextWizard();
					 else
						standardPopup(fqdSelectOption, 'Ok', '', '', function(){});
				 }
		 );
	},
	
	loadPocketOptionsData:function(){
		FQD.dialog.setProductDescription();
		$('#fqdMsgPocketChoice').html(resourcesData.fqdMsgPocketChoice);
		loadLocaleData();
		
		var len = config.productDetails.pocketOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		
		for(var i = 0; i < len; i++)
		{
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			
			var selectorData = FQD.products.getPocketData(config.productDetails.pocketOptions[i].pocketId);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = selectorData.displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.pocketId = parseInt(config.productDetails.pocketOptions[parseInt(this.id)].pocketId);
						config.productDetails.printJob.options.pocket = config.pocketId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
						
						config.productDetails.printProductBleedBean = config.productDetails.pocketOptions[parseInt(this.id)].printProductBleed;
						FQD.dialog.loadSlitOptionsData(config.productDetails.pocketOptions[parseInt(this.id)].slits, true);
					}
			);
			
			jQuery("#innerWindowPocketOptions #optionsBar").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#innerWindowPocketOptions #optionsBar").append(clearDiv);
			}
			
			var btnBarWidth = (110 * len) + 10 ;
			jQuery("#innerWindowPocketOptions #optionsBar").css('width', btnBarWidth+'px');
		}
		
		FQD.dialog.loadSlitOptionsData(config.productDetails.pocketOptions[0].slits, false);
		
		$('#innerWindowPocketOptions #frontBackCancel').click(function(){
	    	history.go(-1);
	    });
		
		$('#innerWindowPocketOptions #frontBackNext').click(
				 function(){
					 if(config.pocketId > 0 && config.slitId > 0)
						 FQD.dialog.gotoNextWizard();
					 else
						standardPopup(fqdSelectOption, 'Ok', '', '', function(){});
				 }
		 );
	},
	
	loadSlitOptionsData:function(slitArr, defaultSelect){
		
		while(jQuery("#innerWindowPocketOptions #optionsBar2").children()[0] != undefined){
			jQuery("#innerWindowPocketOptions #optionsBar2").children()[0].remove();
		}
		
		var len = slitArr.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		var flag = false;
		for(var i = 0; i < len; i++)
		{
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			
			var selectorData = FQD.products.getSlitsData(slitArr[i].id);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			
			if(slitArr[i].id == config.slitId){
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
				flag = true;
			}
			else
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = slitArr[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.slitId = parseInt(slitArr[parseInt(this.id)].id);
						config.productDetails.printJob.options.slit = config.slitId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
					}
			);
			
			jQuery("#innerWindowPocketOptions #optionsBar2").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#innerWindowPocketOptions #optionsBar2").append(clearDiv);
			}
			
			var btnBarWidth = (110 * len) + 10 ;
			jQuery("#innerWindowPocketOptions #optionsBar2").css('width', btnBarWidth+'px');
		}
		
		if(!flag && defaultSelect){
			$(options[0].icon).addClass("selected");
			$(options[0].icon).css('background', 'url(' + folderPath + options[0].data.iconOn+') center  no-repeat');
			config.slitId = parseInt(slitArr[0].id);
			config.productDetails.printJob.options.slit = config.slitId;
		}
	}
}

FQD.dialog.setProductDescription=function(){
	var detail=config.productDetails.description;
	detail = detail.replace("<br>","");
    $('#QDProdDetail .prodType').html(config.productDetails.productName);
    $('#QDProdDetail .prodSize').html(detail);
}

FQD.dialog.setPagesOptions=function(pageNum)
{	
	pageNum = parseInt(pageNum);
	config.pageSelection = pageNum;
	config.pageLength = pageNum;
	config.pageNumber = [];
	for(var i=0; i < pageNum; i++){
		config.pageNumber.push([])
	}
	
	if(pageNum == 1){
		$('#tabs .last').hide();
		config.isFrontOnly="true";
	}else{
		$('#tabs .last').show();
	}
}

FQD.dialog.gotoNextWizard=function()
{
	$(FQD.dialog.wizard[0]).hide();
	FQD.dialog.wizard.shift();
	
	if(FQD.dialog.wizard.length > 0)
	{
		if(FQD.dialog.wizard.length > 1){
			$(FQD.dialog.wizard[0]+' #frontBackNext').val(resourcesData['frontBackNext']);
		}else{
			$(FQD.dialog.wizard[0]+' #frontBackNext').val(resourcesData['applyToMyDesign']);
		}
		$(FQD.dialog.wizard[0]+' #frontBackCancel').val(resourcesData['frontBackCancel']); 
		$(FQD.dialog.wizard[0]).show();
	}
	else{
		FQD.canvas.init();
		FQD.activity.startAutoSave();
	}	
}

FQD.dialog.hideGetStaringDialog=function()
{
	while(FQD.dialog.wizard.length > 0){
		$(FQD.dialog.wizard[0]).hide();
		FQD.dialog.wizard.shift();
	}
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 




