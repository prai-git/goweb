/**
 * 
 */
FQD.helper={};
if(window.standAloneExecution){
	FQD.helper.qdAction=standAlone.serviceBaseUrlAction;
}
else{
	FQD.helper.qdAction="/OnlineDesignerAction";
}

FQD.helper.validateEmail=function (value,id){
	filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(value)) {
	jQuery(id).html("");
	  config.isEmailOK="true";
	  return true;
	}
	else
	  {
		jQuery(id).html(resourcesData.emailNotValid);
		config.isEmailOK="false";
		return false;
	  }
}

FQD.helper.validateReferralText=function(value){
	if(value.trim().length>=255){
		jQuery("#referrerTextError_message").html(resourcesData.referralTxtLengthMsg);
		config.isOK="false";
	}else{
		jQuery("#referrerTextError_message").html("");
		config.isOK="true";
	}
}
FQD.helper.authenticateUser=function(){
	   
	   var email=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter($('#usrEmail').val())).replace(/\+/g,"%2B"));
	   var passwd=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter($('#usrPasswd').val())).replace(/\+/g,"%2B"));
	   var actionUrl;
	   FQD.elements.innerLoginWindow.hide();
	   FQD.elements.progressLogin.show();
	   FQD.elements.progressLogin.attr("src",config.qdpath+"css/preloader.gif");
	   var random=Math.random();
	   var uri="QDAction=6&email="+email+"&password="+passwd+"&cid="+config.cid+"&random="+random;
	   if(window.standAloneExecution){
		   actionUrl=standAlone.secureServiceBaseUrlAction;
	   }else{
		   actionUrl= "https://"+document.domain+"/OnlineDesignerAction";
	   }
		if(config.fromProceedToOrder){
			config.autoSave=true;
		}
	   FQD.activity.resetKeepAliveTimer();
	   $.ajax({
		    mimeType: 'text/plain; charset=x-user-defined',
		    url :actionUrl,
		    async: false,
			jsonpCallback: 'processJSON',
			contentType: "application/json",
			dataType: 'jsonp',
		    type: "GET",
		    data : uri,
		    success: function(data, textStatus, jqXHR)
		    {

		    	 FQD.elements.progressLogin.hide();
		    	 FQD.elements.innerLoginWindow.show();
		    	var status=data.status;
		    	var message=data.message;
		    	var id=data.id;
		    	if(status=="0")
		    		{
		    		 FQD.activity.startAutoSave();
		    		 if(message=="legacyAccount"){
		    				customAlertBox('alert',"Cancel","Ok",resourcesData.LegacyUserMEssage,function(result){
		    				});
		    		 }
		    		 FQD.elements.btnLogin.hide();
		    		 FQD.elements.btnSignUp.hide();
		    		 $('#SavedDesigns').show();
		    		 $("#errorMsg").hide();
		    		 config.IsUserLoggedIn=true;
		    		 config.productDetails.isUserLoggedin=true;
		    		 if(data.isAdmin=="true"){
		    			 config.productDetails.isAdmin=true;
		    		 }else{
		    			 config.productDetails.isAdmin=false;
		    		 }
		    		 if(config.productDetails.isAdmin){
		    			 $("#help").hide();
		    			 FQD.tips.close();
		    		 }
		    		 FQD.updateFD.updateFileDescriptor(id);
		    		  
		    		  if(config.btnPress == 3 || config.autoSave)
		    		  {
		    			  $("#progressImage").css('display','none');
		    			  $("#saveDesignArea").css('display','inline');
		    			  $('#progressImage').css('display','inline');
		    			  $('#progressImage').css('display','none');
		    			  $('#errorMsg').css('display','none');
		    			  $("#saveErrorMessageContainer").css('display','none');
		    			  
		    			  $("#saveDesignName").dialog({
			    				width : 530,
			    				height : 235,
			    				modal : true,
			    				resizable: false,
			    				closeOnEscape: config.autoSave? false: true,
			    				dialogClass:"saveDesignName", 
			    				
			    				close : function() {
			    					$("#saveDesignName").dialog("close");
			    			        $('#messgaediv').css('display','none');
			    		        	$('#innerdiv').css("margin-top","34px");
			    		        	$('#innerdiv1').css("margin-top","0px");
			    		        	$('#innerdiv').css("display","block");
			    		        	$('#innerdiv1').css("display","block");
			    		        	$('#designNameButton').css('display','block');
			    		        	$('#linebreak').css('margin-top','0px');
			    			        $('#designSaved').css('display','none');
			    			        $('#savedDesignOK').css('display','none');
			    			        $("#loadingQD").hide();
			    			        $('#loaderContainer').hide();
			    			        $("#designName").css("border-color","#62a3ff");
			    			        config.autoSave = false;
			    				}
		    			  });
		    			  $("#designName").val(FQD.utility.getAutoSaveDesignName());
		    			  if(config.proceedOrder){
		    				  $(".saveDesignName button")[0].style.display=none; 
		    			  }
		    		  }
		    		  if(config.btnPress==4){
		    			  FQD.saveDesign.savedDesignList();
		    		  }
		    		  myUploads.userLoggedIn=true;
		    		  refreshRecent();
		    		  FQD.elements.userLoginWindow.dialog("close");
		    		}
		    	else{
		    	    var msg=message.replace('Advanced Designer','Quick Designer');
		    	    FQD.elements.errorMessage.show();
		    	    FQD.elements.errorMessage.html(msg);
		    	    var anchor=$("#userLoginWindow #errorMessage a");
		    	    if(anchor.length==1 && (anchor.attr("href").indexOf("/login.html")==-1)){
			    	    	anchor.attr("href","javascript:$('#resetPassword').click();");

		    	    }
		    		config.IsUserLoggedIn=false;
		    		 FQD.elements.btnLogin.show();
		    		 FQD.elements.btnSignUp.show();
		    		 return;
		    	 }
		    },
		    error: function (jqXHR, textStatus, errorThrown)
		    {
		    	FQD.elements.progressLogin.hide();
		    	FQD.elements.innerLoginWindow.show();
		    },
		    xhrFields:{
		        withCredentials: true
		     }
		});
}
FQD.helper.textonly=function textonly(e,loginText){
	var regex = new RegExp("^[a-zA-Z0-9\b ]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var allowedSpecialKeys = '37383940';
    if(loginText){
    	 allowedSpecialKeys = '37383940190173';
    }
    var key = (e.which) ? e.which : e.keyCode;
    if(allowedSpecialKeys.indexOf(key)>-1){
        return true;
    }
    if (regex.test(str)) {
        return true;
    }
    //e.preventDefault();
    e.stopPropagation();
    e.cancelBubble = true;
    return false;
}

FQD.helper.userSignUp=function(){
	FQD.activity.removeAutoSaveTimer();
	FQD.helper.getReferrerOptions();
	var d = new Date();
	config.timeStamp=d.getTime();
	$("#qd_captcha").attr("src",urlPrefix+"/common/resource/captcha?t="+config.timeStamp);
	
	$("#userSignUpWindow").dialog({
		width : 625,
		height :480,
		modal : true,
		dialogClass: "userSignUpWindow",
		close:function(){
			FQD.activity.startAutoSave();
		},
		buttons : [
			{
				text : resourcesData.signUp,
				click : function () {
					FQD.helper.signUpValidate();
				}
			},
			{
				text : resourcesData.frontBackCancel,
				click : function () {
					FQD.activity.startAutoSave();
					$(this).dialog("close");
				}
			}
		]
	});
	
	 $("#tr_qd_referrerOtherInputTextArea").css("display","none");

	$('#userSignUpWindow input:text').val('');
	$('#userSignUpWindow input:password').val('');
	$('#userSignUpWindow input:checkbox').prop('checked',false);
	$('#userSignUpWindow input').removeClass('textBoxMandatory');
    $('#userSignUpWindow input').removeClass('chkBoxMandatory');
    $('#userSignUpWindow select').removeClass('chkBoxMandatory');
    $('#userSignUpWindow textarea').removeClass('textBoxMandatory');
    $('#ReferrerType').val('-1');
    $('#email_message').html('');
    $('#password_message').html('');
    $('#signupErrorMsg').html('');
    $("#userSignUpWindow input").focusout(function(){
		var val=$(this).val();
		if(val.trim()!="")
			{
			  $(this).removeClass('textBoxMandatory');
			}


	});
	$("#ReferrerType").change(function(){
		var val=$(this).val();
		if(val!="-1")
			{
			  $(this).removeClass('chkBoxMandatory');
			}
		else{
			$(this).addClass('chkBoxMandatory');
		}
		
		if (val === "6"){
			   $("#tr_qd_referrerOtherInputTextArea").css("display","table-row");
		   }else {
			   $("#tr_qd_referrerOtherInputTextArea").css("display","none");
		   }

	});
	$("#qd_password").on('input', function() {
          var password = $(this).val();
          FQD.helper.getPasswordComplexity(password);
    });
}

FQD.helper.signUpValidate=function(){
	
	   FQD.elements.innerSignUpWindow.hide();
	   FQD.elements.progressSignUp.show();
	   FQD.elements.progressSignUp.attr("src",config.qdpath+"css/preloader.gif");
	   var qd_firstName     	=  $('#qd_firstName').val().trim();
	   var qd_lastName      	=  $('#qd_lastName').val().trim();
	   var qd_company       	=  $('#qd_company').val().trim();
	   var qd_email         	=  $('#qd_email').val().trim();
	   var qd_confirmEmail  	=  $('#qd_confirmEmail').val().trim();
	   var qd_password      	=  $('#qd_password').val().trim();
	   var qd_confirmPassword	=  $('#qd_confirmPassword').val().trim();
	   var qd_promotion		    =  $('#qd_promotion').prop('checked');
	   var qd_termsconditions   =  $('#qd_termsconditions').prop('checked');
	   var qd_number		    =  $('#qd_number').val().trim();
	   var qd_referrer		    =  $('#ReferrerType').val().trim();
	   var qd_referrerOtherInputTextArea	=  $('#qd_referrerOtherInputTextArea').val();
	   $('#userSignUpWindow input').removeClass('textBoxMandatory');
	   $('#userSignUpWindow input').removeClass('chkBoxMandatory');
	   $('#userSignUpWindow select').removeClass('chkBoxMandatory');
	   $('#userSignUpWindow textarea').removeClass('textBoxMandatory');
	   config.isOK="true";
	   if( config.isPasswordOK!="true")
		   {
		     $('#qd_password').addClass('textBoxMandatory');
		   }
	   if(qd_firstName == "")
		   {
		   	 $('#qd_firstName').addClass('textBoxMandatory');
		   	config.isOK="false";
		   }
	   if(qd_lastName == "")
		   {
		     $('#qd_lastName').addClass('textBoxMandatory');
		     config.isOK="false";
		   }
	   if(qd_email == "")
		   {
		     $('#qd_email').addClass('textBoxMandatory');
		     config.isOK="false";
		   }
	   if(qd_confirmEmail == "")
		   {
		     $('#qd_confirmEmail').addClass('textBoxMandatory');
		     config.isOK="false";
		   }
	   if(qd_password == "")
		   {
		     $('#qd_password').addClass('textBoxMandatory');
		     config.isOK="false";
		   }
	   if(qd_confirmPassword == "")
		   {
		     $('#qd_confirmPassword').addClass('textBoxMandatory');
		     config.isOK="false";
		   }
	   if(!qd_termsconditions)
		   {
		     $('#qd_termsconditions').addClass('chkBoxMandatory');
		     config.isOK="false";
		   }
	   if(qd_number == "")
		   {
		     $('#qd_number').addClass('textBoxMandatory');
		     config.isOK="false";
		   }
	   if(qd_referrer == "-1")
	   	   {
	         $('#ReferrerType').addClass('chkBoxMandatory');
	         config.isOK="false";
	        }
	   if ($('#ReferrerType').val() === "6"){
		   if(qd_referrerOtherInputTextArea.trim()=="")
	   	   {
	         $('#qd_referrerOtherInputTextArea').addClass('textBoxMandatory');
	         config.isOK="false";
	        }
		   if(jQuery("#referrerTextError_message").html()!=""){
	    	   config.isOK="false";
	       }
	   }
     
	   
	   if(config.isOK=="true"&&config.isPasswordOK=="true"&& config.isEmailOK=="true"){
		   qd_email=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(qd_email)).replace(/\+/g,"%2B"));
		   qd_confirmEmail=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(qd_confirmEmail)).replace(/\+/g,"%2B"));
		   qd_password=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(qd_password)).replace(/\+/g,"%2B"));
		   qd_confirmPassword=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(qd_confirmPassword)).replace(/\+/g,"%2B"));
		   
		   FQD.activity.resetKeepAliveTimer();
		   
		      var random=Math.random();
		      var passingData  =  "&qd_firstName="+qd_firstName+"&qd_lastName="+qd_lastName+"&qd_company="+qd_company+"&qd_email="+qd_email+"&qd_confirmEmail="+qd_confirmEmail+"&qd_password="+qd_password;
		          passingData +=  "&qd_confirmPassword="+qd_confirmPassword+"&qd_promotion="+qd_promotion+"&qd_termsconditions="+qd_termsconditions+"&qd_number="+qd_number;
		          passingData +=  "&qd_referrer="+qd_referrer+"&qd_referrerOtherInputTextArea="+qd_referrerOtherInputTextArea+"&timeStamp="+config.timeStamp;

		   	   var actionUrl;
			   if(window.standAloneExecution){
				   actionUrl=standAlone.secureServiceBaseUrlAction;
			   }else{
				   actionUrl= "https://"+document.domain+"/OnlineDesignerAction";
			   }
			   var uri="QDAction=28&cid="+config.cid+"&random="+random+passingData;
			   
		 		 $.ajax({
					    mimeType: 'text/plain; charset=x-user-defined',
					    url :actionUrl,
					    async: false,
						jsonpCallback: 'processJSON',
						contentType: "application/json",
						dataType: 'jsonp',
					    type: "GET",
					    data : uri,
					    success: function(data, textStatus, jqXHR)
					    {
					    	
					    	if(parseInt(data.status)<0)
					    	{
					    		  $('#signupErrorMsg').html(data.message);
					    		  $('#qd_password').val('');
					    		  $('#qd_confirmPassword').val('');
					    		  $('#qd_number').val('');
					    		  $('#password_message').html('');
					    		  $('#qd_password').addClass('textBoxMandatory');
					    		  $('#qd_confirmPassword').addClass('textBoxMandatory');
					    		  $('#qd_number').addClass('textBoxMandatory');
					    		  var d = new Date();
					    		  config.timeStamp=d.getTime();
					    		  $("#qd_captcha").attr("src",urlPrefix+"/common/resource/captcha?t="+ config.timeStamp);
					    		  FQD.elements.innerSignUpWindow.show();
					    		  FQD.elements.progressSignUp.hide();
				    		}
					    	else{
					    		config.IsUserLoggedIn=true;
					    		config.productDetails.isUserLoggedin=true;
					    		$('#btnLogin').hide();
					    		$('#btnSignUp').hide();
					    		$('#SavedDesigns').show();
					    		$('#btnSave').show();
					    		$("#userSignUpWindow").dialog('close');
					    		config.userId=data.id;
					    		FQD.updateFD.updateFileDescriptor(data.id);
					    		
					    	}

					    	
					    },
					    error: function (jqXHR, textStatus, errorThrown)
					    {
				    		  FQD.elements.innerSignUpWindow.show();
				    		  FQD.elements.progressSignUp.hide();
					    },
					    xhrFields:{
					        withCredentials: true
					     }
					});
	
	   }else{
		 		  FQD.elements.innerSignUpWindow.show();
				  FQD.elements.progressSignUp.hide();
				  if(config.isPasswordOK=="false" && config.isOK=="true" && config.isEmailOK=="true"){
					  if($('#qd_password').val()!=$('#qd_confirmPassword').val()){
						  $('#signupErrorMsg').html(resourcesData.passwordAndConfirmationDontMatch);
					  }else{
						  $('#signupErrorMsg').html(resourcesData.passwordTooWeak);
					  }
					  $('#qd_password').addClass('textBoxMandatory');
		    		  $('#qd_confirmPassword').addClass('textBoxMandatory');
		    		  $('#qd_number').addClass('textBoxMandatory');
		    		  $('#qd_password').val('');
		    		  $('#qd_confirmPassword').val('');
		    		  $('#qd_number').val('');
		    		  $('#password_message').html('');
		    		  var d = new Date();
		    		  config.timeStamp=d.getTime();
		    		  $("#qd_captcha").attr("src",urlPrefix+"/common/resource/captcha?t="+ config.timeStamp);
				  }
	   }
	   
	
}

FQD.helper.getReferrerOptions=function(){
	var random=Math.random(),option;
	FQD.activity.resetKeepAliveTimer();
	FQD.request.getData({"QDAction":26,"random":random},"GET","json",FQD.helper.qdAction+"?cid="+config.cid,
	        function success(data){
	    	if(data)
			{
			  
	    	  data = data.sort(compare);
			  var referrerType=data;
			  data[5].id == -1 ? option = '<option value="'+referrerType[5].id+'">'+referrerType[5].label+'</option>' : option = "";
			  for (var loop=0;loop<referrerType.length;loop++) {
				  if(referrerType[loop].id != -1){
					  option += '<option value="'+referrerType[loop].id+'">'+referrerType[loop].label+'</option>';
				  }
				}
			  function compare(a,b){
				 return a.label.localeCompare(b.label);
			  }
			}
		   $('#ReferrerType').html(option);
	},
		function error(data){
			console.log(data);
		});


}


FQD.helper.getPasswordComplexity=function(password){

	   config.isPasswordOK="true";
	   var random=Math.random();
	   FQD.activity.resetKeepAliveTimer();
	   var actionUrl;
	   if(window.standAloneExecution){
		   actionUrl=standAlone.secureServiceBaseUrlAction;
	   }else{
		   actionUrl= "https://"+document.domain+"/OnlineDesignerAction";
	   }
	   var qd_password=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(password)).replace(/\+/g,"%2B"));
	   var uri="QDAction=27&password="+qd_password+"&cid="+config.cid+"&random="+random;
	   
		 $.ajax({
			    mimeType: 'text/plain; charset=x-user-defined',
			    url :actionUrl,
				jsonpCallback: 'processJSON',
				contentType: "application/json",
				dataType: 'jsonp',
			    type: "GET",
			    data : uri,
			    success: function(data, textStatus, jqXHR)
			    {
			    	if(data){
			    		var status=data.status;
			    		var message='';
			    		  if(status=="TOO_SHORT")
			       		  {
			       		    message=resourcesData.pwdTooShortMsg;
			       		    $('#password_message').css('color','rgb(83, 81, 76)');
			       		    $('#qd_password').addClass('textBoxMandatory');
			       		    config.isPasswordOK="false";
			       		  }
			       	  if(status=="WEAK")
			   	  	  	  {
			   		        message=resourcesData.Weak;
			   		        $('#password_message').css('color','rgb(176, 34, 18)');
			   		        config.isPasswordOK="false";
				          }
			       	  if(status=="FAIR")
			       	  	  {
			       		    message=resourcesData.Fair;
			       		    $('#password_message').css('color','rgb(234, 196, 31)');
			   		      }
			       	  if(status=="GOOD")
			   	  	  	  {
			       		    message=resourcesData.Good;
			       		    $('#password_message').css('color','rgb(34, 139, 188)');
				          }
			       	  if(status=="STRONG")
				  	  	  {
			       		    message=resourcesData.Strong;
			       		    $('#password_message').css('color','rgb(43, 99, 14);');
			             }
			       	  if(status=="VERY_STRONG")
				  	  	  	  {
			   		        message=resourcesData.veryStrong;
			   		        $('#password_message').css('color','rgb(43, 99, 14);');
			                 }
			       	  $('#password_message').html(message);
			    	}
			    },
			    error: function (jqXHR, textStatus, errorThrown)
			    {
			    	FQD.elements.progressLogin.hide();
			    	FQD.elements.innerLoginWindow.show();
			    },
			    xhrFields:{
			        withCredentials: true
			     }
			});

}

FQD.helper.keyboardHelpWindow=function(){
	FQD.elements.keyboardHelpWindow.dialog({
		width : '100%',
		height : 500,
		modal : true,
		dialogClass: "keyboardHelpWindow",
		resizable: false,
		fluid: true,
		position: {
	        my: "center center",
	        at: "center center",
	        of: window
	    }
	});
}

FQD.helper.resetPassword=function(){
	FQD.activity.removeAutoSaveTimer();
    $('#showEmailError1').html("");
	FQD.elements.errorMessage.html("");
	FQD.elements.userName.val('');
	FQD.elements.userLoginWindow.dialog("close");
	 FQD.elements.resetErrorMessage.html("");
	var d = new Date();
	config.timeStamp=d.getTime();
	$("#qd_captcha_resetPassword").attr("src",urlPrefix+"/common/resource/captcha?t="+config.timeStamp);
	FQD.elements.resetPasswordWindow.dialog({
		width : 400,
		height :280,
		modal : true,
		dialogClass: "resetPasswordWindow",
		close:function(){
			FQD.activity.startAutoSave();
		},
		buttons : [
			   {
				   text: resourcesData.resetPwd,
				   click : function () {
					   var userName=$("#userName").val();
		                  var capcha=$("#reset_captcha").val();
		                  if(userName.trim()==""){
		                		jQuery("#showEmailError1").html(resourcesData.emailFieldRequired);
		                		var d = new Date();
		                		config.timeStamp=d.getTime();
		                		$("#qd_captcha_resetPassword").attr("src",urlPrefix+"/common/resource/captcha?t="+config.timeStamp);
		                		return;
		                    }
		                  if(capcha.trim()==""){
		              		jQuery("#showEmailError1").html(resourcesData.captchaFieldRequired);
		              		var d = new Date();
		              		config.timeStamp=d.getTime();
		              		$("#qd_captcha_resetPassword").attr("src",urlPrefix+"/common/resource/captcha?t="+config.timeStamp);
		              		return;
		                  }
		                  FQD.elements.resetErrorMessage.html("");
		                  if(config.isEmailOK=="false")
		                	  {
		                		var d = new Date();
		                		config.timeStamp=d.getTime();
		                  		$("#qd_captcha_resetPassword").attr("src",urlPrefix+"/common/resource/captcha?t="+config.timeStamp);
		                	    return;
		                	  }
		                  var random=Math.random(); 
		                  FQD.activity.resetKeepAliveTimer();
		                  FQD.request.getData({"QDAction":29,"random":random},"GET","json",FQD.helper.qdAction+"?username="+userName+"&captcha="+capcha+"&timeStamp="+config.timeStamp+"&cid="+config.cid,
		                	        function success(data){
				
				                	  if(data!=0)
							        	{
				                		  if(data==5006){
				                			  FQD.elements.resetErrorMessage.html(resourcesData.plsInputValidCaptcha);
				                		  }else{
				                			  FQD.elements.resetErrorMessage.html(resourcesData.emailDoesntExist);
				                		  }
				                		  var d = new Date();
				                		  config.timeStamp=d.getTime();
				                    	  $("#qd_captcha_resetPassword").attr("src",urlPrefix+"/common/resource/captcha?t="+ config.timeStamp);
				                    	  $("#reset_captcha").val("");
				                    	  $("#userName").val("");
							        	  return;
							        	}
							        else{
							        	FQD.elements.resetPasswordWindow.dialog('close');
							        	FQD.elements.resetPasswordWindow1.dialog({
							        		width : 400,
							 				height :200,
							 				modal : true,
							 				dialogClass: "resetPasswordWindow1",
							 				buttons : [
							 				{
                                             text:resourcesData.loginLink,							 					
                                             click:function(){
								                 $(this).dialog('close');
								             	 FQD.elements.btnLogin.click(); 
                                              }
											   }]
											
							        	     });
							        	 }
							        	 return;
		                		},
		                		function error(data){
		                			console.log(data);
		                		});
				   }
			   },
			   {
				   text : resourcesData.frontBackCancel,
					click : function () {
						FQD.activity.startAutoSave();
						 $(this).dialog("close");
					}
			   }
			]
	});

}
FQD.helper.isUserLoggedIn=function(callingFunction){
	
	
	if(config.productDetails.isUserLoggedin){
		 FQD.elements.btnLogin.hide();
		 FQD.elements.btnSignUp.hide();
	}else{
		FQD.elements.btnLogin.show();
		FQD.elements.btnSignUp.show();
	}
    if(callingFunction=='promptSavedDesign'){

 	   if(!config.IsUserLoggedIn)
			{
			 $('#saveDesignArea').hide();
	    	 $('#errorMsg').css('display','inline');
	    	 $('#saveErrorMessageContainer').hide();
	    		$("#saveDesignName").dialog({
 				width : 530,
 				height : 235,
 				modal : true,
 				resizable: false,
 				dialogClass: "saveDesignName",
 				close : function() {
 					$("#saveDesignName").dialog("close");
 			        $('#messgaediv').hide();
 		        	$('#innerdiv').css("margin-top","34px");
 		        	$('#innerdiv1').css("margin-top","0px");
 		        	$('#innerdiv').css("display","block");
 		        	$('#innerdiv1').css("display","block");
 		        	$('#designNameButton').css('display','block');
 		        	$('#linebreak').css('margin-top','0px');
 			        $('#designSaved').hide();
 			        $('#savedDesignOK').hide();
 			        $("#loadingQD").hide();
 			        $('#loaderContainer').hide();
 			       $("#designName").css("border-color","#62a3ff");
 				}				
 			}); 
	      $("#designName").val(FQD.utility.getAutoSaveDesignName());
     	  return;
			}
 	   else{
 		  FQD.saveDesign.savedDesignList();

 	   }
	   
    }
    
    if(callingFunction=='promptDesignName')
	   {
 	   if(!config.IsUserLoggedIn)
			{
			 $('#saveDesignArea').hide();
	    	 $('#errorMsg').css('display','inline');
	    	 $('#saveErrorMessageContainer').hide();
	    	 $("#saveDesignName").dialog({
					width : 530,
					height : 235,
					modal : true,
					resizable: false,
					dialogClass: "saveDesignName",
					close : function() {
						$("#saveDesignName").dialog("close");
				        $('#messgaediv').hide();
			        	$('#innerdiv').css("margin-top","34px");
			        	$('#innerdiv1').css("margin-top","0px");
			        	$('#innerdiv').css("display","block");
			        	$('#innerdiv1').css("display","block");
			        	$('#designNameButton').css('display','block');
			        	$('#linebreak').css('margin-top','0px');
				        $('#designSaved').hide();
				        $('#savedDesignOK').hide();
				        $("#loadingQD").hide();
				        $('#loaderContainer').hide();
				        $("#designName").css("border-color","#62a3ff");
					},
				}); 
	    	 $("#designName").val(FQD.utility.getAutoSaveDesignName());
	    	 
	    	 $(".ui-dialog-titlebar-close").click(function(){
	    	   config.autoSave = false;
	    	 });
     	 return;
			}
 	   else
 		   {

 		   if((config.productDetails.isProductSaved||(config.productDetails.designId && config.productDetails.designId!="undefined"))&&(config.productDetails.designerType!=2))
 		   {
 			   		$('#saveOptions').show();
 			   			return;
		    	 	}
 		     $("#progressImage").hide();
	           	 $("#saveDesignArea").css('display','inline');
	           	 $('#progressImage').css('display','inline');
	           	 $('#progressImage').hide();
	   	    	 $('#errorMsg').hide();
	   	    	 $('#saveErrorMessageContainer').hide();
	   	    	
	   	    	 $("#saveDesignName").dialog({
 				width : 530,
 				height : 235,
 				modal : true,
 				resizable: false,
 				closeOnEscape: config.autoSave? false: true,
		    		dialogClass:"saveDesignName", 
 				close : function() {
 					$("#saveDesignName").dialog("close");
 			        $('#messgaediv').hide();
 		        	$('#innerdiv').css("margin-top","34px");
 		        	$('#innerdiv1').css("margin-top","0px");
 		        	$('#innerdiv').css("display","block");
 		        	$('#innerdiv1').css("display","block");
 		        	$('#designNameButton').css('display','block');
 		        	$('#linebreak').css('margin-top','0px');
 			        $('#designSaved').hide();
 			        $('#savedDesignOK').hide();
 			        $("#loadingQD").hide();
 			        $('#loaderContainer').hide();
 			       $("#designName").css("border-color","#62a3ff");
 			        config.autoSave = false;
 				}				
 			}); 
	   	    $("#designName").val(FQD.utility.getAutoSaveDesignName());
 			}
	   }
}
FQD.helper.proceedToOrderPreCheck=function(){
	if((!config.isUserLoggedInBeforeProceed && config.IsUserLoggedIn)||config.stopRedirect){
		delete config.stopRedirect;
		return;
	}
	if(!config.productDetails.isProductSaved && config.IsUserLoggedIn){
        config.notSavedLoggedIn=true;
          $("#progressImage").hide();
		  $("#saveDesignArea").css('display','inline');
		  $('#progressImage').css('display','inline');
		  $('#progressImage').hide();
		  $('#errorMsg').hide;
		  $("#saveErrorMessageContainer").hide();
		  
		  $("#saveDesignName").dialog({
				width : 530,
				height : 235,
				modal : true,
				resizable: false,
				closeOnEscape: config.autoSave? false: true,
				dialogClass:"saveDesignName", 
				close : function(){
					if(config.organizeManually !== true){
						FQD.helper.proceedToOrder();
						$("#designName").css("border-color","#62a3ff");
					}
				}
		  });
		  $("#designName").val(FQD.utility.getAutoSaveDesignName());
	}else{
		if(config.IsUserLoggedIn){
			if(config.currentDesignId){
				FQD.saveDesign.autoCategorize(config.currentDesignId,true,true);
			}
			else if(config.productDetails.designId){
				FQD.saveDesign.autoCategorize(config.productDetails.designId,true,true);
			}
			else{ 
				FQD.saveDesign.autoCategorize(undefined,false,true);
			}
			
		}else{
			 FQD.helper.proceedToOrder();
		}
	}
}
 FQD.helper.proceedToOrder=function(){
	 var z=FQD.canvas.pages[config.activeCanvas].getZoom();
		FQD.canvas.setZoom(1);// reset canvas to get data in 100% zoom
		//Auto save design before proceeding if user is working on saved design
		 if(config.productDetails.isProductSaved==true || config.productDetails.designCode>0){
			 config.proceedToOrderExecuted = true;
			 if (config.currentDesignId) {
				FQD.saveDesign.saveNewDesign(config.currentDesignId,true);
			} else {
				FQD.saveDesign.saveNewDesign(config.productDetails.designId,true);
			}
			 
		 }
			FQD.view.getView(FQD.elements.proceedToOrderPage,"proceedToOrder.html",function(){
				var dpi=config.dpi;
				var imgArr=[];
				
			    var actualWidth=config.canvasWidth/dpi;
			    var actualHeight=config.canvasHeight/dpi;
			    
			    var prodType=config.prodType;
				var svgParam='';
				var jsonParam='';	
				 var length=FQD.canvas.pages.length;
					if(config.isFrontOnly == "true"){
						length=1;
					}
			    for(var i=0;i < length;i++){
                    svgParam   += '<input type="hidden" name="svgdata"/>\n';
					jsonParam += '<input type="hidden" name="svgtojson"/>\n';
				}
			     var formobj=$('#proceedToOrderPage')[0];
			     var data=$('#proceedToOrderPage').html();
			     data += svgParam;
			     data += jsonParam;
			     $('#proceedToOrderPage').html(data);
			     
			     var svgdataArr=$('#proceedToOrderPage').find('[name="svgdata"]');
			     var svgtojsonArr=$('#proceedToOrderPage').find('[name="svgtojson"]');
			    
			     for(var i=0;i < length;i++){
			    	    var obj=FQD.canvas.pages[i].getObjects();
			    	    var arr=FQD.preview.textPlaceholder(obj);
			    	    var cArea = FQD.canvas.pages[i].getItemByName("canvasArea");
			    	    cArea.stroke =  "#FFFFFF";
			    	    
			    	    //comment below line because as per no need to require addition properties attached with Text element.
			    	    //config.textAddedAtr=FQD.preview.setTextAnchor(obj);
			    		
			    	    for(var j=0;j<obj.length;j++){
			    			 if(obj[j].type=="image" && obj[j].cropped=="true"){
			    				 FQD.crop.addObjectAddedAtr(obj[j]);
			    			 }
			    		}
						var svgData=FQD.canvas.pages[i].toSVG('',FQD.preview.toSVG);
						var jsonData=JSON.stringify(FQD.canvas.pages[i].toJSON(config.newProperties));
						
						cArea.stroke =  "#000000";
						
						arr.forEach(function(element){
							delete element.isHidden;
							element.setOpacity(element.initialOpacity);
							
						});

						svgData=svgData.replace('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>','');
						svgData=svgData.replace('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">','');
						svgData=jQuery.trim(svgData).replace(/(?:\r\n|\r|\n)/g, '');//.replace(/\s+/g, " ");
						
						//Below replace logic used for viewbox transparent "Rect" tag created default from Fabric need to set opacity 0.  
						svgData=svgData.replace('</defs><rect','</defs><rect style="opacity:0;"');
						svgData=svgData.replace('<defs /><rect','<defs /><rect style="opacity:0;"');
						svgData=FQD.preview.removeElementNotForPreview(svgData, true);
						svgData = FQD.preview.removePlaceHoldersImage(svgData);
						svgData=svgData.replace('xmlns:NS1=""','');
						svgData=svgData.replace('NS1:','');
						svgdataArr[i].value=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(svgData)).replace(/\+/g,"%2B"));
						svgtojsonArr[i].value=window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(jsonData)).replace(/\+/g,"%2B"));
;

					}
		       
			    
			    formobj.designId.value=(config.currentDesignId == undefined)? 0: config.currentDesignId;
			    
			    config.productDetails.printJob.svgScaleMultiplier = config.scaleMultiplier;
				config.productDetails.printJob.exportArea=config.canvasOrigin;
				
			    formobj.printJob.value = getEncodedPrintJob(config.productDetails.printJob);
		        
		        formobj.cid.value=config.cid;
		        formobj.canvasOrigin.value = JSON.stringify(config.canvasOrigin);
		        formobj.scaleMultiplier.value = JSON.stringify(config.scaleMultiplier);
		        
		        if(config.isFrontOnly=="true"){	
		        	 formobj.isFront.value="true";
		        }
		       
		        FQD.canvas.setZoom(z); // zoom canvas as per previous value again
		        
		        if(config.orderItemRedesignMode)
		        	formobj.QDAction.value = 42;
		        FQD.activity.resetKeepAliveTimer();
		        $('#proceedToOrderPage').submit(); 
			}); 
			    
			

	}
 FQD.helper.getProductsSizeDetails=function(){
		if(config.productsSizeDetails){
			return;
		}
		jQuery("#loaderContainer").show();
		jQuery("#loadingQD").show();
		  var random=Math.random();
		  FQD.activity.resetKeepAliveTimer();
		  FQD.request.getData({"QDAction":16,"random":random},"GET","json",FQD.helper.qdAction+"?cid="+config.cid,
      	        function success(data){
                  config.productsSizeDetails=data;
                  FQD.helper.setProductDropDown();
        
      		},
      		function error(data){
      			console.log(data);
      		});
	}
	
FQD.helper.setProductDropDown=function(){

		var selProductHtml="";
		var prodCode=Object.keys(config.productsSizeDetails);
		for(var i=0;i<prodCode.length;i++){
			if(prodCode[i]=="1"){
				selProductHtml+='<option value="'+prodCode[i]+'" rel="/store/business-card/home.html"></option>';
				selProductHtml=selProductHtml.replace('><','>'+resourcesData.businessCards+'<');
			}
			if(prodCode[i]=="2"){
				selProductHtml+='<option value="'+prodCode[i]+'"  rel="/store/postcard/home.html">2</option>';
				selProductHtml= selProductHtml.replace('>2<','>'+resourcesData.postCards+'<');
			}
		}
		
		FQD.elements.selProduct.html(selProductHtml);
		
		FQD.elements.selProduct.val(config.productTypeId);
		FQD.helper.setCavnvasSizeDropDown(config.productTypeId);
		
		FQD.elements.selProduct.change(function(){
			var id=jQuery(this).val();
			FQD.helper.setCavnvasSizeDropDown(id,true);
		});
		FQD.elements.selCanvasSizes.change(function(){
			FQD.helper.setSizes();
		});
		jQuery("#loaderContainer").hide();
		jQuery("#loadingQD").hide();
	}
FQD.helper.setSizes=function(){

	var w=FQD.elements.selCanvasSizes.find("option:selected").attr("w"),
		h=FQD.elements.selCanvasSizes.find("option:selected").attr("h");
	    unit=FQD.elements.selCanvasSizes.find("option:selected").attr("unit");
	    if(unit=="mm"){
	    	w=w*0.0393701;
	    	h=h*0.0393701;
	    }
		w=(config.dpi*parseFloat(w)).toFixed(0);
		h=(config.dpi*parseFloat(h)).toFixed(0);
		FQD.elements.textCanvasWidth.val(w);
		FQD.elements.textCanvasHeight.val(h);

}
FQD.helper.setCavnvasSizeDropDown=function(PTId,onchange){
	var selCanvasHtml="";
	var data=config.productsSizeDetails[PTId];
	for(var i=0;i<data.length;i++){
		var detail=data[i].productSizeString.replace(/dblquote/g,"\"");
		selCanvasHtml+='<option value="'+data[i].id+'" w="'+data[i].width+'"  h="'+data[i].height+'"  unit="'+data[i].unit+'">'+detail+'</option>';
	}
	FQD.elements.selCanvasSizes.html(selCanvasHtml);
	$('#selCanvasSizes>option:eq(1)').prop('selected', true);
	if(onchange){
		var id=FQD.elements.selCanvasSizes.val();
		FQD.elements.selCanvasSizes.val(""+id);
	}
	else{
		FQD.elements.selCanvasSizes.val(""+config.productSizeId);

	}
	FQD.helper.setSizes();
}
FQD.helper.sendNewConfiguration=function(){
	var sizeId=FQD.elements.selCanvasSizes.val(),
	sizeLabel=FQD.elements.selCanvasSizes.find("option:selected").text(),
	productUrl=FQD.elements.selProduct.find("option:selected").attr("rel");
	

	if(config.productSizeId == sizeId){
		return ;
	}
	FQD.elements.inpProductId.val(sizeId);
	FQD.elements.inpProductSize.val(sizeLabel);
	FQD.elements.inpProductType.val(productUrl);
	FQD.elements.formGp_FQD.submit();
}

FQD.helper.storeJsonData=function(){
	var pageLength=config.pageLength;
	if(pageLength==2){
		config.firstPage=FQD.canvas.pages[0].toJSON(config.newProperties);
		config.lastPage=FQD.canvas.pages[1].toJSON(config.newProperties);
		config.firstPageBackgroundImage=FQD.canvas.pages[0].backgroundImage;
		config.lastPageBackgroundImage=FQD.canvas.pages[1].backgroundImage;

      }
	else{
		config.firstPage=FQD.canvas.pages[0].toJSON(config.newProperties);
		config.firstPageBackgroundImage=FQD.canvas.pages[0].backgroundImage;
	}

	
}
FQD.helper.loadJsonData=function(cornerType){
	if(config.firstPage){
		var jsonData=FQD.imgLib.updateHDImageOnJson(config.firstPage);
		FQD.canvas.pages[0].loadFromJSON(jsonData,
				function(){
					FQD.canvas.pages[0].renderAll.bind(FQD.canvas.pages[0]);
					config.cornerChanged = true;
					FQD.canvas.resetCanvasAsPerWindowSize(0);
		   		},
				function(o, object){
					FQD.utility.setObjectPropertiesAfterLoadJSON(o,object);
				}
		);
	}
	
	if(config.lastPage && FQD.canvas.pages[1]){
		var jsonData=FQD.imgLib.updateHDImageOnJson(config.lastPage);
		FQD.canvas.pages[1].loadFromJSON(jsonData,
				function(){
					FQD.canvas.pages[1].renderAll.bind(FQD.canvas.pages[1]);
					config.cornerChanged = true;
					FQD.canvas.resetCanvasAsPerWindowSize(1);
		   		},
				function(o, object){
					FQD.utility.setObjectPropertiesAfterLoadJSON(o,object);
				}
		);
	}
	
	FQD.canvas.getInitialZoom();
}

FQD.helper.adJustBackgroundImage=function(canvas){
	var bgImage = canvas.getItemByName("bgElement");
	
    if(bgImage && bgImage != null && bgImage != undefined)
    {
    	if(FQD.PrintProductType.isEnvelope() && !FQD.canvas.hasSystemBackground(bgImage.filedescriptorid)){
    		return;
    	}
    	var setTime = setInterval(function setTimmer(){
    			clearInterval(setTime);
    			var src = bgImage.getSrc();
    			var flag = (bgImage.scaleX != 1 && bgImage.scaleY != 1)? true: false;
  				FQD.imgLib.filedescriptorid = bgImage.filedescriptorid;
  				FQD.imgLib.setBgImage(src, canvas, bgImage.originalWidth, bgImage.originalHeight, flag); 
  			}, 50);
    }
}

FQD.helper.adjustTemplateObjects = function(obj)
{	
	var extraBleed = FQD.canvas.getExtraBleedDifference();
	obj.left = roundTo(obj.getLeft() + extraBleed.left, 2);
	obj.top = roundTo(obj.getTop() + extraBleed.top, 2);
	obj.setCoords();
}

FQD.helper.closePageOptions=function(){
	//$("#pagesOptions").hide();
	closeEditPanel();
}
FQD.helper.closePageCornerOptions=function(){
	//$("#pagesCornerOptions").hide();
	closeEditPanel();
}

FQD.helper.applyPageOptions=function(){
	var pageLength=config.pageLength;
	if(pageLength==2){
		var pageRemoveMessage= resourcesData.pageRemoveMessage;
		customAlertBox('confirm','Cancel','Ok',pageRemoveMessage,function(result){
			if(result){
				config.changePageOption=true;
				config.lastPageData = FQD.canvas.pages[1].toJSON(config.newProperties);
				config.firstPageData = FQD.canvas.pages[0].toJSON(config.newProperties);
				$('#tab-container #tabs li.last').hide();
				
				config.pageNumber=[[]];
				FQD.helper.closePageOptions();
				config.pageLength = 1;
				var jsonData=FQD.imgLib.updateHDImageOnJson(config.firstPageData);
				FQD.canvas.pages[0].loadFromJSON(jsonData,
						function(){
							FQD.canvas.pages[0].renderAll.bind(FQD.canvas.pages[0]);
							FQD.canvas.resetCanvasAsPerWindowSize();
							FQD.events.tabs(0);
				   		},
						function(o, object){
				   			FQD.utility.setObjectPropertiesAfterLoadJSON(o,object);
						}
				);
				
				FQD.undoManager.clearHistory(true);
				FQD.helper.setScaleUnit();
				if(FQD.elements.buttonShowAllCanvas.hasClass('show-all')){
					FQD.events.showAllCanvas(FQD.elements.buttonShowAllCanvas);
				}
				FQD.elements.buttonShowAllCanvas.hide();
			}
			config.isFrontOnly='true';
			
		});
		
	}else{
		config.pageLength = 2;
		config.pageNumber=[[],[]];
		config.isFrontOnly = "false";
		FQD.helper.closePageOptions();
		
		if(!FQD.canvas.pages[1]){
			config.firstPageData = FQD.canvas.pages[0].toJSON(config.newProperties);
			FQD.canvas.init();
			var jsonData=FQD.imgLib.updateHDImageOnJson(config.firstPageData);
			FQD.canvas.pages[0].loadFromJSON(jsonData,
					function(){
						FQD.canvas.pages[0].renderAll.bind(FQD.canvas.pages[0]);
						if(!config.lastPageData){
							FQD.canvas.resetCanvasAsPerWindowSize();
						}
			   		},
					function(o, object){
			   			FQD.utility.setObjectPropertiesAfterLoadJSON(o,object);
					}
			);
		}
		
		$("#tab-container #tabs li.last").show();
		config.changePageOption=true;
		
		if(config.lastPageData){
			var jsonData=FQD.imgLib.updateHDImageOnJson(config.lastPageData);
			FQD.canvas.pages[1].loadFromJSON(jsonData,
					function(){
						FQD.canvas.pages[1].renderAll.bind(FQD.canvas.pages[1]);
						FQD.initializecanvas.createSVGOverlay(FQD.canvas.pages[1]);
						FQD.canvas.resetCanvasAsPerWindowSize();
			   		},
					function(o, object){
			   			FQD.utility.setObjectPropertiesAfterLoadJSON(o,object);
					}
			);
		}
		
		FQD.undoManager.saveHistory(true);
		if(FQD.elements.buttonShowAllCanvas.hasClass('show-all')){
			FQD.events.showAllCanvas(FQD.elements.buttonShowAllCanvas);
		}
		FQD.elements.buttonShowAllCanvas.show();
		FQD.helper.setScaleUnit();
	}
}

FQD.helper.applyPerforationOptions=function(){
	closeEditPanel();
	FQD.initializecanvas.setEventTicketOptios();
	for(var i = 0; i < FQD.canvas.pages.length; i++){
		FQD.canvas.pages[i].selection=true;
		FQD.canvas.pages[i].renderAll();
	}
}

FQD.helper.applySlitOptions=function(){
	closeEditPanel();
	FQD.initializecanvas.setSlitsOptions();
	for(var i = 0; i < FQD.canvas.pages.length; i++){
		FQD.canvas.pages[i].selection=true;
		FQD.canvas.pages[i].renderAll();
	}
}

FQD.helper.setScaleUnit=function(){
	if($("#MM").prop("checked")){
		$("#MM").click();
	}
	if($("#IN").prop("checked")){
		$("#IN").click();
	}
	if($("#PX").prop("checked")){
		$("#PX").click();
	}
}
FQD.helper.setNonBoldItalicFont=function(){
	config.nonBoldItalicFontList=[];
	config.nonBoldItalicFontList.push("gp_auktyon");
	config.nonBoldItalicFontList.push("gp_auktyondot");
	config.nonBoldItalicFontList.push("gp_bebas");
	config.nonBoldItalicFontList.push("gp_bebasneue");
	config.nonBoldItalicFontList.push("gp_blanco");
	config.nonBoldItalicFontList.push("gp_centabelbook");
	config.nonBoldItalicFontList.push("gp_chunk");
	config.nonBoldItalicFontList.push("gp_cometa");
	config.nonBoldItalicFontList.push("gp_dotage");
	config.nonBoldItalicFontList.push("gp_earthquake");
	config.nonBoldItalicFontList.push("gp_jaggy");
	config.nonBoldItalicFontList.push("gp_karolla");
	config.nonBoldItalicFontList.push("gp_leaguegothic");
	config.nonBoldItalicFontList.push("gp_leaguegothiccondensed");
	config.nonBoldItalicFontList.push("gp_leaguescriptone");
	config.nonBoldItalicFontList.push("gp_magmixer");
	config.nonBoldItalicFontList.push("gp_masterofbreak");
	config.nonBoldItalicFontList.push("gp_ostrichsansdashed");
	config.nonBoldItalicFontList.push("gp_ostrichsansinline");
	config.nonBoldItalicFontList.push("gp_ostrichsansrounded");
	config.nonBoldItalicFontList.push("gp_raleway");
	config.nonBoldItalicFontList.push("gp_sanchez");
	config.nonBoldItalicFontList.push("gp_ultracondensedcanscerif");
	config.nonBoldItalicFontList.push("gp_vonique92");
	config.nonBoldItalicFontList.push("gp_zubilo");

}
