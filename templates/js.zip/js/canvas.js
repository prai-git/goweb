/**********************************************************************************
 * 
 * Responsible for initializing canvas as per selected product
 * 
 *********************************************************************************/
FQD.canvas={};
FQD.canvas.pages=[];
FQD.canvas.svgOverlayElms=[];
FQD.canvas.svgOverlayElmParts=[];
FQD.canvas.noPrintElms =[];
FQD.canvas.overlayScaleX = 1;
FQD.canvas.overlayScaleY = 1;
FQD.canvas.zoomCount=0;
FQD.canvas.holeSize = 0.125; //Actual Hole size is 0.0625 INCH but we take double because we set border radius 50% to show circle size 0.0625 INCH. (21.875 pixel)
FQD.canvas.holePositionSpace = 0.1875;
FQD.canvas.holeTopSpace = 0.1875;

// initializing canvas
FQD.canvas.init=function(){
	
	FQD.canvas.initialiseCanvasSize();
	FQD.canvas.pages = [];
	FQD.canvas.pages.length = 0;
	config.svgOverCount = config.pageNumber.length;
	FQD.elements.divCanvasWrapper.html("");
	var w=FQD.elements.divScroller.width(),
	h=FQD.elements.divScroller.height();
	config.scrollerWidth=w;
	config.scrollerHeight=h;
	var i,c;
	for(i=0;i<config.pageNumber.length;i++){
		c= document.createElement('canvas');
		c.id     = "c"+i;
		c.width  = w;
		c.height = h;
		FQD.elements.divCanvasWrapper.width(w);
		FQD.elements.divCanvasWrapper.height(h);
		FQD.elements.divCanvasWrapper.append(c);
		
		// pushing canvas in to array.
		FQD.canvas.pages[i] = new fabric.Canvas('c'+i ,{ 
											selection: true,
											backgroundColor:"transparent",
											preserveObjectStacking: true,
											renderOnAddRemove: true,
											rotationCursor:'url("'+config.resourcePath+'/images/rotate.png") 10 10, crosshair',
											pageId:i
								});
		// attaching events to canvas
		FQD.setCanvasArea(FQD.canvas.pages[i]);
		FQD.canvas.canvasEvents(FQD.canvas.pages[i]);
		FQD.initializecanvas.createSVGOverlay(FQD.canvas.pages[i]);
		FQD.initializecanvas.drawBleedSafeZone(FQD.canvas.pages[i]);
	}
	
	


	FQD.utility.setImageEffect();		
	FQD.canvas.setCanvasOptions();
	FQD.customize.init();
	if(config.productDetails.isAdmin){
		FQD.tips.close();
	}
	
	FQD.ruler.changeUnit("in",1);
	if(locale=="en_GB"||locale=="de_DE"||locale=="de_AT"||locale=="fr_FR"||locale=="nl_NL"||locale=="en_IE"||locale=="nl_BE"){
		$("#MM").click();
	}
	
	$("#enter-text").show();
	if(config.productDetails.conversionRequired=="true"){
		FQD.utility.convertJsonToSvg("design",config.productDetails.designCode);  
	}
	$("#themesAndStyles").show();
	$("#backgroundArt").show();
	$("#clipArtImages").show();
	
	if(config.isPageRoundCorner=="true"){
		    config.isPageRoundCorner="true";
			var roundCorner;
			if(config.productDetails.radius==0){
				roundCorner=config.productDetails.cornerRadius;
			}else{
				roundCorner=config.productDetails.radius;
			}
			var radius=parseInt(roundCorner)*(350/72)+"";
			$("#canvas-wrapper .trimZone").css("border-radius",radius+"px");
	}
	if(urlPrefix!=""){
		$('#fileUploadWrapper form').attr('action',urlPrefix+'/FileUploadJsonAction');
		$('#proceedToOrderPage').attr('action',standAlone.serviceBaseUrlAction);
	}
	jQuery("#left-tool-bar").show();
	 initToolTip();
	 FQD.allOverlayOnTop();
	 FQD.ruler.addWraper();
	 FQD.canvas.getInitialZoom();
	 FQD.canvas.setProdDescription();
	 config.loaded=true;
	 showDefaultMenuLabels();
	 if(config.isGeneric || config.productDetails.foldingOptions == undefined || FQD.PrintProductType.isFoldedBusinessCard() || FQD.PrintProductType.isFoldedHangTag() || FQD.PrintProductType.isGreetingCard()){
		 FQD.imgLib.loadDefaultCategoryTemplate(true);
		}else{
			FQD.imgLib.getProductCategories();
	 }
	 FQD.canvas.canvasScroll();
	 FQD.elements.fontLoader.remove();
}


FQD.canvas.getScaleMultiplier=function(cw,ch){
	var w=FQD.elements.divScroller.width(),
	h=FQD.elements.divScroller.height(),
	size=1;
	if(cw > w && ch < h){
		size=((w-200)/cw);
	}
	if(cw < w &&  ch > h){
		size=((h-100)/ch);
	}
	if(cw > w &&  ch > h){
			if(cw > ch){
				if(cw > ch*2){
					size=((w-200)/cw);
				}else{
					size=((w/2)/cw);
				}
			}else{
				size=((h-100)/ch);
			}
	}
	return size;
}




FQD.canvas.initialiseCanvasSize=function(){
	if(config.bleedMargin){
		FQD.events.setScroller();
		if(config.productDetails.unit=="mm"){
			config.productWidth = config.productDetails.dpi*config.productDetails.canvasWidth*(1/25.4);
			config.productHeight = config.productDetails.dpi*config.productDetails.canvasHeight*(1/25.4);
		}
		else{
			config.productWidth = config.productDetails.dpi*config.productDetails.canvasWidth;
			config.productHeight = config.productDetails.dpi*config.productDetails.canvasHeight;
		}
		
		if(config.isPageRoundCorner=="true"){
			config.safeMargin = config.productDetails.printProductSafeZoneRoundCornerBean;
			config.bleedMargin = config.productDetails.printProductBleedRoundCornerBean;
	    }else{
	    	config.safeMargin = config.productDetails.printProductSafeZoneBean;
	    	config.bleedMargin = config.productDetails.printProductBleedBean;
	    }

		config.productTypeId=parseInt(config.productDetails.productType);
		config.productSizeId=parseInt(config.productDetails.productSize);
		
		config.productDetails.printJob.printProductBleedId = config.bleedMargin.id;
		
		config.dpi=parseInt(config.productDetails.dpi);
		config.rulerDpi=config.dpi/100;
		
		config.canvasOriginalWidth = config.productWidth + config.bleedMargin.bleedLeft + config.bleedMargin.bleedRight;
		config.canvasOriginalHeight = config.productHeight + config.bleedMargin.bleedTop + config.bleedMargin.bleedBottom;
		
		config.scaleMultiplier=FQD.canvas.getScaleMultiplier(config.canvasOriginalWidth,config.canvasOriginalHeight);
		
		//resize canvas area as per window size
		config.canvasWidth = Math.floor(config.canvasOriginalWidth*config.scaleMultiplier);
		config.canvasHeight = Math.floor(config.canvasOriginalHeight*config.scaleMultiplier);
		
		config.objScaleWidthMultiplier=config.canvasWidth/config.canvasOriginalWidth;
		config.objScaleHeightMultiplier=config.canvasHeight/config.canvasOriginalHeight;
		
		config.shapesStrokeWidth=Math.round(4*config.objScaleWidthMultiplier);
		
	}
	
	if(config.isPageRoundCorner=="true"){
		config.safeMargin = config.productDetails.printProductSafeZoneRoundCornerBean;
		config.bleedMargin = config.productDetails.printProductBleedRoundCornerBean;
    }else{
    	config.safeMargin = config.productDetails.printProductSafeZoneBean;
    	config.bleedMargin = config.productDetails.printProductBleedBean;
    }

	config.productTypeId=parseInt(config.productDetails.productType);
	config.productSizeId=parseInt(config.productDetails.productSize);
	
	config.productDetails.printJob.printProductBleedId = config.bleedMargin.id;
	
	config.dpi=parseInt(config.productDetails.dpi);
	config.rulerDpi=config.dpi/100;
	
	config.canvasOriginalWidth = config.productWidth + config.bleedMargin.bleedLeft + config.bleedMargin.bleedRight;
	config.canvasOriginalHeight = config.productHeight + config.bleedMargin.bleedTop + config.bleedMargin.bleedBottom;
	
	config.scaleMultiplier=FQD.canvas.getScaleMultiplier(config.canvasOriginalWidth, config.canvasOriginalHeight);
	//resize canvas area as per window size
	config.canvasWidth = config.canvasOriginalWidth*config.scaleMultiplier;
	config.canvasHeight = config.canvasOriginalHeight*config.scaleMultiplier;
	
	config.objScaleWidthMultiplier=config.canvasWidth/config.canvasOriginalWidth;
	config.objScaleHeightMultiplier=config.canvasHeight/config.canvasOriginalHeight;
	
	config.shapesStrokeWidth=Math.round(4*config.objScaleWidthMultiplier);
	
}

// to get selected objects on canvas
FQD.canvas.getActiveObjects=function(){
	if(FQD.canvas.pages[config.activeCanvas]){
		var activeObject = FQD.canvas.pages[config.activeCanvas].getActiveObject(),
	    activeGroup = FQD.canvas.pages[config.activeCanvas].getActiveGroup();
		
	    if (activeObject) {
	    	return activeObject;
	    }
	    else if (activeGroup) {
	    	return activeGroup;
	    }
	}
	
}

//to get selected objects on canvas
FQD.canvas.getActiveObjectsHasImage=function(){
	var activeObject = FQD.canvas.getActiveObjects();
	
	if(activeObject && activeObject.type == "group"){
		var items = activeObject._objects;
		for(var i = 0; i < items.length; i++){
	        if(items[i].type == "image" && items[i].id != "placeHolders" && FQD.shapes.hasImageScaleWarning(items[i], activeObject.getScaleX(), activeObject.getScaleY()))
	        	return true;
	    }
	}
	else if(activeObject && activeObject.type == "image" && activeObject.id != "placeHolders" && FQD.shapes.hasImageScaleWarning(activeObject))
		return true;
	else
		return false;
	
	return false;
}

// get active canvas
FQD.canvas.setActiveCanvas=function(id){
	config.activeCanvas=parseInt(id);
	config.activeCanvasId="c"+id;
}

//clear current canvas
FQD.canvas.clearCanvas=function(id){
	customAlertBox(resourcesData.confirm, resourcesData.frontBackCancel,resourcesData.ok,FQD.message.clearCanvas,function(result){
	if (result) { 
		if(FQD.undoManager.undoItems.length == 0 && FQD.undoManager.redoItems.length == 0){
			FQD.undoManager.saveHistory(true);
		}
		config.selectedTool="select";
		FQD.canvas.pages[id].clear();
		jQuery(".canvas-container").eq(id).find('.warning-msg').remove();
		FQD.initializecanvas.resetSVGOverlay(FQD.canvas.pages[id]);
		FQD.canvas.pages[id].selection=true;
		FQD.canvas.pages[id].renderAll();
		FQD.elements.inputColorB.spectrum("set","#ffffff");
		jQuery("#bg-bucket").css("color","#ffffff");
		FQD.elements.divContextMenu.hide();
		FQD.elements.divImgProperties.hide();
		FQD.undoManager.saveHistory(true);
		FQD.imgLib.disableEnableBgTools(false);
		FQD.shapes.showHideCanvasProperties();
		FQD.shapes.showEditProperties();
		FQD.canvas.addNewText();
		FQD.setCanvasArea(FQD.canvas.pages[id]);
		FQD.visualAids.drawGrid(config.gridSize,jQuery('#btnGrid').prop("checked"));
		FQD.initializecanvas.drawBleedSafeZone(FQD.canvas.pages[id]);
		FQD.canvas.pages.forEach(function(canvas){
			canvas.defaultCursor="default";
		});
		FQD.utility.unloadStoreDesign();
		delete config.isAnyRecentTextElementDeleted;
		FQD.visualAids.addScissors(false);
		FQD.visualAids.addScissors($('#visualAids').prop('checked'));
	}
	});
}
FQD.canvas.deselect=function(){
	FQD.canvas.removeSelection();
}

//clear all canvas
FQD.canvas.clearAllCanvas=function(id){
	customAlertBox(resourcesData.confirm, resourcesData.frontBackCancel,resourcesData.ok,FQD.message.clearAll,function(result){
		if(result){
			 config.clearAll=true;
			 FQD.canvas.resetCanvas();
			 FQD.undoManager.clearHistory(true);
			 FQD.elements.divContextMenu.hide();
			 FQD.shapes.showHideCanvasProperties();
			 FQD.canvas.addNewText();
			 FQD.visualAids.drawGrid(config.gridSize,jQuery('#btnGrid').prop('checked'));
			 FQD.utility.unloadStoreDesign();
			 FQD.shapes.showEditProperties();
			 delete config.isAnyRecentTextElementDeleted;
			 FQD.visualAids.addScissors(false);
			 FQD.visualAids.addScissors($('#visualAids').prop('checked'));
			 jQuery(".warning-msg").remove();
			 
		}
	});
}

FQD.canvas.resetCanvas=function(){
	 config.selectedTool="select";
	 var i=0;
	 for(i ;i < FQD.canvas.pages.length;i++){
			FQD.canvas.pages[i].clear();
			jQuery(".canvas-container").eq(i).find('.warning-msg').remove();
			FQD.initializecanvas.resetSVGOverlay(FQD.canvas.pages[i]);
			FQD.canvas.pages[i].selection=true;
			FQD.canvas.pages[i].renderAll();
			FQD.setCanvasArea(FQD.canvas.pages[i]);
			FQD.initializecanvas.drawBleedSafeZone(FQD.canvas.pages[i]);
			FQD.imgLib.disableEnableBgTools(false);
		}
	 FQD.elements.inputColorB.spectrum("set","#ffffff");
	 jQuery("#colorB2").spectrum("set","#ffffff");
	 jQuery("#bg-bucket").css("color","#ffffff");
	 FQD.visualAids.addScissors(false);
	 FQD.visualAids.addScissors($('#visualAids').prop('checked'));
	 if(config.firstTimePageRender && config.productDetails.designCode > 0 && !config.clearAll){
		 FQD.utility.reloadRefreshData();
	 }
	 delete config.clearAll;
}
FQD.canvas.resetZoom=function(id){
		var lavel= (config.scaleMultiplier*100).toFixed();
			FQD.canvas.zoomCount=0;
			FQD.canvas.setZoom(1);
			id.val(lavel);
			if(config.productDetails.productType == 1 || config.productDetails.productType == 2){
				FQD.canvas.setZoom(0.6);
			}
			FQD.visualAids.addScissors(false);
			FQD.visualAids.addScissors($('#visualAids').prop('checked'));
}
FQD.canvas.zoomIn=function(id){
		var size=parseFloat(FQD.canvas.pages[config.activeCanvas].getZoom().toFixed(2));
		size=size+0.1;
		FQD.canvas.setZoom(1);
		FQD.canvas.setZoom(size,id);
		FQD.visualAids.addScissors(false);
		FQD.visualAids.addScissors($('#visualAids').prop('checked'));
}

FQD.canvas.zoomOut=function(id){
		var size=parseFloat(FQD.canvas.pages[config.activeCanvas].getZoom().toFixed(2));
		if(size > 0.1){
			size=size-0.1;
			FQD.canvas.setZoom(1);
			FQD.canvas.setZoom(size,id);
			FQD.visualAids.addScissors(false);
			FQD.visualAids.addScissors($('#visualAids').prop('checked'));
		}
}

FQD.canvas.getInitialZoom=function(){
	if(config.productDetails.productType == 1 || config.productDetails.productType == 2){
		FQD.canvas.setZoom(0.6);
	}else{
	var level= (config.scaleMultiplier*100).toFixed();
	 var id=setInterval(function(){
		 var isLoaded=jQuery('#zoom-level').length;
		 if(isLoaded==1){
				jQuery('#zoom-level').val(level);
				clearInterval(id);
		 }
		 
	 }, 10);
	}
}

FQD.canvas.setProdDescription=function(){
	
	config.setProdDescriptionIntervalId=setInterval(function(id){ 
		if($("#prodDimension").length!=0)
         {
			   var prodDimension=config.productDetails.canvasWidth+" X "+config.productDetails.canvasHeight+" "+config.productDetails.unit;
			   $("#prodDimension").html(prodDimension);
			   $("#prodDpi").html(config.productDetails.dpi);
			   FQD.canvas.stopProdDescriptionInterval(config.setProdDescriptionIntervalId);
         }
	},
	10);

}
FQD.canvas.stopProdDescriptionInterval=function(id){
	clearInterval(id);
	delete config.setProdDescriptionIntervalId;
	if(config.productDetails.isAdmin){
		$("#tipsButton").hide();
		$("#help").hide();
	}
}
FQD.canvas.resetCanvasAsPerWindowSize=function(canvasId, canvasRotate){
	FQD.canvas.initialiseCanvasSize();
	 var i=0; 
	 for(i;i < FQD.canvas.pages.length;i++){
		 if(canvasId != undefined && canvasId != i && canvasId != -1){
			 continue;
		 }
		 var canvas = FQD.canvas.pages[i];
		 var w = FQD.elements.divScroller.width(),
		 h = FQD.elements.divScroller.height();
		 canvas.setWidth(w);
		 canvas.setHeight(h);
		 FQD.canvas.setElementAsperCanvas(canvas, canvasRotate);
		 FQD.initializecanvas.createSVGOverlay(FQD.canvas.pages[i]);
	 }
	 
	 config.cornerChanged = false;
	 FQD.canvas.getInitialZoom();
	 
	 if(!FQD.products.hasTemplateOverlay())
		 FQD.visualAids.applyChangedSetting();
}

FQD.canvas.setElementAsperCanvas = function(canvas, canvasRotate, hasExtraBleed){
	var canArea = canvas.getItemByName("canvasArea");
	fill= null;
	FQD.removeOverlay(canvas, false);
	FQD.setCanvasArea(canvas);
	FQD.initializecanvas.drawBleedSafeZone(canvas);
	
	
	if(!canArea || canArea == undefined){
		canArea = canvas.getItemByName("canvasArea");
	}
	
	canvasRotate = canvasRotate == undefined? false: canvasRotate;
	hasExtraBleed = hasExtraBleed == undefined? false: hasExtraBleed;
	
	fill=canArea.getFill();
	x=config.canvasOrigin.x0;
 	y=config.canvasOrigin.y0;
 	cx=canArea.getLeft();
 	cy=canArea.getTop();
 	sx=roundTo(config.canvasOrigin.width/canArea.getWidth(), 4);
 	sy=roundTo(config.canvasOrigin.height/canArea.getHeight(), 4);
 	 
 	if(config.cornerChanged){
 		var extraBleed = FQD.canvas.getExtraBleedDifference();
 		var dX = roundTo((config.canvasOrigin.width - (extraBleed.left + extraBleed.right))/canArea.getWidth(), 4);
 		var dY = roundTo((config.canvasOrigin.height - (extraBleed.top + extraBleed.bottom))/canArea.getHeight(), 4);
 	}
 	else if(hasExtraBleed){
 		sx = roundTo((config.canvasOrigin.width - (config.extBleed_XDiff*config.scaleMultiplier * 2))/canArea.getWidth(), 4);
 	 	sy = roundTo((config.canvasOrigin.height - (config.extBleed_XDiff*config.scaleMultiplier * 2))/canArea.getHeight(),4);
 	}
 	
 	if(canvasRotate)
 		sx = sy = dX = dY = 1;
 	
 	var objects = canvas.getObjects();
	objects.forEach(function(obj){
		if(obj.name == "canvasArea" && fill){
			obj.setFill(fill);
		}
		if(obj.name =="bgElement"){
			if(config.cornerChanged || canvasRotate || hasExtraBleed || FQD.PrintProductType.isEnvelope()){
				FQD.helper.adJustBackgroundImage(canvas);
			}
		}
		else{
			if(obj.name != "overlayElm" && obj.name !="canvasArea"){
				if(config.cornerChanged){
					obj.scaleX = obj.scaleX * dX;
					obj.scaleY = obj.scaleY * dY;
					obj.left = roundTo(x + roundTo((obj.left - cx), 2) * dX, 4);
					obj.top = roundTo(y + roundTo((obj.top - cy), 2) * dY, 4);
					FQD.helper.adjustTemplateObjects(obj);
					obj.setCoords();
				}else{
					obj.scaleX = obj.scaleX * sx;
					obj.scaleY = obj.scaleY * sy;
					obj.left = roundTo(x + roundTo((obj.left - cx), 2) * sx, 4);
					obj.top = roundTo(y + roundTo((obj.top - cy), 2) * sy, 4);
					 
					
					if(hasExtraBleed){
						obj.left += config.extBleed_XDiff * config.scaleMultiplier;
						obj.top += config.extBleed_YDiff * config.scaleMultiplier;
					}
					
					obj.setCoords();
				}
			}
			FQD.message.setImageWarnings(obj,canvas);
		}
	});
	canvas.renderAll();
}

// set Zoom
FQD.canvas.setZoom=function(size){
	 var i=0,w,h; 
	 for(i;i < FQD.canvas.pages.length;i++){
		 var canvas = FQD.canvas.pages[i];
		 var zoomCenter = new fabric.Point(canvas.getWidth()/2,canvas.getHeight()/2);
		 canvas.zoomToPoint(zoomCenter, size);		
		 canvas.setZoom(size);
		 w = config.canvasWidth * size,
		 h = config.canvasHeight * size;
		 canvas.calcOffset();
		 canvas.renderAll();
		 canvas.getObjects().forEach(function(obj){
			 obj.setCoords();
			 if(obj.type ==='image' && obj.id){
				 setIconPosition(canvas,obj ,jQuery("#"+obj.id));
			 }
			 
		 });
		 if(config.holeOptionId > 0)
				FQD.canvas.changeHolePosition(i);
		 if(size == 1){
			 var delta = new fabric.Point(0, 0);
			canvas.absolutePan(delta);
		 }
	 }
	 
	 config.rulerDpi = config.dpi/100*size;
	 config.zoom = size;
	
     jQuery("#zoom-level").val((size*config.scaleMultiplier*100).toFixed(1));

	
	 FQD.ruler.changeUnit(config.unit, config.tick);

	 
	 if(config.selectedTool !== "pan"){
		 FQD.canvas.removeSelection();	
	 }
	 if(config.canvasOrigin && config.canvasOrigin){
		 config.virtualCanvasHeight=config.canvasOrigin.height*size;
		 config.virtualCanvasWidth=config.canvasOrigin.width*size; 
	 }
	
}

FQD.canvas.changeHolePosition = function(cnvInx){
	var wid = config.canvasWidth;
	var heg = config.canvasHeight;
	var holeW = FQD.canvas.holeSize * config.scaleMultiplier;
	var leftSpace = holeLeft = FQD.canvas.holePositionSpace;
	var holeTop = (FQD.canvas.holeTopSpace + config.bleedMargin.bleedTop) * config.scaleMultiplier;
	holeTop += config.canvasOrigin.y0;

	if(cnvInx == undefined){
		for(var i = 0; i < FQD.canvas.pages.length; i++){
			FQD.canvas.changeHolePosition(i);
		}
		return;
	}
	
	var canvas = FQD.canvas.pages[cnvInx];
	var items = canvas.getItemsByName("overlayElm"); 
	
	items.forEach(function(obj){
		if((obj.hole && obj.hole != undefined) || (obj.foldpagehole && obj.foldpagehole != undefined))
		{
			switch(config.holeOptionId){
				case FQD.PrintProductType.HOLE_POSITION_TOP_LEFT:
					if(FQD.PrintProductType.isFoldedHangTag()){
						if(obj.foldpagehole && obj.foldpagehole != undefined)
							holeLeft = (wid/2)-(holeW/2) + ((leftSpace + config.bleedMargin.bleedLeft) * config.scaleMultiplier);
						else
							holeLeft = (wid/2)-(holeW/2) - ((leftSpace + config.bleedMargin.bleedLeft) * config.scaleMultiplier);
						holeLeft += config.canvasOrigin.x0;
					}else{
						if(cnvInx == 0){
							holeLeft = (leftSpace + config.bleedMargin.bleedLeft) * config.scaleMultiplier;
							holeLeft += config.canvasOrigin.x0;
						}
						else if(cnvInx == 1){
							holeLeft = wid - holeW -((leftSpace + config.bleedMargin.bleedRight)*config.scaleMultiplier);
							holeLeft += config.canvasOrigin.x0;
						}
					}
					break;
				case FQD.PrintProductType.HOLE_POSITION_TOP_CENTER:
					if(FQD.PrintProductType.isFoldedHangTag()){
						holeLeft = (wid/2)-(holeW/2);
						holeLeft += config.canvasOrigin.x0;
						if(obj.foldpagehole && obj.foldpagehole != undefined)
							holeTop = (heg/2)-(holeW/2) + ((leftSpace + config.bleedMargin.bleedLeft) * config.scaleMultiplier);
						else
							holeTop = (heg/2)-(holeW/2) - ((leftSpace + config.bleedMargin.bleedLeft) * config.scaleMultiplier);
						holeTop += config.canvasOrigin.y0;
					}else{
						holeLeft = (wid/2)-(holeW/2);
						holeLeft += config.canvasOrigin.x0;
					}
					break;
				case FQD.PrintProductType.HOLE_POSITION_TOP_RIGHT:
					if(cnvInx == 0){
						holeLeft = wid - holeW -((leftSpace + config.bleedMargin.bleedRight)*config.scaleMultiplier);
						holeLeft += config.canvasOrigin.x0;
					}
					else if(cnvInx == 1){
						holeLeft = (leftSpace + config.bleedMargin.bleedLeft) * config.scaleMultiplier;
						holeLeft += config.canvasOrigin.x0;
					}
					break;
			}
			obj.setLeft(holeLeft);
			obj.setTop(holeTop);
		}
	});
	
	canvas.renderAll();
}

FQD.canvas.changeFoldingOption = function(){
	for(var i = 0; i < FQD.canvas.pages.length; i++){
		var canvas = FQD.canvas.pages[i];
		var items = canvas.getItemsByName("overlayElm"); 
		items.forEach(function(obj){
			if(obj.foldline && obj.foldline != undefined){
				obj.remove();
			}
		});
		
		FQD.initializecanvas.drawFoldLine(canvas);
	}
}

FQD.canvas.getZoneSizes=function(w, h){
	var trimRadius = 0;
	if(document.querySelector(".trimZone")){
		trimRadius = parseInt(document.querySelector(".trimZone").style.borderRadius.replace("px",""));
	}
	if(trimRadius > 0){
		trimRadius = (parseInt(config.productDetails.cornerRadius)*100)/config.canvasWidth;
		trimRadius = (((trimRadius*w)/100)*(350/72)).toFixed(2); 
	}
	 
	var zoneGap = FQD.canvas.getCanvasZonesGap(0);
	
	var bleed_L = zoneGap.bleedZone.bleedLeft;
	var bleed_B = zoneGap.bleedZone.bleedBottom;
	var bleed_R = zoneGap.bleedZone.bleedRight;
	var bleed_T = zoneGap.bleedZone.bleedTop;
	var safe_L = zoneGap.safeZone.safeLeft;
	var safe_B = zoneGap.safeZone.safeBottom;
	var safe_R = zoneGap.safeZone.safeRight;
	var safe_T = zoneGap.safeZone.safeTop;
		
	var bzW = w-(bleed_L+(bleed_R));
	var bzH = h-(bleed_T+(bleed_B));
	
	var szW = w-(safe_L+(safe_R));
	var szH = h-(safe_T+(safe_B));
	
	return ({bzL:bleed_L, bzT:bleed_T, bzW:bzW, bzH:bzH, szL:safe_L, szT:safe_T, szW:szW, szH:szH, tRadius:trimRadius});
}

FQD.canvas.getExtraBleedDifference=function(){
	var leftDiff = parseInt(config.productDetails.printProductBleedRoundCornerBean.bleedLeft) - parseInt(config.productDetails.printProductBleedBean.bleedLeft);
	var rightDiff = parseInt(config.productDetails.printProductBleedRoundCornerBean.bleedRight) - parseInt(config.productDetails.printProductBleedBean.bleedRight);
	var topDiff = parseInt(config.productDetails.printProductBleedRoundCornerBean.bleedTop) - parseInt(config.productDetails.printProductBleedBean.bleedTop);
	var bottomDiff = parseInt(config.productDetails.printProductBleedRoundCornerBean.bleedBottom) - parseInt(config.productDetails.printProductBleedBean.bleedBottom);
	
	leftDiff = roundTo(((config.isPageRoundCorner == "true")? leftDiff: (leftDiff*-1)) * config.scaleMultiplier, 4);
	rightDiff = roundTo(((config.isPageRoundCorner == "true")? rightDiff: (rightDiff*-1)) * config.scaleMultiplier, 4);
	topDiff = roundTo(((config.isPageRoundCorner == "true")? topDiff: (topDiff*-1)) * config.scaleMultiplier, 4);
	bottomDiff = roundTo(((config.isPageRoundCorner == "true")? bottomDiff: (bottomDiff*-1)) * config.scaleMultiplier, 4);
	
	return ({left:leftDiff, bottom:bottomDiff, right:rightDiff, top:topDiff});
}

//remove selections of all the canvas
FQD.canvas.removeSelection=function(leaveCanvas){
	FQD.shapes.removeShadow();
	for(i=0;i < FQD.canvas.pages.length;i++){
		if(i != leaveCanvas){
			FQD.canvas.pages[i].deactivateAll().renderAll();
		}
	}
	if(config.selectedTool !== "pan"){
		config.selectedTool="select";
	}

}

//allow canvas selection 
FQD.canvas.setCanvasSelectionTrue=function(){
	if(FQD.canvas.getActiveObjects()){
		return ;
	}
	config.selectedTool="select";
	for(i=0;i < FQD.canvas.pages.length;i++){
		FQD.canvas.pages[i].forEachObject(function(obj){
			if(!obj.isObjectLocked){
				obj.selectable=true;
				obj.hasControls=true;
			    obj.hasBorders=true;
			    obj.setShadow(null);
			}
			obj.evented=true;
			if(obj.alwaysNotselectable){
				obj.selectable=false;
				obj.hasControls=false;
				obj.hasBorders=false;
				obj.evented=false;
			}
			obj.setCoords();
		  });
		FQD.canvas.pages[i].defaultCursor="default";
		FQD.canvas.pages[i].selection=true;
		FQD.canvas.pages[i].renderAll();
	}
	jQuery("#eyeDropper").removeClass("activeted");
}

//allow canvas selection 
FQD.canvas.setCanvasSelectionFalse=function(){
	if(!jQuery("#objInfo").hasClass('active')){
		for(i=0;i < FQD.canvas.pages.length;i++){
			FQD.canvas.pages[i].forEachObject(function(obj){
				if(!obj.isObjectLocked){
					obj.selectable=true;
					obj.hasControls=false;
				    obj.hasBorders=false;
				}
				obj.evented=false;
			  });
			FQD.canvas.pages[i].selection=false;
			FQD.canvas.pages[i].renderAll();
		}
	}
		
}

//allow to delete selected objects
FQD.canvas.deleteObjects=function(){
		var canvas=FQD.canvas.pages[config.activeCanvas];
		var activeObject = canvas.getActiveObject(),
	    activeGroup = canvas.getActiveGroup(),
		isUploadedImage=false;
	    if (activeObject) {
	    	  if(activeObject.type == "image"){
	    		  isUploadedImage=true;
	    		  if(activeObject.id){
	    			  jQuery("#"+activeObject.id).remove();
	    		  }
	    	  }
	    	  
	    	  if(activeObject.placeHolderContent){
	    		  config.templateDeletedTextElements.push(activeObject);
	    		  config.isAnyRecentTextElementDeleted=true;
	    	  }
	    	  canvas.remove(activeObject);
	       
	    }		
	    else if (activeGroup) {

	            var objectsInGroup = activeGroup.getObjects();
	            canvas.discardActiveGroup();
	            objectsInGroup.forEach(function(object) {
	            	if(object.type == "image"){
	  	    		  isUploadedImage=true;
	  	    		  if(object.id){
		    			  jQuery("#"+object.id).remove();
		    		  }
	  	    	  }
	  	    	  if(object.placeHolderContent){
	  	    		config.templateDeletedTextElements.push(object);
	  	    		config.isAnyRecentTextElementDeleted=true;
		    	  }
	            	canvas.remove(object);
	           });
	       
	    }
	    FQD.elements.imgResizeWarning.hide();
	    FQD.elements.divContextMenu.hide();
	    canvas.renderAll();
	    FQD.canvas.addNewText();
	    FQD.undoManager.saveHistory(true);
	    FQD.shapes.showEditProperties();
	    if(isUploadedImage){
	    	FQD.utility.unloadStoreDesign();
	    }
	
}

FQD.canvas.setImageAsBackground=function(){
	jQuery("#divBgImageEffects").show();
	jQuery("#removeBgImg").show();
	jQuery("#BGEffects").show();
	jQuery("#BgZoomProp").show();
	jQuery("#dvBgImgDirn").show();
	var img=FQD.canvas.getActiveObjects();
	var src=img.getSrc();
	var isClipArt=img.isClipArt;
	var originalWidth=img.originalWidth;
	var originalHeight=img.originalHeight;
	var canvas=FQD.canvas.pages[config.activeCanvas];
	canvas.remove(img);
	FQD.imgLib.setBgImage(src,canvas,originalWidth,originalHeight);	
	var setTime=setInterval(function setTimmer(){
			if(canvas.backgroundImage){	
				clearInterval(setTime);
				FQD.imgLib.disableEnableBgTools(true);
				FQD.undoManager.saveHistory(true);
			}
  	} , 50);
}

FQD.canvas.setTextBoxId=function(){
	return "textBox"+Math.floor(Math.random()*100000000);
},

FQD.canvas.addNewText=function(addTextByBtn){
	var inputText="",value="",shape,
	canvas=FQD.canvas.pages[config.activeCanvas];
	if(addTextByBtn){
		FQD.shapes.newText(50);
	}
	else
	{
		var arr=[];
		canvas.getObjects().forEach(function(obj){
			var placeHolder=config.textPlaceHolder;
			if(obj.type == "textbox"){
				var disabled="";
				if(obj.id === undefined){
					obj.set('id',FQD.canvas.setTextBoxId());
				}
				if(obj.isObjectLocked == "true"){
					disabled="disabled";
				}
				
				if(obj.placeHolderContent){
					if(obj.text==obj.placeHolderTextValue){
						value="";
						placeHolder=obj.placeHolderTextValue;
					}else{
						value=obj.text;
					}
					
				}else{
					if(obj.text == config.textPlaceHolder){
						value="";
					}else{
						value=obj.text;
						
					}
				}
				
				inputText +='<textarea rows="2" oninput="FQD.canvas.UpdateNewText(this);"\
					onfocus="FQD.canvas.selectText(this,event);setTextAreaCursor(this);"\
							 id ="'+obj.id+'"placeholder="'+placeHolder+'" '+disabled+'>'+value+'</textarea>';
			  obj.set("breakWords",true);
			}
			if(obj.type=="group"){
				var objArr=obj._objects;
				for(var i=0;i<objArr.length;i++){
					var disabled="";
					 if(objArr[i].type=="textbox"){
						 if(objArr[i].isObjectLocked == "true"){
								disabled="disabled";
							}
							inputText +='<textarea rows="2" oninput="FQD.canvas.UpdateNewText(this);"\
								onfocus="FQD.canvas.selectText(this,event);setTextAreaCursor(this);"\
										 id ="'+objArr[i].id+'" '+disabled+'>'+objArr[i].text+'</textarea>';
						  obj.set("breakWords",true);
						  arr.push(objArr[i].id);
					 }
				}
			}
		});
		FQD.elements.divNewTextField.html(inputText);
		for(var i=0;i<arr.length;i++){
			   $("#"+arr[i]).prop("disabled",true);
			   $("#"+arr[i]).css("background-color","#DEDEDD");
		}
	}
}

FQD.canvas.selectText=function(that,event){
	FQD.canvas.removeSelection();
	var canvas=FQD.canvas.pages[config.activeCanvas];
	canvas.getObjects().forEach(function(obj){
		if(obj.type == "textbox" && obj.id && obj.id == that.id){
			if(obj.isObjectLocked != "true"){
				canvas.setActiveObject(obj);
			}
			 return false;
		}
	});
	FQD.shapes.showEditProperties();
}
FQD.canvas.FocusOnText=function(id){
	FQD.elements.divNewTextField.find("textarea").removeClass("focus");
	jQuery("#"+id).addClass("focus");
}
FQD.canvas.UpdateTextField=function(id,value){
	
	if(FQD.canvas.getActiveObjects().placeHolderContent){
		if(value==FQD.canvas.getActiveObjects().placeHolderTextValue){
			jQuery("#"+id).val("");
		}else{
			jQuery("#"+id).val(value);
			jQuery("#"+id).scrollTop(1);
		}
		
	}else{
		if(value == config.textPlaceHolder){
			jQuery("#"+id).val("");
		}else{
			jQuery("#"+id).val(value);
			jQuery("#"+id).scrollTop(1);
		}
	}

}
FQD.canvas.UpdateNewText=function(that){
	var text=that.value;
	text=text.replace(/\t/g, "    ");
	that.value=text;
	fabric.util.clearFabricFontCache();
	var obj=FQD.canvas.getActiveObjects();
	if(obj == undefined)
		return;
	
	if(obj._objects){
		obj._objects.forEach(function(elm){
			if(elm.type == "textbox" && elm.id && elm.id == that.id){
				if(that.value == ""){
					if(elm.placeHolderContent){
						elm.setText(elm.placeHolderTextValue);
					}else{
						elm.setText(config.textPlaceHolder);
					}
					elm.lastOpacityUsed=elm.getOpacity();
					elm.setOpacity(.41);
				}else{
					elm.setText(that.value);
					if(elm.lastOpacityUsed){
						elm.setOpacity(elm.lastOpacityUsed);
					}
				}
				elm.isModified=true;
			}
		});
	}
	else{
		if(obj.type == "textbox" && obj.id && obj.id == that.id){
			if(that.value == ""){
				if(obj.placeHolderContent){
					obj.setText(obj.placeHolderTextValue);
				}else{
					obj.setText(config.textPlaceHolder);
				}
				obj.lastOpacityUsed=obj.getOpacity();
				obj.setOpacity(.41);
			}else{
				obj.setText(that.value);
				if(obj.lastOpacityUsed){
					obj.setOpacity(obj.lastOpacityUsed);
				}
			}
			obj.isModified=true;
		}
	}
	
	FQD.canvas.pages[config.activeCanvas].renderAll();
}


FQD.canvas.hasText=function(){
	var obj=FQD.canvas.getActiveObjects(),
	hasText=false;
	if(obj._objects){
		obj._objects.forEach(function(elm){
			if(elm.type == "textbox"){
				hasText=true;
			}
		});
	}else if(obj.type == "textbox"){
			hasText=false;
		}
	return hasText;
}

FQD.canvas.updateTransformControls=function(){
	var hasText=false;
	if(FQD.canvas.hasText()){
		if(FQD.canvas.getActiveObjects()._objects && FQD.canvas.getActiveObjects()._objects.length > 1){
			FQD.canvas.getActiveObjects().setControlsVisibility({
				mt: false,
				mb: false,
				ml: false,
				mr: false,
				tr: false,
				tl: false,
				br: false,
				bl: false
			});
		}else{
			FQD.canvas.getActiveObjects().setControlsVisibility({
				mt: false,
				mb: false,
				tr: false,
				tl: false,
				br: false,
				bl: false
			});
		}
		hasText=true;
		FQD.canvas.getActiveObjects().hasRotatingPoint = true;
	}else if(FQD.canvas.getActiveObjects().type != "textbox"){

		FQD.canvas.getActiveObjects().setControlsVisibility({
			mt: FQD.shapes.constrainScale? false: true,
			mb: FQD.shapes.constrainScale? false: true,
			ml: FQD.shapes.constrainScale? false: true,
			mr: FQD.shapes.constrainScale? false: true
		});
	}
	
	jQuery("#constrainBtn").show();
	$("#objInfo .height-container").css("visibility","visible");
	$("#objInfo .width-container").css("visibility","visible");
	$("#constrainBtn").css({
		'position':'relative',
		'top':'',
		'left':''
	});
	jQuery("#heightobj, #widthobj, #applyobj, #constrainBtn").prop("disabled", hasText);
	if(FQD.canvas.getActiveObjects().type=="textbox"){
		FQD.elements.objectWidth.attr("disabled","disabled");
		FQD.elements.objectHeight.attr("disabled","disabled");
		FQD.elements.objectWidth.val("");
		FQD.elements.objectHeight.val("");
	}
	if(FQD.canvas.getActiveObjects().type=="line"){
		$("#objInfo .height-container").css("visibility","hidden");
		$("#objInfo .width-container").css("visibility","hidden");
		$("#constrainBtn").css({
			'position':'absolute',
			'top':'103px',
			'left':'143px'
		});
	}
	if(FQD.canvas.getActiveObjects().type == "textbox" || hasText)
		jQuery("#constrainBtn").hide();
	FQD.canvas.pages[config.activeCanvas].renderAll();
}


FQD.canvas.getColorFromCanvas = function(canvas,o) {
		var z=FQD.canvas.pages[config.activeCanvas].getZoom();
	    var mouse = canvas.getPointer(o.e);
	    var x = o.e.offsetX;
        var y = o.e.offsetY;
	    var ctx = canvas.getContext("2d");
	    var px = ctx.getImageData(x, y, 1, 1).data;
	    var hex = "#" + ("000000" + rgbToHex(px[0], px[1], px[2])).slice(-6);
	    //console.log(hex);
	    jQuery("#dropper-color").val(hex);
	    config.fillColor=hex;
    	config.txtColor=hex;
	    if(config.dropperObj){
	    	config.dropperObj.setFill(hex);
	    	FQD.canvas.pages[config.activeCanvas].renderAll();
	    }
}

FQD.canvas.setDropper=function(elm){
	if(!elm.hasClass("disabled")){
		config.dropperObj = FQD.canvas.pages[config.activeCanvas].getActiveObject();
		FQD.canvas.setCanvasSelectionFalse();
		if(elm.hasClass("activeted")){
			elm.removeClass("activeted");
			FQD.canvas.setCanvasSelectionTrue();
			FQD.canvas.pages.forEach(function(canvas){
				canvas.defaultCursor="default";
			});
		}else{
			config.selectedTool="dropper";
			elm.addClass("activeted");
			FQD.canvas.pages.forEach(function(canvas){
				canvas.defaultCursor="crosshair";
			});
			FQD.shapes.showHideCanvasProperties();
		}
	}
};

//responsible for all the canvas events for drawing and get target elements properties.
FQD.canvas.canvasEvents=function(canvas){
	
	var shape, isDown,isMove, origX, origY,x,y,w,h,panning=false;

	//draw objects as per selected tool
	canvas.on('mouse:down', function(o){
		jQuery(".warning-msg").hide();
		  config.pageX=o.e.pageX;
		  config.pageY=o.e.pageY;
		  panning = true;
		  isDown = true;
		  config.down=true;
		  
		  if(o.target && o.target.isObjectLocked == "true"){
			  o.target.selectable = false;
			  return;
		  }
		  
		  if(config.selectedTool === 'dropper'){
			  FQD.canvas.getColorFromCanvas(canvas,o);
			  return;
		  }
		  
		  if(config.selectedTool != "select"){
		    var pointer = canvas.getPointer(o.e);
		    origX = roundTo(pointer.x, 4);
		    origY = roundTo(pointer.y, 4);
		    var pointer = canvas.getPointer(o.e);
		    
		    if(config.selectedTool == "rect"){
		    	  shape = FQD.shapes.rect(origX,origY,pointer.x,pointer.y);
		    	  shape.isModified=true;
		    	  shape.setFill(config.fillColor);
		    	  canvas.add(shape);
		    }
		    else if(config.selectedTool == "rounded-rect"){
		    	  shape = FQD.shapes.rect(origX, origY, pointer.x, pointer.y, true);
		    	  shape.isModified=true;
		    	  shape.setFill(config.fillColor);
		    	  canvas.add(shape);
		    }
		    else if(config.selectedTool == "ellipse"){
		    	  shape = FQD.shapes.circle(origX,origY,pointer.x,pointer.y);
		    	  shape.isModified=true;
		    	  shape.setFill(config.fillColor);
		    	  canvas.add(shape);
		    }
		    else if(config.selectedTool == "line"){
		    	  shape = FQD.shapes.line(origX,origY,pointer.x,pointer.y);
		    	  shape.isModified=true;
		    	  canvas.add(shape);
		    }
		    else if(config.selectedTool == "text"){
		    	  shape = FQD.shapes.text(origX,origY,pointer.x,pointer.y);
		    	  shape.setFontFamily("gp_arial");
		    	  shape.placeHolderTextValue=config.textPlaceHolder;
		    	  jQuery('#select').trigger("click");
		    	  shape.isModified=true;
		    	  canvas.add(shape);
		    	  FQD.canvas.addNewText();
		    	  config.origText="";		    	  
		    	  FQD.undoManager.saveHistory(true);
		    	  fabric.util.clearFabricFontCache();
		    	  
		    }
		     FQD.utility.setCachedProperties(shape);
		     if(shape){
		    	 shape.setFill(config.fillColor);
		     }
		     canvas.renderAll();
		}
	    if(this.getActiveObject() || this.getActiveGroup()) {
	    	var obj=this.getActiveObject();
	    	if(obj){
	    		config.moveObject  = jQuery.extend({}, this.getActiveObject());
	    	}else{
	    		config.moveObject  = jQuery.extend({}, this.getActiveGroup());
	    	}
            config.initialCanvas = this.lowerCanvasEl.id;
        }
	    
		if(!FQD.canvas.getActiveObjects()){
			FQD.initializecanvas.disableInputs();
		}
		else{
			$("#objInfo, #obj-rotation, #obj-align, #opacity-properties, #stroke-width-container").removeClass("active");
			FQD.canvas.updateTransformControls();
			FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
		}
		FQD.elements.divContextMenu.hide();
		
		var elms=FQD.canvas.pages[config.activeCanvas]._objects;
	   	 for(var i=0;i<elms.length;i++){
	   		  if(elms[i].isObjectLocked=="true"){
	   			  elms[i].selectable=false;
	   		  }
	   	 }
	   	 var timeout=1000;

	});
	//move to draw objects as per selected tool
	canvas.on('mouse:move', function(o){
		if (config.selectedTool === "pan" && o && o.e && panning) {	
			 var width=screen.availWidth;
			 var height=screen.availHeight;
			 config.isPan=true;
			 FQD.canvas.panning(o.e.movementX,o.e.movementY);
		}
		else if(config.selectedTool !== "dropper"){
			if (!isDown) return;
		    var flagCursor=true;
			 	isMove=true;
			 	var pointer = canvas.getPointer(o.e);
				if(config.selectedTool != "select"){
				    if(config.selectedTool == "rect" || config.selectedTool == "rounded-rect"){
					    if(origX>pointer.x ){
					        shape.set({ left: Math.abs(pointer.x) });
					    }
					    if(origY>pointer.y && config.key != 16){
					        shape.set({ top: Math.abs(pointer.y) });
					    }
					  var w,h; 
					  w = Math.abs(origX - pointer.x);
					  h = Math.abs(origY - pointer.y);
					  if(config.key && config.key == 16){
						  shape.set({ width: w, height:w});
					  }else{
						  shape.set({ width: w, height:h });
					  }
				    }
				    if(config.selectedTool == "line"){
				    	  if(config.key && config.key == 16){
					    	  if(origX > pointer.y){
					    		  shape.set({ x2: pointer.x, y2: origY });
					    	  }else{
					    		  shape.set({ x2: origX, y2: pointer.y });
					    	  }
						  }else{
							  shape.set({ x2: pointer.x, y2: pointer.y });
						  }
				    }
				    if(config.selectedTool == "ellipse"){
				    	shape.set({ radius: Math.abs(origY - pointer.y)});
				    }
				    canvas.renderAll();
			   }
				if(FQD.canvas.getActiveObjects() && flagCursor) {
					flagCursor=false;
				}
		}
		 
		});

	canvas.on('mouse:up', function(o){
		 jQuery(".warning-msg").show();
		panning = false;
		if(!isMove && shape){
			  if(config.selectedTool == "rect"){
				  shape.set({ width: 70, height:50});
			  }
			  if(config.selectedTool == "rounded-rect"){
				  shape.set({width: 90, height:75, rx:20, ry:20});
			  }
			  if(config.selectedTool == "line"){
				  shape.set({ x2: origX+80 });
			  }
			  if(config.selectedTool == "ellipse"){
				  shape.set({ radius: 40 });
			  }
			  canvas.renderAll();
		}
		
		if(shape && (config.selectedTool == "rect" || config.selectedTool == "rounded-rect" || config.selectedTool == "line" || config.selectedTool == "ellipse")){
			shape.remove(); 
			canvas.add(shape);
			FQD.allOverlayOnTop();
			canvas.renderAll();
			FQD.undoManager.saveHistory(true);
			jQuery('#select').trigger("click");
			FQD.message.objectOutsideSafeAndTrimZone(shape);
		}
		
		FQD.shapes.showEditProperties();
		isDown = false;
		shape  = false;
		config.down=false;
		config.sliderEvent=false;
	    
		if(FQD.canvas.getActiveObjects())
	    {
			FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
			FQD.elements.divAlignTools.find("a").removeClass("disabled");
			FQD.canvas.updateTransformControls();
			
			if(FQD.elements.selObjAlign.val()=="alignToItem" && o.target != null && !isMove)
				FQD.shapes.addAndRemoveShadow(o.target);
			
			
		}else{
			FQD.elements.divAlignTools.find("a").addClass("disabled");
			FQD.elements.divAlignTools.find("a").removeClass("activeAlign");
			FQD.shapes.removeShadow();
		}
	    
	    isMove = false;
	    FQD.message.objectOutsideSafeAndTrimZone();
	    FQD.events.tabs(config.activeCanvas);
	    jQuery("body, canvas").css("cursor","select");
	    FQD.events.getOnFocusText();
	});
	canvas.on('text:editing:entered', function(e) {
		    $('#enter-text').click();
		    if($('#new-text').css('display')=="none"){
		    	$("#enter-text .collapse").click();
		    }
		    
			var obj=this._activeObject;
			if(!obj){
				obj=e.target;
			}
			if(obj.getText() === obj.placeHolderTextValue && obj.isObjectLocked != "true"){
				obj.setSelectionStart(0);
				var selectionLength=obj.placeHolderTextValue.length;
				obj.setSelectionEnd(selectionLength);
				obj.setText("");
				FQD.canvas.textObj=obj;
				FQD.canvas.pages[config.activeCanvas].renderAll();
			}
		});
	canvas.on('text:changed', function(e) {
		fabric.util.clearFabricFontCache();
		var obj=this._activeObject;
		if(!obj){
			obj=e.target;
		}
		
		if(obj.getText() === '' && obj.isObjectLocked != "true"){
			if(FQD.canvas.getActiveObjects().placeHolderContent){
				obj.setText(obj.placeHolderTextValue);
			}else{
				obj.setText(config.textPlaceHolder);
			}
			obj.setSelectionStart(0);
			var selectionLength=obj.placeHolderTextValue.length;
			obj.setSelectionEnd(selectionLength);
			obj.hiddenTextarea.value = "";
		}
		
		if(obj.isObjectLocked != "true"){
			var text=obj.text;
			text=text.replace(/\t/g,'    ');
			FQD.events.getOnFocusText();
			FQD.canvas.UpdateTextField(obj.id,text);
			obj.setText(text);
			config.textChanged=true;
			if(obj.placeHolderContent){
				config.lastSelectedTextElement=obj;
			}
			config.origText=text;
			FQD.canvas.getActiveObjects().setCoords();
			if(obj.lastOpacityUsed &&(obj.getText()!=obj.placeHolderTextValue)){
				obj.setOpacity(obj.lastOpacityUsed);
			}
		}
		
		FQD.canvas.pages[config.activeCanvas].renderAll();
	});
	
	canvas.on('object:modified',function(e){
		var elm=e.target;
		if(elm.templateObject){
			elm.templateObject = undefined;
		}
		
		elm.resizeToScale();
		
		if(FQD.canvas.textObj && FQD.canvas.textObj.getText() == ''){
 			FQD.canvas.textObj.setText(FQD.canvas.textObj.placeHolderTextValue);
 		}
		
		if(FQD.shapes.isScaling && FQD.canvas.getActiveObjectsHasImage())
			FQD.canvas.checkForImageResize();
		else
			FQD.undoManager.saveHistory(true);
		
		FQD.shapes.isScaling = false;
		
		var activeObject=FQD.canvas.getActiveObjects();
		if(activeObject && activeObject._objects){
			for(var i=0;i<activeObject._objects.length;i++){
				var obj=activeObject._objects[i];
					obj.isModified=true;
					FQD.message.setImageWarnings(obj,canvas);
			}
		}else if(activeObject){
			activeObject.isModified=true;
			FQD.message.setImageWarnings(activeObject,canvas);
			
		}
	});
	
	fabric.Object.prototype._renderStroke = function(ctx) {
		 if (!this.stroke || this.strokeWidth === 0) {
		        return;
		    }
		    if (this.shadow && !this.shadow.affectStroke) {
		        this._removeShadow(ctx);
		    }
		    ctx.save();
		    ctx.scale(1 / this.scaleX, 1 / this.scaleY);
		    this._setLineDash(ctx, this.strokeDashArray, this._renderDashedStroke);
		    this._applyPatternGradientTransform(ctx, this.stroke);
		    ctx.stroke();
		    ctx.restore();
		    
		    if(config.triggerMovingEvent == true && !!config.currentActiveObject){
		    	canvas.trigger('object:modified', {target: config.currentActiveObject});
		    	config.triggerMovingEvent = false;
		    	delete config.currentActiveObject;
		    }
		    
		};
	canvas.on('object:scaling',FQD.utility.objectScalingCallback);
	canvas.on('object:selected',FQD.utility.objectSelectedCallback);
	canvas.on('object:rotating',FQD.utility.objectRotatingCallback);
	canvas.on('object:moving',FQD.utility.objectMovingCallback);
	
	canvas.on('mouse:over',FQD.utility.objectMouseOverCallback);
	canvas.on('mouse:out',FQD.utility.objectMouseOutCallback);
	
	// commented below line due to performance issue.
	canvas.on('before:selection:cleared',FQD.utility.onBeforeSelectionCleared);
}

FQD.canvas.panning=function(x,y,wheel){
	if(config.selectedTool == "pan" || wheel){
		var delta = new fabric.Point(x, y);
		jQuery.each(FQD.canvas.pages, function(i,canvas){
			canvas.relativePan(delta);
			canvas.getObjects().forEach(function(obj){
				 obj.setCoords();
				 if(obj.type ==='image' && obj.id){
					 setIconPosition(canvas,obj ,jQuery("#"+obj.id));
				 }
			 });
		})
		FQD.ruler.setRulerPan(x, y);
	}
}
FQD.canvas.canvasScroll=function(){
	 document.getElementById("canvas-wrapper").addEventListener("wheel", function(e){
			if(e && e.deltaY){
				var delta=10;
				if(e.deltaY > 0)delta=-10;
				if(config.isSpaceKey){
					FQD.canvas.panning(delta,0,true);
				}else{
					FQD.canvas.panning(0,delta,true);
				}
			}
		});
}
FQD.canvas.setImageAfterResize=function(result){
	if(result)
	{
		var activeObject = FQD.canvas.getActiveObjects();
		if(activeObject && activeObject.type == 'group'){
			var items = activeObject._objects;
			activeObject._restoreObjectsState()
			FQD.canvas.pages[config.activeCanvas].setActiveGroup(null);
			for(var i = 0; i < items.length; i++){
		        if(items[i].type == 'image'){
		        	FQD.shapes.commiteScaleValues(items[i]);
		        	items[i].set('scaled',true);
		        	FQD.message.setImageWarnings(items[i],FQD.canvas.pages[config.activeCanvas]);
		        }
		    }
			FQD.canvas.pages[config.activeCanvas].renderAll();
		}
		else if(activeObject && activeObject.type == 'image'){
			FQD.shapes.commiteScaleValues(activeObject);
			activeObject.set('scaled',true);
			FQD.canvas.pages[config.activeCanvas].renderAll();
			FQD.message.setImageWarnings(activeObject,FQD.canvas.pages[config.activeCanvas]);
			
		}
	}else{
		var activeObject = FQD.canvas.getActiveObjects();
		if(activeObject && activeObject.type == 'group'){
			var items = activeObject._objects;
			activeObject._restoreObjectsState()
			FQD.canvas.pages[config.activeCanvas].setActiveGroup(null);
			for(var i = 0; i < items.length; i++){
		        if(items[i].type == 'image'){
		        	items[i].setScaleX(items[i]['lastScaleX']);
		        	items[i].setScaleY(items[i]['lastScaleY']);
		        	FQD.message.setImageWarnings(items[i],FQD.canvas.pages[config.activeCanvas]);
		        }
		    }
			FQD.canvas.pages[config.activeCanvas].renderAll();
		}
		else if(activeObject && activeObject.type == 'image'){
			activeObject.setScaleX(activeObject['lastScaleX']);
			activeObject.setScaleY(activeObject['lastScaleY']);
			FQD.canvas.pages[config.activeCanvas].renderAll();
			FQD.message.setImageWarnings(activeObject,FQD.canvas.pages[config.activeCanvas]);
		}
	}
}

FQD.canvas.checkForImageResize=function(){
	var activeObject = FQD.canvas.getActiveObjects();
	customAlertBox(resourcesData.confirm, resourcesData.frontBackCancel,resourcesData.ok, FQD.message.imageResized,function(result){
		FQD.canvas.setImageAfterResize(result);
	});

}

FQD.canvas.setCanvasOptions=function(){
	if(FQD.canvas.pages.length == 1){
		FQD.elements.buttonShowAllCanvas.hide();	
	}else{
		FQD.elements.buttonShowAllCanvas.show();
	}
}

FQD.canvas.setSelectedItemHighlight = function(){
	if(FQD.elements.selObjAlign.val() == "alignTo"){
		FQD.shapes.removeShadow();
		$(".obj-align-icon").addClass("disableAlignment");
	}else{
		$(".obj-align-icon").removeClass("disableAlignment");
	}
	if(FQD.elements.selObjAlign.val() != "alignToItem"){
		FQD.shapes.removeShadow();
		return;
	}
	var obj=FQD.canvas.getActiveObjects();
	if(obj && obj._objects){
		FQD.shapes.addAndRemoveShadow(obj._objects[0]);
	}
	
	FQD.canvas.pages[config.activeCanvas].renderAll();
}

FQD.canvas.resetActiveGroupTransfromTool = function(){
	if(FQD.canvas.pages[config.activeCanvas].getActiveGroup())
	{
		FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
		FQD.canvas.pages[config.activeCanvas].renderAll();
	}
}

FQD.canvas.isCanvasEmpty=function(){
	for(i = 0; i < FQD.canvas.pages.length; i++)
	{
		if(FQD.canvas.pages[i]._objects.length > 0)
			return false;
	}
	
	return true;
}

FQD.canvas.hasSystemBackground = function(bgFiledescriptorId){
	if(bgFiledescriptorId && (bgFiledescriptorId.split(":")[2]).toString() == "9")
		return true;
	return false;
}

FQD.canvas.getCanvasZonesGap=function(zcode, fromOverlay)
{
	var zoomVal = 1;
	var bleed_L, bleed_B, bleed_R, bleed_T, safe_L, safe_B, safe_R, safe_T;
	fromOverlay = fromOverlay == undefined? false: fromOverlay;
	
	if(config.bleedMargin)
	{
		if(fromOverlay && FQD.products.hasTemplateOverlay() && FQD.canvas.svgOverlayElmParts[config.activeCanvas] != undefined)
		{
			var trim = FQD.canvas.svgOverlayElmParts[config.activeCanvas]["Trim"];
			bleed_L = trim.minX*trim.zoomX;
			bleed_B = config.canvasHeight - ((trim.minY + trim.height) * trim.zoomY);
			bleed_R = config.canvasWidth - ((trim.minX + trim.width) * trim.zoomX);
			bleed_T = trim.minY * trim.zoomY;
			
			var safe = FQD.canvas.svgOverlayElmParts[config.activeCanvas]["Safe"];
			safe_L = safe.minX * safe.zoomX;
			safe_B = config.canvasHeight - ((safe.minY + safe.height) * safe.zoomY);
			safe_R = config.canvasWidth - ((safe.minX + safe.width) * safe.zoomX);
			safe_T = safe.minY * safe.zoomY;
		}
		else{
			bleed_L = config.bleedMargin.bleedLeft < config.productDetails.minLineGap? config.productDetails.minLineGap: config.bleedMargin.bleedLeft;
			bleed_B = config.bleedMargin.bleedBottom < config.productDetails.minLineGap? config.productDetails.minLineGap: config.bleedMargin.bleedBottom;
			bleed_R = config.bleedMargin.bleedRight < config.productDetails.minLineGap? config.productDetails.minLineGap: config.bleedMargin.bleedRight;
			bleed_T = config.bleedMargin.bleedTop < config.productDetails.minLineGap? config.productDetails.minLineGap: config.bleedMargin.bleedTop;
			
			safe_L = config.safeMargin.safeZoneLeft - bleed_L;
			safe_B = config.safeMargin.safeZoneBottom - bleed_B;
			safe_R = config.safeMargin.safeZoneRight - bleed_R;
			safe_T = config.safeMargin.safeZoneTop - bleed_T;
			
			safe_L = safe_L < config.productDetails.minLineGap? (bleed_L+config.productDetails.minLineGap): config.safeMargin.safeZoneLeft;
			safe_B = safe_B < config.productDetails.minLineGap? (bleed_B+config.productDetails.minLineGap): config.safeMargin.safeZoneBottom;
			safe_R = safe_R < config.productDetails.minLineGap? (bleed_R+config.productDetails.minLineGap): config.safeMargin.safeZoneRight;
			safe_T = safe_T < config.productDetails.minLineGap? (bleed_T+config.productDetails.minLineGap): config.safeMargin.safeZoneTop;
			
			if(config.isPageRoundCorner=="true"){
				bleed_L = config.bleedMargin.bleedLeft < config.productDetails.minLineGapWithRoundCorner? config.productDetails.minLineGapWithRoundCorner: config.bleedMargin.bleedLeft;
				bleed_B = config.bleedMargin.bleedBottom < config.productDetails.minLineGapWithRoundCorner? config.productDetails.minLineGapWithRoundCorner: config.bleedMargin.bleedBottom;
				bleed_R = config.bleedMargin.bleedRight < config.productDetails.minLineGapWithRoundCorner? config.productDetails.minLineGapWithRoundCorner: config.bleedMargin.bleedRight;
				bleed_T = config.bleedMargin.bleedTop < config.productDetails.minLineGapWithRoundCorner? config.productDetails.minLineGapWithRoundCorner: config.bleedMargin.bleedTop;
				
				safe_L = safe_L < config.productDetails.minLineGapWithRoundCorner? (bleed_L+config.productDetails.minLineGapWithRoundCorner): safe_L;
				safe_B = safe_B < config.productDetails.minLineGapWithRoundCorner? (bleed_B+config.productDetails.minLineGapWithRoundCorner): safe_B;
				safe_R = safe_R < config.productDetails.minLineGapWithRoundCorner? (bleed_R+config.productDetails.minLineGapWithRoundCorner): safe_R;
				safe_T = safe_T < config.productDetails.minLineGapWithRoundCorner? (bleed_T+config.productDetails.minLineGapWithRoundCorner): safe_T;
			}
			
			zoomVal = config.scaleMultiplier;
		}
		
		var bleed = {bleedLeft:bleed_L*zoomVal, bleedBottom:bleed_B*zoomVal, bleedRight:bleed_R*zoomVal, bleedTop:bleed_T*zoomVal};
		var safe = {safeLeft:safe_L*zoomVal, safeBottom:safe_B*zoomVal, safeRight:safe_R*zoomVal, safeTop:safe_T*zoomVal}; 
		
		if(zcode == 0)
			return ({bleedZone:bleed, safeZone:safe});
		else if(zcode == 1)
			return bleed;
		else if(zcode == 2)
			return safe;
		
		return ({bleedZone:bleed, safeZone:safe});
	}

}

FQD.canvas.getDefaultPosition=function(xoff, yoff, fromCenter){
	var offSet = Math.floor((Math.random() * 100) + 50);
	var xValue = config.safeMargin.safeZoneLeft + offSet;
	var yValue = config.safeMargin.safeZoneTop + offSet;
	

	{
		xoff = xoff == undefined? 0: xoff*config.scaleMultiplier;
		yoff = yoff == undefined? 0: yoff*config.scaleMultiplier;
		
		var pos = FQD.canvas.getNearCenterRandomPosition();
		if(pos){
			xValue = pos.leftPos - xoff/2;
			yValue = pos.topPos - yoff/2;
			
			xValue = (xValue < 0)? 0: (((xValue + xoff) >= (config.canvasOrigin.x0 + config.canvasWidth))? ((config.canvasOrigin.x0 + config.canvasWidth) - xoff): xValue);
			yValue = (yValue < 0)? 0: (((yValue + yoff) >= (config.canvasOrigin.y0 + config.canvasHeight))? ((config.canvasOrigin.y0 + config.canvasHeight) - yoff): yValue);
			
			return ({leftPosition: xValue, topPosition: yValue});
		}

	}
	
	if(config.canvasOrigin){
		return ({leftPosition: (config.canvasOrigin.x0 + xValue), topPosition: (config.canvasOrigin.y0 + yValue)});	
	}else{
		return ({leftPosition: (xValue), topPosition: (yValue)});	
	}
	
}

FQD.canvas.getNearCenterRandomPosition=function(){
	var nearX = config.canvasWidth/4;
	var nearY = config.canvasHeight/4;
	var rNum = 0;
	
	rNum = getRandom(1, nearX);
	nearX = (rNum < nearX/2)? rNum: -(rNum - nearX/2);
	nearX = (config.canvasWidth/2) - nearX;
	
	rNum = getRandom(1, nearY);
	nearY = (rNum < nearY/2)? rNum: -(rNum - nearY/2);
	nearY = (config.canvasHeight/2) - nearY;
	
	if(config.canvasOrigin && config.canvasOrigin)
	return ({leftPos: (config.canvasOrigin.x0 + nearX), topPos: (config.canvasOrigin.y0 + nearY)});
}

FQD.canvas.getSafeZone=function(pIndex)
{
	pIndex = pIndex == undefined? config.activeCanvas: pIndex;
	var canvas = FQD.canvas.pages[pIndex];
	var safeObj;
	if(FQD.products.hasTemplateOverlay() && FQD.canvas.svgOverlayElmParts[pIndex] != undefined){
		safeObj = FQD.canvas.svgOverlayElmParts[pIndex]["Safe"];
	}else{
		var items = canvas.getItemsByName("overlayElm"); 
		items.forEach(function(obj){
			if(obj.safeZone && obj.safeZone != undefined){
				safeObj = obj;
			}
		});
	}
	
	return safeObj;
}

FQD.canvas.getTrimZone=function(pIndex)
{
	pIndex = pIndex == undefined? config.activeCanvas: pIndex;
	var canvas = FQD.canvas.pages[pIndex];
	var trimObj;
	
	if(FQD.products.hasTemplateOverlay() && FQD.canvas.svgOverlayElmParts[pIndex] != undefined){
		trimObj = FQD.canvas.svgOverlayElmParts[pIndex]["Trim"];
	}else{
		var items = canvas.getItemsByName("overlayElm"); 
		items.forEach(function(obj){
			if(obj.trimZone && obj.trimZone != undefined){
				trimObj = obj;
			}
		});
	}
	
	return trimObj;
}

FQD.canvas.getEnvelopeBackgroundRect = function()
{
	var bgPart = FQD.canvas.svgOverlayElmParts[0]["background"];
	return {width:(bgPart.width * FQD.canvas.overlayScaleX), height:(bgPart.height * FQD.canvas.overlayScaleY), left:(bgPart.minX * FQD.canvas.overlayScaleX), top:(bgPart.minY * FQD.canvas.overlayScaleY)}; 
}

//customize fabric.Object with a method to resize rather than just scale after transformation
fabric.Object.prototype.resizeToScale = function () {
    // resizes an object that has been scaled (e.g. by manipulating the handles), setting scale to 1 and recalculating bounding box where necessary
    switch (this.type) {
        case "circle":
            break;
        case "ellipse":
            this.rx *= this.scaleX;
            this.ry *= this.scaleY;
            this.width = this.rx * 2;
            this.height = this.ry * 2;
            this.scaleX = 1;
            this.scaleY = 1;
            break;
        case "polygon":
        case "polyline":
            var points = this.get('points');
            for (var i = 0; i < points.length; i++) {
                var p = points[i];
                p.x *= this.scaleX
                p.y *= this.scaleY;
            }
            this.scaleX = 1;
            this.scaleY = 1;
            this.width = this.getBoundingBox().width;
            this.height = this.getBoundingBox().height;
            break;
        case "triangle":
        case "line":
        case "rect":
        case "rounded-rect":
            this.width *= this.scaleX;
            this.height *= this.scaleY;
            this.scaleX = 1;
            this.scaleY = 1;
        default:
            break;
    }
}

// helper function to return the boundaries of a polygon/poly-line
fabric.Object.prototype.getBoundingBox = function () {
    var minX = null;
    var minY = null;
    var maxX = null;
    var maxY = null;
    switch (this.type) {
        case "polygon":
        case "polyline":
            var points = this.get('points');

            for (var i = 0; i < points.length; i++) {
                if (typeof (minX) == undefined) {
                    minX = points[i].x;
                } else if (points[i].x < minX) {
                    minX = points[i].x;
                }
                if (typeof (minY) == undefined) {
                    minY = points[i].y;
                } else if (points[i].y < minY) {
                    minY = points[i].y;
                }
                if (typeof (maxX) == undefined) {
                    maxX = points[i].x;
                } else if (points[i].x > maxX) {
                    maxX = points[i].x;
                }
                if (typeof (maxY) == undefined) {
                    maxY = points[i].y;
                } else if (points[i].y > maxY) {
                    maxY = points[i].y;
                }
            }
            break;
        default:
            minX = this.left;
            minY = this.top;
            maxX = this.left + this.width; 
            maxY = this.top + this.height;
    }
    return {
        topLeft: new fabric.Point(minX, minY),
        bottomRight: new fabric.Point(maxX, maxY),
        width: maxX - minX,
        height: maxY - minY
    }
}















