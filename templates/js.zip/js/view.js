/*************************************************************************************************************
 * 
 * Responsible to get view(HTML files and append it on to target element) as per product type
 * 
 * 
 **********************************************************************************************************/
FQD.view={};
FQD.view.getView=function(elementId,moduleName ,callback){
	var loadModule=config.resourcePath+"view/"+moduleName;
	jQuery(elementId).load(loadModule,callback);
}

FQD.view.src=function(id,url){
	id="#"+id;
	if(jQuery(id)){
		jQuery(id).attr("src", window.staticContentBaseUrl + url);
	}
}
