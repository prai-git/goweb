	//This File is for combining multiple tspan into single tspan while exporting it to SVG.

   FQD.toSVGCustomize={};
	
	   FQD.toSVGCustomize._setSVGObjects=function(obj,markup, reviver) {
          var instance;
          for (var i = 0, objects = obj.getObjects(), len = objects.length; i < len; i++) {
            instance = objects[i];
            if (instance.excludeFromExport) {
              continue;
            }
            FQD.toSVGCustomize._setSVGObject(markup, instance, reviver);
          }
        };
        FQD.toSVGCustomize._setSVGObject=function(markup, instance, reviver) {
        	markup.push(FQD.toSVGCustomize.toSVG1(instance,reviver));
        };
	
	
	
	FQD.toSVGCustomize.toSVG = function(reviver) {
		if (!this.ctx) {
			this.ctx = fabric.util.createCanvasElement().getContext('2d');
	      }
		  var markup = this._createBaseSVGMarkup(),
	      offsets =  this._getSVGLeftTopOffsets(this.ctx),
	      textAndBg = FQD.toSVGCustomize._getSVGTextAndBg(this,offsets.textTop, offsets.textLeft);
		  this._wrapSVGTextAndBg(markup, textAndBg);
	
		  return reviver ? reviver(markup.join('')) : markup.join('');
	};
	FQD.toSVGCustomize._getSVGTextAndBg=function(obj,textTopOffset, textLeftOffset){
		   var textSpans = [],
	       textBgRects = [],
	       height = 0;
	   // bounding-box background
		   obj._setSVGBg(textBgRects);
	
	   // text and text-background
		   for (var i = 0, len = obj._textLines.length; i < len; i++) {
		     if (obj.textBackgroundColor) {
		    	 obj._setSVGTextLineBg(textBgRects, i, textLeftOffset, textTopOffset, height);
		     }
		     FQD.toSVGCustomize._setSVGTextLineText(obj,i, textSpans, height, textLeftOffset, textTopOffset, textBgRects);
		     height += obj._getHeightOfLine(obj.ctx, i);
		   }
		
		   return {
		     textSpans: textSpans,
		     textBgRects: textBgRects
		   };
	};
	FQD.toSVGCustomize._setSVGTextLineText=function(obj, lineIndex, textSpans, height, textLeftOffset, textTopOffset, textBgRects){
		 if (!obj._getLineStyle(lineIndex)) {
		        fabric.Text.prototype._setSVGTextLineText.call(obj,
		          lineIndex, textSpans, height, textLeftOffset, textTopOffset);
		      }
		      else {
		    	  FQD.toSVGCustomize._setSVGTextLineChars(obj,
		          lineIndex, textSpans, height, textLeftOffset, textBgRects);
		      }
	};
	
	FQD.toSVGCustomize._getTSpanLineLeftOffset=function(obj, lineIndex){
		var t = obj.__lineWidths[lineIndex];
		return "center"===obj.textAlign? (-t/2): "right"===obj.textAlign? (obj.width/2)-t:(-obj.width/2);
	};
	
	FQD.toSVGCustomize._setSVGTextLineChars=function(obj, lineIndex, textSpans, height, textLeftOffset, textBgRects){
		var chars = obj._textLines[lineIndex].split(''),
	    lineLeftOffset = FQD.toSVGCustomize._getTSpanLineLeftOffset(obj, lineIndex);
	    lineOffset = obj._getSVGLineTopOffset(lineIndex),
	    heightOfLine = obj._getHeightOfLine(obj.ctx, lineIndex);
	
	var previousStyleDecl = undefined;
	var groups = [];
	var currentGroup = undefined;
	
	for (var i = 0, len = chars.length; i < len; i++) {
		 var styleDecl;
		 if(!obj.styles[lineIndex]){
			 styleDecl={};
		 }else{
			 styleDecl = obj.styles[lineIndex][i] || {};
		 }
	
	    var a = JSON.stringify(previousStyleDecl), b = JSON.stringify(styleDecl);
	    if (!a) a = '';
	    if (!b) b = '';
	    var areEqualStyles = (a.split('').sort().join('') == b.split('').sort().join(''));
	
	    var charWidth = obj._getWidthOfChar(obj.ctx, chars[i], lineIndex, i);
	
	    // If the previous style is not defined,
	    // or, the current style does not match the previous style, then
	    // create a new grouping
	    if (previousStyleDecl == undefined || !areEqualStyles) {
	
	        var prevCharOffset = 0;
	
	        if (currentGroup != undefined) {
	            prevCharOffset = currentGroup.charWidth;
	        }
	
	        currentGroup = {
	            style: styleDecl,
	            text: chars[i],
	            charWidth: charWidth,
	            charOffset: prevCharOffset
	        }
	
	        groups.push(currentGroup);
	    }
	
	    // if the styles are equal, then add the current character to the group
	    if (areEqualStyles) {
	        if (currentGroup) {
	            currentGroup.text += chars[i];
	            currentGroup.charWidth += charWidth;
	        }
	    } 
	
	    previousStyleDecl = styleDecl;
	}
	
	var charOffset = 0;
	for (var j = 0; j < groups.length; j++) {
	    var group = groups[j];
	
	    charOffset += group.charOffset;
	
	    textSpans.push(obj._createTextCharSpan(group.text, group.style, lineLeftOffset, lineOffset.lineTop + lineOffset.offset, charOffset));
	
	    if (group.style.textBackgroundColor) {
	        textBgRects.push(obj._createTextCharBg(group.style, lineLeftOffset, lineOffset.lineTop, heightOfLine, group.charOffset, charOffset));
	    }
	}
	
	};
