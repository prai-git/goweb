//to convert translate attribute to matrix
fabric.Object.prototype._removeTransformMatrix = function(addTranslate) {

	var left = this.left;
	var top = this.top;

	if (this.type !== 'text' && this.type !== 'i-text'
			&& !this.type == "textbox") {
		left += this.width / 2;
		top += this.height / 2;
	}

	var matrix = fabric.util.multiplyTransformMatrices(this.transformMatrix
			|| [ 1, 0, 0, 1, 0, 0 ], [ 1, 0, 0, 1, left, top ]);
	var options = fabric.util.qrDecompose(matrix);
	this.scaleX = options.scaleX;
	this.scaleY = options.scaleY;
	this.angle = options.angle;
	this.skewX = options.skewX;
	this.skewY = 0;
	this.flipX = false;
	this.flipY = false;
	config.importObjectLeft = matrix[4] - 0.5;
	config.importObjectTop = matrix[5] - 0.5;
	var point = new fabric.Point(options.translateX, options.translateY);
	this.setPositionByOrigin(point, 'center', 'center');
	this.transformMatrix = null;
};
FQD.importSvg = {
	allSVGs : [],
	init : function() {
		var z = FQD.canvas.pages[config.activeCanvas].getZoom();
		FQD.canvas.setZoom(1);// reset canvas to get data in 100% zoom
		jQuery("#svgEdit").val("");
		FQD.importSvg.allSVGs = [];
		var pages = FQD.canvas.pages;
		jQuery.each(FQD.canvas.pages,function(k, v) {
							var canvas=FQD.canvas.pages[k];
								canvas.getItemByName("canvasArea").excludeFromExport=true;
							if (canvas.backgroundImage) {
								canvas.backgroundImage.id = "backgroundImage";
								canvas.renderAll();
							}
							v = v.toSVG();
							canvas.getItemByName("canvasArea").excludeFromExport=false;
							v = v.replace('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>','');
							v = v.replace('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">','');
							v = v.replace('fill="transparent"','id="removeFromPreview"');
							v = FQD.preview.removeElementNotForPreview(v);
							v = FQD.preview.removePlaceHoldersImage(v);
							FQD.importSvg.allSVGs.push(v);
						});
		FQD.canvas.setZoom(z); // zoom canvas as per previous value again
	},
	addSVG : function() {
		FQD.importSvg.init();
		var temp = "", selTemp = "";
		jQuery
				.each(
						FQD.importSvg.allSVGs,
						function(k, v) {
							k = k + 1;
							temp += '<div class="svgDiv" id="svgDiv'
									+ k
									+ '" style="padding:10px;">\
							<textarea class="exportsvgDiv" cols="65" rows="25" style="padding:4px;" ></textarea>\
						</div>';
							if (FQD.importSvg.allSVGs.length == 1) {
								selTemp = '<option value="1">Front</option>';
							} else if (FQD.importSvg.allSVGs.length == 2) {
								selTemp = '<option value="1">Front</option><option value="2">Back</option>';
							} else {
								selTemp += '<option value="' + k + '">Page' + k
										+ '</option>';
							}
						});
		FQD.elements.divExportSvgMarkup.html(temp);
		FQD.elements.setExportedSvg.html(selTemp);
		jQuery("#importedSvg").html(selTemp);
		jQuery.each(FQD.importSvg.allSVGs, function(k, v) {
			k = k + 1
			jQuery("#svgDiv" + k).find("textarea").val(v);
		});
		FQD.importSvg.showSelectedSvg(1);
	},
	addJSON : function() {
		var temp = "", selTemp = "";
		FQD.importSvg.allJSONs = [];
		for (var i = 0; i < FQD.canvas.pages.length; i++) {
			var canvas=FQD.canvas.pages[i];
			var json = JSON.stringify(canvas.toJSON(config.newProperties));
			FQD.importSvg.allJSONs.push(json);
		}
		jQuery.each(FQD.importSvg.allJSONs,function(k, v) {
							k = k + 1;
							temp += '<div class="jsonDiv" id="jsonDiv'
									+ k
									+ '" style="padding:10px;">\
							<textarea class="exportjsonDiv" cols="65" rows="25" style="padding:4px;" ></textarea>\
						</div>';
							if (FQD.importSvg.allJSONs.length == 1) {
								selTemp = '<option value="1">Front</option>';
							} else if (FQD.importSvg.allJSONs.length == 2) {
								selTemp = '<option value="1">Front</option><option value="2">Back</option>';
							} else {
								selTemp += '<option value="' + k + '">Page' + k
										+ '</option>';
							}
							FQD.elements.divExportJsonMarkup.html(temp);
							FQD.elements.setExportedJson.html(selTemp);
							jQuery("#importedSvg").html(selTemp);
							jQuery.each(FQD.importSvg.allJSONs, function(k, v) {
								k = k + 1
								jQuery("#jsonDiv" + k).find("textarea").val(v);
							});
							FQD.importSvg.showSelectedJson(1);
						});

	},
	showSelectedSvg : function(id) {
		FQD.elements.divExportSvgMarkup.find(".svgDiv").hide();
		jQuery("#svgDiv" + id).css("display", "block");
	},
	showSelectedJson : function(id) {
		FQD.elements.divExportJsonMarkup.find(".jsonDiv").hide();
		jQuery("#jsonDiv" + id).css("display", "block");
	},
	toImage : function(img) {
		var selectedCanvas = parseInt(FQD.elements.setExportedSvg.val());
		if (img == "png") {
			selectedCanvas = selectedCanvas - 1;
			window.open(FQD.canvas.pages[selectedCanvas].toDataURL(img));
		} else {
			var img = document.createElement("img");
			var svgData = jQuery("#svgDiv" + selectedCanvas).find("textarea")
					.val();
			svgData = svgData.replace(/a[0-9]:href/g, 'xlink:href');
			svgData = svgData.replace(/xmlns:a[0-9]/g, 'xmlns:xlink');
			svgData = svgData.replace(/&quot;/g, '');
			svgData = svgData.replace(/"[/]common/g, '"http://'
					+ document.domain + '/common');
			svgData = svgData.replace(/url\([/]common/, 'url(http://'
					+ document.domain + '/common');
			svgData = svgData.replace(/&imageEffectType/g,
					"&amp;imageEffectType");
			var data = btoa(unescape(encodeURIComponent(svgData)));
			img.setAttribute("src", "data:image/svg+xml;base64," + data);
			window.open(img.src);
		}
	},
	import : function(rawSVG, atCanvas) {
		try {
			if (typeof rawSVG === 'undefined')
				throw 'No data was provided.';

			rawSVG = rawSVG.replace(/\n|\r|\t/gi, '');
			if (!rawSVG.match(/<svg(.*?)>(.*)<\/svg>/i)) {
				throw "The data you entered doesn't contain valid SVG.";
			}
			atCanvas = parseInt(atCanvas) - 1;
			FQD.events.tabs(atCanvas);
			rawSVG = rawSVG.trim();
			var canvas = FQD.canvas.pages[config.activeCanvas], bgSrc = false;
			var path = fabric.loadSVGFromString(rawSVG, function(objects,
					options) {
				for (var i = 0; i < objects.length; i++) {
					if (objects[i].type == "text"
							|| objects[i].type == "textbox") {
						objects[i]._removeTransformMatrix();
						var text = new fabric.Textbox(objects[i].text, {
							fontFamily : objects[i].getFontFamily(),
							fontSize : objects[i].getFontSize(),
							fontWeight : objects[i].getFontWeight(),
							fill : objects[i].getFill(),
							fontStyle : objects[i].getFontStyle(),
							top : objects[i].getTop(),
							selectable : true,
							left : objects[i].getLeft(),
							width : objects[i].getWidth(),
							textAlign : objects[i].getTextAlign(),
							id : FQD.canvas.setTextBoxId(),
							objectCaching : false
						});
						FQD.shapes.setTextAddedAlignProperties(text);
						text.setAngle(objects[i].getAngle());
						text.setCoords();
						text.toSVG = FQD.toSVGCustomize.toSVG;
						canvas.add(text);
					} else if (objects[i].id
							&& objects[i].id == "backgroundImage") {
						if (canvas.backgroundImage) {
							var r = confirm(FQD.message.importSvgBg);
							if (r) {
								bgSrc = objects[i].getSrc();
								canvas.setBackgroundImage(objects[i].getSrc(),
										canvas.renderAll.bind(canvas), {
											width : config.canvasWidth,
											height : config.canvasHeight,
											backgroundImageStretch : true,
											id : objects[i].id
										});
							}
						} else {
							bgSrc = objects[i].getSrc();
							canvas.setBackgroundImage(objects[i].getSrc(),
									canvas.renderAll.bind(canvas), {
										width : config.canvasWidth,
										height : config.canvasHeight,
										backgroundImageStretch : true,
										id : objects[i].id
									});
						}
					} else {
						objects[i]._removeTransformMatrix();
						objects[i].left = config.importObjectLeft;
						objects[i].top = config.importObjectTop;
						objects[i].objectCaching = false;
						canvas.add(objects[i]);
					}
				}
				canvas.renderAll();
				if (bgSrc) {
					var newImg = new Image();
					newImg.src = bgSrc;
					newImg.onload = function() {
						FQD.undoManager.saveHistory(true);
						FQD.imgLib.disableEnableBgTools(true);
					}
				} else {
					FQD.undoManager.saveHistory(true);
				}
				FQD.canvas.addNewText();
			});
			FQD.events.closePopup(jQuery('#close-admmin'));

		} catch (error) {
			alert(fqdInvalidSVGData + '(' + error + ')');
		}
		setTimeout(function() {
			var obj = canvas.getObjects();
			for (var i = 0; i < obj.length; i++) {
				if (obj[i].type == "image") {
					var src = obj[i].getSrc();
					obj[i].setSrc(src.replace("#", "&"), function() {
						canvas.renderAll()
					});
				}
			}

		}, 100);
	}
};
FQD.importJson = function(data, isRound) {
	config.isProcessCompleted=false;
	jQuery('#jsonData').val("");
	
	
	try {
		var jsonData;
		if(typeof data == "object"){
			jsonData =data;
		}else{
			jsonData = JSON.parse(data);
		}
		var elementCount=FQD.templateDataTransfer.elementsCountInTemplate(jsonData);
		if (config.isLoadTemplate == "true") {
			var length = jsonData.length;
			if (length > 1) {
				if (jsonData[0].indexOf("\"id\":\"backgroundImage\"") != -1) {
					config.TemplateFirstPageContainBGImage = "true";
				}
				if (jsonData[1].indexOf("\"id\":\"backgroundImage\"") != -1) {
					config.TemplateLastPageContainBGImage = "true";
				}
			} else {
				if (jsonData[0].indexOf("\"id\":\"backgroundImage\"") != -1) {
					config.TemplateFirstPageContainBGImage = "true";
				}
			}
		}
		if (jsonData.pages == 'undefined' || jsonData.length > 0) {
			var count=0;
			var pageCount = 0;
			var multi = config.objScaleWidthMultiplier;
			for (var jsonPageCnt = 0; jsonPageCnt < jsonData.length; jsonPageCnt++) {
				if (FQD.canvas.pages.length > jsonPageCnt) {
					var canvas = FQD.canvas.pages[jsonPageCnt];
					var json = jsonData[jsonPageCnt];
					if (urlPrefix != "") {
						json = json.replace(/\/seam\/resource/g, urlPrefix
								+ "/seam/resource");
						json = json.replace(/\/common\/resource/g, urlPrefix
								+ "/common/resource");

					}
					 json=JSON.parse(json);
					 canvas.templateBgColor=json.background;
					 json.background='transparent';
					 if(json.backgroundImage){
						 json.backgroundImage.name="bgElement";
						 json.backgroundImage.alwaysNotselectable= true;
						 json.backgroundImage.objectCaching= false;
						 json.backgroundImage.selectable= false;
						 if(json.objects==undefined){
							 json.objects=[];
						 }
						 json.objects.unshift(json.backgroundImage);
						 delete json.backgroundImage;
					 }
					 json=FQD.imgLib.updateHDImageOnJson(json);
					 canvas.loadFromJSON(json,function() {
										pageCount ++;
										for(var j=0;j < FQD.canvas.pages.length;j++){
				        					   FQD.canvas.setElementAsperCanvas(FQD.canvas.pages[j]);
				        					   FQD.setCanvasAreaBackgroundColor(FQD.canvas.pages[j],FQD.canvas.pages[j].templateBgColor);
				        					   FQD.initializecanvas.createSVGOverlay(FQD.canvas.pages[j]);
				        					   FQD.allOverlayOnTop();
				        				   }
										canvas.renderAll.bind(canvas);
										if (pageCount === FQD.canvas.pages.length){
											setTimeout(function(){ FQD.canvas.addNewText(); }, 2000);
											FQD.utility.refreshTimeout(2000);
					 					}
									},
									function(o, object) {
										if(object){
											if(object.name != "bgElement" && object.id != "backgroundImage" && object.type!="textbox"){
							   				    object.scaleX = object.scaleX*multi;
												object.scaleY = object.scaleY*multi;
											}else{
												object.width *= multi;
												object.height *= multi;
											}
											
											object.left = config.canvasOrigin.x0+object.left*multi;
											object.top = config.canvasOrigin.y0+object.top*multi;
											
											object.objectCaching = false;
											object.templateObject = true;
											
											
											if(object.isObjectLocked){
												object.hasBorders = false;
												object.selectable = false;
											}
											
											object.isObjectLocked = object.isObjectLocked != undefined? object.isObjectLocked.toString(): "false";
											
											if(object.strokeWidth != undefined){
												object.strokeWidth *= multi;
											}
											
											if(object.strokeDashArray != undefined && object.strokeDashArray == ""){
												object.strokeDashArray = null;
											}
											
											if(object.type == "textbox")
											{	
												FQD.shapes.setTextElmTopFromAD(object);
												object.fontSize = object.fontSize * multi;
												
												var lineHeight = object.lineHeight;
												object.minLineHeight = lineHeight;
												object.set("minLineHeight",lineHeight);
												
												FQD.shapes.setTextAddedAlignProperties(object);
												object.toSVG = FQD.toSVGCustomize.toSVG;
												
												
												if(object.textAlign == "right"){
													object.text = object.text.replace(/\s\n/g, "\n");
												}
												object.placeHolderTextValue = object.text;
											}
											
											if(object.type == "image" && object.cropped == "true"){
												var urlCropParam = object.src.split("&crop=")[1];
												if(urlCropParam){
													urlCropParam = urlCropParam.split("&");
													if (urlCropParam.length > 1) 
													{
														var cropParamArr = urlCropParam[0].split(":");
														if (cropParamArr.length >= 4) 
														{
															object.cropStartX = cropParamArr[0];
															object.cropStartY = cropParamArr[1];
															object.orgWidth = cropParamArr[2];
															object.orgHeight = cropParamArr[3];
														}
													}
												 }
											}

											
											if(object.isHidden == "true"){
												object.setOpacity(object.initialOpacity);
												delete object.isHidden;
											}
											
											if(isRound != undefined && isRound == 0 && config.isPageRoundCorner == "true"){
												if(object.name == "bgElement" && object.id == "backgroundImage"){
													var extraBleed = FQD.canvas.getExtraBleedDifference();
													object.width += (extraBleed.left + extraBleed.right);
													object.height += (extraBleed.top + extraBleed.bottom);
												}
												else
													FQD.helper.adjustTemplateObjects(object);
											}
											
										}
										
										count++;
										if(count>=elementCount){
											config.isProcessCompleted=true;
												
										}
									});
					 
				}

			}
			var data = jQuery.parseJSON(jsonData[config.activeCanvas]);
			FQD.imgLib.disableEnableBgTools(data.backgroundImage);
			FQD.elements.inputColorB.spectrum("set",data.background);
			jQuery("#colorB2").spectrum("set",data.background);
			jQuery("#bg-bucket").css("color",data.background);

		} else {
			for (var jsonPageCnt = 0; jsonPageCnt < jsonData.pages.length; jsonPageCnt++) {
				if (FQD.canvas.pages.length > jsonPageCnt) {
					var canvas = FQD.canvas.pages[jsonPageCnt];
					var json = jsonData.pages[jsonPageCnt];
					json=FQD.imgLib.updateHDImageOnJson(json);
					canvas.loadFromJSON(json, function() {
						canvas.renderAll.bind(canvas);
						FQD.canvas.addNewText();
						FQD.undoManager.saveHistory(true);
					}, function(o, object) {
						object.scaleX= object.scaleX*multi;
						object.scaleY= object.scaleY*multi;
						object.left= config.canvasOrigin.x0+object.left*multi;
						object.top= config.canvasOrigin.y0+object.top*multi;
						object.objectCaching = false;
						object.templateObject = true;
						if (object.type == "textbox") {
							var lineHeight = object.lineHeight;
							if (lineHeight < 1) {
								object.lineHeight = 1.16;
							}
							FQD.shapes.setTextAddedAlignProperties(object);
							object.toSVG = FQD.toSVGCustomize.toSVG;
							object.placeHolderTextValue = object.text;
						}
						if (object.isHidden == "true") {
							object.setOpacity(object.initialOpacity);
							delete object.isHidden;
						}
						if(isRound != undefined && isRound == 0 && config.isPageRoundCorner == "true"){
							FQD.helper.adjustTemplateObjects(object);
						}
					});
			
				}

			}
			var data = jQuery.parseJSON(jsonData[config.activeCanvas]);
			FQD.imgLib.disableEnableBgTools(data.backgroundImage);
			FQD.elements.inputColorB.spectrum("set",data.background);
			jQuery("#colorB2").spectrum("set",data.background);object.minLineHeight = lineHeight;
			jQuery('#align-justify-slider').slider('option', 'min',lineHeight);
			jQuery('#align-justify-slider').slider('option', 'value',lineHeight);
			console.log(lineHeight);
			jQuery("#bg-bucket").css("color",data.background);
		}
		FQD.events.closePopup(jQuery('#close-admmin'));
		setTimeout(function(){ 
			fabric.util.clearFabricFontCache();
			FQD.canvas.pages[0].renderAll();
			if(FQD.canvas.pages.length>1){
				FQD.canvas.pages[1].renderAll();
				
			}
		}, 500);

	} catch (e) {
		alert(fqdInvalidJsonData + "\n" + e);
		FQD.elements.divLoadingQd.hide();
		FQD.elements.divLoaderContainer.hide();
	}
	

};

FQD.importJsonFromAdmin = function(json) {
	jQuery('#jsonData').val("");
	var jsonData = JSON.parse(json);
	var pageNo = $("#importedJson").val();
	var canvas = FQD.canvas.pages[parseInt(pageNo) - 1];
	json=FQD.imgLib.updateHDImageOnJson(json);
	canvas.loadFromJSON(json,function(){
				   FQD.drawOverlay(canvas);
				   FQD.initializecanvas.drawBleedSafeZone(canvas);
				   canvas.renderAll.bind(canvas);
				   FQD.initializecanvas.createSVGOverlay(canvas);
			   },
			   function(o, object) {
				   if(object.type == "image"){
					   if(object.id == "placeHolders"){
						   object._element=config.imgElement;
						   object.crossOrigin="anonymous";
					   }
				   }
				   if(!object.isObjectLocked){
					   object.selectable=true;
					   object.hasControls=true;
					   object.hasBorders=true;
					   object.evented=true;
					   object.setShadow(null);
					}
					if(object.alwaysNotselectable){
						object.selectable=false;
						object.hasControls=false;
						object.hasBorders=false;
						object.evented=false;
					}
					if(object.overlayElm){
						object.bringToFront();
					}
			   });
	FQD.events.closePopup(jQuery('#close-admmin'));
	if (pageNo == "1") {
		$('#front').click();
	} else {
		$('#back').click();
	}

};

FQD.setTemplateObjectsLocation = function(isRound, object) {
    if(document.querySelector(".trimZone")==null){
    	return;
    }
	var bleedRadius = parseInt(document.querySelector(".trimZone").style.borderRadius.replace("px", ""));
	if (isRound == 0){
		if (!bleedRadius || bleedRadius == 0) {
			return;
		} else {
			FQD.helper.adjustTemplateObjects(object);
		}
	} else {
		if (bleedRadius && bleedRadius != 0) {
			return;
		} else {
			FQD.helper.adjustTemplateObjects(object);
		}

	}
};