/********************************************************************
 * 
 * Responsible to generate preview, client side(SVG and image) and server side both.
 * 
 * 
 ********************************************************************/

FQD.preview={};
if(	window.standAloneExecution){
	FQD.preview.url=standAlone.serviceBaseUrlAction;
}
else{
	FQD.preview.url="/OnlineDesignerAction";
}
FQD.preview.getAllPreview=function(){
	FQD.canvas.removeSelection();
	var i, length = FQD.canvas.pages.length;
	
	if(config.isFrontOnly == "true"){
		length=1;
	}
	var img="<div class='clear previewProceed_container'><input type='button' value='Proceed to Order' class='previewProceed'/></div><div id='clientSidePreview'><div class='previewImgContainer'>";
	var height=screen.height;
	
	var maxPW = 460;
	var maxPH = 400;
	var pRatio = maxPH / maxPW;
	var pW = config.canvasWidth;
	var pH = config.canvasHeight;
	
	if((pW*pRatio) > pH ){
		pRatio = maxPW/pW;
	}else{
		pRatio = maxPH/pH;
	}
	
	pW = Math.round(pW*pRatio);
	pH = Math.round(pH*pRatio);
	
	config.hasPreviewState = true;
	
	var stylBrd = (FQD.products.hasTemplateOverlay())? "": "border:1px solid #666;";
	var pageLbl = FQD.products.getLabelForPageName();
	
	for(i=0;i < length;i++){
		var z=FQD.canvas.pages[config.activeCanvas].getZoom();
		FQD.canvas.setZoom(1);// reset canvas to get data in 100% zoom
		var txt="";
		var obj=FQD.canvas.pages[i].getObjects();
		var arr=[];
		obj.forEach(function(obj1){
			if(obj1.id == "placeHolders"){
				obj1.setOpacity(0);
			}
		});
		
		var arr=FQD.preview.textPlaceholder(obj);
		if(length>1){
			if(i==0){
				txt="<div class='previewLable'></div>";
				txt = txt.replace('><' , '>' + pageLbl.frontLbl + '<');
				
			}else{
				txt="<div class='previewLable'></div>";
				txt = txt.replace('><' , '>' + pageLbl.backLbl + '<');
			}
		}
		
		txt += '<div style="position:relative; margin:20px;"><div style="width:'+pW+'px; height:'+pH+'px; margin:0 auto;">';
		
		if(config.applicationSettings.previewOverlay == true){
			var text = FQD.preview.previewWatermark(i);
			img+=txt+'<img src="'+FQD.canvas.pages[i].toDataURL('png')+'"style="width:'+pW+'px;height:'+pH+'px;'+stylBrd+'" />';
			FQD.canvas.pages[i].remove(text);
			delete config.previewWatermarkTextObject;
		}else{
			img+=txt+'<img src="'+FQD.canvas.pages[i].toDataURL('png')+'"style="width:'+pW+'px;height:'+pH+'px;'+stylBrd+'" />';
		}
		
		obj.forEach(function(obj){
			if(obj.id == "placeHolders"){
				obj.setOpacity(0.7);
			}
		});

		arr.forEach(function(element){
			delete element.isHidden;
			element.setOpacity(element.initialOpacity);
			
		});
		FQD.canvas.pages[i].renderAll();
		
		/*
		//After new Canvas overflow functionality we dont require this Div
		* 
		zonediv = "";
		if(FQD.products.hasTemplateOverlay()){
			zonediv='<div style="top:0px; position:absolute; width:'+ pW +'px; height:' + pH + 'px; >'+ FQD.canvas.svgOverlayData[i] +'</div>';
			img += zonediv;
		}
		*/
		
		if(config.holeOptionId > 0){
			var hdiv = "";
			var holeW = holeH = 0.125*config.dpi*pRatio;
			var holeLeft = leftSpace = FQD.canvas.holePositionSpace;
			var holeTop = (FQD.canvas.holeTopSpace+config.bleedMargin.bleedTop)*pRatio;
			
			switch(config.holeOptionId){
				case FQD.PrintProductType.HOLE_POSITION_TOP_LEFT:
					holeLeft = ((leftSpace + config.bleedMargin.bleedLeft)*pRatio) + 1; //+1 add because of the border size 1px
					if(i == 1)
						holeLeft = pW - holeW - ((leftSpace + config.bleedMargin.bleedRight)*pRatio);
					break;
				case FQD.PrintProductType.HOLE_POSITION_TOP_CENTER:
					holeLeft = ((pW/2) - (holeW/2)) + 1;
					break;
				case FQD.PrintProductType.HOLE_POSITION_TOP_RIGHT:
					holeLeft = pW - holeW - ((leftSpace + config.bleedMargin.bleedRight)*pRatio);
					if(i == 1)
						holeLeft = ((leftSpace + config.bleedMargin.bleedLeft)*pRatio) + 1;
					break;
			}
			
			hdiv = '<div style="width:' + pW + 'px; height:' + pH + 'px; top:0px; position:absolute;">';
			hdiv += '<div class="holeCanvas" style="width:'+ holeW +'px; height:'+ holeH +'px; left:'+ holeLeft +'px;  top:'+ holeTop +'px;"></div></div>';
			img += hdiv;
		}
		
		img += '</div></div>';
		
		FQD.canvas.setZoom(z);// reset canvas to get data in 100% zoom
	}
	
	img+="</div></div>";
	FQD.elements.divModelContent.html(img);
	
	$("#clientSidePreview").css("max-height",height-200+"px");
	$("#clientSidePreview").css("overflow-y","auto");
	
	FQD.elements.divOverlay.show();
	FQD.elements.divModelWindow.show();
	
	$(".previewProceed").click(function(){
		FQD.utility.gotoProceedToOrder();
	});
},
FQD.preview.previewWatermark=function(pageno){
	var watermark="Preview";
    var text=new fabric.Textbox(watermark, { 
		fontFamily: 'gp-arial',
		fontSize:200,
		fontWeight:400,
	    fill:'#000000',
		fontStyle: 'normal', 
		top:0,
		opacity:0.12,
		selectable:false,
		left:0, 
		width:250,
		height:200,
		cursorWidth: 1,
		breakWords: false,
		objectCaching:false
}); 
    
    config.previewWatermarkTextObject=text;
    FQD.canvas.pages[pageno].add(text);
    text.bringToFront();
    FQD.canvas.pages[pageno].centerObject(text);
    return text;
},
FQD.preview.textPlaceholder=function(obj){
	var arr=[];
	obj.forEach(function(obj1){
		if(obj1.type=="textbox"){
			if(obj1.text==obj1.placeHolderTextValue && obj1.previewOnly){
				arr.push(obj1);
			}
		}
	});
	arr.forEach(function(element){
		var opacity=element.getOpacity();
		element.isHidden="true";
		element.initialOpacity=opacity;
		element.setOpacity(0);
	});
	return arr;
		
},

//This function currently not calling because as per no need to require addition properties attached with Text element.
/*
FQD.preview.setTextAnchor=function(obj){
	var arr=[];
	obj.forEach(function(element){
		if(element.type==="textbox"){
			if(element["text-anchor"] === 'middle' || element["text-anchor"] === 'end'){
				arr.push(element);
			}
		}
	});
	return arr;
},
*/

FQD.preview.Responsive=function(){
	var wMulti=460/config.canvasWidth;
	   var hMulti=400/config.canvasHeight;
	   var imgWidth,imgHeight;
	   
	   if(wMulti < hMulti){
		   imgWidth=config.canvasWidth*wMulti;
		   imgHeight=config.canvasHeight*wMulti;
	   }else{
		   imgWidth=config.canvasWidth*hMulti;
		   imgHeight=config.canvasHeight*hMulti;
	   }
	   var w= jQuery(window).width(),
	   	   h= jQuery(window).height()-jQuery("#header").height();
	   
	   if(imgWidth > imgHeight){
		   imgHeight=(imgHeight/h)*80+"%";
		   imgWidth="auto";
	   }
	   if(imgWidth < imgHeight){
		   imgWidth=(imgWidth/w)*80+"%";
		   imgHeight="auto";
	   }
	   return {imgWidth:imgWidth,imgHeight:imgHeight};
}

FQD.preview.getServerPreview=function(page){
	
	var z=FQD.canvas.pages[config.activeCanvas].getZoom();
		FQD.canvas.setZoom(1);// reset canvas to get data in 100% zoom
	FQD.elements.divLoadingQd.show();
	FQD.elements.divLoaderContainer.show();
	var dpi=config.dpi;
	var imgArr=[];
	
    var actualWidth=config.canvasWidth/dpi;
    var actualHeight=config.canvasHeight/dpi;
    
    var prodType=config.productTypeId;
	var prodSvg='';
	var svgToJson='';
	var radius="0";
	
	config.hasPreviewState = true;
	
	if(config.isPageRoundCorner=="true")
	{
		radius=config.productDetails.cornerRadius;
    }
	
	var length=FQD.canvas.pages.length;
		if(config.isFrontOnly == "true"){
			length=1;
		}
	for(var i=0; i < length; i++){
		var arr=[];
		var objs=FQD.canvas.pages[i].getObjects();
		var arr=FQD.preview.textPlaceholder(objs);
		
		for(var j=0;j<objs.length;j++){
			 if(objs[j].type=="image" && objs[j].cropped=="true"){
				 FQD.crop.addObjectAddedAtr(objs[j]);
			 }
		}
		var svgData=FQD.canvas.pages[i].toSVG('',FQD.preview.toSVG);
		//var bgColor=FQD.canvas.pages[i].backgroundColor;
		//svgData=svgData.replace('</defs>','</defs><rect id="backgroundColor" width="'+config.canvasWidth+'" height="'+config.canvasHeight+'" fill="'+bgColor+'"/>');
		var svgjson=config.pageNumber[i];
		//Store all the images in an arry to send it to the server for categorization
		var temp=svgData.split("filestore?id=");
		if(temp.length>1)
			{
			  for(var loop=1;loop<temp.length;loop++)
				  {
				    var fileDescriptor=temp[loop].split('"')[0];
				    imgArr.push(fileDescriptor);
				  }
			}

		svgData=svgData.replace('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>','');
		svgData=svgData.replace('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">','');
		svgData=jQuery.trim(svgData).replace(/(?:\r\n|\r|\n)/g, '');
		svgData=FQD.preview.removeElementNotForPreview(svgData);
		svgData = FQD.preview.removePlaceHoldersImage(svgData);
		
		
		svgData=svgData.replace('xmlns:NS1=""','');
		svgData=svgData.replace('NS1:','');
		prodSvg +="&svgData="+window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(svgData)).replace(/\+/g,"%2B"));
		config.objectAddedAtr=[];
		arr.forEach(function(element){
			delete element.isHidden;
			element.setOpacity(element.initialOpacity);
			
		});
		FQD.canvas.pages[i].renderAll();
		}
	designname="test";
	isPreview=true;
	isSaveProgress=false;
	FQD.canvas.setZoom(z); // zoom canvas as per previous value again
	
	var bleedZoneId = config.productDetails.printProductBleedBean.id;
	 	bleedZoneRoundCornerId = config.productDetails.printProductBleedRoundCornerBean.id,
	 	safeZoneId = config.productDetails.printProductSafeZoneBean.id,
	 	safeZoneRoundCornerId = config.productDetails.printProductSafeZoneRoundCornerBean.id,
	 	designerTemplateId  = config.productDetails.printJob.designerTemplateId,
		designerTemplate2Id = config.productDetails.printJob.designerTemplate2Id;
	
	config.productDetails.printJob.svgScaleMultiplier = config.scaleMultiplier;
	config.productDetails.printJob.exportArea=config.canvasOrigin;
	
	if(config.productDetails.printJob.printJobSVG && config.productDetails.printJob.printJobSVG.svgPages){
		config.productDetails.printJob.printJobSVG.svgPages=[];
	}
	if(config.productDetails.printJob.printJobJson && config.productDetails.printJob.printJobJson.jsonPages){
		config.productDetails.printJob.printJobJson.jsonPages=[];
	}
	
	if(designerTemplateId === undefined || designerTemplateId === null || designerTemplateId === "undefined" || designerTemplateId === "-1"){
		config.productDetails.printJob.designerTemplateId = -1;
	}else if(typeof designerTemplateId === "string" && designerTemplateId != "-1"){
		config.productDetails.printJob.designerTemplateId=parseInt(designerTemplateId);
	}
	
	if(designerTemplate2Id === undefined || designerTemplate2Id === null || designerTemplate2Id === "undefined" || designerTemplate2Id === "-1"){
		config.productDetails.printJob.designerTemplate2Id = -1;
	}else if(typeof designerTemplate2Id === "string" && designerTemplate2Id != "-1"){
		config.productDetails.printJob.designerTemplate2Id=parseInt(designerTemplate2Id);
	}
	
	//console.log(config.productDetails.printJob);
	
	var printJob = getEncodedPrintJob(config.productDetails.printJob);
	
	var random=Math.random();
	FQD.activity.resetKeepAliveTimer();
	if(page){
		FQD.elements.divLoadingQd.css('z-index','1000');
		FQD.elements.divLoaderContainer.css('z-index','1000');
		if(page==1){
			config.previewPageNumber=config.previewPageNumber+1;
		}else{
			config.previewPageNumber=config.previewPageNumber-1;
		}
	}else{
		config.previewPageNumber=config.activeCanvas+1;
	}

	
 	var errorMsg ='<div style="height:100px;background-color:#fff;">';
    errorMsg +='<span style="margin-top: 28px;display: inline-block;font-size: 17px;text-align: center;width: 340px;margin-left: 29px; margin-bottom: 6px;">';
    errorMsg += resourcesData.internalServerError+'</span><hr>';
    errorMsg +='<button type="button" onclick="FQD.utility.exitPreview()" style="float:right;margin-right:5px;">'+resourcesData.ok+'</button></div></div>';
	jQuery.ajax({
		    mimeType: 'text/plain; charset=x-user-defined',
		    url : FQD.preview.url,
		    type: "POST",
		    data:"QDAction=40"+prodSvg+
		    				"&cid="+config.cid+
		                    "&svgToJson="+svgToJson+
		                    "&printJob="+printJob+
		                    "&pageNumber="+config.previewPageNumber+
		                    "&isStamped="+jQuery('#btnGuidelines').prop('checked')+
	    	                "&random="+random,
		   success: function(data)
		   {
			   if(data.trim()==""){
				   FQD.elements.applicationError.html(errorMsg);
				   FQD.elements.applicationError.addClass("previewError");
				   FQD.elements.applicationError.show(); 
				   FQD.elements.divLoadingQd.show();
				   FQD.elements.divOverlay.show();
				   FQD.elements.divModelWindow.show();
				   return;
			   }
			   var res=FQD.preview.Responsive();
			   var imgWidth=res.imgWidth;
			   var imgHeight=res.imgHeight;
			   var pageLbl = FQD.products.getLabelForPageName();
			   h= jQuery(window).height()-jQuery("#header").height();

		    	if(data && data.length > 1){
			    	data=JSON.parse(data);
			    	var i, length = data.preview.length;
			    	var src="";
			    	var label="";
			    	if(config.previewPageNumber==1){
			    		label="Front";
			    	}else{
			    		label="Back";
			    	}
			    	var img="<div class='clear previewProceed_container'><input type='button' value='Proceed to Order' class='previewProceed'/></div><div id='serverSidePreview'><div class='fl' id='tabs-wrapper-preview'><ul id='tabs'><li> <a id='previewTabFront' onclick='FQD.preview.getServerPreview(-1)'>Front</a></li><li  class='last'><a id='previewTabBack'  onclick='FQD.preview.getServerPreview(1)'>Back</a></li></ul></div><div id='previewBefore' onclick='FQD.preview.getServerPreview(-1)'><i class='fas fa-caret-left'></i></div><div id='previewNext' onclick='FQD.preview.getServerPreview(1)'><i class='fas fa-caret-right'></i></div><div class='previewImgContainer'>";
			    		img+="<div id='zoom'><img  width='"+"auto"+"'height='"+"auto"+"' src='"+urlPrefix+"/common/resource/filestore?id="+data.preview[0]+"' data-zoom-image='"+urlPrefix+"/common/resource/filestore?id="+data.zoom[0]+"' style='margin:20px;'><div class='pageLabel'>"+label+"</div></div>";
			    		$("#zoom").elevateZoom();
			    		src=urlPrefix+"/common/resource/filestore?id="+data.preview[0];
			    	FQD.elements.divModelContent.html(img);
			    	

			    	var newImg = new Image();
					newImg.onload = function() {
						//set the large image dimensions - used to calculte ratio's
						var marginLeft= -newImg.width/2;
						var marginTop = -(newImg.height/2+50);
						$("#zoom").css({
							'margin-left': marginLeft,
							'margin-top': marginTop
						});
					}
					newImg.src = src; // this must be done AFTER setting onload
	
					$("#zoom img").elevateZoom();
					$("#previewTabFront").removeClass("active");
					$("#previewTabBack").removeClass("active");
			    	 if(config.pageLength==1){
			    		 $("#previewBefore").hide();
			    		 $("#previewNext").hide();
			    		 $("#previewTabBack").hide();
			    		 $("#previewTabFront").hide();
			    		 
			    	 }else{
				    	 if(config.previewPageNumber==1){
				    		 $("#previewBefore").hide();
				    		 $("#previewTabFront").addClass("active");
				    	 }else{
				    		 $("#previewNext").hide();
				    		 $("#previewTabBack").addClass("active");
				    	 }
			    	 }

		    	}
		    	if(!page){
		    		FQD.tips.open();
		    	}
		    	FQD.elements.divOverlay.show();
		    	FQD.elements.divModelWindow.show();
		    	FQD.elements.divLoadingQd.hide();
		    	FQD.elements.divLoaderContainer.hide();
		    	jQuery('.previewImgContainer').height(h).perfectScrollbar();
		    	$(".previewProceed").click(function(){
		    		FQD.utility.gotoProceedToOrder();
		    	});
				FQD.elements.divLoadingQd.css('z-index','100');
				FQD.elements.divLoaderContainer.css('z-index','99');
		    },
		    error: function (jqXHR, textStatus, errorThrown)
		    {
		    	console.log(errorThrown);
		    	 FQD.elements.applicationError.html(errorMsg);
				 FQD.elements.applicationError.addClass("previewError");
			    	FQD.elements.divOverlay.show();
			    	FQD.elements.divModelWindow.show();
				 FQD.elements.applicationError.show(); 
				 FQD.elements.divLoadingQd.show();
				 FQD.elements.divLoadingQd.css('z-index','100');
				 FQD.elements.divLoaderContainer.css('z-index','99');
		    	config.hasPreviewState = false;
		    
		    },
		    xhrFields:{
		        withCredentials: true
		     }
		});
}

FQD.preview.removeElementNotForPreview=function(str, checkForBg){
	var svg = $(str);
	
	checkForBg = checkForBg == undefined? false: checkForBg;
	
	if(!config.productDetails.fillBackground && checkForBg)
		svg.children('#canvasArea').remove();
	
	svg.children('#removeFromPreview').remove();
	var strUpdated = serializeXMLNode(svg[0]);
	return strUpdated;
}

FQD.preview.removePlaceHoldersImage=function(str){
	var svg = $(str);
	svg.children('g').children('image#placeHolders').parent().remove();
	var strUpdated = serializeXMLNode(svg[0]);
	return strUpdated;
}
FQD.preview.toSVG=function(e){
	var attrAdded='';
	if(e.toString().indexOf("<image")>-1){
		for(var i=0;i<config.objectAddedAtr.length;i++){
			if(e.includes(config.objectAddedAtr[i].src)){
				var arr=Object.keys(config.objectAddedAtr[0].attr);
				  for(var j=0;j<arr.length;j++){
					  attrAdded+=arr[j]+'="'+config.objectAddedAtr[i].attr[arr[j]]+'" ';
				  }
				
			}
		}
		e=e.replace('<image','<image '+attrAdded);
	}
	
	e=FQD.preview.addImageEffectAttribute(e);
	return e;
	
}
FQD.preview.addImageEffectAttribute=function(e){
    
	if(e.toString().indexOf("&imageEffectType=")>-1){
		var arr=e.split("&imageEffectType=");
		var effect=arr[1].split("\"")[0];
		e=e.replace('&imageEffectType='+effect,'');
		e=e.replace('<image','<image imageEffectType="'+effect+'"');
		return e;
		
	}else{
		return e;
	}
}