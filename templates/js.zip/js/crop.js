FQD.crop={};
FQD.crop.multiplayer=1;
var ratio=72/config.dpi;

FQD.crop.preview = function(img, selection) {

		/*
		 * check if selection are made
		 */
		if (!selection.width || !selection.height)
			return;
		/*
		 * setting scaling variable
		 */
		var scaleX = 100 / selection.width;
		var scaleY = 100 / selection.height;
		/*
		 * adding appropriate css to preview image
		 */
		$('#preview img').css({
			width : Math.round(scaleX * 300),
			height : Math.round(scaleY * 300),
			marginLeft : -Math.round(scaleX * selection.x1),
			marginTop : -Math.round(scaleY * selection.y1)
		});
		var x1WithRatio= Math.round(selection.x1*FQD.crop.multiplayer*ratio);
		var y1WithRatio= Math.round(selection.y1*FQD.crop.multiplayer*ratio);
		if(x1WithRatio < 0){
			x1WithRatio=0;
		}
		if(y1WithRatio < 0){
			y1WithRatio=0;
		}
		$('#x1').val(x1WithRatio);
		$('#y1').val(y1WithRatio);
		$('#x2').val(Math.round(selection.x2*FQD.crop.multiplayer*ratio));
		$('#y2').val(Math.round(selection.y2*FQD.crop.multiplayer*ratio));
		$('#w').val(Math.round(selection.width*FQD.crop.multiplayer*ratio));
		$('#h').val(Math.round(selection.height*FQD.crop.multiplayer*ratio));
		
		var x1= parseInt(selection.x1*FQD.crop.multiplayer);
		var y1= parseInt(selection.y1*FQD.crop.multiplayer);
		if(x1 < 0){
			x1=0;
		}
		if(y1 < 0){
			y1=0;
		}
		$('#x1').attr("x1",x1);
		$('#y1').attr("y1",y1);
		$('#x2').attr("x2",parseInt(selection.x2*FQD.crop.multiplayer));
		$('#y2').attr("y2",parseInt(selection.y2*FQD.crop.multiplayer));
		$('#w').attr("w",parseInt(selection.width*FQD.crop.multiplayer));
		$('#h').attr("h",parseInt(selection.height*FQD.crop.multiplayer));
	};

FQD.crop.cropImage=function(){
	var obj=FQD.canvas.getActiveObjects();
	if(obj == undefined || obj == null){
		return;
	}
	ratio = 72/config.dpi;
	FQD.view.getView(FQD.elements.dlgCropImage,"cropImage.html",function(){
		loadLocaleData();
		var ias = $("#photo").imgAreaSelect({handles: true, fadeSpeed: 200, onSelectChange: FQD.crop.preview,instance: true  });
		var src;
		var orgImgWidth= parseInt(obj.originalWidth);
		var orgImgHeight= parseInt(obj.originalHeight);
		var userUploaded= obj.userUploaded;
		var isClipArt= obj.isClipArt;
		var disImgWidth=orgImgWidth;
		var disImgHeight=orgImgHeight;
		if(obj.croppedSourceURL && obj.cropped=="true"){
			if(config.productDetails.conversionRequired){
				src=obj.orgImg;
			}else{
				src=obj.croppedSourceURL;
			}
		}
		else{
			if(obj.cropped=="true"){
				src = FQD.canvas.getActiveObjects().orgImg;
			}
			else{
				src = FQD.canvas.getActiveObjects().getSrc();
			}
		}
		var parts = src.split(":");
		  var fileType;
		  if(parts.length > 2){
			  fileType = parts[3]
		  }
		if(fileType != 10){
			src = src.replaceLast(':2:', ':1:');
		}
		$('#photo').prop("src", src);
		jQuery("#photo").load(function(){
			
			orgImgWidth=orgImgWidth*(350/config.dpi);
			FQD.crop.multiplayer = orgImgWidth/jQuery("#photo").width();
			
			if(obj.croppedSourceURL && obj.cropped=="true"){
				var x=parseInt(obj.cropStartX);
				var y=parseInt(obj.cropStartY);
				var width=parseInt(obj.orgWidth);
				var height=parseInt(obj.orgHeight);
				jQuery("#x1").val(Math.round(x*ratio)).attr("x1",x);
				jQuery("#y1").val(Math.round(y*ratio)).attr("y1",y);
				jQuery("#x2").val(Math.round((x+width)*ratio)).attr("x2",x+width);
				jQuery("#y2").val(Math.round((x+height)*ratio)).attr("y2",y+height);
				jQuery("#w").val(Math.round(width*ratio)).attr("w",width);
				jQuery("#h").val(Math.round(height*ratio)).attr("h",height);
				
				 x = x/FQD.crop.multiplayer;
				 y = y/FQD.crop.multiplayer;
				 width = width/FQD.crop.multiplayer;
				 height = height/FQD.crop.multiplayer;
				
				ias.setSelection(x, y, x+width,y+height, true);
				ias.setOptions({ show: true,handles:true,movable:true});
				ias.update();
			}
		});
		$('#imgPreview').prop("src", src);

		$("#dlgCropImage").dialog({
			width : 490,
			height : 700,
			modal : true,
			draggable: false,
			resizable:false,
			buttons : [
				{
					text : resourcesData.OK,
					click : function () {
						var initx = parseInt($("#x1").attr("x1"));	
						var  inity = parseInt($("#y1").attr("y1"));
						var width = parseInt($("#w").attr("w"));
						var height = parseInt($("#h").attr("h"));
						var originalImageWidth = parseInt(orgImgWidth);
						var originalImageHeight = parseInt(orgImgHeight);
						var initxVal = parseFloat($("#x1").val());
						var inityVal = parseFloat($("#y1").val());
						var widthVal = parseFloat($("#w").val());
						var heightVal = parseFloat($("#h").val());
						if($("#x1").val()!='-' && $("#y1").val()!='-' && $("#x2").val()!='-' && $("#y2").val()!='-' && $("#w").val()!='-' && $("#h").val()!='-'){
							var cropSrc = $("#preview").find("img").attr(
									"src");
							if(initxVal >=0 && inityVal >=0 && widthVal >0 && heightVal >0){
								$(this).dialog("close");
								$(".imgareaselect-outer").css('display', 'none');
								$(".imgareaselect-selection").parent().css('display', 'none');
								$("#dlgCropImage").find("div").css('display', 'none');
								FQD.crop.getCropImg($("#x1").attr("x1"), $("#y1").attr("y1"),$("#w").attr("w"),$("#h").attr("h"),cropSrc,orgImgWidth,orgImgHeight,disImgWidth,disImgHeight,userUploaded,isClipArt);
							}else{
								alert(resourcesData.cropProperlyMsg);
							}
						}
					}
				},{
					text : resourcesData.frontBackCancel,
					click : function () {
						$(".imgareaselect-outer").css('display', 'none');
						$(".imgareaselect-selection").parent().css('display', 'none');
						$("#dlgCropImage").find("div").css('display', 'none');
						$(this).dialog("close");
					}
				}
			   ],
			close : function() {
				$(".imgareaselect-outer").css('display', 'none');
				$(".imgareaselect-selection").parent().css('display', 'none');
				$("#dlgCropImage").find("div").css('display', 'none');
				$(this).dialog("close");
			}
		});
		
		
	});

	
};

FQD.crop.getCropImg = function(initx,inity,width,height,imgurl,imgWidth,imgHeight,disImgWidth,disImgHeight,userUploaded,isClipArt){
    var userUpload="false";
    config.cropStartX=initx;
    config.cropStartY=inity;
    config.cropImgWidth=width;
    config.cropImgHeight=height;
    config.originalImgUrl=imgurl;
    var random=Math.random();
    var obj=FQD.canvas.getActiveObjects();
    var src=obj.getSrc();
    if(initx == 0){
    	initx = 1;
    }
    if(inity == 0){
    	inity = 1;
    }
    var newUrl=src.substring(0, src.lastIndexOf(".png")+4);
    var imageEffectType=src.split("&imageEffectType=");
        imageEffectType=imageEffectType[1];
        imgurl=newUrl+"&crop="+initx+":"+inity+":"+width+":"+height;
        
    if(imageEffectType){
    	imgurl=imgurl+"&imageEffectType="+imageEffectType;
    }
    FQD.crop.insertImgToCanvas(imgurl,obj);
}

FQD.crop.insertImgToCanvas=function(imgUrl,obj){
	FQD.elements.divLoadingQd.show();
	FQD.elements.divLoaderContainer.show();
	var src=obj.getSrc();
	var canvas=FQD.canvas.pages[config.activeCanvas];
	var img = new Image();
	var scaleX = obj.scaleX;
	var scaleY = obj.scaleY;
	
	var renderImageWidth=config.renderImageSize.previewWidth,
		renderImageHeight=config.renderImageSize.previewHeight;
	
	if(config.isHDImage){
		renderImageWidth=config.renderImageSize.pressWidth,
		renderImageHeight=config.renderImageSize.pressHeight;
	}
	
	if(obj.width>renderImageWidth || obj.height>renderImageHeight){
		if(obj.scaleX >=1 && obj.scaleY >=1){
			var scaleFactor=1;
			if(obj.width>renderImageWidth){
				scaleFactor=obj.width/renderImageWidth;
			}else{
				scaleFactor=obj.height/renderImageHeight;
			}
			scaleX=scaleFactor;
			scaleY=scaleFactor;
		}
		
	}
	
	if(obj.cropped == undefined){
		scaleX *= (config.dpi/350);
		scaleY *= (config.dpi/350);
	}
	
	img.onload = function() {
		var x=obj.left, y=obj.top;
			if(obj.left > (config.canvasOrigin.x1-config.safeMargin.safeZoneLeft)){
				x=(config.canvasOrigin.x1-obj.getWidth())/2;
			}
			if(obj.top > (config.canvasOrigin.y1-config.safeMargin.safeZoneTop)){
				y=(config.canvasOrigin.y1-obj.getHeight())/2;
			}
			if(obj.left < config.canvasOrigin.x0 || x < config.canvasOrigin.x0){
				x=config.canvasOrigin.x0 + config.safeMargin.safeZoneLeft;
			}
			if(obj.top < config.canvasOrigin.y || y < config.canvasOrigin.y0){
				y=config.canvasOrigin.y0 + config.safeMargin.safeZoneTop;
			}
	    	 var image = new fabric.Image(img);
	            image.set({
					originX: obj.originX,
					originY: obj.originY,
					left:x,
					top: y,
					scaleX: (obj.cropped == undefined)? (scaleX*config.scaleMultiplier): scaleX,
					scaleY: (obj.cropped == undefined)? (scaleY*config.scaleMultiplier): scaleY,
					angle:obj.angle,
					flipX:obj.flipX,
					flipY:obj.flipY,
					filedescriptorid:obj.filedescriptorid
	            });
	         if(obj.isClipArt){
	        	 image.isClipArt=obj.isClipArt;
	         }
	        image.originalWidth=obj.originalWidth;
	        image.originalHeight=obj.originalHeight;
	        if(obj.userUploaded=="true")
	        	{
	        	image.userUploaded="true";
	        	}
	        else{
	        	 image.userUploaded="false";
	        }
	        image.cropped="true";
	        image.orgWidth=config.cropImgWidth;
	        image.orgHeight=config.cropImgHeight;
	        image.cropStartX=config.cropStartX;
	        image.cropStartY=config.cropStartY;
	        image.orgImg=config.originalImgUrl;
	        
	        if(obj.croppedSourceURL && obj.croppedSourceURL!=""){
	        	image.croppedSourceURL=obj.croppedSourceURL;
	        }
	        else{
	        	image.croppedSourceURL=src;
	        }
	       
			canvas.add(image);
			FQD.elements.divLoadingQd.hide();
	    	FQD.elements.divLoaderContainer.hide();
	    	FQD.canvas.pages[config.activeCanvas].remove(obj);
	    	FQD.canvas.pages[config.activeCanvas].renderAll();
	    	FQD.shapes.showEditProperties();
	    	FQD.shapes.commiteScaleValues(image);
        	image.set("scaled",false);
        	FQD.allOverlayOnTop();
	        FQD.undoManager.saveHistory(true);
		
	};
	img.src = imgUrl;
	img.onerror=function(){
		FQD.elements.divLoadingQd.hide();
    	FQD.elements.divLoaderContainer.hide();
    	customAlertBox("alert","Cancel","Ok",fqdInvalidImageUrl);
	} 
}

FQD.crop.addObjectAddedAtr=function(image){
	 var obj={};
	 obj.attr={};
	 obj.src=image.getSrc();
	 obj.attr.userUploaded=image.userUploaded;
	 obj.attr.cropped=image.cropped;
	 obj.attr.cropStartX=image.cropStartX;
	 obj.attr.cropStartY=image.cropStartY;
	 if(image.croppedSourceURL){
	  obj.attr.orgImg=image.croppedSourceURL;
	 }else{
	  obj.attr.orgImg=image.orgImg;
	 }
	 obj.attr.orgWidth=image.orgWidth;
	 obj.attr.orgHeight=image.orgHeight;
	 if(!image.cropStartX || image.cropStartY){
		 var arr=obj.src.split("&")[1].replace("crop=","").split(":");
		 obj.attr.cropStartX=arr[0];
		 obj.attr.cropStartY=arr[1];
		 obj.attr.orgWidth=arr[2];
		 obj.attr.orgHeight=arr[3];
	 }
	 // Fix for XGPCOM-10675
	 var cropStartX=obj.attr.cropStartX;
	 var cropStartY=obj.attr.cropStartY;
	 var orgWidth=obj.attr.orgWidth;
	 var orgHeight=obj.attr.orgHeight;
	 if(!parseFloat(cropStartX))
        {
		 obj.attr.cropStartX="0";
        }
	 if(!parseFloat(cropStartY))
     	{
		 obj.attr.cropStartY="0";
     	}
	 if(!parseFloat(orgWidth))
	 	{
		 obj.attr.orgWidth=image.width;
	 	}
	 if(!parseFloat(orgHeight))
  		{
		 obj.attr.orgHeight=image.height;
  		}
	 // end of fix
    
	 config.objectAddedAtr.push(obj);
	}










