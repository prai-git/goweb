/*******************************************************************************
 * 
 * Responsible write condition to initialize application as per product type 
 * 
 * 
 ******************************************************************************/
FQD.mainScreen={};

FQD.mainScreen.updateMainScreen=function()
{
	//HEARDER
	//===============================================================
	FQD.view.getView(FQD.elements.divHeader,"header.html",function(){
		jQuery("#gp_logo").attr("src",config.logoURL);
		if(config.IsUserLoggedIn==true){
			FQD.initElement();
	  		FQD.elements.btnLogin.hide();
    		FQD.elements.btnSignUp.hide();
    		if(config.productDetails.designerType == 2){
    			FQD.elements.btnSaveProgress.hide();
    		}
		}
		FQD.imgLib.adjustCategoryTab();
		jQuery("#description").html((config.productDetails.description).replace("<br>"," "));
		
		// product name is harde coded it should come from response
		var productName=config.productDetails.productName;
		 jQuery("#product-name").html(productName);
		 if(urlPrefix.trim()!=""){
			 $('#designServices').css('background-image','url('+staticContentBaseUrl+'/common/store/online-designer/css/design_services_button_100x45.png)');
			 $('#designServicesBlock a').prop('href',urlPrefix+'/content.html?id=designServicesLandingPage');
		 }
		 FQD.shapeLib.init();
		 
		 if(config.orderItemRedesignMode){
		    FQD.mainScreen.setupOpenRedesignMode();
		 }
		 
		 if(config.productDetails.adminOpenedSavedDesign){
			 FQD.mainScreen.setupAdminOpenDesign();
		 }
		 jQuery('<div class="tool-title"></div>').insertBefore(".close-edit-panel");
		 if(config.userSavedDesignName){
			 	jQuery("#btnSaveProgress,#btnSaveDesignAs").show();
		    	FQD.saveDesign.showDesignName(config.userSavedDesignName);
		    }
		 FQD.customize.setFileMenuListOptions();
	});
	
	//BASIV-TOOL
	//===============================================================
	FQD.view.getView(FQD.elements.divBasicTool,"basic-tools.html",function(){
		FQD.initElement();
	});
	
	//PAGES BUTTON (FRONT/BACK)
	//===============================================================
	FQD.view.getView(FQD.elements.divTabContainer,"pages.html",function(){
		var pageLbl = FQD.products.getLabelForPageName();
		$('#tabs #pageFrontBtn')[0].innerHTML = $('#tabs #pageFrontBtn')[0].title = pageLbl.frontLbl;
		$('#tabs #pageBackBtn')[0].innerHTML = $('#tabs #pageBackBtn')[0].title = pageLbl.backLbl;
		
		if(config.productDetails.color == "1" || config.pageNumber.length == 1)
		{
			$('#tabs .last').hide();
		}
	});
	
	//ZOOM CONTROL PANEL
	//===============================================================
	FQD.view.getView(FQD.elements.divZoom,"zoom.html");
	
	
	//HELP SECTION
	//===============================================================
	FQD.view.getView(jQuery("#help-content"),"help.html", function(){
		
		jQuery("#help-content li.ulCategory").click(function(){
			FQD.imgLib.showHideCategory(jQuery(this));
		});
		
	});
	
	
	//TIPS BUBBLE
	//===============================================================
	 FQD.view.getView(jQuery("#tips-bubble"),"tips.html");
	
	//PRODUCT INFORMATION
	//===============================================================
	FQD.view.getView(FQD.elements.prodInfo,"prodInformation.html");
	
	//ALIGN CONTROLS
	//===============================================================
	FQD.view.getView(FQD.elements.divAlignTools,"align.html");
	
	//CONTEXT MENU POPUP WINDOW
	//===============================================================
	FQD.view.getView(jQuery("#context-menu"),"context-menu.html");
	
	//SIGN-UP POPUP WINDOW
	//===============================================================
	FQD.view.getView(FQD.elements.userSignUpWindow,"signUp.html");
		
	//Keyboard Help POPUP WINDOW
	//===============================================================
	FQD.view.getView(FQD.elements.keyboardHelpWindow,"keyboardHelp.html");
	
	//LOGIN POPUP WINDOW
	//===============================================================
	FQD.view.getView(FQD.elements.userLoginWindow,"loginPopup.html",function(){
		FQD.initElement();
		loadLocaleData();
		jQuery(FQD.elements.usrPasswd).keypress(function(e) {
		    if(e.which == 13) {
		    	FQD.helper.authenticateUser();
		    }
		});
	});
	
	//RESET PASSWORD
	//===============================================================
	FQD.view.getView(FQD.elements.resetPasswordWindow,"resetPassword.html");
	FQD.view.getView(FQD.elements.resetPasswordWindow1,"resetPasswordMessage.html");
	
	
	//PAGES OPTION POPUP VIEW
	//===============================================================
	FQD.view.getView(FQD.elements.pagesOptions,"documentSettings/pageOptionsPopupView.html",function(){
		if(config.isGeneric){
			jQuery("#select-pages").remove();
		}
	});
	
	//SWAP IMAGE WARNING POPUP
	//===============================================================
	FQD.view.getView(FQD.elements.swapImageWarning,"swapImageWarning.html",function(){
		FQD.initElement();
		$("#swapImageWarningMessage1").html(swapImageWarningMessage1);
		$("#swapImageWarningMessage2").html(swapImageWarningMessage2);
	});
	
	//TEMPLATE DATA TRANSFER
	//===============================================================
	FQD.view.getView(FQD.elements.templateDataTransfer,"templateDataTransfer.html");
	
	
	FQD.view.getView(FQD.elements.divImgLib,"img-lib.html",function(){
		if(config.productDetails.adminOpenedSavedDesign && (config.productDetails.savedDesignUserId == null || config.productDetails.savedDesignUserId < 1)){
			jQuery("#up-image").remove();
		}
		else
		{
			FQD.initElement();
			FQD.imgLib.init();
			if(config.overlayOpacity == 1){
				jQuery(".switch-button-button").addClass("switch-checked-button");
			}
		}
		jQuery('.text-edit-tool,.special-text-item,.shape-content,.category-container,#new-text-field,#filesUploaded,#messages').perfectScrollbar();
	});
	
	//SAVE DESIGN POPUP
	//===============================================================
	FQD.view.getView(FQD.elements.saveDesignName,"saveDesign.html",function(){
		$("#SavedDesigns").click(function() {
			config.btnPress=4;
			FQD.helper.isUserLoggedIn('promptSavedDesign');
		});
		FQD.saveDesign.saveDesignAction();
		FQD.saveDesign.saveProgress();
		FQD.saveDesign.saveNew(); 
	});
	
	//Proceed to order session timeout
	//===============================================================
	FQD.view.getView(FQD.elements.proceedToOrderSessionLogout,"proceedToOrderSessionLogout.html",function(){
	});
	
	//BACKGROUND PROPERTIES PANEL
	//===============================================================
	/*if(FQD.PrintProductType.isGenericProduct()){
		jQuery("#bg-image").remove();
	}else{*/
		/*FQD.view.getView(FQD.elements.divBgProperties,"bg-properties.html",function(){
			FQD.initElement();
			FQD.utility.setBackgroundColorPicker(FQD.elements.inputColorB);
			FQD.view.src("imgTop","/common/store/online-designer/images/arrows/top.png");
			FQD.view.src("imgLeft","/common/store/online-designer/images/arrows/left.png");
			FQD.view.src("imgMiddle","/common/store/online-designer/images/arrows/middle.png");
			FQD.view.src("imgRight","/common/store/online-designer/images/arrows/right.png");
			FQD.view.src("imgBottom","/common/store/online-designer/images/arrows/bottom.png");
		});*/
	//}
	
	//ELEMENTS PROPERTIES PANEL
	//===============================================================
	FQD.view.getView(jQuery("#elemet-editor-container"),"edit-properties.html",function(){
		FQD.view.src("forwardImg","/common/store/online-designer/css/qd-images/forward.png");
		FQD.view.src("backwardImg","/common/store/online-designer/css/qd-images/backward.png");
		FQD.view.src("backgroundImg","/common/store/online-designer/css/qd-images/background.png");
		FQD.view.src("imgTop","/common/store/online-designer/images/arrows/top.png");
		FQD.view.src("imgLeft","/common/store/online-designer/images/arrows/left.png");
		FQD.view.src("imgMiddle","/common/store/online-designer/images/arrows/middle.png");
		FQD.view.src("imgRight","/common/store/online-designer/images/arrows/right.png");
		FQD.view.src("imgBottom","/common/store/online-designer/images/arrows/bottom.png");
		FQD.initElement();
		FQD.utility.setElementColorPicker();
		FQD.utility.setStroke();
		FQD.utility.setRoundedRadiusSlider();
		FQD.utility.setOpacity();
		FQD.utility.setFontSize();
		FQD.utility.setLineHeight();
		FQD.utility.setFontFamily(jQuery("#sel-fonts"));    			
		$('#crop-photo').attr("src",config.qdpath+"images/crop.png");
		FQD.utility.cropImage();
		FQD.helper.setNonBoldItalicFont();
		initFonts();
		checkForRoundCorner();
		checkForFoldingOptions();
		checkForPocketOptions();
		checkForHoleOptions();
		checkForPerforationOptions();
		FQD.canvas.setCanvasOptions();
		FQD.utility.setBackgroundColorPicker(jQuery("#colorB2"));
		FQD.utility.setBgImageEffect();
		jQuery("#angle,#xpos,#ypos,#widthobj,#heightobj").on('input', function() {
			   this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
		});
		
		if(!config.productDetails.fillBackground){
			jQuery("#bg-image").remove();
			jQuery("#bgPropertiesContainer").remove();
		}else if(config.isGeneric){
			jQuery("#bg-image").remove();
		}
		
		if(navigator.vendor.trim()==""){
			$("#BGEffects").css('margin-top','-11px');
		}
		$("#selBGEffects option[data-option='noneOptionValueTitle']").html(resourcesData.noneOptionValueTitle);
		$("#selBGEffects option[data-option='lightenOption']").html(resourcesData.lightenOption);
		$("#selBGEffects option[data-option='darkenOption']").html(resourcesData.darkenOption);
		$("#selBGEffects option[data-option='grayScaleOption']").html(resourcesData.grayScaleOption);
		$("#selBGEffects option[data-option='negativeOption']").html(resourcesData.negativeOption);
		$("#selBGEffects option[data-option='blurOption']").html(resourcesData.blurOption);
		$("#selBGEffects option[data-option='sharpenOption']").html(resourcesData.sharpenOption);
		$("#selBGEffects option[data-option='embossOption']").html(resourcesData.embossOption);

	});
	
	//ELEMENTS INFORMATION PANEL
	//===============================================================
	FQD.view.getView(FQD.elements.objectDetail,"objectInfo.html",function(){
		
	});
	
	//CORNER OPTION POPUP VIEW
	//===============================================================
	checkForRoundCorner = function(){
		if(config.isGeneric || config.productDetails.roundCorners == undefined){
			jQuery("#corner-options").remove();
		}else{
			FQD.view.getView(FQD.elements.pagesCornerOptions,"documentSettings/cornerOptionsPopupView.html",function(){});
		}
	}
	
	//FOLDING OPTIONS POPUP VIEW
	//===============================================================
	checkForFoldingOptions = function(){
		if(config.isGeneric || config.productDetails.foldingOptions == undefined || FQD.PrintProductType.isFoldedBusinessCard() || FQD.PrintProductType.isFoldedHangTag() || FQD.PrintProductType.isGreetingCard()){
			jQuery("#fold-options").remove();
		}else{
			FQD.view.getView(FQD.elements.foldingOptionsPopup, "documentSettings/foldingOptionsPopupView.html",function(){});
		}
	}
	
	//POCKET OPTIONS POPUP VIEW
	//===============================================================
	checkForPocketOptions = function(){
		if(config.isGeneric || config.productDetails.pocketOptions == undefined){
			jQuery("#pocket-options").remove();
		}else{
			FQD.view.getView(FQD.elements.pocketOptionsPopup, "documentSettings/pocketOptionsPopupView.html",function(){});
		}
	}
	
	//HOLE OPTION POPUP VIEW
	//===============================================================
	checkForHoleOptions = function(){
		if(config.isGeneric || config.productDetails.holePositionOptions == undefined){
			jQuery("#hole-options").remove();
		}else{
			FQD.view.getView(FQD.elements.holeOptionsPopup,"documentSettings/holeOptionsPopupView.html",function(){});
		}
	}
	
	//PERFORATION AND NUMBERING OPTION POPUP VIEW
	//===============================================================
	checkForPerforationOptions = function(){
		if(config.isGeneric || config.productDetails.perforationAndNumberingOptions == undefined){
			jQuery("#perforation-numbering-options").remove();
		}else{
			FQD.view.getView(FQD.elements.perforationOptionsPopup,"documentSettings/perforationOptionsPopupView.html",function(){});
		}
	}
	
	//VISUAL-ADS PANEL
	//===============================================================
	FQD.view.getView(FQD.elements.divCanvasTools,"visual-aids.html",function(){
		loadLocaleData();
		if(typeof Storage  != "undefined"){
			var  transferTemplateDialog = sessionStorage.getItem('transferTemplateDialog');
			if(transferTemplateDialog == "true"){
				config.transferTemplateDialog=true;
				jQuery("#transfer-template-dialog").prop("checked",true);
			}
		 }
		FQD.visualAids.setGridSlider('#grid-slider','#gridWidth');
		config.visualAdHeight=jQuery("#qd-wrapper .canvas-menu").height();
		config.visualAdTop=config.visualAdHeight+40;
	});
	
	//ADMIN SETTING 
	//===============================================================
	FQD.view.getView(FQD.elements.divAdminPopup,"admin-settings.html",function(){
		loadLocaleData();
		FQD.initElement();
	});
	
	FQD.canvas.holeSize = FQD.canvas.holeSize*config.productDetails.dpi;	
	FQD.canvas.holePositionSpace = FQD.canvas.holePositionSpace *config.productDetails.dpi;
	FQD.canvas.holeTopSpace = FQD.canvas.holeTopSpace * config.productDetails.dpi;
	
	FQD.helper.isUserLoggedIn();
}

FQD.mainScreen.hideProductOptionsPopups=function()
{
	FQD.elements.pagesOptions.hide();
	FQD.elements.pagesCornerOptions.hide();
	FQD.elements.holeOptionsPopup.hide();
	FQD.elements.foldingOptionsPopup.hide();
	FQD.elements.pocketOptionsPopup.hide();
	FQD.elements.perforationOptionsPopup.hide();
}

FQD.mainScreen.setupOpenRedesignMode=function()
{
	jQuery("#select-pages").remove();
	jQuery("#corner-options").remove();
	jQuery("#hole-options").remove();
	jQuery("#fold-options").remove();
	jQuery("#pocket-options").remove();
	jQuery("#perforation-numbering-options").remove();
	jQuery("#proceedOrder").attr("data-text","saveDesignTitle");
	$('#btnSave').remove();
	$('#btnSaveProgress').remove();
	$('#btnSaveDesignAs').remove();
	$('#SavedDesigns').remove();
}

FQD.mainScreen.setupAdminOpenDesign=function()
{
	jQuery("#select-pages").remove();
	jQuery("#corner-options").remove();
	jQuery("#hole-options").remove();
	jQuery("#fold-options").remove();
	jQuery("#pocket-options").remove();
	jQuery("#perforation-numbering-options").remove();
	jQuery("#proceedOrder").remove();
	//jQuery("#file_menu").remove();
	
	jQuery("#upFiles").remove();
	jQuery("#tab-1").remove();
	jQuery("#appButtons").remove();
	jQuery("#searchBox").remove();
	jQuery("#filesUploaded").css({"margin-top": "30px"});
	myUploads.usedBackgroundImages();
	
	$("#btnInsertImg").remove();
	$("#applyBg").remove();
	
	if(config.productDetails.redirectURL.trim()!=""){
		jQuery("#alink_GPLogo").attr("href", config.productDetails.redirectURL);
	}
	
}

FQD.mainScreen.pagesOptions=function(){
	FQD.mainScreen.hideProductOptionsPopups();
	
	var folderPath = config.resourcePath + config.productIconPath;
	var pageLength = config.pageLength;
	var numPages = -1;
	var frontString = resourcesData.lbl_front;
	var backString = resourcesData.lbl_front_and_back;
	
	if(config.productDetails.pages != null && config.productDetails.pages.length > 0)
    	numPages = (config.productDetails.pages.length > 1)? config.productDetails.pages.length: config.productDetails.pages[0];
    
	if(config.productDetails.pages.length == 1){
		 $("#pageOptionsFrontBackContainer").hide();
		 $("#pageOptionsApply").hide();
		 $("#pageOptionsFrontContainer").css({'float':'none', 'width':'100%'});
		 
		 var selectorData = FQD.products.getSinglePageData();
		 $("#pageOptionsFront").css({'background':'url(' + folderPath + selectorData.frontOn+') no-repeat'});
		 
		 if(FQD.PrintProductType.isFoldedProduct()){
	    		frontString = resourcesData.lbl_outside_and_inside;
		 }
	}
	else if(config.productDetails.pages.length == 2)
	{
		var selectorData = FQD.products.getTwoPageData();
		
		$("#pageOptionsApply").hide();
		$("#pageOptionsFront").addClass("front");
		if(pageLength == 1){
			$("#pagesOptionsBody .front").addClass("selected");
			$("#pageOptionsFront").css('background', 'url(' + folderPath + selectorData.frontOn+') no-repeat');
		}else{
			$("#pageOptionsFront").css('background', 'url(' + folderPath + selectorData.frontOff+') no-repeat');
		}
		
		$("#pageOptionsFrontBack").addClass("frontBack");
		if(pageLength == 1){
			$("#pageOptionsFrontBack").css('background', 'url(' + folderPath + selectorData.frontBackOff+') no-repeat');
		}else{
			$("#pagesOptionsBody .frontBack").addClass("selected");
			$("#pageOptionsFrontBack").css('background', 'url(' + folderPath + selectorData.frontBackOn+') no-repeat');
		}
		
		$("#pagesOptionsBody .front").hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + selectorData.frontOn+') no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + selectorData.frontOff+') no-repeat');
				}
		);
		
		$("#pagesOptionsBody .front").click(
				function(){
		    		$(this).css('background', 'url(' + folderPath + selectorData.frontOn+') no-repeat');
		    		$("#pagesOptionsBody .frontBack").css('background', 'url(' + folderPath + selectorData.frontBackOff+') no-repeat');
		    		$(this).addClass("selected");
		    		$("#pagesOptionsBody .frontBack").removeClass("selected");
		    		showHideApplyButton(this);
		    	}
		);
		
		$("#pagesOptionsBody .frontBack").hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + selectorData.frontBackOn+') no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + selectorData.frontBackOff+') no-repeat');
				}
		);
		
	    $("#pagesOptionsBody .frontBack").click(
	    		function(){
	    			$(this).css('background', 'url(' + folderPath + selectorData.frontBackOn+') no-repeat');
	    			$("#pagesOptionsBody .front").css('background', 'url(' + folderPath + selectorData.frontOff+') no-repeat');
	    			$(this).addClass("selected");
	    			$("#pagesOptionsBody .front").removeClass("selected");
	    			showHideApplyButton(this);
	    });
	    
	    if(FQD.PrintProductType.isFoldedProduct()){
			 if(FQD.PrintProductType.isFolder()){
				 frontString = resourcesData.lbl_outside_pocket_only;
				 backString = resourcesData.lbl_outside_pocket_and_inside;
			 }else{
				 frontString = resourcesData.lbl_outside_only;
				 backString = resourcesData.lbl_outside_and_inside;
			 }
		}
	}
	
	$("#popupFrontOptBtnLbl")[0].innerHTML = frontString;
    $("#popupFrontBackOptBtnLbl")[0].innerHTML = backString;
	
    FQD.elements.pagesOptions.show();
    
    //==== Show/Hide Apply Button ====//
    showHideApplyButton=function(action)
    {
    	var frontSelected = $(action).hasClass("front")? true: false;
    	
    	if(frontSelected){
	    	if(pageLength == 1)
	    		 $("#pageOptionsApply").hide();
	    	else
	    		 $("#pageOptionsApply").show();
	    }
	    else
	    {
	    	if(pageLength == 1)
	    		 $("#pageOptionsApply").show();
	    	else
	    		 $("#pageOptionsApply").hide();
	    }
    }
    //==== END ====//   
}


FQD.mainScreen.cornerOptions=function(){
	FQD.mainScreen.hideProductOptionsPopups();

	var folderPath = config.resourcePath + config.productIconPath;
	var imgSquareOff = folderPath + "square-off.png";
	var imgRoundOff  = folderPath + "round-off.png";
	var imgSquareOn  = folderPath + "square-on.png";
	var imgRoundOn   = folderPath + "round-on.png";
	
	if(config.isPageRoundCorner == "true"){
		$("#pageCornerOptionsSquare").css('background', 'url(' + imgSquareOff + ') no-repeat');
		$("#pageCornerOptionsRound").css('background', 'url(' + imgRoundOn + ') no-repeat');
	}else{
		$("#pageCornerOptionsSquare").css('background', 'url(' + imgSquareOn + ') no-repeat');
		$("#pageCornerOptionsRound").css('background', 'url(' + imgRoundOff + ') no-repeat'); 
	}
	
	$("#pageCornerOptionsSquare").click(
		   function(){
			   applySelectedCornerOption("false");
		   }
    );
 
    $("#pageCornerOptionsRound").click(
		   function(){
			   applySelectedCornerOption("true");
		   }
    );
    
    FQD.elements.pagesCornerOptions.show();
    loadLocaleData();
    //==== Apply Selected Corner Options ==== //
    applySelectedCornerOption=function(isRound)
    {
    	if(config.isPageRoundCorner == isRound)
    		return;
    	config.changeCornerOption=true;
    	FQD.canvas.removeSelection();
    	FQD.shapes.showEditProperties();
    	FQD.helper.closePageCornerOptions();
    	FQD.helper.storeJsonData();
    	config.isPageRoundCorner = isRound;
    	config.productDetails.printJob.options.roundCorners = (isRound == "true")? config.productDetails.roundCorners.id: 0;
    	config.cornerChanged = true;
    	FQD.helper.loadJsonData((isRound == "true")? "round": "square");
		$("#front").click();
		if(FQD.elements.buttonShowAllCanvas.hasClass('show-all')){
			FQD.events.showAllCanvas(FQD.elements.buttonShowAllCanvas);
		}
		FQD.helper.setScaleUnit();
    }
}

FQD.mainScreen.foldingOptions=function(){
	FQD.mainScreen.hideProductOptionsPopups();
	if(jQuery("#foldingOptionsContainer #optionsBar").children().length < 1){
		var xpos = 0;
		var ypos = 60;
		var thWid = 85;
		var len = config.productDetails.foldingOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		var count = 0;
		
		xpos = len > 2? 25: (300-(thWid*len))/2;
		
		for(var i = 0; i < len; i++){
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.padding = "5px";
			optDiv.style.width = "75px";
			optDiv.style.position = "absolute";
			optDiv.style.left = (xpos + (thWid*count)) + "px";
			optDiv.style.top = ypos + "px";
			
			count += 1;
			if(count == 3){
				count = 0;
				ypos += 140;
			}
			var selectorData = FQD.products.getFoldingOptionsData(config.productDetails.foldingOptions[i].id);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			if(config.foldingId == config.productDetails.foldingOptions[i].id){
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
				$(iconDiv).addClass("selected");
			}else{
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			}
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			$(iconLblDiv).css("width", "76px");
			iconLblDiv.innerHTML = config.productDetails.foldingOptions[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						config.foldingId = parseInt(config.productDetails.foldingOptions[parseInt(this.id)].id);
						var canvasRotate = (config.productDetails.printJob.options.printProductFoldingId == FQD.PrintProductType.VERTICAL_HALF_FOLD || config.foldingId == FQD.PrintProductType.VERTICAL_HALF_FOLD)? true: false;
						config.productDetails.printJob.options.printProductFoldingId = config.foldingId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
						if(config.foldingId){
							FQD.imgLib.getProductCategories();
						}
						closeEditPanel();
						if(canvasRotate){
							FQD.mainScreen.applyFoldChange(config.foldingId);
							FQD.canvas.resetCanvasAsPerWindowSize(-1, true);
						}else{
							FQD.canvas.changeFoldingOption();
						}
					}
			);
		
			jQuery("#foldingOptionsContainer #optionsBar").append(optDiv);
		}
	}
	FQD.elements.foldingOptionsPopup.show();
}

FQD.mainScreen.holeOptions=function(){
	FQD.mainScreen.hideProductOptionsPopups();
	
	if(jQuery("#holeOptionsContainer #optionsBar").children().length < 1){
		var xpos = 0;
		var len = config.productDetails.holePositionOptions.length;
		var folderPath = config.resourcePath + config.productIconPath;
		var options = [];
		
		for(var i = 0; i < len; i++){
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.left = xpos+"px";
			
			xpos += 100;
			
			var selectorData = FQD.products.getHolePositionData(config.productDetails.holePositionOptions[i].id);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			if(config.holeOptionId == config.productDetails.holePositionOptions[i].id){
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
				$(iconDiv).addClass("selected");
			}else{
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			}
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = config.productDetails.holePositionOptions[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).click(
					function(){
						config.holeOptionId = parseInt(config.productDetails.holePositionOptions[parseInt(this.id)].id);
						config.productDetails.printJob.options.holePosition = config.holeOptionId;
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
						FQD.canvas.changeHolePosition();
						closeEditPanel();
					}
			);
			
			jQuery("#holeOptionsContainer #optionsBar").append(optDiv);
			var btnBarWidth = (110 * len) + 10;
			jQuery("#holeOptionsContainer #optionsBar").css('width', btnBarWidth+'px');
		}
	}
	
	FQD.elements.holeOptionsPopup.show();
}

FQD.mainScreen.perforationAndNumberingOptions = function(){
	FQD.mainScreen.hideProductOptionsPopups();

	while(jQuery("#perforationOptionsContainer #optionsBar").children()[0] != undefined){
		jQuery("#perforationOptionsContainer #optionsBar").children()[0].remove();
	}
	
	while(jQuery("#perforationOptionsContainer #optionsBar2").children()[0] != undefined){
		jQuery("#perforationOptionsContainer #optionsBar2").children()[0].remove();
	}
	
	if(config.numberingPositionId == undefined)
		config.numberingPositionId = config.productDetails.numberingPositionOptions[0].id;
	
	var xpos = 0;
	var len = config.productDetails.numberingPositionOptions.length;
	var folderPath = config.resourcePath + config.productIconPath;
	var perforationId = config.perforationAndNumberingId;
	var numPosId = config.numberingPositionId;
	var options = []; 	//store preforation and numbering options icon button
	var options2 = []; 	//store numbering position icon button
	
	for(var i = 0; i < len; i++){
		var optDiv = document.createElement("div");
		$(optDiv).addClass("optionBtn");
		optDiv.style.left = xpos+"px";
		xpos += 100;
		
		var selectorData = FQD.products.getNumberPositionData(config.productDetails.numberingPositionOptions[i].id);
		var iconDiv = document.createElement("div");
		iconDiv.className = "iconDiv";
		iconDiv.id = i;
		$(iconDiv).addClass("optionBtnImg");
		if(config.numberingPositionId == config.productDetails.numberingPositionOptions[i].id){
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
			$(iconDiv).addClass("selected");
		}else{
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
		}
		
		var iconLblDiv = document.createElement("div");
		$(iconLblDiv).addClass("optionBtnLbl");
		iconLblDiv.innerHTML = config.productDetails.numberingPositionOptions[i].displayName;
		$(optDiv).append(iconDiv);
		$(optDiv).append(iconLblDiv);	
		
		options2.push({icon:iconDiv, data:selectorData});
		
		$(iconDiv).hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + options2[parseInt(this.id)].data.iconOn +') center no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + options2[parseInt(this.id)].data.iconOff +') center  no-repeat');
				}
		);
		
		$(iconDiv).click(
				function(){
					numPosId = parseInt(config.productDetails.numberingPositionOptions[parseInt(this.id)].id);
					$(this).css('background', 'url(' + folderPath + options2[parseInt(this.id)].data.iconOn+') center  no-repeat');
					$(this).addClass("selected");
					for(var j=0;j<options2.length;j++){
						if(options2[j].icon.id != this.id){
							$(options2[j].icon).css('background', 'url(' + folderPath + options2[j].data.iconOff+') center  no-repeat');
							$(options2[j].icon).removeClass("selected");
						}
					}
					showHideApplyButton();
				}
		);
		
		jQuery("#perforationOptionsContainer #optionsBar2").append(optDiv);
	
		if((i+1) >= len){
			var clearDiv = document.createElement("div");
			clearDiv.style.clear = "both";
			jQuery("#perforationOptionsContainer #optionsBar2").append(clearDiv);
		}
		
		var btnBarWidth = (110 * len) + 10;
		jQuery("#perforationOptionsContainer #optionsBar2").css('width', btnBarWidth+'px');
	}
	
	xpos = 0;
	len = config.productDetails.perforationAndNumberingOptions.length;
	
	for(i = 0; i < len; i++){
		var optDiv = document.createElement("div");
		$(optDiv).addClass("optionBtn");
		optDiv.style.left = xpos+"px";
		optDiv.style.padding = "5px";
		xpos += 100;
		
		var selectorData = FQD.products.getPerforationData(config.productDetails.perforationAndNumberingOptions[i].id);
		
		var iconDiv = document.createElement("div");
		iconDiv.className = "iconDiv";
		iconDiv.id = i;
		$(iconDiv).addClass("optionBtnImg");
		if(config.perforationAndNumberingId == config.productDetails.perforationAndNumberingOptions[i].id){
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
			$(iconDiv).addClass("selected");
		}else{
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
		}
		
		
		var iconLblDiv = document.createElement("div");
		$(iconLblDiv).addClass("optionBtnLbl");
		iconLblDiv.innerHTML = config.productDetails.perforationAndNumberingOptions[i].displayName;
		
		$(optDiv).append(iconDiv);
		$(optDiv).append(iconLblDiv);	
		
		options.push({icon:iconDiv, data:selectorData});
		
		$(iconDiv).hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
				}
		);
		
		$(iconDiv).click(
				function(){
					perforationId = parseInt(config.productDetails.perforationAndNumberingOptions[parseInt(this.id)].id);
					$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
					$(this).addClass("selected");
					for(var j=0;j<options.length;j++){
						if(options[j].icon.id != this.id){
							$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
							$(options[j].icon).removeClass("selected");
						}
					}
					setNumberingPositionVisibilty(perforationId == FQD.PrintProductType.PERFORATION_ONLY);
					showHideApplyButton();
				}
		);
		
		jQuery("#perforationOptionsContainer #optionsBar").append(optDiv);
	
		if((i+1) >= len){
			var clearDiv = document.createElement("div");
			clearDiv.style.clear = "both";
			jQuery("#perforationOptionsContainer #optionsBar").append(clearDiv);
		}
		
		FQD.mainScreen.perforationOptArr = options;
		FQD.mainScreen.numberPosArr = options2;
	}
	
	FQD.elements.perforationOptionsPopup.show();
	
	setNumberingPositionVisibilty = function(f){
		if(!f){
			jQuery("#perforationOptionsContainer #tlNumPos").show();
			jQuery("#perforationOptionsContainer #optionsBar2").show();
		}else{
			jQuery("#perforationOptionsContainer #tlNumPos").hide();
			jQuery("#perforationOptionsContainer #optionsBar2").hide();
		}
	}
	
    showHideApplyButton = function()
    {
    	if(perforationId == config.perforationAndNumberingId && numPosId == config.numberingPositionId)
    		$("#perforationApplyBtn").hide();
    	else
    		$("#perforationApplyBtn").show();
    }
    
    setNumberingPositionVisibilty(perforationId == FQD.PrintProductType.PERFORATION_ONLY);
    showHideApplyButton();
    
    $("#perforationApplyBtn").click(
			function(){
				$("#perforationApplyBtn").unbind();
				config.productDetails.printJob.options.perforationAndNumbering = config.perforationAndNumberingId = perforationId;
				config.productDetails.printJob.options.numberingPosition = config.numberingPositionId = numPosId;
				if(perforationId == FQD.PrintProductType.PERFORATION_ONLY)
					config.productDetails.printJob.options.numberingPosition = null;
				FQD.helper.applyPerforationOptions();
			}
	);
}

FQD.mainScreen.pocketOptions = function(){
	FQD.mainScreen.hideProductOptionsPopups();
	
	while(jQuery("#pocketOptionsContainer #optionsBar").children()[0] != undefined){
		jQuery("#pocketOptionsContainer #optionsBar").children()[0].remove();
	}
	
	var len = config.productDetails.pocketOptions.length;
	var folderPath = config.resourcePath + config.productIconPath;
	var options = [];
	var selectedPocketInx;
	var pocketId = config.pocketId;
	var slitId = config.slitId;
	
	for(var i = 0; i < len; i++){
		var optDiv = document.createElement("div");
		$(optDiv).addClass("optionBtn");
		
		var selectorData = FQD.products.getPocketData(config.productDetails.pocketOptions[i].pocketId);
		var iconDiv = document.createElement("div");
		iconDiv.className = "iconDiv";
		iconDiv.id = i;
		$(iconDiv).addClass("optionBtnImg");
		if(config.pocketId == config.productDetails.pocketOptions[i].pocketId){
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
			$(iconDiv).addClass("selected");
			selectedPocketInx = i;
		}else{
			$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
		}
		
		var iconLblDiv = document.createElement("div");
		$(iconLblDiv).addClass("optionBtnLbl");
		iconLblDiv.innerHTML = selectorData.displayName;
		
		$(optDiv).append(iconDiv);
		$(optDiv).append(iconLblDiv);	
		
		options.push({icon:iconDiv, data:selectorData});
		
		$(iconDiv).hover(
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
				},
				function(){
					if(!$(this).hasClass("selected"))
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
				}
		);
		
		$(iconDiv).click(
				function(){
					pocketId = parseInt(config.productDetails.pocketOptions[parseInt(this.id)].pocketId);
					$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
					$(this).addClass("selected");
					for(var j=0;j<options.length;j++){
						if(options[j].icon.id != this.id){
							$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
							$(options[j].icon).removeClass("selected");
						}
					}
					selectedPocketInx = parseInt(this.id);
					slitOptions(config.productDetails.pocketOptions[parseInt(this.id)].slits, true);
					showHideApplyButton();
				}
		);
		
		jQuery("#pocketOptionsContainer #optionsBar").append(optDiv);
		var btnBarWidth = (110 * len) + 10;
		jQuery("#pocketOptionsContainer #optionsBar").css('width', btnBarWidth+'px');
	}
	
	
	slitOptions = function(slitArr)
    {
		while(jQuery("#pocketOptionsContainer #optionsBar2").children()[0] != undefined){
			jQuery("#pocketOptionsContainer #optionsBar2").children()[0].remove();
		}
		
		len = slitArr.length;
		var options = [];
		var flag = false;
		for(var i = 0; i < len; i++)
		{
			var optDiv = document.createElement("div");
			$(optDiv).addClass("optionBtn");
			optDiv.style.width = "88px";
			optDiv.style.padding = "5px";
			
			var selectorData = FQD.products.getSlitsData(slitArr[i].id);
			
			var iconDiv = document.createElement("div");
			iconDiv.className = "iconDiv";
			iconDiv.id = i;
			$(iconDiv).addClass("optionBtnImg");
			
			if(slitArr[i].id == slitId){
				$(iconDiv).addClass("selected");
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOn+') center no-repeat');
				flag = true;
			}
			else
				$(iconDiv).css('background', 'url(' + folderPath + selectorData.iconOff+') center no-repeat');
			
			var iconLblDiv = document.createElement("div");
			$(iconLblDiv).addClass("optionBtnLbl");
			iconLblDiv.innerHTML = slitArr[i].displayName;
			
			$(optDiv).append(iconDiv);
			$(optDiv).append(iconLblDiv);	
			
			options.push({icon:iconDiv, data:selectorData});
			
			$(iconDiv).hover(
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn +') center no-repeat');
					},
					function(){
						if(!$(this).hasClass("selected"))
							$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOff +') center  no-repeat');
					}
			);
			
			$(iconDiv).click(
					function(){
						slitId = parseInt(slitArr[parseInt(this.id)].id);
						$(this).css('background', 'url(' + folderPath + options[parseInt(this.id)].data.iconOn+') center  no-repeat');
						$(this).addClass("selected");
						for(var j=0;j<options.length;j++){
							if(options[j].icon.id != this.id){
								$(options[j].icon).css('background', 'url(' + folderPath + options[j].data.iconOff+') center  no-repeat');
								$(options[j].icon).removeClass("selected");
							}
						}
						showHideApplyButton();
					}
			);
			
			jQuery("#pocketOptionsContainer #optionsBar2").append(optDiv);
		
			if((i+1) >= len){
				var clearDiv = document.createElement("div");
				clearDiv.style.clear = "both";
				jQuery("#pocketOptionsContainer #optionsBar2").append(clearDiv);
			}
			
			var btnBarWidth = (98 * len);
			jQuery("#pocketOptionsContainer #optionsBar2").css('width', btnBarWidth+'px');
		}
		
		if(!flag){
			$(options[0].icon).addClass("selected");
			$(options[0].icon).css('background', 'url(' + folderPath + options[0].data.iconOn+') center  no-repeat');
			slitId = parseInt(slitArr[0].id);
		}
    }
	
	showHideApplyButton = function()
    {
    	if(pocketId == config.pocketId && slitId == config.slitId)
    		$("#pocketSlitApplyBtn").hide();
    	else
    		$("#pocketSlitApplyBtn").show();
    }
	
	showHideApplyButton();
	slitOptions(config.productDetails.pocketOptions[selectedPocketInx].slits);
	
	$("#pocketSlitApplyBtn").click(
			function(){
				$("#pocketSlitApplyBtn").unbind();
				if(config.pocketId != pocketId){
					config.productDetails.printJob.options.pocket = config.pocketId = pocketId;
					config.productDetails.printJob.options.slit = config.slitId = slitId;
					config.productDetails.printProductBleedBean = config.productDetails.pocketOptions[selectedPocketInx].printProductBleed;
					closeEditPanel();
					FQD.canvas.resetCanvasAsPerWindowSize();
					FQD.events.updateRulerPosition();
				}
				else if(config.slitId != slitId){
					config.productDetails.printJob.options.slit = config.slitId = slitId;
					FQD.helper.applySlitOptions();
				}
			}
	);
	
	FQD.elements.pocketOptionsPopup.show();
	loadLocaleData();
}

FQD.mainScreen.applyFoldChange = function(foldId)
{
	var pageWidth = config.orgPrintProductSize.width;
	var pageHeight = config.orgPrintProductSize.height;
		
	// set original width/height
	config.productDetails.canvasWidth = pageWidth;
	config.productDetails.canvasHeight = pageHeight;
	
	switch(config.productSizeId)
	{
		case FQD.PrintProductType.IN_12_0x9_0:
		case FQD.PrintProductType.IN_11_0x8_5:
		case FQD.PrintProductType.IN_14_0x7_0:
			if(foldId == FQD.PrintProductType.VERTICAL_HALF_FOLD) 
			{
				config.productDetails.canvasWidth = pageHeight;
				config.productDetails.canvasHeight = pageWidth;
			}
			break;
		default:
			config.productDetails.canvasWidth = pageWidth;
			config.productDetails.canvasHeight = pageHeight;
			break;
	}
}






