FQD.initKeyboard = function() {
	document.onkeydown = function(event) {
		var OSName = "Unknown OS";
	    if (navigator.appVersion.indexOf("Win") != -1) OSName = "Windows";
	    else if (navigator.appVersion.indexOf("Mac") != -1) OSName = "MacOS";
	    else if (navigator.appVersion.indexOf("X11") != -1) OSName = "UNIX";
	    else if (navigator.appVersion.indexOf("Linux") != -1) OSName = "Linux";
	    
		var key = window.event ? window.event.keyCode : event.keyCode;
		if(key == 32){
			config.isSpaceKey = true;
		}
		config.key = key;
		if ((FQD.elements.divAdminPopup.css('display') == 'block'
				|| jQuery("textarea").is(":focus")
				|| jQuery("input").is(":focus")) && key!=9 ) {
			return;
		}
		switch (key) {
        
		case 76:
			if (event.ctrlKey
					&& FQD.customize.tools.enableDisableLockUnlockKeys.enable) {
				FQD.utility.lockObject();
			}
			if (!event.ctrlKey) {
				FQD.canvas.removeSelection();
				FQD.elements.anchorLine.trigger("click");
			}
			return true;
		case 79:
			FQD.canvas.removeSelection();
			FQD.elements.anchorEllipse.trigger("click");
			return true;
		case 82:
			FQD.canvas.removeSelection();
			FQD.elements.anchorRect.trigger("click");
			return true;
		case 68:
			FQD.canvas.removeSelection();
			FQD.elements.anchorRoundedRect.trigger("click");
			return true;
		case 90:
			if(OSName=="MacOS"){
				if (event.metaKey
						&& FQD.customize.tools.enableDisableUndoRedoKeys.enable
						&& FQD.undoManager.loader == false ) {
					FQD.undoManager.undo();
				}
			}
			else if(OSName=="Windows" || OSName == "Linux" || OSName == "UNIX"){
				if (event.ctrlKey
						&& FQD.customize.tools.enableDisableUndoRedoKeys.enable
						&& FQD.undoManager.loader == false ) {
					FQD.undoManager.undo();
				}
			}
			
			return true;
		case 89:
			if(OSName=="MacOS"){
				if (event.metaKey
						&& FQD.customize.tools.enableDisableUndoRedoKeys.enable
						&& FQD.undoManager.loader == false ) {
					FQD.undoManager.redo();
				}
			}
			else if(OSName=="Windows" || OSName == "Linux" || OSName == "UNIX"){
				if (event.ctrlKey
						&& FQD.customize.tools.enableDisableUndoRedoKeys.enable
						&& FQD.undoManager.loader == false ) {
					FQD.undoManager.redo();
				}
			}
			
			return true;
		case 88:
			if(OSName=="MacOS"){
				if (event.metaKey
						&& FQD.customize.tools.enableDisableCopyPasteKeys.enable) {
					FQD.utility.copy(false);
				}
			}
			else if(OSName=="Windows" || OSName == "Linux" || OSName == "UNIX"){
				if (event.ctrlKey
						&& FQD.customize.tools.enableDisableCopyPasteKeys.enable) {
					FQD.utility.copy(false);
				}
			}
			
			return true;
		case 67:
			if(OSName=="MacOS"){
				if (event.metaKey
						&& FQD.customize.tools.enableDisableCopyPasteKeys.enable) {
					FQD.utility.copy(true);
				}
			}
			else if(OSName=="Windows" || OSName == "Linux" || OSName == "UNIX"){
				if (event.ctrlKey
						&& FQD.customize.tools.enableDisableCopyPasteKeys.enable) {
					FQD.utility.copy(true);
				}
			}
			
			return true;
		case 86:
			if(OSName=="MacOS"){
				if (event.metaKey
						&& FQD.customize.tools.enableDisableCopyPasteKeys.enable) {
					FQD.utility.paste();
				}
			}
			else if(OSName=="Windows" || OSName == "Linux" || OSName == "UNIX"){
				if (event.ctrlKey
						&& FQD.customize.tools.enableDisableCopyPasteKeys.enable) {
					FQD.utility.paste();
				}
			}
			
			return true;
		case 46:
			if (FQD.customize.tools.enableDisableDelKeys.enable) {
				FQD.canvas.deleteObjects();
			}
			return true;
		case 65:
			if(OSName=="MacOS"){
				if (event.metaKey) {
					FQD.utility.selectAllObject();
				}
			}
			else if(OSName=="Windows" || OSName == "Linux" || OSName == "UNIX"){
				if (event.ctrlKey) {
					FQD.utility.selectAllObject();
				}
			}
			
			return true;
		case 16:
			return true;
		case 17:
			config.selectedActiveObjects = FQD.canvas.getActiveObjects();
			return true;
		case 37:
			if (FQD.customize.tools.enableDisableArrowKeys.enable
					&& config.sliderEvent == false) {
				var obj = FQD.canvas.getActiveObjects();
				if (obj && config.isSpaceKey == null) {
					obj.left = obj.left - 5;
					FQD.canvas.pages[config.activeCanvas].renderAll();
					FQD.message.objectOutsideSafeAndTrimZone();
				}
			}
			FQD.canvas.panning(-10,0);
			return true;
		case 38:
			if (FQD.customize.tools.enableDisableArrowKeys.enable
					&& config.sliderEvent == false) {
				var obj = FQD.canvas.getActiveObjects();
				if (obj && config.isSpaceKey == null) {
					obj.top = obj.top - 5;
					FQD.canvas.pages[config.activeCanvas].renderAll();
					FQD.message.objectOutsideSafeAndTrimZone();
				}
			}
			FQD.canvas.panning(0,-10);
			return true;
		case 39:
			if (FQD.customize.tools.enableDisableArrowKeys.enable
					&& config.sliderEvent == false) {
				var obj = FQD.canvas.getActiveObjects();
				if (obj && config.isSpaceKey == null) {
					obj.left = obj.left + 5;
					FQD.canvas.pages[config.activeCanvas].renderAll();
					FQD.message.objectOutsideSafeAndTrimZone();
				}
			}
			FQD.canvas.panning(10,0);
			return true;
		case 40:
			if (FQD.customize.tools.enableDisableArrowKeys.enable
					&& config.sliderEvent == false) {
				var obj = FQD.canvas.getActiveObjects();
				if (obj && config.isSpaceKey == null) {
					obj.top = obj.top + 5;
					FQD.canvas.pages[config.activeCanvas].renderAll();
					FQD.message.objectOutsideSafeAndTrimZone();
				}
			}
			FQD.canvas.panning(0,10);
			return true;
		case 27:
			config.autoSave = false;
			closeEditPanel();
			return true;
		case 107:
			if (event.altKey) {
				FQD.utility.zoomIn();
			}
			return true;
		case 187:
			if (event.altKey) {
				FQD.utility.zoomIn();
			}
			return true;
		case 109:
			if (event.altKey) {
				FQD.utility.zoomOut();
			}
			return true;
		case 189:
			if (event.altKey) {
				FQD.utility.zoomOut();
			}
			return true;
		case 80:
			if (event.shiftKey) {
				FQD.shapes.placeHolders("clipart");
			}
			return true;
		case 73:
			if (event.shiftKey) {
				FQD.shapes.placeHolders("image");
			}
			return true;
		case 84:
			if (event.shiftKey) {
				FQD.canvas.addNewText(true);
			}
			return true;
		case 32:
				config.isSpaceKey = true;
				FQD.events.toEvents(jQuery("#pan"));
				return true;
		case 9:
			if(FQD.canvas.getActiveObjects() && FQD.canvas.getActiveObjects().type=='textbox'){
				event.preventDefault();
				var id=FQD.canvas.getActiveObjects().id;
				var elm=$("#"+id);
				var nextId=$("#"+id).next().attr("id");
				if(!nextId){
					nextId=$("#new-text-field textarea:nth-child(1)").attr("id");
				}
				$("#"+nextId).trigger("focus");
			}
			return true;
		}
	}
	document.onkeyup = function(event) {
		if(event.keyCode == 32){
			config.isSpaceKey=null;
			FQD.events.toEvents(jQuery("#select"));
			for(i=0;i < FQD.canvas.pages.length;i++){
				FQD.canvas.pages[i].forEachObject(function(obj){
					if(!obj.isObjectLocked){
						obj.selectable=true;
						obj.hasControls=true;
					    obj.hasBorders=true;
					    obj.setShadow(null);
					}
					obj.evented=true;
					if(obj.alwaysNotselectable){
						obj.selectable=false;
						obj.hasControls=false;
						obj.hasBorders=false;
						obj.evented=false;
					}
					obj.setCoords();
				  });
				FQD.canvas.pages[i].defaultCursor="default";
				FQD.canvas.pages[i].selection=true;
				FQD.canvas.pages[i].renderAll();
			}
		}
		if(event.keyCode == 13 ){
			var zoomLavel= jQuery("#zoom-level");
			if(zoomLavel.is(":focus")){
				var z = parseInt(zoomLavel.val());
				if(z > 0 && z <= 500){
					z = z/(100*config.scaleMultiplier);
					FQD.canvas.setZoom(z);
				}else{
					zoomLavel.val((config.zoom*config.scaleMultiplier*100).toFixed(1));
				}
			}
		}
		config.key = null;
	}
}

