FQD.utility={
	init:function(){
		FQD.utility.getCID();
		FQD.utility.getProductDetail();
	},
	getParameter:function(name){
	    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
	    results = regex.exec(location.search);
	    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
 },
	getCID:function(){
		config.cid=FQD.utility.getParameter("cid");
		if(config.cid==""){
			FQD.utility.createConversation(standAlone);
		}
		
	},
	createConversation:function(){
		 var random=Math.random();
		 FQD.activity.resetKeepAliveTimer();
		 $.ajax({
			mimeType: 'text/plain; charset=x-user-defined',
			url : standAlone.serviceBaseUrlAction,
		    type: "GET",
		    async: false,
		    data : "QDAction=38&cid="+config.cid+"&ProductTypeId="+standAlone.printProductType+"&ProductSizeId="+standAlone.printProductSizeId+"&random="+random,
		    success: function(data, textStatus, jqXHR)
		    {
		    	config.cid=data.trim();
		    	
		    },
		    error: function (jqXHR, textStatus, errorThrown)
		    {
		    	console.log(textStatus);
		    },
		    xhrFields:{
		        withCredentials: true
		     }
		});
	},
	
	getProductDetail :function()
	{
		FQD.elements.divLoadingQd.show();
		FQD.elements.divLoaderContainer.show();
		var random=Math.random();	
		FQD.activity.resetKeepAliveTimer();
		FQD.request.getData({"QDAction":31,"random":random},"GET","json",FQD.helper.qdAction+"?cid="+config.cid,function success(data){
			if(!data){
				config.isApplicationError=true;
				customAlertBox("alert","Cancel","Ok",fqdApplicationStartError);
				window.location.href="/home.html";
				return;
			}
			
			config.productDetails = data;
			if(config.productDetails.description){
				config.productDetails.description=decodeURIComponent(atob(config.productDetails.description)).replace(/\+/g," ");
			}
			if(config.productDetails.productName){
				config.productDetails.productName=decodeURIComponent(atob(config.productDetails.productName)).replace(/\+/g," ");
			}
			if(config.productDetails.printJob && config.productDetails.printJob.printProductSizeId>=5000 && config.productDetails.printJob.printProductSizeId<10000 && config.productDetails.designCode > 0){
				config.isDesignForPreviewOnly=true;
				config.productDetails.adminOpenedSavedDesign=true;
			}
			config.productTypeId = parseInt(config.productDetails.productType);
			config.productSizeId = parseInt(config.productDetails.productSize);
			config.productOrientation = (parseInt(data.canvasHeight) > parseInt(data.canvasWidth))? FQD.ApplicationConstants.VERTICAL: ((parseInt(data.canvasHeight) < parseInt(data.canvasWidth))? FQD.ApplicationConstants.HORIZONTAL: FQD.ApplicationConstants.SQUARE);
			config.orgPrintProductSize = {width:config.productDetails.canvasWidth, height:config.productDetails.canvasHeight};
			config.autoCategorize=data.applicationSettings.autoCategorize;
			
			config.productShape = parseInt(data.shape);
			config.holeOptionId = config.productDetails.printJob.options.holePosition;
			config.perforationAndNumberingId = config.productDetails.printJob.options.perforationAndNumbering;
			config.numberingPositionId = config.productDetails.printJob.options.numberingPosition;
			config.orderItemRedesignMode = config.productDetails.orderItemRedesignMode;
			config.foldingId = config.productDetails.printJob.options.printProductFoldingId;
			config.pocketId = config.productDetails.printJob.options.pocket;
			config.slitId = config.productDetails.printJob.options.slit;
			config.logoURL= data.logoURL;
			
			FQD.mainScreen.updateMainScreen();
			config.isGeneric= data.isGeneric;
			config.pageLength=data.pageLength;
			config.pageNumber=[];
			
			config.IsUserLoggedIn=config.productDetails.isUserLoggedin;
			config.isUserAlreadyLoggedIn=config.productDetails.isUserLoggedin;
		    config.userId=config.productDetails.userId;
		    config.productDetails.savedDesignUserId = config.productDetails.savedDesignUserId == undefined? null: config.productDetails.savedDesignUserId;
		    
		    config.isPageRoundCorner = config.productDetails.printJob.options.roundCorners > 0? "true": "false";
		    
		    config.pageRoundCornerSize = config.productDetails.printJob.options.roundCorners;
		    config.firstTimePageRender=true;
		    
		    config.userSavedDesignName=data.userSavedDesignName;
		    
		    if(config.foldingId != undefined){
		    	FQD.mainScreen.applyFoldChange(config.foldingId);
		    }
		    
		    if(config.productDetails.window != undefined){
		    	config.productDetails.printJob.options.window = config.productDetails.window.id;
		    }
		    
		    if(config.productDetails.pageLength == 1){
		    	config.productDetails.color = "1";
		    }	
		    
			for(var i=0;i < data.pageLength;i++){
				config.pageNumber.push([]);
			}
			
			if(data.designCode){
				 config.productDetails.isProductSaved=true;
				 config.currentDesignId=data.designCode;
			}
			
			if(data.defaultTemplateCategory){
				config.defaultTemplateCategory=data.defaultTemplateCategory;
			}
			
			if(data.templateCategory){
				config.templateCategoryLength=data.templateCategory.length;
			}
			
			if(data.renderImageSize){
				config.renderImageSize=data.renderImageSize;
			}
			
			if(data.description){
				data.description=data.description.replace(/dblquotes/g,"\"").replace(/space/g," ");
			}
			if(config.productDetails.designCode >0){
				FQD.undoManager.undoItems=[];
				FQD.elements.anchorUndo.addClass("disabled");
			}
			
			if(config.productDetails.printJob.printJobSVG && config.productDetails.printJob.printJobSVG.svgPages){
				config.productDetails.printJob.printJobSVG.svgPages=[];
			}
			if(config.productDetails.printJob.printJobJson && config.productDetails.printJob.printJobJson.jsonPages){
				config.productDetails.printJob.printJobJson.jsonPages=[];
			}
			
			if(config.isGeneric){
				setTimeout(function(){ 
					//FQD.elements.divBgProperties.remove();
					jQuery("#select-pages,#corner-options").remove();
					if(config.pageNumber.length == 1){
						$('#tabs .last').hide();
					}
				}, 1000);
			}else{
				if((data.action!="3" && data.action!="4" && data.action!="6"  && data.action!="8" && data.action!="9")){
					FQD.dialog.loadPageSelectionDialog();
				}  
				
			}
			
			if(config.productDetails.pocketOptions != undefined && config.pocketId != undefined && config.pocketId > 0){
				for(var i = 0; i < config.productDetails.pocketOptions.length; i++){
					if(config.pocketId == config.productDetails.pocketOptions[i].pocketId){
						config.productDetails.printProductBleedBean = config.productDetails.pocketOptions[i].printProductBleed;
						break;
					}
				}
			}
			
			FQD.activity.resetKeepAliveTimer();
			
			FQD.imgLib.loadCategory("background-list");
			FQD.imgLib.loadCategory("clipart-list");
			FQD.imgLib.loadCategory("template-list");
			
			if(data.designCode || data.action=="1"||data.action=="3"||data.action=="4"||data.action=="6" ||data.action=="7" ||data.action=="8" ||data.action=="9"){
				if(data.action == "7" || data.action == "8"){
					if((config.productDetails.color == "1" || config.productDetails.color === undefined) && data.pageLength <= 1){
		    			config.pageNumber=[[]];
		    			config.pageLength = 1;
		    			$('#tabs .last').hide();
					}
					FQD.elements.divLoadingQd.hide();
					FQD.elements.divLoaderContainer.hide();
					FQD.canvas.init();
				}else{
					FQD.utility.loadPrintJob();
				}	
				return;
			}else{
				FQD.elements.divLoadingQd.hide();
				FQD.elements.divLoaderContainer.hide();
			}
		},function error(data){
			
			 config.isApplicationError=true;
		     var errorMsg='<div style="height:25px;background-color: rgba(158, 158, 158, 0.18);"><span style="margin-top:5px;float:left;margin-left: 5px;font-size: 15px;">';
		     	errorMsg +='<b>Start-up Error</b></span></div><div style="height:100px;background-color:#fff;">';
		        errorMsg +='<span style="margin-top: 24px;display: inline-block;font-size: 15px;text-align: center;width: 340px;margin-left: 29px;">';
		        errorMsg += fqdApplicationStartError+'</span><hr>';
		        errorMsg +='<button type="button" onclick="FQD.utility.goBack()" style="float:right;margin-right:5px;">OK</button></div></div>';
		        FQD.elements.applicationError.html(errorMsg);
		        FQD.elements.applicationError.show(); 
		        FQD.elements.divLoadingQd.hide();
			
		});
	},
	
	setBackgroundColorPicker : function(elm) {
		elm.spectrum({
	        color: "#fff",
			showInput: true,
	        className: "full-spectrum",
	        showPaletteOnly: true,
	        togglePaletteOnly: true,
	        showInitial: true,
	        showPalette: true,
	       // allowEmpty:true,
	        showSelectionPalette: true,
	        maxPaletteSize: 10,
	        preferredFormat: "hex",
	        togglePaletteMoreText: 'More',
	        togglePaletteLessText: 'Less',
	        palette: config.bgColorPalette,
	        move: function (color) {
				FQD.setCanvasAreaBackgroundColor(FQD.canvas.pages[config.activeCanvas],color.toRgbString());
				FQD.utility.setPickerColor(elm,color);
	        },
	        show: function (color) {
	        },
	        beforeShow: function (color) {
	        },
	        hide: function (color) {
	        	FQD.setCanvasAreaBackgroundColor(FQD.canvas.pages[config.activeCanvas],color.toRgbString());
	        	FQD.utility.setPickerColor(elm,color);
	        	FQD.undoManager.saveHistory(true);
	        },
	        change: function(color) {
	        	FQD.setCanvasAreaBackgroundColor(FQD.canvas.pages[config.activeCanvas],color.toRgbString());
	        },
	    });
	},
	
	setPickerColor:function(elm,color){
		if(elm.attr("id") == "colorB2"){
			FQD.elements.inputColorB.spectrum("set",color);
		}else{
			jQuery("#colorB2").spectrum("set",color);
		}
		jQuery("#bg-bucket").css("color",color.toHexString());
	},
	
	goBack: function(){
		config.applicationError=true;
		history.go(-1);
	},
	exitPreview:function(){
		   FQD.elements.applicationError.hide(); 
		   FQD.elements.divLoadingQd.hide();
		   FQD.elements.divOverlay.hide();
		   FQD.elements.divModelWindow.hide();
		   FQD.elements.divLoaderContainer.hide();
		   $("#exitPreview").click();
		   FQD.elements.applicationError.removeClass("previewError");
	},
	setStroke : function(){
		var stroke,canvas,objArr,objArrOld;
		FQD.elements.inpStrokeWidth.spinner({
            min: 0,
            max: 10,
            value:FQD.elements.inpStrokeWidth.val(),
            spin: function (event, ui) {
		    	if(FQD.shapes.mutlipleSelect){return;}
		    	stroke = Math.round(ui.value * (config.dpi/72));
		    	FQD.elements.inpStrokeWidth.val(stroke);
		    	if(event.originalEvent){
					FQD.shapes.setObjectProperties("strokeWidth", stroke);
				}
		    	if((stroke * config.scaleMultiplier) > 0){
					config.objectCachedProperties.Shapes.strokeWidth = stroke * config.scaleMultiplier;
				}
		    },
		    stop : function(){
		    	canvas=FQD.canvas.pages[config.activeCanvas];
		    	objArrOld=canvas.getObjects();
		    	objArr = objArrOld.filter(function(o){
		    		 if(o.active == true){
		    			 return true;
		    		 }
		    	})
		    	FQD.canvas.removeSelection();
		    	var objs=[];
				if (objArr.length>0){
					for(var i=0;i<objArr.length;i++){
						if(!objArr[i].alwaysNotselectable){
							objArr[i].set('active', true);
							objArr[i].setCoords();
							objs.push(objArr[i]);
						}
					}
					var group = new fabric.Group(objs);
					group.set('canvas', canvas);
					if(objs.length > 0 ){
						canvas.setActiveGroup(group.setCoords());
						canvas.renderAll();
						FQD.canvas.updateTransformControls();
					}
					
				}
		    }
		    
		});
	},
	setRoundedRadiusSlider : function() {
		FQD.elements.spanRoundedRadiusSlider.slider({
			range : "max", 
			min : 10, 
			max : 70, 
			step:1, 
			value:FQD.elements.inpRoundedRadius.val(),
			disabled : true,
			
			slide : function(event, ui){
			 if(jQuery("#rounded-radius-container").hasClass("active")){
				var points = ui.value;
				FQD.elements.inpRoundedRadius.val(Math.ceil(points));
			 }else{
				 event.preventDefault();
			  }
			 },
			
			change : function(event, ui){
				var radius = Math.round(ui.value);
				FQD.shapes.setObjectProperties("roundedRadius", radius);
				config.sliderEvent = true;
			}
		});
	},
	
	setFontFamily:function(id){
		var fontNameArr,fontValueArr;
		var random=Math.random();

		config.applicationSettings=config.productDetails.applicationSettings;
		fontNameArr=config.applicationSettings.fontName.split(",");
	    fontValueArr=config.applicationSettings.fontValue.split(",");
	    
	    fontNameArr.pop();
	    fontValueArr.pop();
	    
	    var fontLoadHTML = '';
	    var fontString='<div class="dropdown-item active"><span id="selected-font" style="font-family:gp_arial">Arial</span><i class="material-icons fr arrow-down">keyboard_arrow_down</i></div><div class="dropdown-item-list"><ul>'
		fontNameArr.forEach(function(item,index){
				         fontString +='<li style="font-family:'+ fontValueArr[index]+'">'+item+'</option>';
				         fontLoadHTML +='<p class="remFont" style="font-weight:bold;font-family:'+ fontValueArr[index]+'">'+item+'</p>';
				         fontLoadHTML +='<p class="remFont" style="font-style:italic;font-family:'+ fontValueArr[index]+'">'+item+'</p>';
				         fontLoadHTML +='<p class="remFont" style="font-weight:bold;font-style:italic;font-family:'+ fontValueArr[index]+'">'+item+'</p>';
		   });
	    	fontString +='</ul></div>'
		   id.html(fontString);
	       FQD.elements.fontLoader.html(fontLoadHTML);
			
		id.delegate("li","click",function(){
			var font=jQuery(this).index();
			FQD.shapes.setObjectProperties("fontFamily", fontValueArr[font]);
			id.find("span").html(fontNameArr[font]).css("font-family",fontValueArr[font]);
		});
		if(document.fonts){
			document.fonts.onloadingdone = function (fontFaceSetEvent) {
				if(FQD.canvas.pages[config.activeCanvas]){
					FQD.canvas.pages[config.activeCanvas].renderAll();
				}
				
			};
		}

		
	   },
	   setFontSize : function() {
			FQD.elements.spanFontSlider.slider({
				range : "max",
				min : 10,
				max : 800,
				step: 1,
				value : FQD.elements.inpFontSize.val(),
				disabled : true,
				slide : function(event, ui) {
				  if(jQuery("#sel-font-size").hasClass("active")){	
					points = (ui.value * 72) / parseInt(config.productDetails.dpi);
					FQD.elements.inpFontSize.val(points.toFixed(0));
					FQD.shapes.setObjectProperties("fontSize",ui.value);
					config.sliderEvent=true; //for keyboard keys
				  }else{
					  event.preventDefault();
				  }
					
				},
				change : function(event, ui) {
					FQD.shapes.setObjectProperties("fontSize",ui.value);
					config.sliderEvent=true; //for keyboard keys
				}
			});
			var prevValue=FQD.elements.inpFontSize.val();
			
			FQD.elements.inpFontSize.click(function(){
				prevValue=jQuery(this).val();
			});
			
			FQD.elements.inpFontSize.change(function () {
			    var value =jQuery(this).val();
			    if(isNaN(parseInt(value)) == false){
				  FQD.elements.spanFontSlider.slider("value", parseInt(value)*5);
				  FQD.elements.inpFontSize.val(parseInt(value));
			   }else{
				  FQD.elements.inpFontSize.val(prevValue);
			   }
			});
		},
		setLineHeight : function(){
			FQD.elements.spanAlignJustifySlider.slider({
				range : "min",
				step: 0.01,
				value :  FQD.canvas.getActiveObjects()? FQD.canvas.getActiveObjects().lineHeight: 1.16,
				disabled : true,
				slide : function(event,ui){
				 if(jQuery("#sel-line-height").hasClass("active")){
					jQuery('#align-justify-slider').slider('option', 'step', 0.5);
					valueToAddOrSub = jQuery('#align-justify-slider').slider('option', 'min');
					points = ui.value;
					FQD.elements.inpLineSpace.val(points);
					var lineSpaceNewValue = (points - parseFloat(valueToAddOrSub).toFixed(5)).toFixed(2);
					jQuery("#lineSpacenew").val(lineSpaceNewValue);
					FQD.shapes.setObjectProperties("lineHeight",points);
					config.sliderEvent=true;
				 }else{
					 event.preventDefault();
				 }
				}, 
				change: function(event,ui){
					var lineHeg = FQD.canvas.getActiveObjects()? FQD.canvas.getActiveObjects().lineHeight: ui.value;
					valueToAddOrSub = jQuery('#align-justify-slider').slider('option', 'min');
					FQD.shapes.setObjectProperties("lineHeight",ui.value);
					var lineSpaceNewValue = (lineHeg - parseFloat(valueToAddOrSub).toFixed(5)).toFixed(2);
					jQuery("#lineSpacenew").val(lineSpaceNewValue);
					FQD.elements.inpLineSpace.val(ui.value);
					config.sliderEvent=true; //for keyboard keys
			  }
			});
			var prevValue=FQD.elements.inpLineSpace.val();
			FQD.elements.inpLineSpace.click(function(){
				prevValue=jQuery(this).val();
			});
			FQD.elements.inpLineSpace.change(function () {
				valueToAddOrSub = (jQuery('#align-justify-slider').slider('option', 'min')).toFixed(2);
			    var value =jQuery(this).val();
			    if(value < 0){
			    	value = 0;
			    }else if(value > parseFloat((jQuery('#align-justify-slider').slider('option', 'max')).toFixed(2))){
			    	value = parseFloat(jQuery('#align-justify-slider').slider('option', 'max').toFixed(2) - valueToAddOrSub);
			    }
			    if(isNaN(parseFloat(value)) == false){
			          jQuery('#align-justify-slider').slider('option', 'step', 0.01);
			    	  FQD.elements.spanAlignJustifySlider.slider("value", parseFloat(value) + parseFloat(valueToAddOrSub));
					  FQD.elements.inpLineSpace.val(parseFloat(value) + parseFloat(valueToAddOrSub));
					  jQuery("#lineSpacenew").val(parseFloat(value));
			   }else{
				  FQD.elements.inpLineSpace.val(prevValue);
			   }
			});
			FQD.elements.inpLineSpacenew.change(function () {
				var value =jQuery(this).val();
				FQD.elements.inpLineSpace.val(value).change();
			});
		},
	setOpacity : function() {
		FQD.elements.spanOpacitySlider.slider({
			range : "max",
			min : 0,
			max : 100,
			value : FQD.elements.inpOpacity.val(),
			disabled : true,
			slide : function(event, ui) {
			 if(jQuery("#opacity-properties").hasClass("active")){
			    FQD.elements.inpOpacity.val(parseInt(ui.value));
			 }else{
				  event.preventDefault();
			 }
			},
			change : function(event, ui) {
				if(FQD.shapes.mutlipleSelect)
					return;			
				FQD.shapes.setObjectProperties("opacity",ui.value*0.01);
				config.sliderEvent=true;
			}
		});
	},
	
	setElementColorPicker:function(){
		FQD.elements.inputColorP.spectrum({
	        color: config.fillColor,
			showInput: true,
	        className: "full-spectrum",
	        showPaletteOnly: true,
	        togglePaletteOnly: true,
	        showInitial: true,
	        showPalette: true,
	        showSelectionPalette: true,
	        maxPaletteSize: 10,
	        preferredFormat: "hex",
	        togglePaletteMoreText: 'More',
	        togglePaletteLessText: 'Less',
	        palette: config.elementColorPalette,
	        move: function (color) {
	        	FQD.shapes.setObjectProperties("fill",color.toRgbString());
	        },
	        show: function (color) {
	        },
	        beforeShow: function (color) {
	        },
	        hide: function (color) {
	        	FQD.shapes.setObjectProperties("fill",color.toRgbString());
	        	FQD.undoManager.saveHistory(true);
	        },
	        change: function(color) {
	        	FQD.shapes.setObjectProperties("fill",color.toRgbString());
	        },
	    });
		FQD.elements.inputTextBgColorP.spectrum({
	        color: config.fillColor,
			showInput: true,
	        className: "full-spectrum",
	        showPaletteOnly: true,
	        togglePaletteOnly: true,
	        showInitial: true,
	        showPalette: true,
	        showSelectionPalette: true,
	        maxPaletteSize: 10,
	        preferredFormat: "hex",
	        togglePaletteMoreText: 'More',
	        togglePaletteLessText: 'Less',
	        palette: config.elementColorPalette,
	        move: function (color) {
	        	FQD.shapes.setObjectProperties("textBgColor",color.toRgbString());
	        },
	        show: function (color) {
	        },
	        beforeShow: function (color) {
	        },
	        hide: function (color) {
	        	FQD.shapes.setObjectProperties("textBgColor",color.toRgbString());
	        	FQD.undoManager.saveHistory(true);
	        },
	        change: function(color) {
	        	FQD.shapes.setObjectProperties("textBgColor",color.toRgbString());
	        },
	    });
		


		FQD.elements.inputStrokeP.spectrum({
			color: config.strokeColor,
			showInput: true,
	        className: "full-spectrum",
	        showPaletteOnly: true,
	        togglePaletteOnly: true,
	        showInitial: true,
	        showPalette: true,
	        showSelectionPalette: true,
	        maxPaletteSize: 10,
	        preferredFormat: "hex",
	        togglePaletteMoreText: 'More',
	        togglePaletteLessText: 'Less',
	        palette: config.elementColorPalette,
	        move: function (color) {
	        	$('#stroke-color .sp-preview-inner').css('border-color',color.toRgbString());
	        	FQD.shapes.setObjectProperties("strokeColor",color.toRgbString());
	        },
	        show: function (color) {
	        },
	        beforeShow: function (color) {
	        
	        },
	        hide: function (color) {
	        	FQD.shapes.setObjectProperties("strokeColor",color.toRgbString());
	        	FQD.undoManager.saveHistory(true);
	        },
	        change: function(color) {
	        	FQD.shapes.setObjectProperties("strokeColor",color.toRgbString());
	        },
	    });
	    
	    jQuery("#stroke-color .sp-replacer").append("<div class='over-line'></div>");


	},
	
	alignToOptionChnage:function(){
		FQD.canvas.setSelectedItemHighlight();
	},
	
	setObjectAlign:function(element){
		
		if(jQuery(element).hasClass("disabled") && !config.previewWatermarkTextObject){
			return;
		}
		
		
		jQuery(element).parent().find("a").removeClass("activeAlign");
		jQuery(element).addClass("activeAlign");
		
		var align = jQuery(element).attr("id"),
		    obj = FQD.canvas.getActiveObjects(),
			cw = config.canvasWidth,
			ch = config.canvasHeight,
			withRespectTo = jQuery("#selObjAlign").val(),
			alignToItem = false,
			oCoords = {},
			shadowObj = FQD.shapes.shadowObject;
		
		var alignZoneDistance = {};
		var zoneGap = {};
		var maxGroupSize = {};
		
		if(!obj){
			obj=config.previewWatermarkTextObject;
		}
		
		if(obj && (obj.isObjectLocked!="true")){
			angle = obj.angle;
			
			if(angle != 0){
				 var z=FQD.canvas.pages[config.activeCanvas].getZoom();
				  	   FQD.canvas.pages[config.activeCanvas].setZoom(1);// reset canvas to get data in 100% zoom
			} 
			
				switch(withRespectTo)
				{
					
					case "alignTo":
							return;
					    break;
					
				    case "Safe":
				    	zoneGap = FQD.canvas.getCanvasZonesGap(0, true);
				    	FQD.canvas.getSafeZone();
						alignZoneDistance.left = roundTo(zoneGap.safeZone.safeLeft, 2);
						alignZoneDistance.bottom = roundTo(zoneGap.safeZone.safeBottom, 2);
						alignZoneDistance.right = roundTo(zoneGap.safeZone.safeRight, 2);
						alignZoneDistance.top = roundTo(zoneGap.safeZone.safeTop, 2);
						break;
					case "Trim":
						zoneGap = FQD.canvas.getCanvasZonesGap(0);
						alignZoneDistance.left = roundTo(zoneGap.bleedZone.bleedLeft, 2);
						alignZoneDistance.bottom = roundTo(zoneGap.bleedZone.bleedBottom, 2);
						alignZoneDistance.right = roundTo(zoneGap.bleedZone.bleedRight, 2);
						alignZoneDistance.top = roundTo(zoneGap.bleedZone.bleedTop, 2);
				    break;
					case "Bleed":
						alignZoneDistance = {left:0, bottom:0, right:0, top:0};
				    break;
					case "alignToItem":
						alignToItem = true;
						if(shadowObj){
							if(shadowObj.type == "circle"){
								var elpRect = FQD.shapes.getEllipseBoundingBox(shadowObj);
								var strokeW = shadowObj.strokeWidth / 2;
								alignZoneDistance.left = roundTo((elpRect.x-strokeW), 2);
								alignZoneDistance.bottom = roundTo((elpRect.y+elpRect.height+strokeW), 2);
								alignZoneDistance.right = roundTo((elpRect.x+elpRect.width+strokeW), 2);
								alignZoneDistance.top = roundTo((elpRect.y-strokeW), 2);
							}else{
								xArray = [shadowObj.oCoords.tl.x, shadowObj.oCoords.tr.x, shadowObj.oCoords.bl.x, shadowObj.oCoords.br.x],
								yArray = [shadowObj.oCoords.tl.y, shadowObj.oCoords.tr.y, shadowObj.oCoords.bl.y, shadowObj.oCoords.br.y],
								alignZoneDistance.left = roundTo(xArray.min(), 2);
								alignZoneDistance.bottom = roundTo(yArray.max(), 2);
								alignZoneDistance.right = roundTo(xArray.max(), 2);
								alignZoneDistance.top = roundTo(yArray.min(), 2);
							}
						}
						break;
				}
    		     switch(align) {
    				case "align_left":
    					if(alignToItem){
    						if(obj._objects){
    					    	var i=0,len=obj._objects.length;
    					    	if(shadowObj){
    					    		for(i; i < len; i++){
	    					    		if(obj._objects[i].getShadow() == null)
	    					    		{
	    					    			if(obj._objects[i].type == "circle"){
	    		    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
	    		    							obj._objects[i].setLeft(alignZoneDistance.left + (elpRect.width/2) + (obj._objects[i].strokeWidth/2)); 
	    		    						}else{
	    		    							if(obj._objects[i].angle == 0){
	    		    								obj._objects[i].setLeft(alignZoneDistance.left); 
	    		    	   						}else{
	    		    	   							minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
	    		    	   							topLeft = obj._objects[i].oCoords.tl.x;
	    		    	   							obj._objects[i].setLeft(alignZoneDistance.left + (topLeft-minX));
	    		    	   						}
	    		    						}
	    					    		}
    					    		}
    					    	}
    				    	}
    					}
    					else{
    						if(obj._objects)
    						{
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							maxGroupSize = FQD.shapes.getMaxSizeFromActiveGroup();
    							for(var i = 0; i < obj._objects.length; i++)
    					    	{
					    			if(obj._objects[i].type == "circle"){
		    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
		    							obj._objects[i].setLeft((0-(maxGroupSize.width/2)) + (elpRect.width/2));  
		    						}else{
		    							if(obj._objects[i].angle == 0){
		    								obj._objects[i].setLeft(0-(maxGroupSize.width/2)); 
		    	   						}else{
		    	   							minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
		    	   							topLeft = obj._objects[i].oCoords.tl.x;
		    	   							obj._objects[i].setLeft(0-(maxGroupSize.width/2) + (topLeft-minX));
		    	   						}
		    						}
					    		}
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							obj.setLeft(alignZoneDistance.left + config.canvasOrigin.x0 - maxGroupSize.leftOffset); 
    				    	}
    						else if(obj.type == "circle"){
    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj);
    							obj.setLeft(alignZoneDistance.left + config.canvasOrigin.x0 + (elpRect.width/2) + (obj.strokeWidth/2)); 
    						}else{
    							if(angle == 0){
       							 	obj.setLeft(0 + alignZoneDistance.left + config.canvasOrigin.x0); 
    	   						}else{
    	   							minX = Math.min(obj.oCoords.tl.x, obj.oCoords.tr.x, obj.oCoords.bl.x, obj.oCoords.br.x);
    	   							topLeft = obj.oCoords.tl.x;
    	   							obj.setLeft(alignZoneDistance.left + config.canvasOrigin.x0 + (topLeft - minX)); 
    	   						}
    						}
    					}
    						
    			    break;
    				case "align_center":
    					if(alignToItem){
    						if(obj._objects){
    					    	var i=0,len=obj._objects.length;
    					    	if(shadowObj){
    					    		for(i; i<len; i++){
	    					    		if(obj._objects[i].getShadow() == null){
	    					    			var hCenter = alignZoneDistance.left + ((alignZoneDistance.right - alignZoneDistance.left) / 2);
	    			    					if(obj._objects[i].type == "circle"){
	    			    						obj._objects[i].setLeft(hCenter);
	    				   					}else{
	    				   						var tempAngle = obj._objects[i].angle;
	    				   						obj._objects[i].setAngle(0);
	    				   						obj._objects[i].setLeft(hCenter - obj._objects[i].getWidth()/2);
	    				   						obj._objects[i].setAngle(tempAngle);
	    				   					}
	    					    		}
    					    		}
    					    	}
    						}
    					}
    					else{
    						if(obj._objects)
    						{
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							for(var i = 0; i < obj._objects.length; i++)
    					    	{
    								if(obj._objects[i].type == "circle"){
			    						obj._objects[i].setLeft(0);
				   					}else{
				   						var tempAngle = obj._objects[i].angle;
				   						obj._objects[i].setAngle(0);
				   						obj._objects[i].setLeft(0 - obj._objects[i].getWidth()/2);
				   						obj._objects[i].setAngle(tempAngle);
				   					}
					    		}
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							obj.setLeft((cw/2) - (obj.getWidth()/2) + config.canvasOrigin.x0);
    				    	}
    						else{
    							obj.setAngle(0);
    	    					if(obj.type == "circle"){
    	    						obj.setLeft(cw/2 + config.canvasOrigin.x0);
    	    					}else{
    	    						obj.setLeft((cw/2) - (obj.getWidth()/2) + config.canvasOrigin.x0);
    	    					}
    	   						obj.setAngle(angle);
    						}
    					}
   					break;
    				case "align_middle":
    					if(alignToItem){
    						if(obj._objects){
    					    	var i=0,len=obj._objects.length;
    					    	if(shadowObj){
    					    		for(i; i<len; i++){
    					    			if(obj._objects[i].getShadow() == null)
    					    			{	
    					    				var vCenter = alignZoneDistance.top + ((alignZoneDistance.bottom - alignZoneDistance.top) / 2);
	    			    					if(obj._objects[i].type == "circle"){
	    			    						obj._objects[i].setTop(vCenter);
	    				   					}else{
	    				   						var tempAngle = obj._objects[i].angle;
	    				   						obj._objects[i].setAngle(0);
	    				   						obj._objects[i].setTop(vCenter - obj._objects[i].getHeight()/2);
	    				   						obj._objects[i].setAngle(tempAngle);
	    				   					}
    					    			}
    					    		}
    					    	}
    						}
    					}
    					else{
    						if(obj._objects)
    						{
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							for(var i = 0; i < obj._objects.length; i++)
    					    	{
    								if(obj._objects[i].type == "circle"){
			    						obj._objects[i].setTop(0);
				   					}else{
				   						var tempAngle = obj._objects[i].angle;
				   						obj._objects[i].setAngle(0);
				   						obj._objects[i].setTop(0 - obj._objects[i].getHeight()/2);
				   						obj._objects[i].setAngle(tempAngle);
				   					}
					    		}
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							obj.setTop((ch/2) - (obj.getHeight()/2) + config.canvasOrigin.y0);
    				    	}
    						else{
    							obj.setAngle(0);
      						  	if(obj.type == "circle"){
      						  		obj.setTop(ch/2 + config.canvasOrigin.y0);
      						  	}else{
      						  		obj.setTop((ch/2) - (obj.getHeight()/2) + config.canvasOrigin.y0);
      						  	}
      						  	obj.setAngle(angle);
    						}
    					}
      				break;
    				case "align_right":
    					if(alignToItem){
    						if(obj._objects){
    					    	var i=0,len=obj._objects.length;
    					    	if(shadowObj){
    					    		for(i; i<len; i++){
	    					    		if(obj._objects[i].getShadow() == null){
	    	    					    	if(obj._objects[i].type == "circle"){
	    					    				elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
	    					    				obj._objects[i].setLeft(alignZoneDistance.right - (elpRect.width/2) - (obj._objects[i].strokeWidth/2)); 
	    		    						}else{
	    		    							if(obj._objects[i].angle == 0)
	    		    								obj._objects[i].setLeft(alignZoneDistance.right - obj._objects[i].getWidth());
	    		    	    					 else{
	    		    	    						 minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
	    		    	    						 bottomRight = obj._objects[i].oCoords.br.x;
	    		    	    						 obj._objects[i].setLeft(alignZoneDistance.right - (bottomRight - minX));
	    		    	    					 }
	    		    						}
	    					    		}
    					    		}
    					    	}
    						}
    					}
    					else{
    						if(obj._objects)
    						{
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							maxGroupSize = FQD.shapes.getMaxSizeFromActiveGroup();
    							for(var i = 0; i < obj._objects.length; i++)
    					    	{
					    			if(obj._objects[i].type == "circle"){
		    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
		    							obj._objects[i].setLeft((maxGroupSize.width/2)-(elpRect.width/2));  
		    						}else{
		    							if(obj._objects[i].angle == 0){
		    								obj._objects[i].setLeft((maxGroupSize.width/2) - obj._objects[i].getWidth()); 
		    	   						}else{
		    	   							minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
		    	   							bottomRight = obj._objects[i].oCoords.br.x;
		    	   							obj._objects[i].setLeft((maxGroupSize.width/2) - (bottomRight - minX));
		    	   						}
		    						}
					    		}
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							obj.setLeft(config.canvasOrigin.x0 + (cw - alignZoneDistance.right - obj.getWidth() + maxGroupSize.leftOffset)); 
    				    	}
    						else if(obj.type == "circle"){
    							elpRect = FQD.shapes.getEllipseBoundingBox(obj);
    							obj.setLeft(config.canvasOrigin.x0 + cw - alignZoneDistance.left - (elpRect.width/2) - (obj.strokeWidth/2)); 
    						}else{
    							if(angle == 0){
    	    						obj.setLeft((cw - obj.getWidth()) - alignZoneDistance.right + config.canvasOrigin.x0);
    	    					 }else{
    	    						 minX = Math.min(obj._objects[i].oCoords.tl.x, obj._objects[i].oCoords.tr.x, obj._objects[i].oCoords.bl.x, obj._objects[i].oCoords.br.x);
    	    						 bottomRight = obj._objects[i].oCoords.br.x;
    	    						 obj.setLeft((cw + minX - bottomRight) - alignZoneDistance.right + config.canvasOrigin.x0);
    	    					 }
    						}
    					}
   					 break;
    				case "align_top":
    					if(alignToItem){
    						if(obj._objects){
    					    	var i=0,len=obj._objects.length;
    					    	if(shadowObj){
    					    		for(i; i<len; i++){
	    					    		if(obj._objects[i].getShadow() == null){
	    	    					    	if(obj._objects[i].type == "circle"){
	    					    				var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
	    					    				obj._objects[i].setTop(alignZoneDistance.top + (elpRect.height/2) + (obj._objects[i].strokeWidth/2)); 
	    		    						}else{
	    		    							if(obj._objects[i].angle == 0)
	    		    								obj._objects[i].setTop(alignZoneDistance.top);
	    		    	    					 else{
	    		    	    						 minY = Math.min(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
	    		    	    						 leftTop = obj._objects[i].oCoords.tl.y;
	    		    	    						 obj._objects[i].setTop(alignZoneDistance.top + (leftTop - minY));
	    		    	    					 }
	    		    						}
	    					    		}
    					    		}
    					    	}
    						}
    					}
    					else{
    						if(obj._objects)
    						{
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							maxGroupSize = FQD.shapes.getMaxSizeFromActiveGroup();
    							for(var i = 0; i < obj._objects.length; i++)
    					    	{
					    			if(obj._objects[i].type == "circle"){
		    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
		    							obj._objects[i].setTop((0-(maxGroupSize.height/2)) + (elpRect.height/2));  
		    						}else{
		    							if(obj._objects[i].angle == 0){
		    								obj._objects[i].setTop(0-(maxGroupSize.height/2)); 
		    	   						}else{
		    	   							minY = Math.min(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
		    	    						leftTop = obj._objects[i].oCoords.tl.y;
		    	   							obj._objects[i].setTop(0-(maxGroupSize.height/2) + (leftTop - minY));
		    	   						}
		    						}
					    		}
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							obj.setTop(config.canvasOrigin.y0 + alignZoneDistance.top - maxGroupSize.topOffset); 
    				    	}
    						else if(obj.type == "circle"){
    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj);
    							obj.setTop(alignZoneDistance.top + config.canvasOrigin.y0 + (elpRect.height/2) + (obj.strokeWidth/2)); 
    						}else{
    							if(angle == 0){
    	    						obj.setTop(0 + alignZoneDistance.top + config.canvasOrigin.y0);
    	    					}else{
    	    						minY = Math.min(obj.oCoords.tl.y, obj.oCoords.tr.y, obj.oCoords.bl.y, obj.oCoords.br.y);
    	    						leftTop = obj.oCoords.tl.y;
    	    						obj.setTop((leftTop-minY) + alignZoneDistance.top + config.canvasOrigin.y0);
    	    					}
    						}
    					}
   					 break;
    				case "align_bottom":
    					if(alignToItem){
    						if(obj._objects){
    					    	var i=0,len=obj._objects.length;
    					    	if(shadowObj){
    					    		for(i; i<len; i++){
	    					    		if(obj._objects[i].getShadow() == null){
	    	    					    	if(obj._objects[i].type == "circle"){
	    					    				var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
	    					    				obj._objects[i].setTop(alignZoneDistance.bottom - (elpRect.height/2) - (obj._objects[i].strokeWidth/2)); 
	    		    						}else{
	    		    							if(obj._objects[i].angle == 0)
	    		    								obj._objects[i].setTop(alignZoneDistance.bottom - obj._objects[i].getHeight());
	    		    	    					 else{
	    		    	    						 minY = Math.min(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
	    		    	    						 rightBottom = obj._objects[i].oCoords.br.y;
	    		    	    						 obj._objects[i].setTop(alignZoneDistance.bottom - (rightBottom - minY));
	    		    	    					 }
	    		    						}
	    					    		}
    					    		}
    					    	}
    						}
    					}
    					else{
    						if(obj._objects)
    						{
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							maxGroupSize = FQD.shapes.getMaxSizeFromActiveGroup();
    							for(var i = 0; i < obj._objects.length; i++)
    					    	{
					    			if(obj._objects[i].type == "circle"){
		    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj._objects[i]);
		    							obj._objects[i].setTop((maxGroupSize.height/2) - (elpRect.height/2));  
		    						}else{
		    							if(obj._objects[i].angle == 0){
		    								obj._objects[i].setTop((maxGroupSize.height/2) - obj._objects[i].getHeight()); 
		    	   						}else{
		    	   							minY = Math.min(obj._objects[i].oCoords.tl.y, obj._objects[i].oCoords.tr.y, obj._objects[i].oCoords.bl.y, obj._objects[i].oCoords.br.y);
		    	    						rightBottom = obj._objects[i].oCoords.br.y;
		    	   							obj._objects[i].setTop((maxGroupSize.height/2) - (rightBottom - minY));
		    	   						}
		    						}
					    		}
    							FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
    							obj.setTop(config.canvasOrigin.y0 + (ch - alignZoneDistance.bottom - obj.getHeight() + maxGroupSize.topOffset)); 
    				    	}
    						else if(obj.type == "circle"){
    							var elpRect = FQD.shapes.getEllipseBoundingBox(obj);
    							obj.setTop(config.canvasOrigin.y0 + ch - alignZoneDistance.bottom - (elpRect.height/2) - (obj.strokeWidth/2)); 
    						}else{
    							if(angle == 0){
    	    						obj.setTop((ch - obj.getHeight()) - alignZoneDistance.bottom + config.canvasOrigin.y0);
    	    					}else{
    	    						minY = Math.min(obj.oCoords.tl.y, obj.oCoords.tr.y, obj.oCoords.bl.y, obj.oCoords.br.y);
   	    						 	rightBottom = obj.oCoords.br.y;
    	    						obj.setTop((ch + minY - rightBottom) - alignZoneDistance.bottom + config.canvasOrigin.y0);
    	    					}
    						}
    					}
   					 break;
    			}
    		     obj.setCoords();
    		     if(angle != 0){
    		    	 FQD.canvas.pages[config.activeCanvas].setZoom(z); // zoom canvas as per previous value again
    		    }
    		 }
		 
		 var curShadowElement;
		 if(FQD.shapes.shadowObject && alignToItem){
			 curShadowElement = FQD.shapes.shadowObject; 
		 }
		 
		 if(FQD.canvas.pages[config.activeCanvas].getActiveGroup()){
			FQD.canvas.pages[config.activeCanvas].setActiveGroup(FQD.canvas.pages[config.activeCanvas].getActiveGroup().addWithUpdate()).renderAll();
			 var newObj=FQD.canvas.getActiveObjects();
			 	 newObj.set({left:FQD.canvas.pages[config.activeCanvas].getActiveGroup().getLeft(),top:FQD.canvas.pages[config.activeCanvas].getActiveGroup().getTop()});
			 	 newObj.setCoords();
			 	 
		 	 if(curShadowElement && alignToItem){
				FQD.shapes.addAndRemoveShadow(curShadowElement); 
			}
		 } 
		
		 FQD.canvas.pages[config.activeCanvas].renderAll();
		 FQD.undoManager.saveHistory(true);
		 FQD.utility.objectMovingCallback();
	},
	copy:function(cut){
		if(FQD.canvas.getActiveObjects() && FQD.canvas.getActiveObjects().isEditing){
			return;
		}
		var isUserUploaded=false;
		var canvas=FQD.canvas.pages[config.activeCanvas];
		config.copiedObjects = [];
	    var activeObject = canvas.getActiveObject(),
	      activeGroup = canvas.getActiveGroup();
			
	    if(activeGroup) {
	      var objectsInGroup = activeGroup.getObjects();
	      canvas.discardActiveGroup();
	      objectsInGroup.forEach(function(object) {
	    	  config.copiedObjects.push(object);
		      if(!cut){
		    		canvas.remove(object);
			    }
		      if(object.type == "image"){
		    	  if(object.userUploaded == "true"){
		    		  isUserUploaded=true;
		    	  }
	    			jQuery("#"+object.id).remove();
	    		}
	      });
	    } else if (activeObject) { 
	    	config.copiedObjects.push(activeObject);
	    	if(!cut){
	    		if(activeObject.type == "image"){
			    	  if(activeObject.userUploaded == "true"){
			    		  isUserUploaded=true;
			    	  }
		    			jQuery("#"+activeObject.id).remove();
		    		}
	    		canvas.remove(activeObject);
	    		FQD.undoManager.saveHistory(true);
		    }
	    }
	    if(!cut){
    		FQD.undoManager.saveHistory(true);
    		FQD.canvas.addNewText();
    		FQD.shapes.showEditProperties();
    		if(isUserUploaded){
  			  FQD.utility.unloadStoreDesign();
  			} 
	    }
	    FQD.elements.divContextMenu.hide();
	},

	paste:function(pageNum){
		if(FQD.canvas.getActiveObjects() && FQD.canvas.getActiveObjects().isEditing){
			return;
		}
		var isUserUploaded=false;
		var copiedObjects=config.copiedObjects;
		    	copiedObjects.forEach(function(obj){
		    		obj.clone(function(clone) {
		    			clone.set('id',FQD.canvas.setTextBoxId());
	        			FQD.utility.pasteOne(obj,clone,pageNum);
		    		},config.newProperties);
		    		if(obj.type == "image" && obj.userUploaded == "true"){
		    			isUserUploaded = true;
		    		}
		    	});
		setTimeout(function(){ 
			FQD.undoManager.saveHistory(true);
			FQD.allOverlayOnTop();
			if(isUserUploaded){
			  FQD.utility.unloadStoreDesign();
			} 
		}, 100);
	    FQD.elements.divContextMenu.hide();
	},
	copyToFront:function(){
		FQD.utility.copy(true);
		FQD.utility.paste(1);
		
	},
	copyToBack:function(){
		FQD.utility.copy(true);
		FQD.utility.paste(2);
		
	},
	duplicate:function(){
		FQD.utility.copy(true);
		FQD.utility.paste();
		FQD.undoManager.saveHistory(true);
	    FQD.elements.divContextMenu.hide();
		
		
	},
	swap:function(num,elm){
        var activeObjectSrc=FQD.canvas.getActiveObjects().getSrc();
        var selectedObj=FQD.canvas.pages[config.activeCanvas].getActiveObject();
        if(!num){
        	var obj=config.mouseoverObj;
        	if(obj){
        		if(selectedObj && obj.type == "image"){
        			
			    	config.placerHolderObject.elm=obj;
			    	config.placerHolderObject.left=obj.left;
			    	config.placerHolderObject.top=obj.top;
			    	config.placerHolderObject.angle=obj.angle;
			    	
        			if(obj.imgPlaceholder || obj.userUploaded){
    		    		config.placerHolderObject.userUploaded="true";
    		    		num=1;
    		    		elm=FQD.elements.uploadImgIcon;

            		}
            		if(obj.clipartPlaceholder || obj.isClipArt=="true"){
    		    		num=2;
    		    		elm=FQD.elements.clipartIcon;
            		}
        		}
        	
        	}
        }

        if(activeObjectSrc.indexOf("image.svg")!= -1 || activeObjectSrc.indexOf("clipart.svg")!= -1 ){
        	 if(num==1){
			    	if(!FQD.elements.uploadImgIcon.hasClass("active")){
			    		openEditorPanel(elm);
			    	}
			    }else{
			    	if(!FQD.elements.clipartIcon.hasClass("active")){
			    		openEditorPanel(elm);
			    	}
		   	   
               }
        	 return;
        }
		FQD.elements.swapImageWarning.dialog({
			width : 400,
			height :180,
			modal : true,
			dialogClass: "swapImageWarningPopup",
			resizable: false,
			buttons : {
				"Yes" : function() {
					    jQuery(this).dialog("close");
					    if(num==1){
					    	if(!FQD.elements.uploadImgIcon.hasClass("active")){
					    		openEditorPanel(elm);
					    	}
					    }else{
					    	if(!FQD.elements.clipartIcon.hasClass("active")){
					    		openEditorPanel(elm);
					    	}
					    }
					 },
				"No" : function() {
					jQuery(this).dialog("close");
				}
			}
		});
		
	},
	
	
	pasteOne:function(copiedObj,clone,pageNum) {
		var canvas;
		if(pageNum){
			if(pageNum==1){
				canvas=FQD.canvas.pages[0];
			}else{
				canvas=FQD.canvas.pages[1];
			}
			
		}else{
			canvas=FQD.canvas.pages[config.activeCanvas];
		}

		  	if(copiedObj && copiedObj.imgPlaceholder){
		  		 clone._element=copiedObj._element;
				 clone.imgPlaceholder=copiedObj.imgPlaceholder;
				 clone.crossOrigin = "anonymous";  // This enables CORS
				 clone.id = "placeHolders";
			}
		  	if(copiedObj && copiedObj.clipartPlaceholder){
		  		 clone._element=copiedObj._element;
				 clone.clipartPlaceholder=copiedObj.clipartPlaceholder;
				 clone.crossOrigin = "anonymous";  // This enables CORS
				 clone.id = "placeHolders";
			}
		  	if(clone.type == "textbox"){
		  		if(copiedObj.isHidden){
		  			clone.isHidden=copiedObj.isHidden;
		  		}
		  		if(copiedObj.initialOpacity){
		  			clone.initialOpacity=copiedObj.initialOpacity;
		  		}
		  		if(copiedObj.placeHolderTextValue){
		  			clone.placeHolderTextValue=copiedObj.placeHolderTextValue;
		  		}
		  		clone.toSVG=FQD.toSVGCustomize.toSVG;
		  		clone.breakWords=true;
		  		clone.width=copiedObj.width;
		  		
		  	}
		  if(!pageNum){
			  clone.left += 10; 
			  clone.top += 10;   
		  }

		  clone.set('canvas', canvas);
		  clone.objectCaching=false;
		  if(config.selectedTool === "pan"){
			  clone.selectable=false;
		  }
		  clone.setCoords();
		  canvas.add(clone);
		  FQD.canvas.addNewText();
	},
	selectCopiedObject:function(numberOfItems) {
		var canvas=FQD.canvas.pages[config.activeCanvas];
		  canvas.deactivateAll();
		  canvas.discardActiveGroup();
		  var objs = new Array();
		  var canvasObjects = canvas.getObjects();
		  var count = 0;
		  for (var index = (canvasObjects.length - 1); index >= 0; index--) {
		    if (count < numberOfItems) objs.push(canvasObjects[index].set('active', true));
		    count++;
		  }
		  var group = new fabric.Group(objs, {
		    originX: 'center',
		    originY: 'center'
		  });
		  canvas.calcOffset(); 
		  canvas.setActiveGroup(group.setCoords()).renderAll();
	},
	selectAllObject: function(){
		if(jQuery("a#selectAll").hasClass("disabled")){
			return;
		}
		FQD.canvas.removeSelection();
		var canvas=FQD.canvas.pages[config.activeCanvas];
		var objArr=canvas.getObjects();
		var objs=[];
		if (objArr.length>0){
			for(var i=0;i<objArr.length;i++){
				if(!objArr[i].alwaysNotselectable){
					if(objArr[i].type=="textbox"){
						objArr[i].hasControls=true;
					}
					if(objArr[i].isObjectLocked=="true")
						{
						  continue;
						}
					objArr[i].set('active', true);
					objArr[i].setCoords();
					objs.push(objArr[i]);
					
				}
			}
			var group = new fabric.Group(objs);
			group.set('canvas', canvas);
			if(objs.length > 0 ){
				canvas.setActiveGroup(group.setCoords());
				canvas.renderAll();
				FQD.shapes.showEditProperties();
				FQD.canvas.updateTransformControls();
				FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
			}
			FQD.elements.divAlignTools.find("a").removeClass("disabled");
			FQD.elements.anchorDelete.removeClass("disabled");
			FQD.elements.divAlignTools.find("a").removeClass("activeAlign");
		}
	},
	groupUngroupObjects:function(group){
	    var canvas=FQD.canvas.pages[config.activeCanvas];
			if(group){
			    var activegroup = canvas.getActiveGroup();
			    var objectsInGroup = activegroup.getObjects();
			    activegroup.clone(function(newgroup) {
			        canvas.discardActiveGroup();
			        objectsInGroup.forEach(function(object) {
					    canvas.remove(object);  
				    });
			        newgroup.isGrouped="true";
			        canvas.add(newgroup);
			        FQD.utility.highlightSelectedTextArea(newgroup,true);
			    },config.newProperties);
			}else{
				var activeObject = canvas.getActiveObject();
				  FQD.utility.highlightSelectedTextArea(activeObject,false);
				if(activeObject.type == "group"){
			        var items = activeObject._objects;
			 
			        activeObject._restoreObjectsState();
			        canvas.remove(activeObject);
			        for(var i = 0; i < items.length; i++) {
			          canvas.add(items[i]);
			          if(items[i]._objects){
			        	  var opacity=items[i]._objects[0].getOpacity();
			        	  items[i]._objects[0].setOpacity(opacity);
			        	  canvas.renderAll();
			          }
			     
			        }
			        FQD.canvas.setCanvasSelectionTrue();
			    }
			}
			FQD.elements.divContextMenu.hide();
			FQD.undoManager.saveHistory(true);
	},
	showXYCoordinates:function(obj){
			if(obj){
					FQD.utility.enableBox();
					var angle=obj.getAngle();
					if(angle < 0){
						angle=angle*-1;
					}
				FQD.elements.objectAngle.val(parseInt(angle).toFixed(0));
				var x=((obj.getLeft()-config.bleedMargin.bleedLeft-config.canvasOrigin.x0)/config.scaleMultiplier).toFixed(0),
				y=((obj.getTop()-config.bleedMargin.bleedTop-config.canvasOrigin.y0)/config.scaleMultiplier).toFixed(0)
			    w=(obj.getWidth()/config.scaleMultiplier).toFixed(0),
				h=(obj.getHeight()/config.scaleMultiplier).toFixed(0);
				
				if(config.unit == "px"){
					FQD.elements.objectXpos.val(x);
					FQD.elements.objectYpos.val(y);
					FQD.elements.objectWidth.val(w);
					FQD.elements.objectHeight.val(h);
				}else{
					FQD.elements.objectXpos.val(FQD.utility.changeObjUnit("px",config.unit,x).toFixed(3));
					FQD.elements.objectYpos.val(FQD.utility.changeObjUnit("px",config.unit,y).toFixed(3));
					FQD.elements.objectWidth.val(FQD.utility.changeObjUnit("px",config.unit,w).toFixed(3));
					FQD.elements.objectHeight.val(FQD.utility.changeObjUnit("px",config.unit,h).toFixed(3));
				}
				if(obj.type=="textbox"){
					FQD.elements.objectWidth.attr("disabled","disabled");
					FQD.elements.objectHeight.attr("disabled","disabled");
					FQD.elements.objectWidth.val("");
					FQD.elements.objectHeight.val("");
				}
				if(obj.type=="line"){
					FQD.elements.objectHeight.attr("disabled","disabled");
					FQD.elements.objectWidth.attr("disabled","disabled");
					FQD.elements.objectHeight.val("");
					FQD.elements.objectWidth.val("");
				}
		}
	   },
	    objectScalingCallback:function(){
	    	FQD.visualAids.hideInformationPopup();
	    	if(FQD.canvas.getActiveObjects()){
	    		FQD.shapes.isScaling = true;
	    		FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
			}	
	    	
	    },
	    objectRotatingCallback:function(e){
	    	FQD.visualAids.hideInformationPopup();
	    	if(FQD.canvas.getActiveObjects()){	
				 FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
				 if(e.e.shiftKey){
					 if(FQD.canvas.getActiveObjects().snapAngle){
						  return;
					 }else{
						 FQD.canvas.getActiveObjects().snapAngle=15;
					 }
				 }else{
					 if(FQD.canvas.getActiveObjects().snapAngle){
						  delete FQD.canvas.getActiveObjects().snapAngle;
					 }else{
						 return;
					 }
				 }

			}
	  
	    	
	    },
	    objectSelectedCallback:function(){
	    	if(FQD.canvas.getActiveObjects().type!='textbox'){
	    		 if($('#new-text').css('display')!="none"){
	 		    	//$("#enter-text .collapse").click();
	 		    }
	    	}else{
	    		var that=jQuery("#text");
	    		config.leftEditorWidth=300;
	    		jQuery("#editor-panel-container").width(config.leftEditorWidth);
	    		var rel=that.attr("rel");
	    		 jQuery("#left-tool-bar li").removeClass("active");
	    	        that.addClass("active");
	    	        jQuery("#editor-panel-container .left-editor-content").hide();
	    	        jQuery("#editor-panel-container").find("."+rel).show();
	    	        animateLeftEditorMemu(true);
	    	        var title_text = jQuery(that).html();
	    	        jQuery(".tool-title").html(title_text);
	    		
	    	}
	    	$('#right-bar').click();
	    	FQD.canvas.setSelectedItemHighlight();
	    	 FQD.activity.resetKeepAliveTimer();
	    },

	    objectMovingCallback:function(options){
	    	FQD.visualAids.hideInformationPopup();
	    	if(FQD.canvas.getActiveObjects()){
				 FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
			}
	    	if($('#btnGrid').prop("checked"))
	    		{
		    		options.target.set({
			    	    left: Math.round(options.target.left / config.gridSize) * config.gridSize,
			    	    top: Math.round(options.target.top / config.gridSize) * config.gridSize
			    	  });
	    		}
	       config.isMoveing=true;
	    },
	       objectMouseOverCallback:function(e){
		    	 var obj=e.target;
		    	 if(obj){
			    	 config.mouseoverObj=obj;
			    	 var obX=obj.getLeft(),
			    	 	 obY=obj.getTop();
			    	 	 obW=obj.getWidth(),
			    	 	 obH=obj.getHeight(),
			    	 	 xpos = obj.oCoords.ml != undefined? obj.oCoords.ml.x: obj.oCoords.tl.x, 
		    		     ypos = obj.oCoords.ml != undefined? obj.oCoords.ml.y: obj.oCoords.tl.y;
			    	 	
			    	 var width,height;
			    		if(obj.cropped=="true"){
			    			width=obj.orgWidth;
			    			height=obj.orgHeight;
			    		}else{
			    			width=obj.originalWidth;
			    			height=obj.originalHeight;
			    		}
			    	 if(obj.isObjectLocked == "true"){
			    		 FQD.elements.lockMessage.html(resourcesData.lockMessage);
			    		 FQD.elements.lockMessage.show();
		    		     FQD.elements.lockMessage.css({"left":xpos.toFixed(0)+"px", "top":ypos.toFixed(0)+"px", "pointer-events":"none"});
		    		     
			    	 }
			    	 else if(obj.type == "image" && obj.scaled && (obj.getScaleX()*(obj.width) > width || obj.getScaleY()*(obj.height)  > height)){
			    		 /*if(FQD.elements.imgResizeWarning.css("display") == "none") {
			    			 xpos = obj.oCoords.tl.x + FQD.elements.imgResizeWarning.width()/2,
				    		 ypos = obj.oCoords.tl.y + FQD.elements.imgResizeWarning.height() - 8;
				    		 FQD.elements.imgResizeWarning.show();
			    		     FQD.elements.imgResizeWarning.css({"left":xpos.toFixed(0)+"px", "top":ypos.toFixed(0)+"px"});
			    		     FQD.elements.imgResizeWarning.mouseenter(function(e) {
			    		    	FQD.elements.imgResizeWarning.show();
			    		    	var mousex = e.pageX + 20,mousey = e.pageY - 50,ww=jQuery(document).width(),wh=jQuery(document).height();tw=jQuery(".tooltip").width()
				 	            if(mousex > (ww-tw-100)){
				 	            	mousex = e.pageX -tw;
				 	            }
			    		    	jQuery('.tooltip').remove();
			 	                jQuery('<p class="tooltip"></p>').text("This image was resized beyond the full size and may result in loss of image quality").appendTo('body').css({ top: mousey, left: mousex }).fadeIn('slow');
			 	             }).mouseleave(function() {
			    		    	 jQuery('.tooltip').remove();
			    		     });
				    	 }*/
			    	 }
			    	 FQD.message.setImageWarnings(obj,FQD.canvas.pages[config.activeCanvas]);
		    	 }
		    },
	    objectMouseOutCallback: function(e){
	    	FQD.visualAids.hideInformationPopup();
	    },
	    dblClickCallback:function(e){	    	
	    	var obj=config.mouseoverObj,selectedObj=FQD.canvas.pages[config.activeCanvas].getActiveObject();
		    if(obj){
		    	if(selectedObj && obj.type == "image"){
			    	config.placerHolderObject.elm=obj;
			    	config.placerHolderObject.left=obj.left;
			    	config.placerHolderObject.top=obj.top;
			    	config.placerHolderObject.angle=obj.angle;
			    	
			    	if(obj.imgPlaceholder || obj.userUploaded =="true"){
			    		config.placerHolderObject.userUploaded="true";
			    		//if(!FQD.elements.uploadImgIcon.hasClass("active")){
			    			FQD.utility.swap(1,FQD.elements.uploadImgIcon);
			    			//openEditorPanel(FQD.elements.uploadImgIcon);
			    		//}
			    	}
			    	if(obj.clipartPlaceholder || obj.isClipArt=="true"){
			    		if(e!="swap"){
			    			
			    			config.isDoubleClicked=true;
			    		}
			    		
			    	//	if(!FQD.elements.clipartIcon.hasClass("active")){
			    			FQD.utility.swap(2,FQD.elements.clipartIcon);
			    			///openEditorPanel(fFQD.elements.clipartIcon);
			    		//}
			    	}
		    	}
		        if(obj.isObjectLocked == "true"){
		        	 delete obj.isObjectLocked;
		        	 	obj.selectable=true;
						obj.hasControls=true;
					    obj.hasBorders=true;
					    obj.evented=true;
		    		 FQD.elements.lockMessage.show();
		    		 FQD.elements.lockMessage.html(resourcesData.objectUnlocked);
		    		 if(obj.type == "textbox"){
		    			 obj.editable=true;
						 jQuery("#"+obj.id).prop("disabled",false);
					 }
		     }
		      
		   }
       },
       onSelectionCleared:function(){
    	   var z=FQD.canvas.pages[config.activeCanvas].getZoom();
    	   FQD.canvas.setZoom(1);
    	   var objects=FQD.canvas.pages[config.activeCanvas]._objects;
    	   var pointTL= new fabric.Point(config.safeMargin,config.safeMargin);
    	   var pointBR= new fabric.Point(config.canvasWidth -config.safeMargin, config.canvasHeight-config.safeMargin);
    	   var warning=false;
    	   
    	   for(var i=0;i<objects.length;i++){
    		  if(!objects[i].isContainedWithinRect(pointTL,pointBR)){
    			  warning=true;
    		  }
    		  
    	   }
    	   FQD.canvas.setZoom(z); 
    	   if(warning){
    		   FQD.message.showWarning(FQD.message.safeMsg);
    		   config.warning="true";
    	   }
       },
       onBeforeSelectionCleared:function(){
    	   delete config.isSwapInitiate;
       },
        highlightSelectedTextArea:function(group,action){
    	   var objs=group._objects;
    	   for(var i=0;i<objs.length;i++){
    		   if(objs[i].type=="textbox"){
    			   var id=objs[i].id;
    			   if(action){
    				   $("textarea[id="+id+"]").prop("disabled",true);
    				   $("textarea[id="+id+"]").css("background-color","#DEDEDD");
    			   }
    			   else{
    				   $("textarea[id="+id+"]").prop("disabled",false);
    				   $("textarea[id="+id+"]").css("background-color","");
    			   }
    			   
    		   }
    	   }
       },
	    enableBox:function(){
	    	if(FQD.elements.objectXpos.attr("disabled"))
			 {
	    		FQD.elements.objectAngle.removeAttr("disabled");
				FQD.elements.objectXpos.removeAttr("disabled");
				FQD.elements.objectYpos.removeAttr("disabled");
				FQD.elements.objectWidth.removeAttr("disabled");
				FQD.elements.objectHeight.removeAttr("disabled");
				jQuery("#applyobj, #constrainBtn").removeClass("disabled");
			 }
	    },
	  changeObjUnit:function(currentUnit,newUnit,value){
		   var defaultDpi=config.dpi,modifiedUnit;
				if(currentUnit == "px" && newUnit == "in"){
					modifiedUnit=value/defaultDpi;
				}
				else if(currentUnit == "px" && newUnit == "mm"){
					modifiedUnit=(value*0.264583*100)/defaultDpi;
				}
				else if(currentUnit == "in" && newUnit == "px"){
					modifiedUnit=value*defaultDpi;
				}
				else if(currentUnit == "in" && newUnit == "mm"){
					modifiedUnit=(value*25.4*100)/defaultDpi;
				}
				else if(currentUnit == "mm" && newUnit == "in"){
					modifiedUnit=value/25.4;
				}
				else if(currentUnit == "mm" && newUnit == "px"){
					modifiedUnit=(value*defaultDpi)/(0.264583*100);
				}
	    	return modifiedUnit;
	    },
	    
	    keyUpObjectInfo:function(event){
	    	if(FQD.shapes.constrainScale){
	    		if(event.currentTarget.id == "widthobj"){
	    			var ratio = event.currentTarget.value/FQD.shapes.selectedElementWidth();
	    			jQuery('#heightobj').val((FQD.shapes.selectedElementHeight()*ratio).toFixed(3));
	    		}
	    		else if(event.currentTarget.id == "heightobj"){
	    			var ratio = event.currentTarget.value/FQD.shapes.selectedElementHeight();
	    			jQuery('#widthobj').val((FQD.shapes.selectedElementWidth()*ratio).toFixed(3));
	    		}
	    	}
	    },
	    
	    setObjInfo:function(event){
		  event = event.which || event.keyCode;
		  
		  if(event == 13){
			  FQD.utility.setObjTranslation();
		  }
	  },
	  setObjTranslation: function(){
		  var obj=FQD.canvas.getActiveObjects(), elmWidth,elmHeight,elmX,elmY,elmAngle;
	    	
	    	if(obj && !FQD.elements.objectXpos.attr("disabled")){ 
	    			 elmWidth = obj.getWidth();
	    		     elmHeight = obj.getHeight();
	    		     elmX = obj.getLeft();
	    		     elmY = obj.getTop();
	    		     elmAngle=obj.getAngle();
	    	}
	    	else{return;}
	    	
	    	    var valAngle=parseFloat(jQuery('#angle').val()),
					valx=parseFloat(jQuery('#xpos').val()),
					valy=parseFloat(jQuery('#ypos').val()),
					valwidth=parseFloat(jQuery('#widthobj').val()),
					valheight=parseFloat(jQuery('#heightobj').val());
	    	    
	    	    if(obj.type=="textbox" ||obj.type=="line" ){
	    	    	
	    	    	 if(isNaN(valAngle) || isNaN(valx) || isNaN(valy)){
		  	    	    	FQD.utility.showXYCoordinates(obj);
		  	    	    	return; 
		  	    	    }
	    	    }else{
	    	    	 if(isNaN(valAngle) || isNaN(valx) || isNaN(valy) || isNaN(valwidth) || isNaN(valheight)){
	  	    	    	FQD.utility.showXYCoordinates(obj);
	  	    	    	return; 
	  	    	    }
	    	    }
	    	    
	    
	    	    valx=valx*config.scaleMultiplier,
	    	    valy=valy*config.scaleMultiplier,
			    valwidth=valwidth*config.scaleMultiplier,
			    valheight=valheight*config.scaleMultiplier;
	    	    
				if(config.unit !== "px"){
					valx=FQD.utility.changeObjUnit(config.unit,"px",valx);
					valy=FQD.utility.changeObjUnit(config.unit,"px",valy);
					valwidth=FQD.utility.changeObjUnit(config.unit,"px",valwidth);
					valheight=FQD.utility.changeObjUnit(config.unit,"px",valheight);
				}
					obj.setLeft(valx+config.bleedMargin.bleedLeft+config.canvasOrigin.x0);
					obj.setTop(valy+config.bleedMargin.bleedTop+config.canvasOrigin.y0);
					if(obj.type!="textbox" && obj.type!="line"){					
						obj.setScaleX(obj.scaleX*(valwidth/elmWidth));
						obj.setScaleY(obj.scaleY*(valheight/elmHeight));
					}
					
					obj.setAngle(valAngle % 360);
					obj.setCoords();  
					FQD.canvas.pages[config.activeCanvas].renderAll();
					config.triggerMovingEvent = true;
					config.currentActiveObject = obj;
					FQD.canvas.removeSelection(obj);
					FQD.canvas.pages[config.activeCanvas].setActiveObject(obj);
					FQD.utility.showXYCoordinates(obj);
				    FQD.undoManager.saveHistory(true);
		},
		showContextMenu: function(event){
			jQuery(".canvas-container .context-menu").remove();
			var contextHtml = jQuery("#context-menu").html();
			contextHtml = '<div class="context-menu">' + contextHtml + '</div>';
			jQuery(event.target).parent().append(contextHtml);
			FQD.elements.divContextMenu = jQuery(".context-menu");

			FQD.elements.divContextMenu.find("li").show();
			jQuery('#setImageAsBackground').hide();
			jQuery('#swap').hide();
			jQuery('#duplicate').hide();

			FQD.elements.divContextMenu.css({
			    top: event.offsetY + "px",
			    left: event.offsetX + "px"
			}).fadeIn('fast',function(){
				jQuery(this).show();
			});
			
			var obj = FQD.canvas.getActiveObjects();
			var pointX = event.offsetX;
			var pointY = event.offsetY;
			var target = event.target.nodeName;
			jQuery("#group, #un-group").hide();
			if (!obj) {
			    jQuery('.context-menu li').hide();
			    var bg=FQD.canvas.pages[config.activeCanvas].getItemByName("bgElement");
			    if (bg) {
			        jQuery('.context-menu #removeBgImage').show();
			    }
			    jQuery('.context-menu #clearCanvas').show();
			    FQD.canvas.removeSelection();
			    if (config.copiedObjects.length > 0) {
			        jQuery('.context-menu #paste').show();
			    } else {
			        jQuery('.context-menu #paste').hide();
			    }
			    jQuery('.context-menu #deselectAll').hide();
			} else {
			    if (!obj.containsPoint({
			            x: pointX,
			            y: pointY
			        })) {
			        jQuery('.context-menu li').hide();
			        jQuery('.context-menu #clearCanvas').show();
			        FQD.canvas.removeSelection();
			    } else {
			        if (obj._objects && !obj.isGrouped) {
			        	jQuery('.context-menu #deselectAll').show();
			        } else {
			            if (obj.isObjectLocked == "true") {
			                jQuery('.context-menu li').hide();
			                jQuery('.context-menu #clearCanvas').show();
			            }
			            if (obj.type == "image" && obj.id != "placeHolders") {
			            	if(!config.isGeneric){
			            		jQuery('#setImageAsBackground').show();
			            	}
			            		
			            	
			            }
			            if (obj.type == "image" || obj.id== "placeHolders") {
			            	if(obj.id != "placeHolders"){
				                jQuery('#swap').show();
			            	}  
			                jQuery('#duplicate').show();
			            }
			            jQuery('.context-menu #deselectAll').hide();
			        }
			    }
			    if (obj.type == "textbox" && obj.isEditing) {
			        jQuery('.context-menu #lock').hide();
			    }
			    if (obj.type == 'group') {
			        jQuery("#un-group").show();
			    }
			    if (FQD.canvas.pages[config.activeCanvas].getActiveGroup() != null) {
			        jQuery("#group").show();
			        jQuery("#un-group").hide();
			    }
			    if(obj.isEditing){
			    	jQuery("#copy,#cutObject").hide();
			    	jQuery("#paste").next("hr").hide();
				}else{
					jQuery("#paste").next("hr").show();
				}
			    jQuery('.context-menu #paste,.context-menu #removeBgImage').hide();
			    
			    if(config.pageLength === 2)
			    {
			      if(config.activeCanvas==0){
					 jQuery("#copytoback").hide();
				  }else{
					 jQuery("#copytofront").hide();
				   }
			    	
			    }else{
			    	jQuery("#copytoback").hide();
			    	jQuery("#copytofront").hide();
			    }
			  
			}
			var objs=FQD.canvas.pages[config.activeCanvas].getObjects();
			if(objs.length==1){
				jQuery('.context-menu #bringToFront').hide();
				jQuery('.context-menu #sendToBack').hide();
				
			}
             
			FQD.utility.adjustcontextMenuPosition(event);
	 },
	 adjustcontextMenuPosition:function(event){
		 
			var constantX=70;
			var constantY=100;
			var maxWidth=window.innerWidth-constantX;
			var maxHeight=window.innerHeight-constantY-$('#bottom-panel').height();
			var opacity=$("#editor-panel-container").css("opacity");
			if(opacity==1)
				{
					if($('#up-image').hasClass('active')){
						maxWidth=maxWidth-250;
					}else{
						maxWidth=maxWidth-200;
					}
				    
				}
			var width=$(".context-menu").width();
			var height=$(".context-menu").height();
			var left=event.offsetX;
			var top=event.offsetY;
			if((left+width)>maxWidth){
				left=left-((left+width)-maxWidth);
			}
			if((top+height)>maxHeight){
				top=top-((top+height)-maxHeight);
			}	
			FQD.elements.divContextMenu.css({
			    top: top + "px",
			    left: left+ "px"
			})
	 },
	 lockObject: function(){
		 var obj=FQD.canvas.getActiveObjects();
		 if(obj._objects&&obj.isGrouped!="true"){
			 var objs=obj.getObjects();
			 for(var i=0;i<objs.length;i++){
				 objs[i].isObjectLocked="true";
				 objs[i].hasBorders=false;
				 objs[i].selectable =false;
				 if(objs[i].type == "textbox"){
					 objs[i].editable=false;
					 jQuery("#"+objs[i].id).prop("disabled",true);
				 }
			 }
			 
		 }else{
			 obj.isObjectLocked="true";
			 obj.hasBorders=false;
			 obj.selectable =false;
			 if(obj.type == "textbox"){
				 obj.editable=false;
				 jQuery("#"+obj.id).prop("disabled",true);
			 }
		 }
		 FQD.elements.divContextMenu.hide();
		 FQD.canvas.removeSelection();
		 FQD.undoManager.saveHistory(true);
		 
	 },
	 bringForward: function(){
		 var obj=FQD.canvas.getActiveObjects();
		 obj.bringForward();
		 FQD.allOverlayOnTop();
		 FQD.elements.divContextMenu.hide();
		 FQD.undoManager.saveHistory(true);
	 },
	 sendBackwards: function(){
		 var obj=FQD.canvas.getActiveObjects();
		 obj.sendBackwards();
		 FQD.allOverlayOnTop();
		 FQD.elements.divContextMenu.hide();
		 FQD.undoManager.saveHistory(true);
	 },
	 sendToFront: function(){
		 var obj=FQD.canvas.getActiveObjects();
		 obj.bringToFront();
		 FQD.allOverlayOnTop();
		 FQD.elements.divContextMenu.hide();
		 FQD.undoManager.saveHistory(true);
	 },
	 sendToBack:function(){
		 var obj=FQD.canvas.getActiveObjects();
		 obj.sendToBack();
		 FQD.allOverlayOnTop();
		 FQD.elements.divContextMenu.hide();
		 FQD.undoManager.saveHistory(true);
	 },
	 userLogin:function(fromProceedToOrder){
		    FQD.activity.removeAutoSaveTimer();
		    config.btnPress=1;
			FQD.elements.usrEmail.val("");
			FQD.elements.usrPasswd.val("");
			FQD.elements.errorMessage.hide();
			if(fromProceedToOrder){
				jQuery(".login-message").show();
			}else{
				jQuery(".login-message").hide();
			}
			
			FQD.elements.userLoginWindow.dialog({
				width : 400,
				height :350,
				modal : true,
				dialogClass: "userLoginWindow",
				resizable: false,
				close:function(){
					FQD.activity.startAutoSave();
					if(config.proceedOrder=="true"){
						FQD.helper.proceedToOrderPreCheck();
					}
				},
				buttons : [
				{
					text : resourcesData.logIn,
					click : function () {
						if(fromProceedToOrder){
							config.autoSave=true;
							jQuery(".login-message").show();
						}else{
							jQuery(".login-message").hide();
						}
						FQD.helper.authenticateUser();
					}
				},{
					text : resourcesData.frontBackCancel,
					click : function () {
						FQD.activity.startAutoSave();
						jQuery(this).dialog("close");
					}
				}
			   ]
			});
			FQD.elements.userLoginWindow.css("");
			

	 },
	 exitOD:function(){
		 window.open("/","_self");
	 },
	  SignUp:function(){
		  config.btnPress=2;
		 FQD.helper.userSignUp();
	 },
	 resetPassword:function(){
		 
		 FQD.helper.resetPassword();
	 },
	gotoServerPreview:function(){
		config.isServerPreviewOn = true;
		isSessionChanged(function(){
			FQD.preview.getServerPreview();
		});
		FQD.message.hideWarning();
		FQD.shapes.showEditProperties();
		jQuery('#ServPreview,.file-menu').hide();
		jQuery('#overlay').css('top','50px');
		jQuery('#exitPreview').show();
	},
		 
	gotoProceedToOrder:function(){
		config.isUserLoggedInBeforeProceed=config.IsUserLoggedIn;
		config.proceedOrder=true;
		FQD.utility.proceedToOrder();
	},
		 
	proceedToOrder:function(){
		FQD.canvas.removeSelection();
		config.proceedOrder="true";
		FQD.shapes.showEditProperties();
		 if(config.IsUserLoggedIn){
			 FQD.helper.proceedToOrderPreCheck();
		 }else{
			 config.fromProceedToOrder=true;
			 FQD.utility.userLogin(true);
		 }
	},
	proceedToOrderSessionLogout:function(){
		$("#proceedToOrderSessionLogout div").html(fqdSessionLogoutMessage);
		$("#proceedToOrderSessionLogout div").css({
			"margin-left": "48px",
			"font-size": "16px",
			"margin-top": "39px",
			"font-weight": "bold"
		});
		$("#proceedToOrderSessionLogout").dialog({
			width : 600,
			height :200,
			modal : true,
			dialogClass: "proceedToOrderSessionLogout",
			buttons : {
				"OK" : function() {
					 config.isSessionLogout=true;
					 window.open("http://"+document.domain,"_self");
					},
			}
		});
	},
	 unloadStoreDesign:function(reload){
		 	config.fds=[];
			var prodSvg='',
			 svgToJson='',
			 background='',
			 qdAction=22,
			 designId=0;
			
			if(config.currentDesignId){
				designId=config.currentDesignId;
			}
			if(config.productDetails.designId){
				designId=config.productDetails.designId;
			}
		    for(var i=0;i<FQD.canvas.pages.length;i++)
		    {
		    	var obj=FQD.canvas.pages[i].getObjects();
		    	var arr=FQD.preview.textPlaceholder(obj);
				var svgData=FQD.canvas.pages[i].toSVG();
				config.fds[i]=[];
				obj.forEach(function(element){
					if(element.type == "image"){
						config.fds[i].push(element.getSrc());
					}
				});
				var svgjson=JSON.stringify(FQD.canvas.pages[i].toJSON(config.newProperties));
				arr.forEach(function(element){	
					delete element.isHidden;
					element.setOpacity(element.initialOpacity);
					
				});
				FQD.canvas.pages[i].renderAll();
				prodSvg +="&prodSvg="+window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(svgData)));
				svgToJson+="&svgToJson="+window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(svgjson)));
			}
		    
            var random=Math.random();
            var asyncFlag=false;
            if(reload == undefined){
				qdAction=41;
				asyncFlag=true;
			}
            
            FQD.activity.resetKeepAliveTimer();
            
            var printJobData = getEncodedPrintJob(config.productDetails.printJob);
            
            jQuery.ajax({
            	mimeType: 'text/plain; charset=x-user-defined',
            	url : FQD.preview.url,
			    type: "POST",
			    async: asyncFlag,
			    data : "QDAction="+qdAction+
			           "&isProductSaved="+config.productDetails.isProductSaved+
			           "&designId="+designId+prodSvg+svgToJson+
			           "&printJob="+printJobData+
			           "&cid="+config.cid+"&random="+random,
			    
			    
			    success: function(data)
			    {
			    },
			    error: function (jqXHR, textStatus, errorThrown)
			    {
			    	console.log(textStatus);
			    },
			    xhrFields:{
			        withCredentials: true
			     }
			});
		
	 },
	 setObjectPropertiesAfterLoadJSON:function(o,object){
		 if(object){
			 if(object.type=="textbox"){
				   object.toSVG=FQD.toSVGCustomize.toSVG;
				  }
				if(object.isHidden=="true"){
					object.setOpacity(object.initialOpacity);
					delete object.isHidden;
				}
		     if(object.type == "image"){
			   if(object.imgPlaceholder){
				   object._element=config.imgElement;
				   object.crossOrigin="anonymous";
			   }
			   if(object.clipartPlaceholder){
				   object._element=config.clipArtElement;
				   object.crossOrigin="anonymous";
			 }
		    }
		 }
	 },
	 setBackgroundRightProperties:function(data){
		 var bgElm,bg;
		 if(typeof data == "string"){
			 var data=jQuery.parseJSON(data);
		 }
		    if(data.objects){
		   		bgElm=data.objects[0],
		    	bg=data.objects[1];
		    }

	   if(bg && bg.type == "image" && bg.name =="bgElement"){
		   FQD.imgLib.disableEnableBgTools(bg);
	   }else{
   		FQD.imgLib.disableEnableBgTools(false);
	   }  
	   if(bgElm && bgElm.type == "rect" && bgElm.name == "canvasArea"){
		   FQD.elements.inputColorB.spectrum("set",bgElm.fill); 
		   jQuery("#colorB2").spectrum("set",bgElm.fill);
		   jQuery("#bg-bucket").css("color",bgElm.fill);
	   }
	 },
	   loadPrintJob: function(){
		   $('#innerWindowFrontBack').hide();
		    var random=Math.random();
		    FQD.activity.resetKeepAliveTimer();
		    FQD.request.getData({"QDAction":4,"random":random},"GET","text",FQD.helper.qdAction+"?cid="+config.cid,
			        function success(data){
					FQD.elements.divLoadingQd.hide();
					FQD.elements.divLoaderContainer.hide();
					 if(data =='' )
		    	    	{
		    	    	  return;
		    	    	}
					    var jsonData=decodeURIComponent(atob(data));
					    jsonData=jsonData.replace(/|||||||||||||||/g,"");
					    jsonData=jsonData.replace(/\\u0001|\\u0004|\\u0007|\\b|\\u0003|\\u0016|\\u0002|\\u000e|\\u0005|\\u0019|\\u000f|\\u001e|\\u000b|\\u0008|\\u001a|\\u0018|\\u0017|\\u2028|\\u000b/g,"");
					 	config.loadRefreshData=JSON.parse(jsonData);
						var div = '<div id="LoadDesignInformation" title="Information" class="container demo" style="display:none">';
						div+='<span style="margin-top: 4%;display: inline-block;font-size: 15px;text-align: center;"><span>';
						div+='</div>';
						div = div.replace('="Information"' , '='+ '"' +resourcesData.information+ '"');
						div = div.replace('><' , '>'+ resourcesData.LoadDesignInformation + '<');
						$("body").append(div);	
						if(config.IsUserLoggedIn){
							var str=config.loadRefreshData.toString();
							if(str.indexOf("worker")!=-1){
								FQD.updateFD.updateFileDescriptorBeforeLoading(config.loadRefreshData);
							}
						}
						if(config.productDetails.action=="4"){
							config.designLoadedFromOrderPage=true;
						}
						if(config.productDetails.action=="3" || config.productDetails.action=="4" || config.productDetails.action=="5" || config.productDetails.action=="6" || config.productDetails.action=="9" || config.productDetails.adminOpenedSavedDesign){
							
							if(config.productDetails.action=="5"){
								var hasExtraBleed = config.productDetails.oldBleed != undefined? true: false;
								if(hasExtraBleed){
									if(config.isPageRoundCorner == "true"){
										config.extBleed_XDiff = config.productDetails.printProductBleedRoundCornerBean.bleedLeft - config.productDetails.oldBleed.bleedLeft;
										config.extBleed_YDiff = config.productDetails.printProductBleedRoundCornerBean.bleedTop - config.productDetails.oldBleed.bleedTop;
									}else{
										config.extBleed_XDiff = config.productDetails.printProductBleedBean.bleedLeft - config.productDetails.oldBleed.bleedLeft;
										config.extBleed_YDiff = config.productDetails.printProductBleedBean.bleedTop - config.productDetails.oldBleed.bleedTop;
									}
									config.hasExtraBleed = true;
								}
							}
							
							FQD.elements.divLoadingQd.show();
							FQD.elements.divLoaderContainer.show();
							$('#frontBackSelection').hide();
							var jsonArr = config.loadRefreshData;
							config.pageLength=jsonArr.length;
							config.pageNumber=[];
							for(var i=0;i < config.pageLength;i++){
								config.pageNumber.push([]);
							}
				    		
							config.hasReloadData = true;
							FQD.canvas.init();
							
							if(!FQD.products.hasTemplateOverlay()){
								if(config.productDetails.action == "9" && !config.productDetails.adminOpenedSavedDesign){
									FQD.importJson(config.loadRefreshData,config.pageRoundCornerSize);
								}else{
									FQD.utility.reloadRefreshData();
								}
								
							}
								
							
							return;
						 }
						 $("#LoadDesignInformation").dialog({
					    		width : 500,
								height :200,
								modal : true,
								dialogClass: "LoadDesignInformation",
								buttons : [
									{
									text : resourcesData.New,
									click : function() {
										    $(this).dialog("close");
										    $('#innerWindowFrontBack').show();
										    if(config.productDetails.isProductSaved){
										    	config.productDetails.isProductSaved=false;
										    	config.productDetails.designCode=0;
										    	$('#btnSaveProgress').hide();
										    	$('#btnSaveDesignAs').hide();
										    	$('#SavedDesigns').show();
										    	$("#showSaveDesignName,#btnSaveProgress,#btnSaveDesignAs").hide();
										    	config.userSavedDesignName=undefined;
											 }
									   }
									},{
											
											text : resourcesData.reload,
											click : function() {
											FQD.elements.divLoadingQd.show();
											FQD.elements.divLoaderContainer.show();
											$(this).dialog("close");
											$('#frontBackSelection').hide();
											FQD.dialog.hideGetStaringDialog();
											
											config.hasReloadData = true; 
											FQD.canvas.init();
											
											if(!FQD.products.hasTemplateOverlay())
												FQD.utility.reloadRefreshData();
										}
										},{
									 text : resourcesData.openSavedDesign,
									 click : function(){
									    	var jsonArr= config.loadRefreshData;
											if(jsonArr.length==1){
												config.isFrontOnly="true";
												$('#tabs .last').hide();
								    			config.pageNumber=[[]];
								    			config.pageLength=1;
											}
									    	 FQD.canvas.init();
								    	     FQD.saveDesign.loadDesign(config.productDetails.designCode);
								    	     $(this).dialog("close");
								    	     $('#frontBackSelection').hide();
															
								  }
								}	
							  ]		
					    	});
						 $('.LoadDesignInformation button:nth-child(3)').hide();
						 if(config.productDetails.isProductSaved){
							 $('.LoadDesignInformation button:nth-child(3)').show();
						 }
						 if(config.isGeneric){
							 jQuery("#LoadDesignInformation").next("div").find("button").eq(0).remove();
							
						 }
			    
				   },function error(data){
					   FQD.elements.divLoadingQd.hide();
					  FQD.elements.divLoaderContainer.hide();
					console.log(data);
				});
	
	   },
	   
	   reloadRefreshData:function(){
		   config.reloadElmCount=0;
		   config.hasReloadData = false; 
		   var jsonArr = config.loadRefreshData;
		   config.isProcessCompleted=false;
			
		   if(jsonArr){
			   if(jsonArr.length == 1){
				   config.isFrontOnly="true";
				   $('#tabs .last').hide();
			   }
			
			   config.loadJSONCount = 0;
			   var elementCount=FQD.templateDataTransfer.elementsCountInTemplate(jsonArr);
			   for(var i = 0; i < jsonArr.length; i++)
			   {
				   FQD.utility.canvasLoadFromJSON(FQD.canvas.pages[i], jsonArr[i],elementCount);
			   }
			   
				var id=setInterval(function(){
					FQD.elements.divLoadingQd.show();
					FQD.elements.divLoaderContainer.show();
					 if(config.isProcessCompleted){
						 clearInterval(id);
						 FQD.saveDesign.replaceBlankSrcWithPlaceHolder();
						
						 config.isProcessCompleted=false;
						 config.reloadElmCount=0;
						 FQD.elements.divLoadingQd.hide();
						 FQD.elements.divLoaderContainer.hide();
				  			if(config.firstTimePageRender && config.productDetails.designCode > 0){
								FQD.undoManager.undoItems=[];
								FQD.elements.anchorUndo.addClass("disabled");
				  			}
					 }
					 
				 }, 10);
		   }
		   
		  
	   },
	   
	   canvasLoadFromJSON:function(canvas, json, elementCount){
		   var jsonData;
		   if(typeof json == "object"){
			   jsonData =json;
		   }else{
			   jsonData = JSON.parse(json);
		   }
		   canvas.BgColor=jsonData.background;
		   jsonData.background='transparent';
		   
		   if(jsonData.backgroundImage){
			   jsonData.backgroundImage.name="bgElement";
			   jsonData.backgroundImage.alwaysNotselectable= true;
			   jsonData.backgroundImage.objectCaching= false;
			   jsonData.backgroundImage.selectable= false;
			   
			   if(jsonData.objects==undefined){
				   jsonData.objects=[];
			   }
			   
			   jsonData.objects.unshift(jsonData.backgroundImage);
			   delete jsonData.backgroundImage;
		   }
		   
		   jsonData=FQD.imgLib.updateHDImageOnJson(jsonData);
		   
		   canvas.loadFromJSON(jsonData,
				   function(){
			   			FQD.canvas.setElementAsperCanvas(canvas, false, config.hasExtraBleed);
			   			FQD.initializecanvas.resetSVGOverlay(canvas);
			   			
			   			setTimeout(function(){ 
			   								canvas.renderAll.bind(canvas); 
			   								config.hasExtraBleed = false;
			   								}, 2000);
			   			
			   			var interval=setInterval(function(){
			   				if(canvas.getItemByName("canvasArea")){
			   					clearInterval(interval);
			   					if(canvas.BgColor && canvas.BgColor!='transparent'){
				   					$(".sp-preview-inner").css('background-color',canvas.BgColor);
				   					FQD.setCanvasAreaBackgroundColor(canvas,canvas.BgColor);
			   					}

			   				}
			   				
			   			}, 100);
			   			config.loadJSONCount += 1
			   			if(config.loadJSONCount === config.loadRefreshData.length)
			   				FQD.utility.doProcessAfterJSONLoaded();
    			   },
    			   function(o, object) {
    				   FQD.utility.setObjectPropertiesAfterLoadJSON(o, object);
    				   config.reloadElmCount++;
    				   if(object && (config.productDetails.designerType == 2 || config.hasExtraBleed || config.productDetails.isADDesign)){
    					   var multi = config.objScaleWidthMultiplier;
        				   if(object.name != "bgElement" && object.id != "backgroundImage"){
        					   object.scaleX = object.scaleX*multi;
        					   object.scaleY = object.scaleY*multi;
        				   }else{
        					   object.width *= multi;
        					   object.height *= multi;
        				   }
        				   object.left = config.canvasOrigin.x0 + object.left*multi;
        				   object.top = config.canvasOrigin.y0 + object.top*multi;
        				   
        				   if(config.hasExtraBleed){
        					   object.left = roundTo(object.getLeft() + config.extBleed_XDiff*config.scaleMultiplier, 2);
        					   object.top = roundTo(object.getTop() + config.extBleed_YDiff*config.scaleMultiplier, 2);
        					   object.setCoords();
        				   }
    				   }
    				   
    				   if(object && object.type == "textbox") {
    					    object.caching = false;
    					    if(parseInt(config.productDetails.designerType) == 2 || config.productDetails.isADDesign)
    					    	FQD.shapes.setTextElmTopFromAD(object);
    				   }
    				   
    				   if(config.reloadElmCount >= elementCount){
							config.isProcessCompleted=true;
    				   }
    			   }
		   );
	   },
	   
	   doProcessAfterJSONLoaded:function(){
		   FQD.elements.divLoadingQd.hide();
		   FQD.elements.divLoaderContainer.hide();
    			
		   FQD.utility.setBackgroundRightProperties(config.loadRefreshData[0]);
		   FQD.canvas.addNewText();
		   FQD.activity.startAutoSave();
	   },
	   
	   backgroundImgFlip:function(isFlip,flip){
		     var page=FQD.canvas.pages[config.activeCanvas];
		     var background=page.getItemByName("bgElement");
		     if(background){
		    	  if(flip=="FLIPH"){
		    		  background.flipX=isFlip;
				     }
		    	  else if(flip=="FLIPV"){
		    		  background.flipY=isFlip;
				   }
		    	  page.renderAll();    
		    	  FQD.undoManager.saveHistory(true);
		     }
	   },
  setBgImageEffect: function(){
		   jQuery("#selBGEffects").change(function(val) {
			   var page=FQD.canvas.pages[config.activeCanvas];
			   var bgImage=FQD.canvas.pages[config.activeCanvas].getItemByName("bgElement");
			   var src=bgImage.getSrc();
		       var effect=jQuery(this).val();
		       if(effect){
			          FQD.elements.divLoadingQd.show();
			          FQD.elements.divLoaderContainer.show();
			         var srcarr = src.split("&imageEffectType=");
			           srcarr = srcarr[0]+"&imageEffectType="+effect;
			           var newImg=new Image();
			             newImg.src=srcarr;
			             FQD.imgLib.setBgImage(srcarr,page);
			          newImg.onload = function() {
			          FQD.elements.divLoadingQd.hide();
			           FQD.elements.divLoaderContainer.hide();
			         }
			         newImg.onerror=function(){
			        	 FQD.elements.divLoadingQd.hide();
			             FQD.elements.divLoaderContainer.hide();
			            customAlertBox("alert","Cancel","Ok",fqdInvalidImageUrl);
			      }
			        }
			  
		        });
		  
	   },
	   
	   setImageEffect: function(){

		    jQuery('#elemet-editor-container').delegate("#flipButton","click",function(val){
				   var page=FQD.canvas.pages[config.activeCanvas];
				   var chkFlipH=$("#chkFlipH").prop("checked");
				   var chkFlipV=$("#chkFlipV").prop("checked");
				   var img=FQD.canvas.getActiveObjects();
				   img.flipX=chkFlipH;
				   img.flipY=chkFlipV;
				   page.renderAll();
				   FQD.undoManager.saveHistory(true);
			 });

		    
		    jQuery('#elemet-editor-container').delegate("#selImageEffects","change",function(val){

		     	var page=FQD.canvas.pages[config.activeCanvas];
		        var effect = jQuery(this).val();
		        var img = FQD.canvas.getActiveObjects();
		        var src = img.getSrc();
		        var width = img.width;
		        var height = img.height;
		        var newUrl = src.substring(0, src.lastIndexOf(".png")+4);
		        
		        img.croppedSourceURL = newUrl;
		        
		        if(src)
		        {
		        	FQD.elements.divLoadingQd.show();
		        	FQD.elements.divLoaderContainer.show();
		          
		        	if(src.indexOf("crop") > 0){
		        		newUrl = newUrl+"&crop="+img.cropStartX+":"+img.cropStartY+":"+img.orgWidth+":"+img.orgHeight;
		        	}
		        	newUrl=newUrl+"&imageEffectType="+effect;
		             
		        	var newImg = new Image();
		        	newImg.src = newUrl;
		        	
		        	img.setSrc(newUrl, function(){
		        			img.setWidth(width);
		        			img.setHeight(height);
		        			page.renderAll()
		        	});
		        	
		        	img.src = newUrl;
		        	
        			newImg.onload = function() {
        					FQD.elements.divLoadingQd.hide();
        					FQD.elements.divLoaderContainer.hide();
        					FQD.undoManager.saveHistory(true);
        			}
         
        			newImg.onerror=function(){
        					FQD.elements.divLoadingQd.hide();
        					FQD.elements.divLoaderContainer.hide();
        					customAlertBox("alert","Cancel","Ok",fqdInvalidImageUrl);        			
        			}
		        }
	   
			 });
	},
	
	 setImagePropertiesSelections:function(){
		 var img=FQD.canvas.getActiveObjects();
		   var chkFlipH=img.flipX;
		   var chkFlipV=img.flipY;
		   var src=img.getSrc();
		   var srcarr = src.split("&imageEffectType=");
		   $("#chkFlipH").prop("checked",chkFlipH);
		   $("#chkFlipV").prop("checked",chkFlipV);
		   if(srcarr.length>1){
			   $("#selImageEffects").val(srcarr[1]);
		   }
		   else{
			   $("#selImageEffects").val("NONE");
		   }
		      FQD.undoManager.saveHistory(true);
	 },
	 cropImage:function(){
		 $("#crop-photo").click(function() {
			 FQD.crop.cropImage();
			});
	 },
	 
	  updatePurgeTime:function(imgUrl, addOnCanvas){
		     var arr = imgUrl.split("filestore?id=");
		     var fd = arr[1];
		     var random = Math.random();
		     var canvas = FQD.canvas.pages[config.activeCanvas];
		     FQD.activity.resetKeepAliveTimer();
		     
		     FQD.request.getData({"QDAction":25,"cid":config.cid,"fileDescriptor":fd,"random":random},"POST","text",FQD.imgLib.qdAction,function success(data)
		     	{
					if(data && typeof data == "string" && data.length > 0)
					{
						data = JSON.parse(data);
						if(data.responseMessage){
							customAlertBox("alert", "Cancel", "Ok", data.responseMessage);
							FQD.undoManager.clearHistory(true);
							canvas.renderAll();
							refreshRecent();
						}
						
						FQD.elements.divLoadingQd.hide();
				    	FQD.elements.divLoaderContainer.hide();
					}
					else{
						if(addOnCanvas != undefined){
					        var activeObj = FQD.canvas.getActiveObjects();
					        if((activeObj && config.isSwapInitiate)||(config.swapImageObject  && config.isSwapInitiate))
				    			FQD.imgLib.swapImageOnCanvas(activeObj, canvas);
				    		else
				    			FQD.imgLib.addImageOnCanvas(canvas, addOnCanvas);
						}
					}
				},
				function error(data){
					FQD.elements.divLoadingQd.hide();
			    	FQD.elements.divLoaderContainer.hide();
					console.log(data);
				});
	   },
	   
	   convertJsonToSvg:function(action,id){

			var z=FQD.canvas.pages[config.activeCanvas].getZoom();
				FQD.canvas.setZoom(1);// reset canvas to get data in 100% zoom
			var prodSvg='';
			var urlData;
			if(action=="design"){
				urlData="&userSavedDesignId="+id;
			}
			else{
				urlData="&designerTemplateId="+id;
		
			}
			for(var i=0;i<FQD.canvas.pages.length;i++)
				{
				var objs=FQD.canvas.pages[i].getObjects();
				var svgData=FQD.canvas.pages[i].toSVG('',FQD.preview.toSVG);
				var bgColor=FQD.canvas.pages[i].backgroundColor;
				svgData=svgData.replace('</defs>','</defs><rect id="backgroundColor" width="'+config.canvasWidth+'" height="'+config.canvasHeight+'" fill="'+bgColor+'"/>');
				//Store all the images in an arry to send it to the server for categorization
				svgData=svgData.replace('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>','');
				svgData=svgData.replace('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">','');
				svgData=jQuery.trim(svgData).replace(/(?:\r\n|\r|\n)/g, '').replace(/\s+/g, " ");

				prodSvg +="&svgData="+window.btoa(encodeURI(svgData));
				

				}

			FQD.canvas.setZoom(z); // zoom canvas as per previous value again
			
			var random=Math.random();
			FQD.activity.resetKeepAliveTimer();
			
			jQuery.ajax({
					mimeType: 'text/plain; charset=x-user-defined',    
					url : FQD.preview.url,
				    type: "POST",
				    data : "QDAction=36"+prodSvg+urlData+"&cid="+config.cid+"&random="+random,
				    success: function(data)
				    {
				    	
				    },
				    error: function (jqXHR, textStatus, errorThrown)
				    {

				    
				    },
				    xhrFields:{
				        withCredentials: true
				     }
				});

	   },
	   showHideBoldItalic:function(val){
		   if(config.nonBoldItalicFontList && config.nonBoldItalicFontList.lastIndexOf(val)!=-1){
			   $("#textStyleProp #bold").hide();
			   $("#textStyleProp #italic").hide();
		   }else{
			   $("#textStyleProp #bold").show();
			   $("#textStyleProp #italic").show();
		   }
	   },
	   
	   refreshTimeout:function(timeout){
		   setTimeout(function(){ FQD.canvas.pages[config.activeCanvas].renderAll();
		    FQD.undoManager.saveHistory(true);
			FQD.elements.divLoadingQd.hide();
	    	FQD.elements.divLoaderContainer.hide();
	    	FQD.undoManager.loader=false;
	    	FQD.allOverlayOnTop();
		   }, timeout);
	   },
	   setCachedProperties:function(obj){
		   if(obj && obj.type=="textbox"){
			   var keys=Object.keys(config.objectCachedProperties.Text);
			   for(var i=0;i<keys.length;i++){
				   if(config.objectCachedProperties.Text[keys[i]]){
					   FQD.shapes.setObjectProperties(keys[i],config.objectCachedProperties.Text[keys[i]],obj);
				   }
				  
			   }
		   }else{
			   var keys=Object.keys(config.objectCachedProperties.Shapes);
			   for(var i=0;i<keys.length;i++){
				   if(config.objectCachedProperties.Shapes[keys[i]]){
					   if(keys[i] == "strokeWidth"){
						   FQD.shapes.setObjectProperties(keys[i], (config.objectCachedProperties.Shapes[keys[i]])/config.scaleMultiplier, obj);
					   }else{
						   FQD.shapes.setObjectProperties(keys[i],config.objectCachedProperties.Shapes[keys[i]],obj);
					   }
				   }
			   }
		   }
	   },
	   setProductDimensions:function(unit,changeUnit){
		   var prodDimension;
		   
		   if(changeUnit){
			   
			   if(unit=="in"){
				   if(config.productDetails.unit=="in"){
					   prodDimension= config.productDetails.canvasWidth +" X "+config.productDetails.canvasHeight+" in";
				     }
				   if(config.productDetails.unit=="px"){
					   prodDimension= Math.round(config.productDetails.canvasWidth/config.productDetails.dpi) +" X "+Math.round(config.productDetails.canvasHeight/config.productDetails.dpi)+" in";
				     }
				   if(config.productDetails.unit=="mm"){
					   prodDimension= Math.round(config.productDetails.canvasWidth/25.4) +" X "+Math.round(config.productDetails.canvasHeight/25.4)+" in";
				     }
				   
			   }
			   
			   if(unit=="mm"){
				   if(config.productDetails.unit=="in"){
					  prodDimension= Math.round(config.productDetails.canvasWidth*25.4) +" X "+Math.round(config.productDetails.canvasHeight*25.4)+" mm";
				     }
				   if(config.productDetails.unit=="mm"){
					   prodDimension= config.productDetails.canvasWidth +" X "+config.productDetails.canvasHeight+" mm";
				     }
				   if(config.productDetails.unit=="px"){
						  prodDimension= Math.round((config.productDetails.canvasWidth/config.productDetails.dpi)*25.4) +" X "+Math.round((config.productDetails.canvasHeight/config.productDetails.dpi)*25.4)+" mm";
					 }
				   
			   }
			   
			   if(unit=="px"){
				   if(config.productDetails.unit=="in"){
					   prodDimension=Math.round(config.productDetails.canvasWidth*config.productDetails.dpi) +" X "+Math.round(config.productDetails.canvasHeight*config.productDetails.dpi)+" px";
				     } 
				   if(config.productDetails.unit=="mm"){
					   prodDimension=Math.round((config.productDetails.canvasWidth/25.4)*config.productDetails.dpi) +" X "+Math.round((config.productDetails.canvasHeight/25.4)*config.productDetails.dpi)+" px";
				     }
				   if(config.productDetails.unit=="px"){
					   prodDimension= config.productDetails.canvasWidth +" X "+config.productDetails.canvasHeight+"px";
				     }
			   }
		   }
			   $("#prodDimension").html(prodDimension);

			   
	   },
	   rotateRight:function(){
			var activeObj=FQD.canvas.getActiveObjects();
			var angle=FQD.canvas.getActiveObjects().getAngle();
			activeObj.rotate(angle+config.angleSteps);
			FQD.canvas.pages[config.activeCanvas].renderAll();
			FQD.utility.showXYCoordinates(activeObj);
	   },
	   rotateLeft:function(){
			var activeObj=FQD.canvas.getActiveObjects();
			var angle=FQD.canvas.getActiveObjects().getAngle();
			activeObj.rotate(angle-config.angleSteps);
			FQD.canvas.pages[config.activeCanvas].renderAll();
			FQD.utility.showXYCoordinates(activeObj);
	   },
	   getAutoSaveDesignName:function(obj){
		    var month,date,time;
		    var d = new Date();
		    month=d.getMonth()+1;
		    time=d.toLocaleTimeString().split(" ")[0];
		    date=d.getDate();
		    if(month<10){
		    month="0"+month;
		    }
		    if(date<10){
		        date="0"+date;
		    }
		    var name = "my-design_"+d.getFullYear()+""+month+date+"_"+time;
		    return name;
	   },
	   zoomIn:function(){
		   FQD.canvas.zoomIn(jQuery('#zoom-level'));
	   },
	   zoomOut:function(){
		   FQD.canvas.zoomOut(jQuery('#zoom-level'));
	   },
	   sortCategory: function(arr){
		   var sortedList=arr.sort(FQD.utility.compare);
		   return sortedList;
	   },
	   compare : function(a,b){
		   if (FQD.imgLib.decodeData(a.name) < FQD.imgLib.decodeData(b.name))
			    return -1;
			  if (FQD.imgLib.decodeData(a.name) > FQD.imgLib.decodeData(b.name))
			    return 1;
			  return 0;
	   },
	   getProductName:function(productType){
		   
		 var productName='';
		 switch(productType){
		    case 1:
		    	productName="Business Cards"
		        break;
		    case 2:
		    	productName="PostCards"
		        break;
		    case 3:
		    	productName="Bookmarks"
		        break;
		    case 4:
		    	productName="Flyers"
		        break;
		    case 7:
		    	productName="Stickers"
		        break;
		    case 8:
		    	productName="Posters"
		        break;
		    case 10:
		    	productName="Letterheads";
		    	break;
		    case 13:
		    	productName="Notepads";
		    	break;
		    case 16:
		    	productName="Banners";
		    	break;
		    case 17:
		    	productName="Wide Posters";
		    	break;
		    case 18:
		    	productName="Window Clings";
		    	break;
		    case 19:
		    	productName="Window Decals";
		    	break;
		    case 20:
		    	productName="Hang Tags";
		    	break;
		    case 22:
		    	productName="Event Tickets";
		    	break;
		    case 27:
		    	productName="Club Flyers";
		    	break;
		    case 28:
		    	productName="Collectors Cards";
		    	break;
		    case 29:
		    	productName="Door Hangers";
		    	break;
		    case 32:
		    	productName="Rack Cards";
		    	break;
		    case 41:
		    	productName="Window Perfs";
		    	break;	    	
		    default:
		    	productName="PostCards"
			    break;
		 
	        }
		 return productName;
	   }
};
