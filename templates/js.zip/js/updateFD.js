
String.prototype.replaceAll = function(searchStr, replaceStr) {
    var str = this;
    // escape regexp special characters in search string
    searchStr = searchStr.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    return str.replace(new RegExp(searchStr, 'gi'), replaceStr);
};


FQD.updateFD = {

	updateFileDescriptor : function(id) {
		if (!id) {
			return;
		}
		config.userId=id;
		var loadFileDescriptors = [];
		var fileDescriptors = function() {
			this.oldFileDescriptor = new Array();
			this.newFileDescriptor = new Array();
			this.oldFileDescriptor1 = new Array();
			this.newFileDescriptor1 = new Array();
		};
		for (var i = 0; i < FQD.canvas.pages.length; i++) {

			var elm = FQD.canvas.pages[i].getObjects();
			var bg = FQD.canvas.pages[i].backgroundImage;
			if (bg != null) {
				var obj = new fileDescriptors();
				obj.oldFileDescriptor.push(bg.getSrc().split("=")[1]);
				if(bg.filedescriptorid){
					obj.oldFileDescriptor1.push(bg.filedescriptorid);
				}
				loadFileDescriptors.push(obj);
			}
			for (var j = 0; j < elm.length; j++) {
				if (elm[j].type == "image") {
					var obj = new fileDescriptors();
					obj.oldFileDescriptor.push(elm[j].getSrc().split("=")[1]);
					if(elm[j].filedescriptorid){
						obj.oldFileDescriptor1.push(elm[j].filedescriptorid);
					}

					loadFileDescriptors.push(obj);
				}
			}

		}

		FQD.updateFD.getNewFileDescriptor(loadFileDescriptors, id);
	},
	getNewFileDescriptor : function(fd, id, boolean) {
		var TEMP_UPLOAD_ORIGINAL = 1;
		var TEMP_UPLOAD_FULL_AREA = 2;
		var TEMP_UPLOAD_FULL_AREA_WITH_ALPHA = 3;
		var USER_ORIGINAL = 6;
		var USER_FULL_AREA = 7;
		var USER_FULL_AREA_WITH_ALPHA = 8;
		for (var i = 0; i < fd.length; i++) {
			var len = fd[i].oldFileDescriptor.length;
			for (var j = 0; j < len; j++) {
				var isContinue=false;
				var temp = fd[i].oldFileDescriptor[j];
				var temp1 = fd[i].oldFileDescriptor1[j];
				var fidOld = temp;
				var fidOld1 = temp1;
				var fidNew = '';
				var fidNew1 = '';
				var arr = fidOld.split(":");
				var arr1 = fidOld1.split(":");
				fidNew += arr[0] + ":" + arr[1] + ":";
				fidNew1 += arr1[0] + ":" + arr1[1] + ":";
				if (arr.length > 2 && parseInt(arr[2]) > 3) {
					fd[i].newFileDescriptor[j] = fidOld;
					isContinue=true;
				}
				if (arr1.length > 2 && parseInt(arr1[2]) > 3) {
					fd[i].newFileDescriptor1[j] = fidOld1;
					//isContinue=true;
				}
				if(isContinue){
					continue;
				}
				
				if(parseInt(arr1[2])==1){
					fidNew1 += USER_ORIGINAL + ":" + id + ":" + arr1[4];
				}
				
				switch (parseInt(arr[2])) {
				case TEMP_UPLOAD_ORIGINAL:
					fidNew += USER_ORIGINAL + ":" + id + ":";
					break;
				case TEMP_UPLOAD_FULL_AREA:
					fidNew += USER_FULL_AREA + ":" + id + ":" + arr[4] + ":";
					break;
				case TEMP_UPLOAD_FULL_AREA_WITH_ALPHA:
					fidNew += USER_FULL_AREA_WITH_ALPHA + ":" + id + ":"
							+ arr[4] + ":";
					break;
				}
				
				fidNew += arr[arr.length - 1];
				fd[i].newFileDescriptor[j] = fidNew;
				fd[i].newFileDescriptor1[j] = fidNew1;
			}
		}
		if (boolean) {
			return fd;
		} else {
			FQD.updateFD.replaceFileDescriptor(fd);
		}

	},
	replaceFileDescriptor : function(fd) {
		config.loadElmCount=0;
		config.checkForCroppedImageCompleted=false
		var page=[];
		var count=0;
		for (var i = 0; i < FQD.canvas.pages.length; i++) {
			var json=JSON.stringify(FQD.canvas.pages[i].toJSON(config.newProperties));
			for (k = 0; k < fd.length; k++) {
				json=json.replaceAll(fd[k].oldFileDescriptor[0], fd[k].newFileDescriptor[0]);
				json=json.replaceAll(fd[k].oldFileDescriptor1[0], fd[k].newFileDescriptor1[0]);
				var a=fd[k].oldFileDescriptor[0].slice(0,fd[k].oldFileDescriptor[0].length-4).replace(":1:",":").replace(":3:",":1:");
				var b=fd[k].newFileDescriptor[0].slice(0,fd[k].newFileDescriptor[0].length-4).replace(":1:",":").replace(":8:",":6:");
				json=json.replaceAll(a, b);
			}
			page.push(json);
			count += FQD.updateFD.elementCount(json);
           }
        config.loadFDTotalElmCount=count;
		for (var i = 0; i < page.length; i++) {
			FQD.undoManager.loadCanvasFromJSON(page[i],FQD.canvas.pages[i]);
		}
		
	    FQD.updateFD.CheckForCropedImage(count);
	},
	CheckForCropedImage:function(count){
		 config.checkForCroppedImageCompleted=false;
		 var id=setInterval(function(){
			 var isLoaded=FQD.templateDataTransfer.isTemplateLoaded();
			 if(config.loadElmCount>=count){
				 clearInterval(id);
				 for (var i = 0; i < FQD.canvas.pages.length; i++) {
					 var objs=FQD.canvas.pages[i].getObjects();
					  for(var j=0;j<objs.length;j++){
						  if(objs[j].cropped=="true"){
							var newCroppedSourceURL;
							  var arrOld=objs[j].croppedSourceURL.split("id=");
							  var oldCroppedSourceURLFD=arrOld[1];
							  var oldOrgImage=objs[j].orgImg;
							  var arr=oldCroppedSourceURLFD.split(":");
								if (arr.length > 2 && parseInt(arr[2]) == 3) {
									newCroppedSourceURL=arrOld[0]+"id="+arr[0]+":"+arr[1]+":8:"+config.userId+":"+ arr[4] + ":"+ arr[arr.length - 1];
									var newOrgImage=arrOld[0]+"id="+arr[0]+":"+arr[1]+":8:"+config.userId+":"+ 1 + ":"+ arr[arr.length - 1];
									objs[j].croppedSourceURL=newCroppedSourceURL;
									if(oldOrgImage){
										objs[j].orgImg=newOrgImage;
									}
                                   
								}
						  }
					  }
					  FQD.canvas.pages[i].renderAll();
				 }
				 config.checkForCroppedImageCompleted=true;
			 }
			 
		 }, 10);
		 
		
	},
	
	elementCount:function(json){
		var count=0;
		var json=JSON.parse(json);
    	if(json.objects){
    		count= json.objects.length;
    	}
	    if(json.backgroundImage){
	    	count++;
	    }
	    return count;
	},
	updateFileDescriptorBeforeLoading : function(svg) {
		var modifiedSvg = [];
		var loadFileDescriptors = [];
		var fileDescriptors = function() {
			this.oldFileDescriptor = new Array();
			this.newFileDescriptor = new Array();
		};
		for (var i = 0; i < svg.length; i++) {
			var rawSvg = svg[i];
			var json = JSON.parse(rawSvg);

			var bg = json.backgroundImage;
			if (bg != null) {
				var obj = new fileDescriptors();
				obj.oldFileDescriptor.push(bg.src.split("=")[1]);
				loadFileDescriptors.push(obj);
			}
			var objs = json.objects;
			for (var j = 0; j < objs.length; j++) {
				if (objs[j].type == "image") {
					var obj = new fileDescriptors();
					obj.oldFileDescriptor.push(objs[j].src.split("=")[1]);
					loadFileDescriptors.push(obj);
				}
			}

		}
		console.log(loadFileDescriptors);
		var fd = FQD.updateFD.getNewFileDescriptor(loadFileDescriptors,
				config.userId, true);
		FQD.updateFD.replaceBeforeLoadingFileDescriptor(fd);

	},
	replaceBeforeLoadingFileDescriptor : function(fd) {
		var svgData = JSON.stringify(config.loadRefreshData);
		for (var i = 0; i < fd.length; i++) {

			svgData = svgData.replace(new RegExp(fd[i].oldFileDescriptor, 'g'),
					fd[i].newFileDescriptor);
		}
		config.loadRefreshData = JSON.parse(svgData)

	}
}