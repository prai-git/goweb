/*************************************************************************************************************
 * 
 * Responsible for store all the messages
 * 
 * 
 **********************************************************************************************************/
FQD.message={
	deleteSingleObject:resourcesData.deleteSingleObject,
	deleteObjects:resourcesData.deleteObjects,
	clearAll:resourcesData.clearAll,
	clearCanvas:resourcesData.areYouSureToclearCanvas,
	bleedMsg:resourcesData.bleedMsg,
	safeMsg:resourcesData.safeMsg,
	importSvgBg:resourcesData.importSvgBg,
	imageResized:resourcesData.imageResized,
	msgReviewPages:resourcesData.msgReviewPages,
	msgRGBWarning:resourcesData.msgRGBWarning,
	removeBgImage:resourcesData.areYouSureToRemoveBgImage,
	warnInterval:0,
	msgReviewPagesBeforeProceeding : resourcesData.msgReviewPagesBeforeProceeding,
	
	showWarning: function(msg){	
		if(jQuery("#btnWarn").prop("checked")){
			jQuery("#indicator").slideDown('fast');
			jQuery("#warn-text").text(msg);
			clearTimeout(FQD.message.warnInterval)
			FQD.message.warnInterval = setTimeout(function(){jQuery("#indicator").slideUp('fast');}, 2*1000);
		}	
	},
	
	hideWarning:function(){
		jQuery("#warn-text").text("");
		jQuery("#indicator").hide();
	},
	
	setImageWarnings:function(imgObj,canvas){
		if(imgObj && imgObj.type == "image"){
			
			var dpi=config.productDetails.dpi;
			var differenceZoneGap=config.productDetails.printProductBleedBean.bleedLeft+config.productDetails.printProductBleedBean.bleedRight;
			if(config.isPageRoundCorner == 'true'){
				differenceZoneGap=config.productDetails.printProductBleedRoundCornerBean.bleedLeft+config.productDetails.printProductBleedRoundCornerBean.bleedRight;
			}
			differenceZoneGap=differenceZoneGap/dpi;
			differenceZoneGap=Math.round(differenceZoneGap * 100) / 100;
			
			var warningFlags=config.productDetails.imageWarningFlags,
				productColorspace=config.productDetails.productColorspace,
				productWidth=parseFloat(config.productDetails.canvasWidth)+differenceZoneGap,
				productHeight=parseFloat(config.productDetails.canvasHeight)+differenceZoneGap,
				imgWidth=parseFloat(imgObj.originalWidth),
				imgHeight=parseFloat(imgObj.originalHeight),
				imgWidthInch=parseFloat(imgObj.widthInches);
				imgHeightInch=parseFloat(imgObj.heightInches);
				currentImgWidth=imgObj.getWidth(),
				currentImgFileType=imgObj.fileType,
				imgDpi=parseFloat(imgObj.imgDpi);
				inch='in',
				currentImgHeight=imgObj.getHeight();
				
			if(imgObj.userUploaded == 'true'){
			 imgObj.imgWarnings={};
				 if(warningFlags.colorspaceWarning && productColorspace && imgObj.colorSpace && productColorspace != imgObj.colorSpace){
					var editImageColorSpace = resourcesData.editImageColorSpace;
					editImageColorSpace=editImageColorSpace.replace("#0",imgObj.colorSpace).replace("#1",productColorspace);
					imgObj.imgWarnings.colorspace = editImageColorSpace;
	 			 }
				 if(warningFlags.resolutionWarning && currentImgFileType != 'pdf' && dpi && imgDpi && dpi != imgDpi){
					 var editImageResolution = resourcesData.editImageResolution;
					 editImageResolution=editImageResolution.replace("#0",imgDpi).replace("#1",imgWidthInch);
					 editImageResolution=editImageResolution.replace("#2",inch).replace("#3",imgHeightInch);
					 editImageResolution=editImageResolution.replace("#4",inch).replace("#5",dpi);
					 editImageResolution=editImageResolution.replace("#6",productWidth).replace("#7",inch);
					 editImageResolution=editImageResolution.replace("#8",productHeight).replace("#9",inch);
					 imgObj.imgWarnings.resolution = editImageResolution;
		 		 }
				 
				 if(warningFlags.resolutionWarning && currentImgFileType == 'pdf' && imgWidthInch != productWidth && imgHeightInch != productHeight){
					 var scalableImageResoulutionMsg = resourcesData.scalableImageResoulutionMsg;
					 scalableImageResoulutionMsg = scalableImageResoulutionMsg.replace("#0",imgWidthInch).replace("#1",inch);
					 scalableImageResoulutionMsg = scalableImageResoulutionMsg.replace("#2",imgHeightInch).replace("#3",inch);
					 scalableImageResoulutionMsg = scalableImageResoulutionMsg.replace("#4",productWidth).replace("#5",inch);
					 scalableImageResoulutionMsg = scalableImageResoulutionMsg.replace("#6",productHeight).replace("#7",inch);
					 imgObj.imgWarnings.resolution = scalableImageResoulutionMsg;
				 }
				 
				 if(warningFlags.placementWarning && FQD.message.checkForOuterside(imgObj) && !FQD.products.hasTemplateOverlay()){
					 var editImageClippingMayOccur = resourcesData.editImageClippingMayOccur;
					 imgObj.imgWarnings.placement = editImageClippingMayOccur;
				 }
				 
				 /*if(warningFlags.placementWarning && FQD.message.isObjOutSideCanvasArea(imgObj) && !FQD.products.hasTemplateOverlay()){
					 var outSideVisibleWarning = resourcesData.outSideVisibleWarning;
					 imgObj.imgWarnings.placement = outSideVisibleWarning;
				 }*/
				 
				 if(warningFlags.resizeWarning && (imgWidth < currentImgWidth || imgHeight < currentImgHeight)){
					 var editImageDistortionMayOccur = resourcesData.editImageDistortionMayOccur;
					 imgObj.imgWarnings.distortion = editImageDistortionMayOccur;
		 		 }
				 if(config.isImageWArnings){
					 FQD.message.setWarningIcon(imgObj,imgObj.imgWarnings,canvas);
				 }
				 
			}else{
				imgObj.clipArtWarnings={};
				if(warningFlags.resizeWarning && (imgWidth < currentImgWidth || imgHeight < currentImgHeight)){
					 var editImageDistortionMayOccur = resourcesData.editImageDistortionMayOccur;
					 imgObj.clipArtWarnings.distortion = editImageDistortionMayOccur;
		 		 }
				if(config.isImageWArnings){
				   FQD.message.setWarningIcon(imgObj,imgObj.clipArtWarnings,canvas);
				}
			}
		}
	},
	
	isObjOutSideCanvasArea:function(obj){
		var bleed	= (FQD.canvas.pages[config.activeCanvas]).getItemByName("canvasArea");
		var xArray	= [obj.oCoords.tl.x, obj.oCoords.tr.x, obj.oCoords.bl.x, obj.oCoords.br.x],
		 yArray		= [obj.oCoords.tl.y, obj.oCoords.tr.y, obj.oCoords.bl.y, obj.oCoords.br.y],
		 minX		= Math.round(xArray.min()),
		 minY		= Math.round(yArray.min()),
		 maxX		= Math.round(xArray.max())-1,
		 maxY		= Math.round(yArray.max())-1,
		 objW		= obj.getWidth(),
		 objH		= obj.getHeight(),
		 bleedX		= bleed.getLeft(),
		 bleedW		= bleed.getWidth(),
		 bleedH		= bleed.getHeight(),
		 bleedY		= bleed.getTop();
		if(maxX < bleedX || minX > (bleedX+bleedW) || minY > (bleedY+bleedH) || maxY < bleedY){
			return true;
		}else{
			return false;
		}
	},
	setWarningIcon:function(imgObj,warnings,canvas){
		jQuery("#"+imgObj.id).remove();
		if(!jQuery.isEmptyObject(warnings)){
			var list='<div id="'+imgObj.id+'" class="warning-msg" style="display: block;" onmouseenter="showImageWarnings(jQuery(this))" onmouseleave="hideImageWarnings(jQuery(this))" >';
			list +='<i class="fas fa-exclamation-triangle"></i>';
			list +='<div class="warningMsgContainer">';
		 list +="<ol>";
		 jQuery.each(warnings,function(k,d){
			 list +='<li>'+d+'</li>';
		 });
		 list+='</ol></div></div>';
		 jQuery(".canvas-container").eq(canvas.pageId).prepend(list);
		}
		var elm = document.getElementById(imgObj.id);
		setIconPosition(canvas,imgObj ,jQuery(elm));
	},
	
	objectOutsideSafeAndTrimZone:function(element)
	{
		if(FQD.products.hasTemplateOverlay()){
			return;
		}
		
	   	var trim = FQD.canvas.getTrimZone();
	   	
	   	if(FQD.canvas.getActiveObjects() || element != undefined){
	   		var obj = FQD.canvas.getActiveObjects();
   			obj = obj == undefined? element: obj;
   			if(obj == undefined)
   				return;
   			
	   		if(obj.templateObject == undefined && obj.templateObject != true)
   			{	
				/*
   				if(!obj.isContainedWithinObject(trim)){
					FQD.message.showWarning(FQD.message.bleedMsg);
					return true;
				}
 				*/
   				
   				if(!FQD.message.checkForOuterside(obj)){
   					FQD.message.hideWarning();
   				}
   			}
	   	}
	},
	
	checkForOuterside:function(obj)
	{
		var safe = FQD.canvas.getSafeZone();
		if((obj.type == "circle" || obj.type == "ellipse") && obj.angle != undefined && obj.angle > 0)
		{
			var bound = obj.getBoundingBox(FQD.canvas.pages[config.activeCanvas]);
			var rl, rt, rw, rh;
			rw = (obj.radius * obj.scaleX);
			rh = (obj.radius * obj.scaleY);
			rl = bound.topLeft.x;
			rt = bound.topLeft.y;
			
			var ro = FQD.message.ellipseBoundingBox(rl, rt, rw, rh, obj.angle);
			var strokeW = (obj.strokeWidth/2) * config.scaleMultiplier;
			var tempRect = new fabric.Rect({originX: 'left', originY: 'top', left:(ro.x-strokeW), top:(ro.y-strokeW), width:(ro.wid+strokeW*2), height:(ro.heg+strokeW*2)});
			tempRect.opacity = 0.5;
			FQD.canvas.pages[config.activeCanvas].add(tempRect);
			if(!tempRect.isContainedWithinObject(safe)){
				FQD.message.showWarning(FQD.message.safeMsg);
				tempRect.remove();
				return true;
			}
			tempRect.remove();
		}
		else if(!obj.isContainedWithinObject(safe)){
			if(obj.userUploaded == 'true' && (!config.isImageWArnings || config.isImageWArnings == null)){
				FQD.message.showWarning(FQD.message.safeMsg);
			}
			return true;
		}
		
		return false;
	},
	
	ellipseBoundingBox:function(eCX, eCY, eRX, eRY, eAngle)
	{
	    var angle = eAngle * Math.PI/180;
	    var a = eRX * Math.cos(angle);
	    var b = eRY * Math.sin(angle);
	    var c = eRX * Math.sin(angle);
	    var d = eRY * Math.cos(angle);
	    var wid = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2)) * 2;
	    var heg = Math.sqrt(Math.pow(c, 2) + Math.pow(d, 2)) * 2;
	    var x = eCX - wid * 0.5;
	    var y = eCY - heg * 0.5;
	    return ({x:x, y:y, wid:wid, heg:heg});
	}
};
