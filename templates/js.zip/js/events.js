/*******************************************************
 * 
 * Responsible to invoke methods for the events 
 * we are not going to write any method inside it.
 * 
 ****************************************************/

function getZoomCompensatedBoundingRect(fabricObject){
  //fabricObject is the object you want to get the boundingRect from
  fabricObject.setCoords();
  var boundingRect = fabricObject.getBoundingRect();
  var zoom = canvas.getZoom();
  var viewportMatrix = canvas.viewportTransform;
  
  //there is a bug in fabric that causes bounding rects to not be transformed by viewport matrix
  //this code should compensate for the bug for now
  
  boundingRect.top = (boundingRect.top - viewportMatrix[5]) / zoom;
  boundingRect.left = (boundingRect.left - viewportMatrix[4]) / zoom;
  boundingRect.width /= zoom;
  boundingRect.height /= zoom;
  
  return boundingRect;

}
FQD.events={};
FQD.events.init=function(){
	
	FQD.elements.divCanvasWrapper.delegate("canvas","mouseup",function(){
		FQD.canvas.setActiveCanvas(jQuery(this).prev().attr("id").replace("c",""));
	});
	
	
    jQuery(document).on('mouseup', function(evt) {
        if(evt.target.localName === 'canvas' && config.initialCanvas && config.isMoveing) {
            canvasId = jQuery(evt.target).siblings().attr('id');
            if(canvasId !== config.initialCanvas) {
            	var newY=evt.offsetY,newX=evt.offsetX;
				var z=FQD.canvas.pages[config.activeCanvas].getZoom();
					  FQD.canvas.pages[config.activeCanvas].setZoom(1);// reset canvas to get data in 100% zoom
					  	   
            	var objArray=[];
            	if(config.moveObject._objects){
            		FQD.canvas.removeSelection();
            		config.moveObject._objects.forEach(function(object) {
            		    	  object.set('canvas', FQD.canvas.pages[config.activeCanvas]);
            		    	  object.set('active', true);
            		    	  FQD.canvas.pages[config.activeCanvas].add(object);
            		    	  objArray.push(object);
            		    	  FQD.canvas.pages[parseInt(config.initialCanvas.replace("c",""))].remove(object);
            		      });
            		var group = new fabric.Group(objArray, {
		    			originX: 'left', 
		    			originY: 'top'
		    		});
            		group.set("canvas",FQD.canvas.pages[config.activeCanvas]);
            		FQD.canvas.pages[config.activeCanvas].setActiveGroup(group.setCoords()).renderAll();
            		FQD.canvas.getActiveObjects().set({left:newX,top:newY});
            		FQD.canvas.getActiveObjects().setCoords();
            		FQD.canvas.pages[config.activeCanvas].deactivateAll();
            	    FQD.canvas.pages[config.activeCanvas].discardActiveGroup();
            	}else{
            		console.log(config.moveObject);
                	config.moveObject.set('canvas', FQD.canvas.pages[config.activeCanvas]);
                	config.moveObject.set({left:newX,top:newY});
                	config.moveObject.setCoords();
                    FQD.canvas.pages[config.activeCanvas].add(config.moveObject);
                    FQD.canvas.pages[parseInt(config.initialCanvas.replace("c",""))].remove(FQD.canvas.pages[parseInt(config.initialCanvas.replace("c",""))].getActiveObject());
                    FQD.canvas.removeSelection();
            	}
            	FQD.canvas.pages[config.activeCanvas].setZoom(z); // zoom canvas as per previous value again
                FQD.canvas.pages[config.activeCanvas].renderAll();
                FQD.canvas.pages[parseInt(config.initialCanvas.replace("c",""))].renderAll();
                FQD.elements.divTabContainer.find("li a").removeClass("selected");
                FQD.elements.divTabContainer.find("li a").eq(config.activeCanvas).addClass("selected");
                FQD.undoManager.saveHistory(true);
            }
        }
        
        if(evt.target.localName !== 'canvas') {
	    	FQD.elements.divContextMenu.hide();
	    }
        
        config.initialCanvas = '';
        config.moveObject  = {};  
        config.isMoveing=false;
    }); 

    
    jQuery("#qd-wrapper").mouseup(function(e){
    	jQuery(".button-menu").hide();
    	if(config.textChanged){
    		//FQD.templateDataTransfer.setTaggedElementsInAllPages(config.lastSelectedTextElement);
	   		FQD.undoManager.saveHistory(true);
	   		config.textChanged=false;
	   	}
    	if(jQuery(e.target).closest("#divCanvasMenu").length == 0){
    		FQD.visualAids.showAndClose('divCanvasMenu','close');
    	}
    });
	
	FQD.elements.divCanvasWrapper.delegate("canvas","contextmenu",function(event){
		 event.preventDefault();
		 FQD.utility.showContextMenu(event);
	});
	FQD.elements.divCanvasWrapper.delegate("canvas","dblclick",function(event){
		 FQD.utility.dblClickCallback(event);
	});
	
	
	FQD.events.toEvents=function(that){
		var id=that.attr("id");
		if(id !="paper-zoom-less" &&  id !="paper-zoom-plus"){
			jQuery(".selected-tool").removeClass("selected-tool");
		}
		FQD.events.allActions(id);
	}
	
	jQuery(".text-edit-tool .t").click(function(){
			var s=jQuery(this).attr("size");
			FQD.shapes.newText(s);
	});
	
	FQD.elements.divTool.delegate("a","click",function(e){
		var id=jQuery(this).attr("id");
		if(id !="paper-zoom-less" &&  id !="paper-zoom-plus"){
			FQD.elements.divTool.find("a").removeClass("selected-tool");
		}
		FQD.events.allActions(id);
	});
	
	
	
	jQuery("#elemet-editor-container").delegate("#textStyleProp li","click",function(e){
		e.stopPropagation();
		FQD.events.allActions(jQuery(this).attr("id"),this);
	});	
	FQD.elements.divRightBar.delegate("#textStyleProp .symbols-div","mouseover",function(){
		jQuery(this).find("#special").show();
	});
	FQD.elements.divRightBar.delegate("#textStyleProp .symbols-div","mouseout",function(){
		jQuery(this).find("#special").hide();
	});
	jQuery(document).on("click",function(event){
		if(event.target.localName === 'canvas'){
			FQD.events.getOnFocusText();
		}
	});
	
	FQD.elements.divRightBar.delegate("#symbols","mouseover",function(){
		FQD.events.getOnFocusText();
	});
	
	jQuery("#elemet-editor-container").delegate("#special li","click",function(){
		 var specialChar = jQuery(this).text();
		 var flag = false;
		 
		 if(FQD.canvas.getActiveObjects()._objects){
			var i=0,len=FQD.canvas.getActiveObjects()._objects.length;
			for(i; i<len; i++){
	    		if(FQD.canvas.getActiveObjects()._objects[i].type == "textbox"){
	    			FQD.shapes.addSymboleInTextElement(FQD.canvas.getActiveObjects()._objects[i], specialChar, false);
	    			flag = true;
	    		}
	    	}
		}else if(FQD.canvas.getActiveObjects().type == "textbox"){
			FQD.shapes.addSymboleInTextElement(FQD.canvas.getActiveObjects(), specialChar, true);
			flag = true;
		}
		 
		if(flag){			
			FQD.canvas.pages[config.activeCanvas].renderAll();	
			FQD.undoManager.saveHistory(true);
		 }		 	
	});
	
	FQD.elements.divHeader.delegate("input,button,li","click",function(){
		FQD.events.allActions(jQuery(this).attr("id"));
	});
	
	FQD.elements.divImgLib.delegate(".imgTabs li","click",function(){
			FQD.elements.divImgLib.find(".imgTabs li").removeClass("active");
			FQD.elements.divImgLib.find(".imgTabContent").hide();
			jQuery(".imgTabContent").eq(jQuery(this).index()).show();
			jQuery(this).addClass("active");
			FQD.elements.buttonApplyBg.show();
			if(jQuery(".imgTabs .active").attr("id")=="clipArtCategory"){
				FQD.elements.buttonApplyBg.hide();
			}
			FQD.elements.divImgLib.find("li").removeClass("selected");
			jQuery("#fileUploadWrapper div").find("input[type='checkbox']").prop("checked",false).removeClass("checked");
			FQD.imgLib.selectedImg="";
	});
	
	FQD.elements.divAdminPopup.delegate("ul.tabs li","click",function(){
		FQD.elements.divAdminPopup.find(".tabs li").removeClass("active");
		FQD.elements.divAdminPopup.find(".tabContent").hide();
		FQD.elements.divAdminPopup.find("#"+jQuery(this).attr("rel")).show();
		jQuery(this).addClass("active");
	});

	FQD.elements.spanCloseWindow.click(function(){
		FQD.events.closePopup(jQuery(this));
		config.hasPreviewState = false;
	});
	
	FQD.elements.divAdminTools.click(function(){
		FQD.helper.getProductsSizeDetails();
		FQD.importSvg.addSVG();
		FQD.importSvg.addJSON();
		FQD.elements.divOverlay.show();
		FQD.elements.divAdminPopup.show();
	});
	
	FQD.elements.divTabContainer.delegate("li","click",function(){
		FQD.events.tabs(jQuery(this).index());
	});
	
	jQuery("#elemet-editor-container").delegate("#applyobj","click",function(){
	    FQD.utility.setObjTranslation();
	    FQD.message.objectOutsideSafeAndTrimZone();
	});
	

	FQD.elements.userLoginWindow.delegate("#resetPassword","click",function(){
		config.stopRedirect=true;
	    FQD.utility.resetPassword();
	});
    FQD.elements.userLoginWindow.delegate("#createAccount","click",function(){
    	config.stopRedirect=true;
    	FQD.elements.userLoginWindow.dialog("close");	
    	FQD.utility.SignUp();
	});
    
    	window.onresize=function(e){
        	if(e.isTrusted){
        		resizeWindow();
        	}
        	if (!e.isTrusted){
        		   clearTimeout(this._timer);
        		   this._timer = setTimeout(function(){  jQuery(window).trigger('resize'); }, 250);
        	}
        
        }
    

    
    jQuery("#objectDetail").delegate(".bars","mousedown",function(){
    	jQuery(this).parent().find(".info-wrapper").toggle("fast");
    });
    
    jQuery(".res-btm-menu").click(function(){
    	jQuery(".res-btm-tools").toggle("fast");
    });
    
    jQuery(".res-tab-container").click(function(){
    	var tabContainer=jQuery("#tab-container");
    	tabContainer.toggle("fast");
    	var visibleTabs = jQuery("#tab-container li:visible").length;
    	if(visibleTabs == 1){
    		tabContainer.css("left", "575px");
    	}else{
    		tabContainer.css("left","545px");
    	}
    });
    
    jQuery("#elemet-editor-container").delegate("#res-menu","mousedown",function(){
    	responsiveMenu(jQuery(this));
    });
    
    jQuery("#align-tools").delegate("#alignObjtoggleTcon","mousedown",function(){
    	jQuery(this).parent().find("#divObjAllign").toggle("fast");
    });
 // to set scroller width and height
	
    jQuery("#bg-properties,#right-bar,#enter-text").click(function() {
      
    	  jQuery("#bg-properties,#right-bar,#enter-text").css('z-index','1');
    	  jQuery(this).css('z-index','2');
    
     });
    jQuery("#right-bar,#enter-text").delegate(" h4 span", "click", function() {
    	jQuery(this).parent().next("div").slideToggle("fast");
		   if(jQuery(this).find("i").hasClass("fa-minus-circle")){
			   jQuery(this).find("i").removeClass("fa-minus-circle").addClass("fa-plus-circle");
		   }else{
			   jQuery(this).find("i").removeClass("fa-plus-circle").addClass("fa-minus-circle"); 
		   }
	       
      });
    jQuery("#bg-properties").delegate(" h4 span", "click", function() {
    	jQuery("#bg-contents, #bg-content").slideToggle("fast");
    	jQuery("#dvBgImgDirn").slideToggle("fast");
          if(jQuery(this).find("i").hasClass("fa-minus-circle")){
        	  jQuery(this).find("i").removeClass("fa-minus-circle").addClass("fa-plus-circle");
		   }else{
			   jQuery(this).find("i").removeClass("fa-plus-circle").addClass("fa-minus-circle"); 
		   }
      });
      
     jQuery("#header").delegate("#header-menu .menu","click",function(){
    	 FQD.events.showHideLeftButtons(jQuery(this));
     });

 
   
     /* added events for new layout */
     
     var headHeight=jQuery("#header").height();
     var h = jQuery(window).height()-headHeight-20;
     var w  = jQuery(window).width()-config.leftEditorWidth;
     //jQuery("#main-container").width(w);
     //jQuery("#main-container").height(h+60);
     jQuery("#editor-panel-container").height(h);
     jQuery(".shape-content,.category-container").height(h-60);
     jQuery('.dropdown ul').perfectScrollbar();
     jQuery("#left-tool-bar").css("margin-top",(headHeight)+"px");
     jQuery("#qd-wrapper").height(jQuery(window).height());
     jQuery("input[type=checkbox]").switchButton({
           show_labels: false,
           width: 50,
           height: 20,
           button_width: 20
         });
     
     
     jQuery("#left-tool-bar li").mousedown(function(){
     	openEditorPanel(jQuery(this));
     });

        jQuery(".close-edit-panel").mousedown(function(){
            closeEditPanel();
        });
     
     jQuery.each(jQuery(".design-templates .parent-category-label"),function(i){
         jQuery(this).parent().attr("id","pc"+i);  
     });
     
     jQuery.each(jQuery(".design-templates .child-category-label"),function(i){
         jQuery(this).parent().attr("id","cc"+i);
     });
     
     jQuery(".design-templates .parent-category .parent-category-label").click(function(event){
         var that=jQuery(this); 
         if(that.parent().hasClass("active-category")){
             that.parent().find(".category-list").slideUp(function(){
                 that.find("i").html("keyboard_arrow_down");
                 that.parent().removeClass("active-category");
                 //TweenLite.to(jQuery(".design-templates"), 1, {scrollTo:"#"+that.parent().attr("id")});
                 jQuery(".design-templates").perfectScrollbar('update');
             });
         }else{
             that.parent().find(".category-list").slideDown(function(){
                 that.find("i").html("keyboard_arrow_up");
                 that.parent().addClass("active-category");
                 //TweenLite.to(jQuery(".design-templates"), 1, {scrollTo:"#"+that.parent().attr("id")});
                 jQuery(".design-templates").perfectScrollbar('update');
             });
         }   
         
     });
     
     
     jQuery(".shape-edit-tool").delegate(".shape-lib-head","click",function(event){
         var that=jQuery(this); 
         if(that.hasClass("active-shape")){
        	 that.next(".svg-shape").slideUp("fast");
        	 that.find("i").addClass("fa-caret-left").removeClass("fa-caret-down");
        	 that.removeClass("active-shape");
         }else{
        	 that.next(".svg-shape").slideDown("fast");
        	 that.find("i").addClass("fa-caret-down").removeClass("fa-caret-left");
        	 that.addClass("active-shape");
         }
     });
     
     jQuery(".more-horiz").click(function(){
    	 var currentElm=jQuery(this).parent();
    	 if(!currentElm.hasClass("show-labels")){
    		 currentElm.addClass("show-labels");
    		 currentElm.find("li").removeClass("masterTooltip");
    		 config.showLeftMenuLabels=true;
    	 }else{
    		 currentElm.removeClass("show-labels");
    		 currentElm.find("li").addClass("masterTooltip");
    		 config.showLeftMenuLabels=false;
    	 }
    	 if(typeof Storage  != "undefined"){
    		 localStorage.setItem('showLeftMenuLabels', config.showLeftMenuLabels);
		 }
    	 var position = jQuery("#editor-panel-container").position();
    	 if(position.left > 0){
    		 animateLeftEditorMemu(true);
    	 }else{
    		 animateLeftEditorMemu(false);
    	 }
     });
     
     FQD.elements.divCanvasWrapper.delegate(".canvas-container","dragover",function(event){
		 event.preventDefault();
     });
     
     FQD.elements.divCanvasWrapper.delegate(".canvas-container","drop",function(event){
		 event.preventDefault();
		 var dragItemId = config.dragItemId;
		 if(dragItemId){
			 var dragItem = jQuery("#"+dragItemId);
			 if(dragItem.hasClass("svg")){
				 FQD.shapeLib.appendElement(event,dragItem);
			 }
			 else if(dragItem.attr("useruploaded") == "true"){
				 FQD.imgLib.setSelectedImg(dragItem);
			 }
			 else{
				 var dragItemType = dragItem[0].attributes["rel"].value;
				 if(dragItemType == "template-item"){
					 FQD.templateDataTransfer.getTemplateJSON(dragItem[0].parentElement.id);
				 }else if(dragItemType == "template-single-page"){
					 FQD.templateDataTransfer.getTemplateJSON(dragItem[0].getAttribute("templateId"));
				 }else{
					 FQD.imgLib.setSelectedImage(dragItem, 'previewsrc', 'selected');
				 }
			 }
		 }
		 config.dragItemId=null;
     });
     
     /* added events for new layout end */
     
     jQuery("#editor-panel-container").mousedown(function(){
    	 jQuery(".showThumbPreviewImage").remove();
     });
     
     jQuery("#container,#bottom-panel,#left-tool-bar,#header").mouseover(function(){
    	 jQuery(".showThumbPreviewImage").remove();
     });
     
     jQuery("#help-content").delegate("li a.ulCategory", "click" ,function(event){
    	 if(!jQuery(this).hasClass("b")){
    		 jQuery("#help-content li a.ulCategory i").html("add_circle_outline");
    		 FQD.imgLib.showHideSubCategory(jQuery(this).find("i"));
        	 jQuery(".help-text").slideUp();
        	 jQuery("#help-content li a.ulCategory").removeClass("b");
        	 jQuery(this).next(".help-text").slideDown();
        	 jQuery(this).addClass("b");
    	 }
     });
     
     jQuery("#header").delegate("#file_menu","mouseover",function(){
    	 isSessionChanged(); 
     });
     jQuery.ajaxSetup({
    	    // Disable caching of AJAX responses
    	    cache: false
    	});
}

FQD.tips={
	showTips:true,
	tipsCount:0,
	yes:function(){
		this.tipsCount=1;
		FQD.tips.gotToNextBubble(this.tipsCount);
	},
	open:function(btn){
		var tipsBubble=jQuery("#tips-bubble");
		tipsBubble.removeAttr("style");
		tipsBubble.removeAttr("class");
		tipsBubble.find(".tutorial").hide();
		tipsBubble.find("#bubbleSlides").hide();
		if(btn && btn.hasClass("on")){
			jQuery("#tipsButton").addClass("off").removeClass("on");
			jQuery("#tips-bubble").fadeOut();
		}else{
			jQuery("#tipsButton").addClass("on").removeClass("off");
			if(!config.isDesignForPreviewOnly && !config.productDetails.adminOpenedSavedDesign){
				jQuery("#tips-bubble").fadeIn();
			}
			
		}
		
		if(config.isServerPreviewOn){
			tipsBubble.css("z-index","9999");
			tipsBubble.addClass("tips-preview");
			tipsBubble.find("#tutorial-on-preview").show();
		}else{
			tipsBubble.css("z-index","99");
			tipsBubble.addClass("tips-0");
			tipsBubble.find("#tutorial-0").show();
		}
		loadLocaleData();
	},
	close:function(){
		FQD.tips.tipsCount=0;
		jQuery("#tips-bubble").fadeOut().css("z-index","99");
		jQuery("#tipsButton").addClass("off").removeClass("on");
	},
	gotToNextBubble:function(slide){
		if(slide){
			var tipsBubble=jQuery("#tips-bubble"),
				tutorial=tipsBubble.find("#tutorial-"+slide);
				id="#"+tutorial.attr("rel"),
			tipsBubble.removeAttr("class");
			tipsBubble.addClass("tips-"+slide);
			tipsBubble.find(".tutorial").hide();
			tutorial.show();
			tipsBubble.find("#bubbleSlides").show();
			tipsBubble.find(".current-slide").html(slide);
			if(slide == 1){
				tipsBubble.find(".prev-slide").hide();
			}else{
				tipsBubble.find(".prev-slide").show();
			}
			if(slide == 6){
				tipsBubble.find(".next-slide").hide();
			}else{
				tipsBubble.find(".next-slide").show();
			}
			FQD.tips.setBubblePosition(slide);
		}
	},
	setBubblePosition:function(slide){
		var tipsBubble=jQuery("#tips-bubble"),
		tutorial=tipsBubble.find("#tutorial-"+slide),
		id="#"+tutorial.attr("rel"),
		offset=jQuery(id).offset(),
		l= offset.left,
		t = offset.top;
		if(slide == 2 || slide == 3){
			tipsBubble.css("left",(l-15)+"px");
		}else{
			tipsBubble.removeAttr("style");
		}
	},
	next:function(){
		this.tipsCount++;
		FQD.tips.gotToNextBubble(this.tipsCount);
	},
	prev:function(){
		this.tipsCount--;
		FQD.tips.gotToNextBubble(this.tipsCount);
	},
	enableTips:function(checked){
		if(checked){
			FQD.tips.showTips=false;
		}else{
			FQD.tips.showTips=true;
		}
		if(typeof Storage  != "undefined"){
			localStorage.setItem('showTutorialTips',FQD.tips.showTips);
		}
	}
	
}

function showDefaultMenuLabels(){
	if(typeof Storage  != "undefined"){
		
		var showTutorialTips=localStorage.getItem('showTutorialTips');
			if(showTutorialTips === "true"){
				FQD.tips.showTips=true;
			}else if(showTutorialTips === "false"){
				FQD.tips.showTips=false;
				jQuery("#turnOnOffTips").prop("checked",true);
			}
			if(FQD.tips.showTips && !config.productDetails.isAdmin){
				if(!config.isDesignForPreviewOnly && !config.productDetails.adminOpenedSavedDesign){
					jQuery("#tips-bubble").fadeIn();
				}
			}else{
				jQuery("#tipsButton").addClass("off").removeClass("on");
			}
		 var showLeftMenuLabels = localStorage.getItem('showLeftMenuLabels');
		 if(showLeftMenuLabels === "true"){
			 config.showLeftMenuLabels=true;
			 loadLocaleData();
			 jQuery("#left-tool-bar").addClass("show-labels");
			 
			 var leftMenuWidth = jQuery("#left-tool-bar").width(),
		  	     w  = jQuery(window).width()-leftMenuWidth;
			 jQuery("#bottom-panel").css({width:w+"px","margin-left":leftMenuWidth+"px"});	
		 }else if(showLeftMenuLabels === "false"){
			 config.showLeftMenuLabels=false;
			 jQuery("#left-tool-bar").removeClass("show-labels");
		 }
		 config.isImageWArnings = localStorage.getItem('isImageWArnings');
		 if(config.isImageWArnings){
			 jQuery("#imageWarningFlag").prop("checked",true);
		 }
	}
}


config.hasToolTip=true;
function initToolTip(){
	if(config.hasToolTip){
		jQuery('.masterTooltip').hover(function(){
	    	if(!jQuery(this).parent().parent().hasClass("show-labels")){
	    		var title = jQuery(this).attr('title');
	    		var pMode=jQuery(this).find("#previewMode").prop("checked");
	    		if(pMode){ 
	    			title=resourcesData.hideOverFlow; 
	    		}else if(pMode === false){
	    			title=resourcesData.showOverflow; 
	    		}
	    		
		        jQuery(this).data('tipText', title).removeAttr('title');
		        jQuery('<p class="tooltip"></p>')
		        .html(title)
		        .appendTo('body')
		        .fadeIn('slow');
	    	}
	            
	    }, function() {
	            jQuery(this).attr('title', jQuery(this).data('tipText'));
	            jQuery('.tooltip').remove();
	    }).mousemove(function(e) {
	            var mousex = e.pageX + 20,
	                mousey = e.pageY - 50; 
	                ww=jQuery(document).width(),
	                wh=jQuery(document).height();
	                tw=jQuery(".tooltip").width()
	            if(mousex > (ww-tw-100)){
	            	mousex = e.pageX -tw;
	            }
	            jQuery('.tooltip')
	            .css({ top: mousey, left: mousex })
	    });
		config.hasToolTip=false;
	}
}


function validateInputNumber(event) {
	  var key = window.event ? event.keyCode : event.which;
	  if (event.keyCode == 8 || event.keyCode == 46
	   || event.keyCode == 37 || event.keyCode == 39) {
	      return true;
	  }
	  else if ( key < 48 || key > 57 ) {
	      return false;
	  }
	  else return true;
	}

function constrainBtnScale(){
	if(FQD.elements.objectWidth.attr("disabled"))
		return;
	
	if(FQD.shapes.constrainScale){
		FQD.shapes.constrainScale = false;
		jQuery("#constrainBtn").find("i").removeClass("fa-link");
		jQuery("#constrainBtn").find("i").addClass("fa fa-unlink");
	}else{
		FQD.shapes.constrainScale = true;
		jQuery("#constrainBtn").find("i").removeClass("fa-unlink");
		jQuery("#constrainBtn").find("i").addClass("fa-link");
	}
	FQD.canvas.updateTransformControls();
}

function responsiveMenu(elm){
	var hasClass= elm.hasClass("active");
	if(hasClass){
		elm.removeClass("active");
		jQuery("#common-properties, #opacity-properties,#colorWithPickerProp").removeAttr("style");
    	if(config.activElm.type == "textbox"){
    		jQuery("#sel-font-size,#textStyleProp,#special-text-content,#text-align").removeAttr("style");
    	}
	}else{
		elm.addClass("active");
		jQuery("#common-properties, #opacity-properties,#colorWithPickerProp").attr("style","display:block !important");
		if(config.activElm.type == "textbox"){
    		jQuery("#sel-font-size,#textStyleProp,#special-text-content,#text-align").attr("style","display:block !important");
    	}
	}
}

function resizeWindow(){
	if(config.loaded){
		if(jQuery(window).width() > 560){
			FQD.canvas.removeSelection();
			var h = jQuery(window).height()-jQuery("#header").height()-20;
			jQuery("#editor-panel-container").height(h);
		    jQuery(".text-edit-tool").height(h-50);
		    jQuery(".image-edit-tool").height(h-50);
		    jQuery("#template-list,#clipart-list,.bg-panel,.shape-content").height(h-50);
			closeEditPanel();
			FQD.events.setScroller();
			sw = FQD.elements.divScroller.width();
			sh = FQD.elements.divScroller.height();
			setElementEditorResponsive(sw);
			if(config.autoZoom){
				FQD.canvas.resetCanvasAsPerWindowSize();
				jQuery(".ruler-wrap-top").width(sw-19);
				jQuery(".ruler-wrap-left").height(sh-19);
				FQD.canvas.resetZoom(jQuery('#zoom-level'));
			}
			
		}
	}
}




function setElementEditorResponsive(sw){
	var resCommon=jQuery("#res-menu,#common-properties"),
	op=jQuery("#opacity-properties"),
	cow=jQuery("#colorWithPickerProp"),
	spt=jQuery("#special-text-content"),
	ta=jQuery("#text-align"),
	tst=jQuery("#textStyleProp,#special-text-content,#text-align"),
	st=jQuery("#special-text-content,#text-align"),
	sf=jQuery("#sel-font-size");
	
	if(sw > 1200){
		jQuery("#res-menu").removeClass("abs");
		resCommon.removeClass("abs");
		op.removeClass("abs");
		cow.removeClass("abs");
		spt.removeClass("abs");
		ta.removeClass("abs");
		ta.removeClass("abs");
		tst.removeClass("abs");
		tst.removeClass("abs2");
		st.removeClass("abs2");
		st.removeClass("abs3");
		sf.removeClass("abs");
		jQuery("#tab-container").removeAttr("style");
	}
	if(sw < 1200){
		resCommon.addClass("abs");
	}
	if(sw < 1260){
		jQuery(".res-btm-tools,#tab-container").removeAttr("style");
	}
	if(sw < 1045){
		op.addClass("abs");
	}
	if(sw < 968){
		if(jQuery("#enableobjectProperties").prop("checked")){
			cow.addClass("abs2");	
		}else{
			cow.addClass("abs");	
		}
		
	}
	if(sw < 910){
		spt.addClass("abs");
	}
	if(sw < 815){
		ta.addClass("abs");
	}
	if(sw < 740){
		tst.removeClass("abs").addClass("abs2");
	}
	if(sw < 607){
		st.removeClass("abs2").addClass("abs3");
	}
	if(sw < 559){
		sf.addClass("abs");
	}
	
}

function openEditorPanel(that){
	FQD.canvas.removeSelection();
	FQD.shapes.showEditProperties();
	config.leftEditorWidth=300;
	if(that.attr("id") == "up-image"){
		config.leftEditorWidth=400;
	}
	jQuery("#editor-panel-container").width(config.leftEditorWidth);
    var rel=that.attr("rel");
    if(that.hasClass("active")){
        closeEditPanel();
    }else{
        jQuery("#left-tool-bar li").removeClass("active");
        that.addClass("active");
        jQuery("#editor-panel-container .left-editor-content").hide();
        jQuery("#editor-panel-container").find("."+rel).show();
        animateLeftEditorMemu(true);
        var title_text = jQuery(that).html();
        jQuery(".tool-title").html(title_text);
    }
    jQuery("#select").trigger("click");
}


function closeEditPanel(){
    jQuery("#left-tool-bar li").removeClass("active");
    config.leftEditorWidth=300;
    jQuery("#editor-panel-container").width(config.leftEditorWidth);
    animateLeftEditorMemu(false);
}


function isSessionChanged(callback){
	var loggedIn=FQD.saveDesign.isUserLoggedIn();
	if(loggedIn =='true'){
		loggedIn=true;
	}else{
		loggedIn=false;
	}
	if(loggedIn != config.IsUserLoggedIn){
		config.isSessionChanged=true;
		customAlertBox('confirm',"Cancel","Ok",fqdSessionLogoutMessage,function(result){
			location.reload();
		});
		jQuery('#customCancelBtn').hide();
	}else if(callback){
		callback();
	}
}


function animateLeftEditorMemu(open){
	config.leftPanelOpen = open;
	var leftMenuWidth=jQuery("#left-tool-bar").width(),
 	leftEditorWidth=config.leftEditorWidth,
 	w  = jQuery(window).width()-leftEditorWidth-leftMenuWidth-40,
 	leftPos=leftEditorWidth+leftMenuWidth+40;
	jQuery("#elemet-editor-container").css("margin-left","0px");
	if(open){
		jQuery("#editor-panel-container").css({left:leftMenuWidth+"px",opacity:"1"});
        jQuery("#main-container").css({left:(leftPos-40)/2+'px',width:w+"px"});
        jQuery("#elemet-editor-container").width(w);
        jQuery("#bottom-panel").css({width:w+"px","margin-left":"0px"});
        jQuery(".ruler-wrap-left,.ruler-corner").css("left",leftPos+"px");
	}else{
		w  = jQuery(document).width()-leftMenuWidth;
		jQuery("#editor-panel-container").css({left:-leftEditorWidth+'px',opacity:"0"});
		jQuery("#main-container").css({left:'-1px',width:"100%"});
		jQuery(".ruler-wrap-left,.ruler-corner").css("left",leftMenuWidth+"px");
	    jQuery("#elemet-editor-container").width(w);
	    jQuery("#bottom-panel").css({width:w+"px","margin-left":leftMenuWidth+"px"});
	    jQuery("#elemet-editor-container").css("margin-left",leftMenuWidth+"px");
	  }
	setElementEditorResponsive(w);
	if(jQuery("#tipsButton").hasClass("on") && (FQD.tips.tipsCount == 2 || FQD.tips.tipsCount == 3)){
		setTimeout(function(){FQD.tips.setBubblePosition(FQD.tips.tipsCount);},300)
		
	}
}


function initFonts(){
    jQuery('.dropdown .dropdown-item-list').perfectScrollbar();
    jQuery(".dropdown").click(function(event){
        var that=jQuery(this), currentElm = event.target, currentElmName=currentElm.nodeName;
        if(currentElmName == "LI" && !jQuery(currentElm).hasClass("slider-l") && jQuery(currentElm).parent().attr("class") != "special-list"){
            var t = jQuery(currentElm).html(),
                f = jQuery(currentElm).css("font-family");
              that.find(".dropdown-item span").html(t);
              if(that.attr("id")=="sel-fonts"){
                  that.find(".dropdown-item span").css("font-family",f);
               }
        }
        jQuery(".dropdown").removeClass("active");
        if(config.isClosed){
        	    delete config.isClosed;
        	    return;
        }
        jQuery(this).addClass("active");
        jQuery(".dropdown-item-list").mouseleave(function(){
        	if(!that.is("#obj-align")){
        		jQuery(".dropdown").removeClass("active");
        	}else{
        		jQuery("#obj-align.dropdown").addClass("active");
        	}
        });
    });
}

FQD.events.slideLeftButton=true;
FQD.events.showHideLeftButtons=function(that){  
	if(!FQD.events.slideLeftButton){
		return;
	}
	FQD.events.slideLeftButton=false;
	 if(that.parent('.menu-slider').css("left") != "0px"){
		 jQuery(".menu-slider").animate({left:'-760px'},"slow",function(){
			 that.parent('.menu-slider').show().animate({left:'0'},function(){
				 jQuery(".menu-slider .menu").removeClass("active");
				 jQuery(".menu-slider .menu").find("i").removeClass(" fa-chevron-circle-up").addClass(" fa-chevron-circle-down");
				 that.addClass('active');
				 that.find("i").removeClass(" fa-chevron-circle-down").addClass(" fa-chevron-circle-up");
				 FQD.events.slideLeftButton=true;
				
				 // to show first category selected
				var elm=jQuery(that).next(".category-container").find(".category-list"),
				    listFlag=true;
				 jQuery.each(elm.find("ul.categoryList ul"),function(i){
					 if(jQuery(this).css("display") == 'block'){
						 listFlag=false;
					 }
				 });
				 if(listFlag){
					 elm.find("li").eq(0).trigger("click");
					 FQD.imgLib.attachEvent(elm.find("li").eq(0).next("ul").find("li").eq(0).find("a"));
				 }
			 });
    	 });
	 }else{
		 that.parent('.menu-slider').animate({left:'-760px'},function(){
			 that.removeClass('active');
			 that.find("i").removeClass(" fa-chevron-circle-up").addClass(" fa-chevron-circle-down");
			 FQD.events.slideLeftButton=true;
		 });
		 
	}
	 jQuery("#select").trigger("click");
		if(!config.isSwapInitiate && !config.isDoubleClicked){
			FQD.canvas.removeSelection();
			delete config.placerHolderObject.elm;
		}
	    delete config.isDoubleClicked;
}

FQD.events.getOnFocusText=function(){
	if(jQuery("textarea[autocapitalize='off']").is(":focus")){
		jQuery("textarea[autocapitalize='off']").attr("id","fbText");
		config.cursorPos=getCursorPos(document.getElementById("fbText")).end;
	}
}

FQD.events.showAllCanvas=function(element){
	if(!element.hasClass("show-all")){
		element.addClass("show-all");
		jQuery(".canvas-container").show();
		jQuery(".canvas-container").css("margin-bottom", "20px");
		element.html('<i class="fa fa-eye fa-2x" aria-hidden="true"></i>');
		element.attr("title", "Show Active Canvas");
		config.showAllCanvas=true;
	}else{
		element.removeClass("show-all");
		jQuery(".canvas-container").hide();
		jQuery(".canvas-container").css("margin-bottom", "0px");
		jQuery(".canvas-container").eq(config.activeCanvas).show();
		element.html('<i class="fa fa-eye-slash fa-2x" aria-hidden="true"></i>');
		element.attr("title", "Show All Canvas");
		config.showAllCanvas=false;
	}
}
// to set scroller width and height
config.load=true;
FQD.events.setScroller=function(){
	if(config.layout == "large")
	{
		var w = jQuery(window).width(),
		 	h = jQuery(window).height(),
		 	hh=jQuery("#header").height(),
		 	leftToolBarWidth = jQuery("#left-tool-bar").width(),
		 	editorPanelWidth = config.leftEditorWidth + 40,
		 	bottomPanleHeight = hh+jQuery("#bottom-panel").height() + 12;
		
		if(config.showLeftMenuLabels){
			leftToolBarWidth=leftToolBarWidth-40;
		}
		w = w-leftToolBarWidth;
	
		if(config.leftPanelOpen){
			w = w - editorPanelWidth;
			FQD.elements.divScroller.css("margin-left","0px");
		}else{
			FQD.elements.divScroller.css("margin-left", leftToolBarWidth + "px");
		}
		
		FQD.elements.divScroller.width(w);
		FQD.elements.divScroller.height(h-bottomPanleHeight);
		jQuery('.previewImgContainer').height(h-hh);
		   var res=FQD.preview.Responsive();
		   var imgWidth=res.imgWidth;
		   var imgHeight=res.imgHeight;
		   jQuery(".previewImgContainer img").width(imgWidth);
		   jQuery(".previewImgContainer img").height(imgHeight);
		
		jQuery("#elemet-editor-container").width(w);
		if(config.load){
			jQuery("#bottom-panel").width(w+leftToolBarWidth);
			config.load=false;
		}
		
		FQD.elements.divCanvasWrapper.width(w);
		FQD.elements.divCanvasWrapper.height(h-bottomPanleHeight);
		
		jQuery("#qd-wrapper").height(jQuery(window).height());
	}
}

FQD.events.closePopup=function(span){
	FQD.elements.divOverlay.hide();
	span.parent().hide();
	jQuery(".zoomContainer").remove();
}

FQD.events.tabs=function(index){
	var selectedTool= config.selectedTool;
	var that=FQD.elements.divTabContainer.find("li").eq(index);
	if(!that.find("a").hasClass("selected")){
		jQuery("#objInfo input").attr("disabled","disabled");
		if(config.selectedTool !== "dropper"){
			FQD.canvas.removeSelection(config.activeCanvas);
		}
		var index=that.index();
		FQD.elements.divTabContainer.find("li a").removeClass("selected");
		that.find("a").addClass("selected");
		if(!config.showAllCanvas){
			FQD.elements.divCanvasWrapper.find(".canvas-container").hide();
			FQD.elements.divCanvasWrapper.find(".canvas-container").eq(index).show();
		}
		FQD.canvas.setActiveCanvas(index);
		var bgColor=FQD.canvas.pages[index].getItemByName("canvasArea").getFill();
		FQD.elements.inputColorB.spectrum("set",bgColor);
		jQuery("#colorB2").spectrum("set",bgColor);
		jQuery("#bg-bucket").css("color",bgColor);
		var bgImg=FQD.canvas.pages[index].getItemByName("bgElement");
		FQD.shapes.showEditProperties();
		if(bgImg){
			FQD.imgLib.disableEnableBgTools(bgImg);
		}else{
			FQD.imgLib.disableEnableBgTools(false);
		}
		FQD.canvas.addNewText();
		FQD.events.updateRulerPosition();
	}
	if(selectedTool == "pan"){
		config.selectedTool=selectedTool;
	}
}

FQD.events.updateRulerPosition = function(){
	if(FQD.PrintProductType.isFolder()){
		var curLeft = parseInt(($("#topRuler").css("margin-left")).replace("px", ""));
		var leftDiff = curLeft - config.rulerStartPosition.left;
		
		var curTop = parseInt(($("#leftRuler").css("margin-top")).replace("px", ""));
		var topDiff = curTop - config.rulerStartPosition.top;
		
		config.resetRulerPosition = false;
		FQD.ruler.changeUnit(config.unit, config.tick);
		
		$("#topRuler").css("margin-left", config.rulerStartPosition.left+leftDiff+"px");
		$("#leftRuler").css("margin-top", config.rulerStartPosition.top+topDiff+"px");
		
		config.resetRulerPosition = true;
	}
}

FQD.events.allActions=function(id,elm){
	if(id=="pan" || $('#pan').hasClass("selected-tool")){
		FQD.canvas.pages.forEach(function(canvas){
			canvas.defaultCursor="url('"+config.resourcePath+"images/pan.cur'),auto";
		});
	}else{
		FQD.canvas.pages.forEach(function(canvas){
			canvas.defaultCursor="default";
		});
	}
	jQuery("#eyeDropper").removeClass("activeted");
	fabric.util.clearFabricFontCache();
	switch(id) {
	
		case "select":
			config.selectedTool="select";
			jQuery("#"+id).addClass("selected-tool");
			FQD.canvas.setCanvasSelectionTrue();
	    break;
	    
		case "delete":
			config.selectedTool="select";
			FQD.canvas.deleteObjects();
		break;
		    
		case "text":
			config.selectedTool=id;
			FQD.canvas.setCanvasSelectionFalse();
			jQuery("#"+id).addClass("selected-tool");
		break;
		
		case "ellipse":
			config.selectedTool=id;
			jQuery("#"+id).addClass("selected-tool");
			FQD.canvas.setCanvasSelectionFalse();
		break;
		
		case "rect":
			config.selectedTool=id;
			jQuery("#"+id).addClass("selected-tool");
			FQD.canvas.setCanvasSelectionFalse();
		break;
		
		case "rounded-rect":
			config.selectedTool=id;
			jQuery("#"+id).addClass("selected-tool");
			FQD.canvas.setCanvasSelectionFalse();
		break;
		
		case "pan":
			config.selectedTool=id;
			jQuery("#"+id).addClass("selected-tool");
			FQD.canvas.setCanvasSelectionFalse();
		break;
		
		case "line":
			config.selectedTool=id;
			jQuery("#"+id).addClass("selected-tool");
			FQD.canvas.setCanvasSelectionFalse();
		break;
		
		case "image":
			config.selectedTool="select";
			FQD.imgLib.showImgPopup();
			config.placerHolderObject.elm=null;
		break;
		
		case "image-placeholder":
			config.selectedTool="select";
			FQD.shapes.placeHolders("image");
			config.placerHolderObject.elm=null;
		break;
		
		case "clipart-placeholder":
			config.selectedTool="select";
			FQD.shapes.placeHolders("clipart");
			config.placerHolderObject.elm=null;
		break;
		
		case "btnUndo":
			config.selectedTool="select";
			FQD.undoManager.undo(0);
		break;
		
		case "btnRedo":
			config.selectedTool="select";
			FQD.undoManager.redo(0);
		break;
		
		case "clear":
			config.selectedTool="select";
			FQD.canvas.clearAllCanvas();
		break;
		
		case "selectAll":
			config.selectedTool="select";
			FQD.utility.selectAllObject();
		break;
		
		case "shapes-img":
			config.selectedTool="select";
			FQD.canvas.setCanvasSelectionTrue();
		break;
		
		case "btnPreview":
			FQD.preview.getAllPreview();
			 FQD.shapes.showEditProperties();
		break;
			
		case "to-json":
			var data=FQD.canvas.pages[config.activeCanvas].toJSON();
			alert(JSON.stringify(data));
		break;
			
		case "ServPreview":
			    FQD.utility.gotoServerPreview();
		break;
		
		case "exitPreview":
			config.isServerPreviewOn = false;
			FQD.events.closePopup(jQuery("#close-window"));
			config.hasPreviewState = false;
			jQuery("#ServPreview,.file-menu").show();
			jQuery("#exitPreview").hide();
			jQuery("#overlay").css("top","0px");
			 FQD.tips.close();
	    break;
		
		case "to-svg":
			alert(FQD.canvas.pages[config.activeCanvas].toSVG());
		 break;
		 
		case "btnLogin":
			FQD.utility.userLogin();
			FQD.shapes.showEditProperties();
		 break;
	    case "btnSignUp":
			FQD.utility.SignUp();
			FQD.shapes.showEditProperties();
			
		 break;
		 
	    case "exitLink":
			FQD.utility.exitOD();
			
			
		 break;
		 
	    case "proceedOrder":
	    	isSessionChanged(function(){
				var login=FQD.saveDesign.isUserLoggedIn();
				var nextBtnText = config.orderItemRedesignMode? resourcesData.saveDesignTitle: resourcesData.proceedOrder; 
				if(config.productDetails.isUserLoggedin && (login=="false")){
				  FQD.utility.proceedToOrderSessionLogout();
				}
				else if(config.isServerPreviewOn){
					standardPopup(FQD.message.msgReviewPages, resourcesData.proceedOrder,"",resourcesData.frontBackCancel, FQD.utility.gotoProceedToOrder, FQD.utility.gotoServerPreview, null);
			    		//FQD.utility.gotoProceedToOrder();
			    	}
				else if(config.orderItemRedesignMode){
			    		standardPopup(FQD.message.msgReviewPagesBeforeProceeding, nextBtnText, resourcesData.ServPreview, resourcesData.frontBackCancel, FQD.utility.gotoProceedToOrder, FQD.utility.gotoServerPreview, null);
			    	}else{
			    		standardPopup(FQD.message.msgReviewPages, nextBtnText, resourcesData.ServPreview, resourcesData.frontBackCancel, FQD.utility.gotoProceedToOrder, FQD.utility.gotoServerPreview, null);
			    	}
			});
	    	
		 break;
	     case "textleft":
	    	var className=jQuery(elm).hasClass("selectedAlign");
	    	var obj=FQD.canvas.getActiveObjects();
	    
	         if(className){
	        	 jQuery(elm).removeClass("selectedAlign");
	         }
	         else{
	        	 FQD.shapes.setTextElementsProperties("textAlign", "left");
	        	 jQuery(elm).addClass("selectedAlign");
	        	 config.objectCachedProperties.Text.textAlign="left";
	         }
	    
	         FQD.elements.textcenter.removeClass("selectedAlign");
	         FQD.elements.textright.removeClass("selectedAlign");
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
	    	
		 break;
		 
	    case "textcenter":
	    	var className=jQuery(elm).hasClass("selectedAlign");
	    	var obj=FQD.canvas.getActiveObjects();
	    	
	         if(className){
	        	 FQD.shapes.setTextElementsProperties("textAlign", "center");
	        	 jQuery(elm).removeClass("selectedAlign");
	        	 config.objectCachedProperties.Text.textAlign="center";
	         }
	         else{
	        	 FQD.shapes.setTextElementsProperties("textAlign", "center");
	        	 jQuery(elm).addClass("selectedAlign");
	        	 config.objectCachedProperties.Text.textAlign="center";
	         }
	         FQD.elements.textleft.removeClass("selectedAlign");
	         FQD.elements.textright.removeClass("selectedAlign");
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
		 break;
		 
	    case "textright":
	    	var className=jQuery(elm).hasClass("selectedAlign");
	    	var obj=FQD.canvas.getActiveObjects();
	    	
	         if(className){
	        	 FQD.shapes.setTextElementsProperties("textAlign", "right");
	        	 config.objectCachedProperties.Text.textAlign="right";
	        	 jQuery(elm).removeClass("selectedAlign");
	         }
	         else{
	        	 FQD.shapes.setTextElementsProperties("textAlign", "right");
	        	 jQuery(elm).addClass("selectedAlign");
	        	 config.objectCachedProperties.Text.textAlign="right";
	         }
	         FQD.elements.textleft.removeClass("selectedAlign");
	         FQD.elements.textcenter.removeClass("selectedAlign");
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
		 break;
		 
		 
	    case "bold":
	    	var className=jQuery(elm).hasClass("textPropSelected");
	    	var obj=FQD.canvas.getActiveObjects();
	  
	         if(className){
	        	 obj.set({fontWeight:''});
	        	 jQuery(elm).removeClass("textPropSelected");
	        	 config.objectCachedProperties.Text.fontWeight="";
	         }
	         else{
	        	 obj.set({fontWeight:'bold'});
	        	 jQuery(elm).addClass("textPropSelected");
	        	 config.objectCachedProperties.Text.fontWeight="bold";
	         }
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
	
	
		 break;
		 
	    case "italic":
	    	
	    	var className=jQuery(elm).hasClass("textPropSelected");
	    	var obj=FQD.canvas.getActiveObjects();
	    	
	         if(className){
	        	 obj.set({fontStyle:''});
	        	 jQuery(elm).removeClass("textPropSelected");
	        	 config.objectCachedProperties.Text.fontStyle="";
	         }
	         else{
	        	 obj.set({fontStyle:'italic'});
	        	 jQuery(elm).addClass("textPropSelected");
	        	 config.objectCachedProperties.Text.fontStyle="italic";
	         }
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
	         
		 break;
		 
	    case "underline":
	    	
	    	var className=jQuery(elm).hasClass("textPropSelected");
	    	var obj=FQD.canvas.getActiveObjects();
	    	
	         if(className){
	        	 obj.set({textDecoration:''});
	        	 jQuery(elm).removeClass("textPropSelected");
	         }
	         else{
	        	 obj.set({textDecoration:'underline'});
	        	 jQuery(elm).addClass("textPropSelected");
	         }
	         FQD.elements.lineThrough.removeClass("textPropSelected");
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
	         
		 break;
		 
	    case "line-through":
	    	var className=jQuery(elm).hasClass("textPropSelected");
	    	var obj=FQD.canvas.getActiveObjects();
	    	
	         if(className){
	        	 obj.set({textDecoration:''});
	        	 jQuery(elm).removeClass("textPropSelected");
	         }
	         else{
	        	 obj.set({textDecoration:'line-through'});
	        	 jQuery(elm).addClass("textPropSelected");
	         }
	         FQD.elements.underline.removeClass("textPropSelected");
	         FQD.canvas.pages[config.activeCanvas].renderAll();
	         FQD.undoManager.saveHistory(true);
		 break;
	  
	}
}
FQD.events.pushObjectInside=function(){
	var elements=FQD.canvas.pages[config.activeCanvas].getObjects();
	var cw=config.canvasWidth;
    var ch=config.canvasHeight;
    var objectOutside=[];
    var z=FQD.canvas.pages[config.activeCanvas].getZoom();
	for(var i=0;i<elements.length;i++){
	  	      FQD.canvas.pages[config.activeCanvas].setZoom(1);
		 var oCoords=elements[i].oCoords;
		 var xArr=[oCoords.tl.x,oCoords.tr.x,oCoords.bl.x,oCoords.br.x];
		 var yArr=[oCoords.tl.y,oCoords.tr.y,oCoords.bl.y,oCoords.br.y];
		 var xmin=xArr.min();
		 var xmax=xArr.max();
		 var ymin=yArr.min();
		 var ymax=yArr.max();
	     if(xmin>cw || xmax<0 || ymin>ch || ymax<0){
	    	 objectOutside.push(elements[i]);
	     }
		 
	}
	   FQD.canvas.pages[config.activeCanvas].setZoom(z);
	   for(var i=0;i<objectOutside.length;i++){
		   objectOutside[i].setLeft(100);
		   objectOutside[i].setTop(100);
		   objectOutside[i].setCoords();
	   }
	   FQD.canvas.pages[config.activeCanvas].renderAll();
	 
} 

FQD.events.pageOptions=function(){
	FQD.mainScreen.pagesOptions();
}

FQD.events.cornerOptions=function(){
	FQD.mainScreen.cornerOptions();
}

FQD.events.foldingOptions=function(){
	FQD.mainScreen.foldingOptions();
}

FQD.events.pocketOptions=function(){
	FQD.mainScreen.pocketOptions();
}

FQD.events.holeOptions=function(){
	FQD.mainScreen.holeOptions(); 
}

FQD.events.keyboardHelpWindow=function(){
	//console.log("FQD.events.keyboardHelpWindow");
	FQD.helper.keyboardHelpWindow();
	
	jQuery(window).resize(function(){
		FQD.helper.keyboardHelpWindow();
	});
}

FQD.events.PerforationNumberingOptions=function(){
	FQD.mainScreen.perforationAndNumberingOptions();
}

window.onbeforeunload = function() {
	if(config.isSessionChanged == true || config.TimeoutDialog.sessionExpired){
		return ;
	}
	if(!config.applicationError && !config.proceedOrder && (!config.productDetails.adminOpenedSavedDesign) && !config.isSessionLogout){
		return resourcesData.leaveODMessage;
	}

}
jQuery(window).unload(function(){
	if(config.proceedOrder=="true"){
		return;
	}
		  FQD.utility.unloadStoreDesign("reload");
	  });



















