/*******************************************************************************
 * 
 * Responsible to save a design into DB at back end and also load and delete a
 * design.
 * 
 * 
 ******************************************************************************/

FQD.saveDesign = {};
FQD.saveDesign.url = "/OnlineDesignerAction";
$("#SavedDesigns").click(function() {
	FQD.helper.isUserLoggedIn('promptSavedDesign');
});


FQD.saveDesign.saveNewDesign=function(designName,isSaveProgress){
	$("#progressImage").attr('src', config.qdpath + "css/preloader.gif");
	$("#progressImage").css('display', 'inline');
	$("#saveDesignArea").css('display', 'none');
	$('#saveErrorMessageContainer').css('display', 'none');
	if(designName && isSaveProgress){
		FQD.saveDesign.saveDesign(designName, isSaveProgress);
	}else{
		var designName = $("#designName").val();
		designName = designName.trim().replace(/\s/g, '_');
		FQD.saveDesign.saveDesign(designName, false);
	}
}


FQD.saveDesign.autoCategorize=function(designName,isSaveProgress,isProceedOrder){
	        $(".saveDesignName").css('z-index',"999");
			var userUploadImgArray=[],temporaryImageIdArray=[];
			FQD.canvas.pages.forEach(function(canvas){
				var objs = canvas.getObjects();
				for (var i=0;i< objs.length;i++){
					var obj=objs[i];
					if(obj.type == "image" && obj.userUploaded == "true" && obj.filedescriptorid!=null && obj.filedescriptorid!=undefined){
						userUploadImgArray.push(obj.filedescriptorid);
					}
				}
			});
				if(userUploadImgArray.length > 0){
					jQuery.ajax({
						mimeType: 'text/plain; charset=x-user-defined',
				        type: 'post',
				        url: myUploads.jsonUrl,
				        data:{requestCode:1,"categoryId":"-1"},
				        success: function (data) {
				        	if(typeof data == "string"){
			        			data=JSON.parse(data);
			        		}
				        	if(data && data.images){
				        		for(var i=0;i< userUploadImgArray.length;i++){
				        			var uploadedImg = userUploadImgArray[i];
				        			uploadedImg=uploadedImg.slice(uploadedImg.lastIndexOf(":"),uploadedImg.length);
				        			for(var j=0;j< data.images.length;j++){
					        			var img =data.images[j];
					        			var fd= img.fileDescriptorId;
					        			fd=fd.slice(fd.lastIndexOf(":"),fd.length);
					        			if(uploadedImg == fd){
					        				temporaryImageIdArray.push(img.id);
					        			}
					        		}
				        		}
				        		if(temporaryImageIdArray.length > 0){
				        			FQD.saveDesign.autoCategorizeDialog(temporaryImageIdArray,isProceedOrder);
				        		}else{
				        			if(isProceedOrder){
				        				FQD.helper.proceedToOrder();
				        			}else{
				        				FQD.saveDesign.saveNewDesign(designName,isSaveProgress);
				        			}
				        		}
				        	}else{
				        		if(isProceedOrder){
				        			FQD.helper.proceedToOrder();
				        		}else{
				        			FQD.saveDesign.saveNewDesign(designName,isSaveProgress);
				        		}
			        		}
				        },
					    xhrFields:{
					        withCredentials: true
					   }
					});
				}else{
					if(isProceedOrder){
						FQD.helper.proceedToOrder();
					}else{
						FQD.saveDesign.saveNewDesign(designName,isSaveProgress);
					}
					
				}
	
}

FQD.saveDesign.sendAutoCategorizeRequest=function(tempImageIdArray,isDialog,isProceedOrder){
	jQuery.ajax({
		mimeType: 'text/plain; charset=x-user-defined',
        type: 'post',
        url: FQD.saveDesign.url,
        data:{QDAction:43,cid:config.cid,imagesIds:tempImageIdArray},
        success: function (data) {
        		if(data == 0){
	        		if(isProceedOrder){
	        			FQD.helper.proceedToOrder();
	        		}
        		else{
        			jQuery("#-1").click();
        			if (config.currentDesignId) {
        				FQD.saveDesign.saveNewDesign(config.currentDesignId,true);
        			}else{
        				if(!config.IsUserLoggedIn && config.proceedOrder=="true"){
        					FQD.helper.proceedToOrder();
        				}else{
        					FQD.saveDesign.saveNewDesign();
        				}
        			
        			}
        		}
        	}
        	else if(data == -4){
        		customAlertBox("alert","Cancel","Ok","Quota limit exceeded. Some file(s) cannot be moved. Please remove other files from any category/folder other than Temporary to free up space.");
        	}else{
        		customAlertBox("alert","Cancel","Ok","Something went wrong. Unable to move the selected image(s). Please try again.");
        	}
        	if(isDialog){
        		jQuery("#autoCategorize").dialog("close");
        	}
        }
	});
}

FQD.saveDesign.autoCategorizeDialog=function(tempImageIdArray,isProceedOrder){
	if(config.autoCategorize){
		FQD.saveDesign.sendAutoCategorizeRequest(tempImageIdArray,false,isProceedOrder);
	}else{
		$("#autoCategorize").dialog({
			width : 650,
			modal : true,
			resizable : false,
			dialogClass : "saveDesignName",
			buttons : {
				"Move and Organize Manually" : function() {
					if(jQuery("#saveDesignName").css("display") == "block"){
						config.organizeManually=true;
						jQuery("#saveDesignName").dialog("close",function(){
							config.organizeManually=false;
							$("#designName").css("border-color","#62a3ff");
						});
					}
					FQD.elements.divLoaderContainer.hide();
					FQD.elements.divLoadingQd.hide();
					jQuery(this).dialog("close");
				},
				"Move and Organize Automatically" : function() {
					FQD.saveDesign.sendAutoCategorizeRequest(tempImageIdArray, true,isProceedOrder);
				}
			}
		});
	}
}


FQD.saveDesign.saveDesignAction = function() {
	$("#btnSave").click(function() {
		config.btnPress = 3;
		// can save empty design as well
		FQD.helper.isUserLoggedIn('promptDesignName');
	});

	$('#loginYes').click(function() {
		config.saveDesignLogin = true;
		$("#saveDesignName").dialog("close");
		FQD.elements.usrEmail.val("");
		FQD.elements.usrPasswd.val("");
		FQD.elements.errorMessage.hide();

		FQD.elements.userLoginWindow.dialog({
			width : 400,
			height : 350,
			modal : true,
			dialogClass : "userLoginWindow",
			resizable : false,
			buttons : {
				"Log In" : function() {
					jQuery(".login-message").hide();
					FQD.helper.authenticateUser();
				},
				Cancel : function() {
					config.autoSave = false;
					jQuery(this).dialog("close");
				}
			}
		});
		
		
		$(".ui-dialog-titlebar-close").click(function() {
			config.autoSave = false;
		});
	});
	$('#cancelLogin').click(function() {
		$("#saveDesignName").dialog("close");
		config.autoSave = false;
	});

	$("#designName").on('input', function() {
		if ($("#designName").val().trim() == '') {
			$("#designNameButton").css("color", "white");
			return;
		} else {
			$("#designNameButton").css("color", "black");
		}
	});

	$("#designNameButton").click(function() {
		$(this).css("pointer-events","none");
		FQD.elements.divLoaderContainer.show();
		FQD.elements.divLoadingQd.show();
		$(".saveDesignName").css('z-index',"99");
		$("#designName").css("border-color","#62a3ff");
	var designName = $("#designName").val();
	if (designName.trim() == '') {
		FQD.elements.divLoaderContainer.hide();
		FQD.elements.divLoadingQd.hide();
		$(".saveDesignName").css('z-index',"999");
		    $("#designName").css("border-color","#ca3005");
			return;
		}
	FQD.saveDesign.autoCategorize();
});

	$("#savedDesignOK").click(function() {
		if(config.proceedOrder=="true"){
			FQD.elements.divLoadingQd.show();
			FQD.elements.divLoaderContainer.show();
			$("#loadingQD").css("z-index","9999");
			$("#loaderContainer").css("z-index","9999");
			var id=setInterval(function(){
				 console.log("config.loadElmCount:" +config.loadElmCount);
				 if(config.loadElmCount == undefined || (config.loadElmCount>= config.loadFDTotalElmCount)){
					 if(config.checkForCroppedImageCompleted == undefined || config.checkForCroppedImageCompleted==true){
					 delete config.loadElmCount;
					 delete  config.loadFDTotalElmCount;
					 $('.saveDesignName').hide();
				     FQD.helper.proceedToOrder(); 
					 clearInterval(id);
					 return;
				 } 
				
			   }
			 }, 10);
		}else{
			$("#saveDesignName").dialog("close");
			$('#messgaediv').css('display', 'none');
			$('#innerdiv').css("margin-top", "34px");
			$('#innerdiv1').css("margin-top", "0px");
			$('#innerdiv').css("display", "block");
			$('#innerdiv1').css("display", "block");
			$('#designNameButton').css('display', 'block');
			$('#linebreak').css('margin-top', '0px');
			$('#designSaved').css('display', 'none');
			$('#savedDesignOK').css('display', 'none');
		}
	
		
	});

	$("#saveErrorMessageContainer input").click(function() {
		$('#saveDesignName').dialog("close");
		var login=FQD.saveDesign.isUserLoggedIn();
		if(config.productDetails.isUserLoggedin && (login=="false")){
			config.isSessionLogout=true;
			 window.open("http://"+document.domain,"_self");
		}

	});
	


	var div = '<div id="savedDesignList" title="Saved Designs" style="position:relative;">';
	div += '</div>';
	div = div.replace('\="Saved Designs\"' ,'='+'"' +resourcesData.savedDesignsData+ '"');
	$("body").append(div);
	$("#savedDesignList").hide();
}

FQD.saveDesign.saveDesign = function(designName, isSaveProgress) {

	var z = FQD.canvas.pages[config.activeCanvas].getZoom();
	FQD.canvas.setZoom(1);// reset canvas to get data in 100% zoom

	if (!config.autoSaveProgress) {
		FQD.elements.divLoadingQd.show();
		FQD.elements.divLoaderContainer.show();
		showDialog = false;
		config.autoSaveProgress = false;
	}

	var showDialog = true;
	if (config.autoSaveProgress) {
		showDialog = false;
		config.autoSaveProgress = false;
	}
	FQD.elements.divLoadingQd.show();
	FQD.elements.divLoaderContainer.show();
	var dpi = config.dpi;
	var imgArr = [];

	var actualWidth = config.productDetails.canvasWidth;
	var actualHeight = config.productDetails.canvasHeight;

	var prodType = config.productTypeId;
	var prodSvg = '';
	var svgToJson = '';
	
	var radius=config.productDetails.radius;
    var cornerRadius=config.productDetails.cornerRadius;
    
    var bleedZoneId = config.productDetails.printProductBleedBean.id;
	var bleedZoneRoundCornerId = config.productDetails.printProductBleedRoundCornerBean.id;
	var safeZoneId = config.productDetails.printProductSafeZoneBean.id;
	var safeZoneRoundCornerId = config.productDetails.printProductSafeZoneRoundCornerBean.id;
	
	var printJobData = config.productDetails.printJob;
	delete printJobData.printJobSVG;
	delete printJobData.printJobJson;
	if(!isSaveProgress && config.currentDesignId!=undefined && config.currentDesignId> 0) {
		printJobData.id=getUUID();
	}
	var printJob = getEncodedPrintJob(printJobData);

	if(typeof designName === "string"){
		designName = designName.replace(/%/g, "amp;percnt;");
	}
	var actionId = isSaveProgress? "39": "18";
	
	var designDetail = isSaveProgress? ("&designId="+designName): ("&designName="+designName);
	
	var length=FQD.canvas.pages.length;
	if(config.isFrontOnly == "true"){
		length=1;
	}
		
	for (var i = 0; i < length; i++) {
		var svgData = FQD.canvas.pages[i].toSVG(config.newProperties);
		var svgjson = FQD.canvas.pages[i].toJSON(config.newProperties);
		// Store all the images in an arry to send it to the server for
		// categorization

		var temp = svgData.split("filestore?id=");
		if (temp.length > 1) {
			for (var loop = 1; loop < temp.length; loop++) {
				var fileDescriptor = temp[loop].split('"')[0];
				if (fileDescriptor.includes("_crop"))
					continue;
				imgArr.push(fileDescriptor);
			}
		}

		svgData = svgData.replace('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>', '');
		svgData = svgData.replace('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">','');
		svgData = jQuery.trim(svgData).replace(/(?:\r\n|\r|\n)/g, '').replace(/\s+/g, " ");

		svgData=FQD.preview.removeElementNotForPreview(svgData);
		
		prodSvg += "&svgData="
				+ window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(svgData)).replace(/\+/g, "%2B"));
		svgToJson += "&svgToJson="
				+ window.btoa(encodeURI(FQD.saveDesign.handleSpecialCharacter(JSON.stringify(svgjson))).replace(/\+/g,
						"%2B"));
	}
	
	designDetail = designDetail+prodSvg+svgToJson;
	var random = Math.random();
	var bgImage = FQD.canvas.pages[config.activeCanvas].backgroundImage;
	
	if (bgImage) {
		var src = bgImage.getSrc();
		FQD.imgLib.setBgImage(src, FQD.canvas.pages[config.activeCanvas]);
	}
	
	FQD.canvas.setZoom(z); // zoom canvas as per previous value again
	FQD.activity.resetKeepAliveTimer();
	
	jQuery.ajax({
		mimeType: 'text/plain; charset=x-user-defined',
		url : FQD.preview.url,
		type : "POST",
		data:"QDAction="+actionId+designDetail+
        	 "&printJob="+printJob+
        	 "&imgArr="+imgArr+
        	 "&cid="+config.cid+"&random="+random,
        
		success : function(data) {
			FQD.elements.divLoaderContainer.hide();
			FQD.elements.divLoadingQd.hide();
			$(".saveDesignName").css('z-index',"999");
			$("#loadingQD").hide();
			
			if(!isSaveProgress){
				FQD.saveDesign.showDesignName(jQuery("#designName").val());
			}
			
			if(config.proceedToOrderExecuted){
				$("#designNameButton").css("pointer-events","");
				return;
			}
			
			if (data.trim() == "null" || data.trim() == "-1"
					|| data.trim() == "" || data.trim() == "DesignNotExist") {
				$('#saveDesignArea').css('display', 'none');
				$('#errorMsg').css('display', 'none');
				$('#progressImage').css('display', 'none');
				$('#progressImage').css('display', 'none');
				$('#saveErrorMessageContainer').css('display', 'inline-block');
				
				$("#saveDesignName").dialog({
					width : 530,
					height : 235,
					modal : true,
					resizable : false,
					dialogClass : "saveDesignName",
					close : function() 
					{
						$("#saveDesignName").dialog("close");
						$('#messgaediv').css('display', 'none');
						$('#innerdiv').css("margin-top", "34px");
						$('#innerdiv1').css("margin-top", "0px");
						$('#innerdiv').css("display", "block");
						$('#innerdiv1').css("display", "block");
						$('#designNameButton').css('display', 'block');
						$('#linebreak').css('margin-top', '0px');
						$('#designSaved').css('display', 'none');
						$('#savedDesignOK').css('display', 'none');
						$("#loadingQD").hide();
						$("#designName").css("border-color","#62a3ff");

					},
				});
				var login=FQD.saveDesign.isUserLoggedIn();
				if(config.productDetails.isUserLoggedin && (login=="false")){
					config.isSessionLogout=true;
					$('#saveErrorMessage').html(fqdSessionLogoutMessage);
					$('#saveDesignName').css('height','202px');
					$('#saveErrorMessage').css('margin-left','81px');
						
				}else{
					if(data.trim() == "DesignNotExist"){
						$('#saveErrorMessage').html(resourcesData.fqdMsgSaveDesignDeleted);
						config.productDetails.isProductSaved = false;
						config.currentDesignId = config.productDetails.designId = undefined;
						FQD.customize.setFileMenuListOptions();
						
					}else{
						$('#saveErrorMessage').html(fqdSaveDesignErrorMessage);
					}
				}
				$("#designName").val(FQD.utility.getAutoSaveDesignName());
				$(".ui-dialog-titlebar-close").click(function() {
					config.autoSave = false;
				});
				$('#loadingQD').hide();
				$("#designNameButton").css("pointer-events","");

				return;
			}

			if (!showDialog) {
				$("#designNameButton").css("pointer-events","");

				return;
			}
			
			
			if(config.fromProceedToOrder){
	        	config.fromProceedToOrder=false;
	        	FQD.utility.proceedToOrder();
	        }
			if(config.proceedOrder!="true"){
				$("#saveDesignName").dialog({
					width : 530,
					height : 235,
					modal : true,
					resizable : false,
					dialogClass : "saveDesignName",
					close : function() {
						$("#saveDesignName").dialog("close");
						$("#loadingQD").hide();
						$("#loaderContainer").hide();
						$("#designName").css("border-color","#62a3ff");
					}

				});
			}

			$("#designName").val(FQD.utility.getAutoSaveDesignName())
			$("#progressImage").css('display', 'none');
			$("#saveDesignArea").css('display', 'inline');
			$('#saveErrorMessageContainer').css('display', 'none');
			if (data.trim() == "-2") {

				$('#messgaediv').css('display', 'inline');
				$('#innerdiv').css("margin-top", "-3px");
				$('#innerdiv1').css("margin-top", "10px");
				$("#designNameButton").css("pointer-events","");

				return;
			}
			if (data.trim() == "") {
				$('#progressImage').css('display', 'none');
				$('#errorMsg').css('display', 'inline');
				$("#designNameButton").css("pointer-events","");

				return;
			}

			$('#messgaediv').css('display', 'none');
			$('#innerdiv').css("margin-top", "34px");
			$('#innerdiv1').css("margin-top", "0px");
			$('#innerdiv').css("display", "none");
			$('#innerdiv1').css("display", "none");
			$('#designNameButton').css('display', 'none');
			$('#linebreak').css('margin-top', '80px');
			$('#designSaved').css('display', 'inline');
			$('#savedDesignOK').css({display: "inline", float: "right", margin: "0 10px"});
			$("#loadingQD").hide();
			$("#loaderContainer").hide();
			config.productDetails.isProductSaved = true;
			config.currentDesignId = data.trim();
			config.productDetails.designerType = 1;
			$('#btnSave').hide();
			$('#btnSaveProgress').show();
			$('#btnSaveDesignAs').show();
			$("#designNameButton").css("pointer-events","");

			
			
		},
		error : function(jqXHR, textStatus, errorThrown) {
			console.log(errorThrown);
			FQD.elements.divLoadingQd.hide();
			FQD.elements.divLoaderContainer.hide();
			$("#designNameButton").css("pointer-events","");

		},
		xhrFields : {
			withCredentials : true
		}
	});

}

FQD.saveDesign.handleSpecialCharacter=function(data){
	data=data.replace(/|||||||||||||||/g,"");
	data=data.replace(/\\u0001|\\u0004|\\u0007|\\b|\\u0003|\\u0016|\\u0002|\\u000e|\\u0005|\\u0019|\\u000f|\\u001e|\\u000b|\\u0008|\\u001a|\\u0018|\\u0017|\\u2028|\\u000b/g,"");
	if(!config.specialCharacterObj){
		var objArr=[];
		var specialCharacterObj={};
		specialCharacterObj.specialCharacter="\~";
		specialCharacterObj.replaceWith="tilde";
		objArr.push(specialCharacterObj);
		config.specialCharacterObj=objArr;
	}

	for(var i=0;i<config.specialCharacterObj.length;config.specialCharacterObj++){
		 var re = new RegExp(config.specialCharacterObj[i].specialCharacter, 'g');
		 data=data.replace(re,config.specialCharacterObj[i].replaceWith);
	}
	return data;
	
}
FQD.saveDesign.isUserLoggedIn=function(){
	var isLoggedin=false;
	var random = Math.random();
	jQuery.ajax({
		mimeType: 'text/plain; charset=x-user-defined',
		url : FQD.preview.url,
		type : "POST",
		async:false,
		data:"QDAction=44&cid="+config.cid+"&random="+random,
        
		success : function(data) {
			isLoggedin=data;
		},
		error : function(jqXHR, textStatus, errorThrown) {
			
		},
		xhrFields : {
			withCredentials : true
		}
	});
	return isLoggedin;
}
FQD.saveDesign.saveProgress = function() {
	$('#btnSaveProgress').click(function() {
		$('#saveOptions').hide();
		if (config.currentDesignId) {
			FQD.saveDesign.autoCategorize(config.currentDesignId,true);
		} else {
			FQD.saveDesign.autoCategorize(config.productDetails.designId,true);
		}

	});
}

FQD.saveDesign.saveNew = function() {
	$('#btnSaveDesignAs').click(function() {
		$('#saveOptions').hide();
		$("#progressImage").css('display', 'none');
		$("#saveDesignArea").css('display', 'inline');
		$('#progressImage').css('display', 'inline');
		$('#progressImage').css('display', 'none');
		$('#errorMsg').css('display', 'none');
		$('#saveErrorMessageContainer').css('display', 'none');
		$("#saveDesignName").dialog({
			width : 530,
			height : 235,
			modal : true,
			resizable : false,
			dialogClass : "saveDesignName",
			close : function() {
				$("#saveDesignName").dialog("close");
				$('#messgaediv').css('display', 'none');
				$('#innerdiv').css("margin-top", "34px");
				$('#innerdiv1').css("margin-top", "0px");
				$('#innerdiv').css("display", "block");
				$('#innerdiv1').css("display", "block");
				$('#designNameButton').css('display', 'block');
				$('#linebreak').css('margin-top', '0px');
				$('#designSaved').css('display', 'none');
				$('#savedDesignOK').css('display', 'none');
				$("#designName").css("border-color","#62a3ff");
			}
		});
		$("#designName").val(FQD.utility.getAutoSaveDesignName())
	});
}


FQD.saveDesign.showDesignName=function(name){
	name=name.trim().replace(/\s/g, '_');
	var designNameElm=jQuery("#showSaveDesignName");
	var designNameElmText=jQuery("#showSaveDesignNameText");
	designNameElmText.attr("title",name);
	designNameElmText.html(name).show();
	designNameElm.show();
	if(config.isDesignForPreviewOnly){
		$("#previewOnly").show();
	}

}

FQD.saveDesign.loadDesign = function(designCode, designName) {
	config.isProcessCompleted=false;
	var count=0;
	FQD.activity.resetKeepAliveTimer();
	if ($("#savedDesignList").css("display") != "none") {
		$("#savedDesignList").dialog("close");
	}
	$("#loadingQD").show();
	$("#loaderContainer").show();
	$.ajax({
		
	    mimeType: 'text/plain; charset=x-user-defined',
		url : urlPrefix + "/OnlineDesignerAction",
		type : "GET",
		data : "QDAction=15&designcode=" + designCode + "&cid=" + config.cid,
		success : function(data, textStatus, jqXHR) {

			data = decodeURIComponent(atob(data));
			var design = data.split("isRoundCorner");
			data = design[0];
			config.isPageRoundCorner = design[1];
			data = JSON.parse(data);
			var jsonData = data.jsonPages;
			jQuery("ul#tabs").find("li").show();
			FQD.elements.buttonShowAllCanvas.show();
			if (jsonData.length == 1) {
				config.pageNumber = [ [] ];
				config.pageLength = 1;
				jQuery("ul#tabs").find("li").hide();
				jQuery("ul#tabs").find("li").eq(0).show();
				FQD.elements.buttonShowAllCanvas.hide();
			}
			if(designName){
				FQD.saveDesign.showDesignName(designName);
			}
			
			FQD.initElement();
			
			var elementCount = FQD.templateDataTransfer.elementsCountInTemplate(jsonData);
			
			for (var i = 0; i < jsonData.length; i++) 
			{
				var canvas = FQD.canvas.pages[i];
				var json = jsonData[i];
				json = FQD.imgLib.updateHDImageOnJson(json);
				
				canvas.loadFromJSON(json, 
									function(){
		    			 				for(var j=0;j < FQD.canvas.pages.length;j++){
		    			 					FQD.canvas.setElementAsperCanvas(FQD.canvas.pages[j]);
		    			 					FQD.initializecanvas.resetSVGOverlay(FQD.canvas.pages[j]);
		    			 				}
		    			 				
		    			 				canvas.renderAll.bind(canvas);
		    			 				$("#loadingQD").hide();
		    			 				$("#loaderContainer").hide();
									},
									
									function(o, object) {
										FQD.utility.setObjectPropertiesAfterLoadJSON(o, object);
										count++;
										if(count >= elementCount){
											config.isProcessCompleted = true;
										}
									});
			}
			
			FQD.utility.setBackgroundRightProperties(jsonData[0]);
			FQD.canvas.addNewText();
			
			$('#btnSaveProgress').show();
			$('#btnSaveDesignAs').show();
			$('#btnSave').hide();
			$('#SavedDesigns').show();
			
			config.currentDesignId=designCode;
			config.productDetails.designCode=designCode;
			config.productDetails.isProductSaved=true;
			
			var id = setInterval(function(){
				 if(config.isProcessCompleted){
					 clearInterval(id);
					 FQD.saveDesign.replaceBlankSrcWithPlaceHolder();
					
					 config.isProcessCompleted=false;
				 }
				 
			 }, 10);
		},
		error : function(jqXHR, textStatus, errorThrown) {
			$("#loadingQD").hide();
			$("#loaderContainer").hide();
		},
		xhrFields : {
			withCredentials : true
		}
	});
}

FQD.saveDesign.replaceBlankSrcWithPlaceHolder=function(){
	for(var i=0;i<FQD.canvas.pages.length;i++){
		var objs=FQD.canvas.pages[i].getObjects();
		var arr=[];
		for(var j=0;j<objs.length;j++){
			if(objs[j].type=="image" && (objs[j].getSrc()=="" || objs[j].src=="")){
				var img = new Image();
				img.crossOrigin = "anonymous"; // This enables CORS
				
				 if(objs[j].userUploaded=="true"){
					 img.src = config.resourcePath + "images/image.svg";
				 }
				 if(objs[j].isClipArt=="true"){
					 img.src = config.resourcePath + "images/clipart.svg";
				 }
				 var left=objs[j].left;
				 var top=objs[j].top;
				 var isClipArt=objs[j].isClipArt;
				 var userUploaded=objs[j].userUploaded;
				 img.objectProperties={};
				 img.objectProperties.left=left;
				 img.objectProperties.top=top;
				 img.objectProperties.userUploaded=userUploaded;
				 img.objectProperties.isClipArt=isClipArt;
				 img.objectProperties.pageNum=i;
				 
					img.onload = function(obj) {
						
						
						var image = new fabric.Image(img);
						image.set({
							originX : 'left',
							originY : 'top',
							left : obj.target.objectProperties.left,
							top :  obj.target.objectProperties.top,
							opacity : 0.7,
							width:292*config.objScaleWidthMultiplier,
							height:258*config.objScaleWidthMultiplier,
							selectable : true,
							id : "placeHolders"
						});
						
						 if(obj.target.objectProperties.isClipArt=="true"){
							 image.imgPlaceholder=true;
						 }
						 if(obj.target.objectProperties.userUploaded=="true"){
							 image.clipartPlaceholder=true;
						 }
						 FQD.canvas.pages[obj.target.objectProperties.pageNum].add(image);
						 FQD.canvas.pages[obj.target.objectProperties.pageNum].renderAll();
						 image.setCoords();
						
					}
					arr.push(objs[j]);
		    		
				 
			}
		}
		for(var k=0;k<arr.length;k++){
			FQD.canvas.pages[i].remove(arr[k]);
		}
		FQD.canvas.pages[i].renderAll();
	}
	       FQD.undoManager.saveHistory(true);
}

FQD.saveDesign.savedDesignList = function() {
	var width = config.productDetails.canvasWidth;
	var height = config.productDetails.canvasHeight;
	var prodType = config.productTypeId;
	var random=Math.random();
	
	FQD.activity.resetKeepAliveTimer();
	
	$("#savedDesignList").dialog({
		width : 860,
		height : 225,
		modal : true,
		resizable : false,
		dialogClass : "savedDesignList",
	});
	$("#savedDesignList").html(
			"<img id='progressImage' src='" + config.qdpath
			+ "css/preloader.gif' style='margin:35px auto;width:80px;display:block;'></img>");

	$.ajax({
				mimeType: 'text/plain; charset=x-user-defined',
				url : urlPrefix + "/OnlineDesignerAction",
				type : "GET",
				data : "QDAction=13&cid="+ config.cid+"&random="+random,
				success : function(data, textStatus, jqXHR) {
					var div;
					if (data.trim() == "null" || data.trim()=="" ) {
						var login=FQD.saveDesign.isUserLoggedIn();
						if(config.productDetails.isUserLoggedin && (login=="false")){
							config.isSessionLogout=true;
							div='<span style="font-size: 16px;font-weight: bold;margin-left: 10%; margin-top: 44px; display:inline-block;">'+fqdSessionLogoutMessage+'</span><div id="saveDesignListRedirectPanel"><hr style="width: 100%;margin-top: 65px;">';
							div +='<input type="button" value="OK" style="float: right;"></div>';
							div = div.replace("OK" , resourcesData.OK);
							$(".savedDesignList").width("685");
							data="null";
							clearInterval(autoSaveTimer);
								
						}else{
							div = serverError;
						}
						
					}

					if (data.trim() == "]") {
						div = resourcesData.noSavedDesign;
					} else {
						var obj = JSON.parse(data);
						if(obj!=null){
							
							config.savedDesignNameList = obj;
							div = '<div class="savedesignlisthead"><span class="loadDesignName" style="color: #222222;">Name</span><span class=" designListHeader" >Creation Time</span><span class="designListHeaderModification" >Modification Time</span><span style="float:right; margin-right: 10px;font-weight: bold;">Action</span></div><ul>';
							div = div.replace('>Name','>' + resourcesData.folderName);
							div = div.replace('Creation Time',resourcesData.creationTime);
							div = div.replace('Modification Time',resourcesData.modificationTime);
							div = div.replace('Action',resourcesData.action);
							for (var loop = 0; loop < obj.length; loop++) {
								var dName=(obj[loop].name).trim().replace(/\s/g, '_');
								
								if (obj[loop].name.search(/(<([^>]+)>)/ig) != -1) {
									div += '<li><a href="javascript:void(0);" onclick=FQD.saveDesign.loadDesign('+ obj[loop].id + ',"'+dName+'"); class="loadDesignName" title="'
											+ obj[loop].name
											+ '"><![CDATA['
											+ dName
											+ '<span>ddd<span><a class="delete fl disabled designDelete" data-value="'
											+ obj[loop].id
											+ '"><i class="far fa-trash-alt" aria-hidden="true"></i></a></li>';
								} else {
									div += '<li><a href="javascript:void(0);" onclick=FQD.saveDesign.loadDesign('+ obj[loop].id + ',"'+dName+'"); class="loadDesignName" title="'
											+ obj[loop].name
											+ '">'
											+ dName
											+ '</a><span class="listTimeStamp">'
											+ obj[loop].createTime
											+ '</span><span class="listTimeStamp">'
											+ obj[loop].modifiedTime
											+ '</span><a class="delete fl disabled designDelete" data-value="'
											+ obj[loop].id
											+ '"><i class="far fa-trash-alt" aria-hidden="true"></i></a></li>';
								}

							}
						}

						div += '</ul>'
					}

					$("#savedDesignList").html(div);
					if(obj==null){
						$("#saveDesignListRedirectPanel input").click(function() {
							$('#savedDesignList').dialog("close");
							var login=FQD.saveDesign.isUserLoggedIn();
							if(config.productDetails.isUserLoggedin && (login=="false")){
								config.isSessionLogout=true;
								 window.open("http://"+document.domain,"_self");
							}

						});
						
					}
					$(".designDelete").click(function() {
						/*
						 * var cnf=confirm("Are you sure you want to delete the
						 * selected User Saved Design?"); if(!cnf){ return; }
						 * FQD.saveDesign.deleteDesign(this.value);
						 * this.parentNode.remove();
						 */
						var deleteId = $(this).data("value");
						var parentNode=jQuery(this).parent();
						if (deleteId != config.currentDesignId) {
							var cnf = customAlertBox("confirm", "Cancel", "Ok",fqdSavedDesignDeleteMessage,function(result){
								if (result) {
									FQD.saveDesign.deleteDesign(deleteId);
									parentNode.remove();
								}
							});
							
						} else {
							 standardPopup(fqdOpenDesignDeleteMessage, 'Ok', '', '', function(){});
						}
					});
					return;
				},
				error : function(jqXHR, textStatus, errorThrown) {

				},
				xhrFields : {
					withCredentials : true
				}
			});
}

FQD.saveDesign.deleteDesign = function(designCode) {
	FQD.activity.resetKeepAliveTimer();
	$.ajax({
		mimeType: 'text/plain; charset=x-user-defined',
		url : urlPrefix + "/OnlineDesignerAction",
		type : "GET",
		data : "QDAction=30&designCode=" + designCode + "&cid=" + config.cid,
		async : false,
		success : function(data, textStatus, jqXHR) {
			console.log(data);
		},
		error : function(jqXHR, textStatus, errorThrown) {
			console.log(data);
		},
		xhrFields : {
			withCredentials : true
		}
	});

}