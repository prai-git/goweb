var urlPrefix="";
if(window.standAloneExecution){
	urlPrefix=standAlone.serviceBaseUrl;
}

FQD.imgLib = {
	bgImgPosition: "",
	scaleH: '', scaleV: '',
	clipArtImgUrl : urlPrefix+"/OnlineDesignerAction?QDAction=9&clipArtImageCategoryId=",
	bgImgUrl : urlPrefix+"/OnlineDesignerAction?QDAction=8&backgroundImageCategoryId=",
	clipArtCetagoryUrl : urlPrefix+"/OnlineDesignerAction?QDAction=1",	
	bgCetagoryUrl : urlPrefix+"/OnlineDesignerAction?QDAction=2",
	templateCetagoryUrl : urlPrefix+"/OnlineDesignerAction?QDAction=33",
	templateImgUrl:urlPrefix+"/OnlineDesignerAction?QDAction=34&designerTemplateCategoryId=",
	templateJsonUrl:urlPrefix+"/OnlineDesignerAction?QDAction=35&designerTemplateId=",
	bleedSafeUrl:urlPrefix+"/OnlineDesignerAction?bleedsafezone=true",
	jsonUrl:urlPrefix+"/UserImageJsonAction",
	qdAction:urlPrefix+"/OnlineDesignerAction",
	searchString:"",
	showItemsPerPage:25,
	pageNumber:1,
	imgStilLoading: false,
	selectedImg:"",
	imageCount:1,
	
	init:function(){
		if(config.isGeneric){
			jQuery("#applyBg").remove();
		}
		jQuery("#upload-img").html(jQuery("#fileUploadContent").html());
		jQuery("#fileUploadContent").html("");
	},
	setSelectedImage:function(img,attr,className){
		var divId=img.attr("rel");
		FQD.imgLib.selectedImg=img.attr(attr);
		jQuery("#"+divId).find("li").removeClass(className);
		jQuery("#fileUploadWrapper div").find("input[type='checkbox']").prop("checked",false).removeClass("checked");
		img.parent().addClass(className);
		FQD.imgLib.selectedImgOriginalHeight=img.attr("originalHeight");
		FQD.imgLib.selectedImgOriginalWidth=img.attr("originalWidth");
		FQD.imgLib.isUserUploaded=img.attr("useruploaded");
		FQD.imgLib.filedescriptorid=img.attr("filedescriptorid");
		
		if(divId === "clipart-item"){
			FQD.imgLib.insertImg("canvas",divId);
		}else{
			FQD.imgLib.insertImg("background",divId);
		}
		jQuery("#clipArtImages .category-container").removeAttr("style");
		FQD.canvas.setCanvasSelectionTrue();
	},
	setSelectedImg:function(img){
		var src=FQD.imgLib.updateHdImage(img.attr("rel"));
		FQD.imgLib.selectedImg=src;
		FQD.imgLib.selectedImgOriginalHeight=img.attr("originalHeight");
		FQD.imgLib.selectedImgOriginalWidth=img.attr("originalWidth");
		FQD.imgLib.isUserUploaded=img.attr("useruploaded");
		FQD.imgLib.filedescriptorid=img.attr("filedescriptorid");
		FQD.imgLib.colorSpace=img.attr("format");
		FQD.imgLib.imgDpi=img.attr("imgDpi");
		FQD.imgLib.widthInches=img.attr("widthInches");
		FQD.imgLib.heightInches=img.attr("heightInches");
		FQD.imgLib.imgId=img.attr("id");
		FQD.imgLib.fileType=img.attr("fileType");
		FQD.imgLib.insertImg('canvas');
		FQD.canvas.setCanvasSelectionTrue();
		
	},
	updateHdImage:function(src){
		  var parts = src;
		  parts = parts.replace("http:","");
		  parts = parts.replace("https:","");
		  parts = parts.split(":");
		  var fileType;
		  if(parts.length > 2){
			  fileType = parts[2]
		  }
		if(fileType != 10){
			if(config.isHDImage){
				src = src.replaceLast(':1:', ':2:');
				if(fileType == 9){
					var len =(src.match(new RegExp(".png", "g")) || []).length;
					if(len == 2){
						src=src.replaceLast('.png', '');
					}
				}
			}else{
				src = src.replaceLast(':2:', ':1:');
				if(fileType == 9){
					var len =(src.match(new RegExp(".png", "g")) || []).length;
					if(len == 1){
						if(src.indexOf("imageEffectType")>0){
							var arr=src.split("&imageEffectType");
							src=arr[0]+'.png';
							src=src+"&imageEffectType"+arr[1];
						}else{
							src=src+'.png';
						}
						
					}
				}
			}
		}
		return src;
	},
	updateHDImageOnJson:function(jsonData){
		if(typeof jsonData === "string"){
			jsonData = JSON.parse(jsonData);
		}
		var length=0,i=0;
		if(jsonData.objects){
			length=jsonData.objects.length;
		}	
			
		for(i=0;i<length;i++){
			var object=jsonData.objects[i];
			if(object.type == "image" && object.isClipArt != "true"){
				var src=object.src;
				if(src)
                 {
					var fileType=src.slice(src.indexOf("id=")+3);
					fileType=fileType.split(":");
					if(fileType[2] != 32 && fileType[2] != 50){
						object.src=FQD.imgLib.updateHdImage(src);
					}
                 }
			  }
		}
		return jsonData;
	},
	showImgPopup:function(){
		isSessionChanged(function(){
			refreshRecent();
		});
		FQD.canvas.removeSelection();
		FQD.imgLib.selectedImg.length == 0;
    	FQD.imgLib.selectedImg="";
		jQuery("#fileUploadWrapper div").find("input[type='checkbox']").prop("checked",false).removeClass("checked");
		jQuery("#fileUploadWrapper div").find("li").removeClass("selected");
	},
	closeImgPopup:function(){
		FQD.elements.divOverlay.hide();
		FQD.elements.divImgLib.hide();
	},
	
	showClipartPopup:function(){
		FQD.events.showHideLeftButtons(jQuery('#clipArtImages'));
	},
	
	insertImg:function(into, divId)
	{
		if(jQuery("#uploadImg").hasClass("active")){
			 var chkLen = jQuery("#fileUploadWrapper div.current").find("input[type='checkbox'].checked").length;
			 if(chkLen == 1){ 
				 FQD.imgLib.selectedImg=jQuery("#fileUploadWrapper div.current").find("input[type='checkbox'].checked").parent().find("img").attr("rel");
			 }else{
					if(chkLen > 1){
						gotError(onlyOneImageMessage);
						return;
					}
					if(chkLen == 0 || FQD.imgLib.selectedImg.length == 0){
						FQD.imgLib.selectedImg=""
						gotError(noItemMessage);
					}
				}
			jQuery("input[type='checkbox'].checked").parent().find("img").attr("rel");
		}
		
		if(FQD.imgLib.selectedImg.length == 0)
			return;
		
		if(FQD.imgLib.selectedImg){
			var isExist = FQD.imgLib.selectedImg.indexOf("id=");
			if(isExist == -1){
				gotError(formatNotSupported);
				return;
			}
		}
		
		FQD.elements.divLoadingQd.show();
    	FQD.elements.divLoaderContainer.show();
    	var canvas = FQD.canvas.pages[config.activeCanvas];
        var activeObj = FQD.canvas.getActiveObjects();
        
    	if(FQD.imgLib.isUserUploaded){
    		FQD.utility.updatePurgeTime(FQD.imgLib.selectedImg, into);
    	}else{
    		if((activeObj && config.isSwapInitiate)||(config.swapImageObject  && config.isSwapInitiate))
    			FQD.imgLib.swapImageOnCanvas(activeObj, canvas);
    		else
    			FQD.imgLib.addImageOnCanvas(canvas, into, divId);
    	}
	},
	
	swapImageOnCanvas: function(activeObj, canvas){
		activeObj = (activeObj)? activeObj: config.swapImageObject;
		activeObj.setSrc(FQD.imgLib.selectedImg,function(){
			canvas.renderAll();
			});
		FQD.elements.divLoadingQd.hide();
    	FQD.elements.divLoaderContainer.hide();
    	obj.originalWidth = FQD.imgLib.selectedImgOriginalWidth;
    	obj.originalHeight = FQD.imgLib.selectedImgOriginalHeight;
    	delete config.swapImageObject;
    	canvas.renderAll();
	},
	
	addImageOnCanvas: function(canvas, into, divId){
		var img = new Image();
		img.onload = function() {
		    var f_img = new fabric.Image();
		    if(into=="canvas"){
		    	 var image = new fabric.Image(img);
		            image.set({
						originX: 'left',
						originY: 'top',
						left:(config.canvasWidth/2)-(img.width/2),
						top: (config.canvasHeight/2)-(img.height/2),
						selectable:true,
						objectCaching: false,
						filedescriptorid:FQD.imgLib.filedescriptorid
		            });
		            
                id=$(".imgTabs .active").attr("id");
                
		        if(FQD.imgLib.isUserUploaded || divId == "clipart-item"){
		        	 if(divId != "clipart-item"){
		        		 image.userUploaded="true";
		        		 image.filedescriptorid=FQD.imgLib.filedescriptorid;
		        		 image.colorSpace=FQD.imgLib.colorSpace;
		        		 image.imgDpi=FQD.imgLib.imgDpi;
		        		 image.id='userUploaded_'+FQD.imgLib.imgId+'_'+(Math.random()*1000000).toFixed(0);
		        		 image.widthInches=FQD.imgLib.widthInches;
		        		 image.heightInches=FQD.imgLib.heightInches;
		        		 image.fileType=FQD.imgLib.fileType;
		        	 }
		        	 else{
		        		 image.isClipArt="true";
		        		 image.id='clipArt_'+(Math.random()*100000000).toFixed(0);
		        	 }
		        	 var orgWidth=parseFloat(FQD.imgLib.selectedImgOriginalWidth),
		        	 	 orgHeight=parseFloat(FQD.imgLib.selectedImgOriginalHeight);
		        	 var pos = FQD.canvas.getDefaultPosition(orgWidth, orgHeight, true);
		        	 image.setWidth(orgWidth*config.objScaleWidthMultiplier);
		        	 image.setHeight(orgHeight*config.objScaleWidthMultiplier);
		        	 image.setLeft(pos.leftPosition);
		        	 image.setTop(pos.topPosition);
		        	 image.originalWidth=FQD.imgLib.selectedImgOriginalWidth;
			         image.originalHeight=FQD.imgLib.selectedImgOriginalHeight;
		        	 delete FQD.imgLib.isUserUploaded;
		        }else{
                    
		        	 image.userUploaded="false";
		        	 FQD.activity.resetKeepAliveTimer(); 
		        	 var arr=FQD.imgLib.filedescriptorid.split(":");
		        	 var imgType=arr[2];
		        	 if(arr[2]=="9"){
		        		 if(FQD.imgLib.selectedImgOriginalWidth){
		        			 image.originalWidth=FQD.imgLib.selectedImgOriginalWidth;
		        		 }
		        		 if(FQD.imgLib.selectedImgOriginalHeight){
		        			 image.originalWidth=FQD.imgLib.selectedImgOriginalHeight;
		        		 }

		        	 }else{
		        		 
			        	 $.ajax({
				        		mimeType: 'text/plain; charset=x-user-defined',
				      		    url :FQD.imgLib.qdAction,
				      		    type: "GET",
				      		    data : "QDAction=24&fileDescriptor="+FQD.imgLib.filedescriptorid+"&cid="+config.cid,
				      		    async: false,
				      		    success: function(data, textStatus, jqXHR)
				      		    {     
				      		    	var dimension=JSON.parse(data);
				      		    	 image.originalWidth = dimension.originalwidth;
				      		    	 image.originalHeight= dimension.originalheight;
				      		    },
				      		    error: function (jqXHR, textStatus, errorThrown)
				      		    {
				      		       
				      		    }	
				       });
		        	 }

		        }
		        image.isModified=true;
		        canvas.add(image);
		        image.setCoords();
		        FQD.allOverlayOnTop();
		        
		        if(config.placerHolderObject.elm){
		        	var placeHolderScaleX=config.placerHolderObject.elm.scaleX,
		        	placeHolderScaleY=config.placerHolderObject.elm.scaleY,
		        	placeHolderWidth=config.placerHolderObject.elm.width*config.placerHolderObject.elm.scaleX,
		        	placeHolderHeight=config.placerHolderObject.elm.height*config.placerHolderObject.elm.scaleY,
		        	placeHolderAngle=config.placerHolderObject.elm.angle,
		        	imageWidth=image.width,
		        	imageHeight=image.height,
		        	imageWidthHeightRatio = Math.min(placeHolderWidth/imageWidth, placeHolderHeight/imageHeight);
		        	FQD.shapes.commiteScaleValues(image);
	        		image.setScaleX(imageWidthHeightRatio);
	        		image.setScaleY(imageWidthHeightRatio);
	        		image.setAngle(placeHolderAngle);
		        	image.setLeft(config.placerHolderObject.left);
		        	image.setTop(config.placerHolderObject.top);
		        	
		        	if(config.placerHolderObject.userUploaded){
		        		image.userUploaded="true";
		        		delete config.placerHolderObject.userUploaded;
			    	}
		        	var objectArray=FQD.canvas.pages[config.activeCanvas].getObjects();
		        	var index=objectArray.indexOf(config.placerHolderObject.elm);
		        	image.moveTo(index);
		        	image.setCoords();
		        	if(config.placerHolderObject.elm.id){
            			jQuery("#"+config.placerHolderObject.elm.id).remove();
            		}
		        	FQD.canvas.pages[config.activeCanvas].remove(config.placerHolderObject.elm);
		        	FQD.canvas.pages[config.activeCanvas].renderAll();
		        	config.placerHolderObject.elm=null;
		        	if(FQD.shapes.hasImageScaleWarning(image)){
		        		config.placerHolderObject.elm=image;
		        		customAlertBox(resourcesData.confirm, resourcesData.frontBackCancel, resourcesData.ok, FQD.message.imageResized,function(result){
		        			if(result){
		        				config.placerHolderObject.elm.set('scaled',true);
		        			}else{
		        				config.placerHolderObject.elm.setScaleX(config.placerHolderObject.elm['lastScaleX']);
		        				config.placerHolderObject.elm.setScaleY(config.placerHolderObject.elm['lastScaleY']);
		        				config.placerHolderObject.elm.set('scaled',false);
		        			}
		        			FQD.canvas.pages[config.activeCanvas].renderAll();
		        			FQD.shapes.commiteScaleValues(config.placerHolderObject.elm);
				        	//FQD.undoManager.saveHistory(true);
				        	config.placerHolderObject.elm=null;
		        		});
		        	}
		        	FQD.allOverlayOnTop();
		        	FQD.utility.unloadStoreDesign();
		        }else{
		        	FQD.shapes.commiteScaleValues(image);
		        	image.set("scaled",false);
		        	FQD.undoManager.saveHistory(true);
		        	FQD.utility.unloadStoreDesign();
		        }
		        FQD.elements.divLoadingQd.hide();
		    	FQD.elements.divLoaderContainer.hide();
		    	FQD.message.setImageWarnings(image,canvas);
				
			}else{
					FQD.imgLib.setBgImage(img.src, canvas, FQD.imgLib.selectedImgOriginalWidth, FQD.imgLib.selectedImgOriginalHeight);
			}
			
	    	if(divId != "clipart-item"){
	    		FQD.imgLib.selectedImg.length == 0;
    	    	FQD.imgLib.selectedImg="";
        		jQuery("#fileUploadWrapper div").find("input[type='checkbox']").prop("checked",false).removeClass("checked");
        		jQuery("#fileUploadWrapper div").find("li").removeClass("selected");
	    	}
	    	$("#btnInsertImg").prop('disabled', true);
			$("#applyBg").prop('disabled', true);
			FQD.undoManager.saveHistory(true);
	    	
		};
		img.src = FQD.imgLib.selectedImg;
		img.onerror=function(){
			FQD.elements.divLoadingQd.hide();
	    	FQD.elements.divLoaderContainer.hide();
	    	customAlertBox("alert",resourcesData.frontBackCancel,resourcesData.ok,fqdInvalidImageUrl);
		}
	},
	
	setBgImage:function(src, canvas, originalWidth, originalHeight, checkLastScale){
		FQD.elements.divLoadingQd.show();
    	FQD.elements.divLoaderContainer.show();
		src=FQD.imgLib.updateHdImage(src);
		var scaleX=1, scaleY=1;
		var lastSX, lastSY;
		
		if(originalWidth && originalHeight){
			var canvasWidth=config.canvasWidth;
			var canvasHeight=config.canvasHeight;
			
			var imgOrginalWidthHeightRatio = originalWidth/originalHeight;
			var canvasWidthHeightRatio = canvasWidth/config.canvasHeight;

			if(imgOrginalWidthHeightRatio >= canvasWidthHeightRatio){
				var newBackgroundImageWidth = canvasHeight*imgOrginalWidthHeightRatio;
				scaleX = newBackgroundImageWidth/canvasWidth;
				
			}else{
				var newBackgroundImageHeight = canvasWidth*(1/imgOrginalWidthHeightRatio);
				scaleY = newBackgroundImageHeight/canvasHeight;	
			}
		}
		
		var previousBgImage = canvas.getItemByName("bgElement");
		var left = config.canvasOrigin.x0,top=config.canvasOrigin.y0;
		
		checkLastScale = checkLastScale == undefined? false: checkLastScale;
		
		if(previousBgImage){
			if((originalWidth === undefined && originalHeight === undefined) || checkLastScale){
				scaleX = lastSX = previousBgImage.getScaleX();
				scaleY = lastSY = previousBgImage.getScaleY();
				
				originalWidth = (originalWidth === undefined)? previousBgImage.originalWidth: originalWidth;
				originalHeight = (originalHeight === undefined)? previousBgImage.originalHeight: originalHeight;
			}	
			left = previousBgImage.getLeft();
			top = previousBgImage.getTop();
			previousBgImage.remove();
		}else{
			jQuery("#bgFlipX").prop("checked",false);
			jQuery("#bgFlipY").prop("checked",false);
		}
		if(isNaN(scaleY)){
			scaleY=1;
		}
		if(isNaN(scaleX)){
			scaleX=1;
		}
		
		var hasSystemBG = FQD.canvas.hasSystemBackground(FQD.imgLib.filedescriptorid);
		var imgWidth = config.canvasWidth;
		var imgHeight = config.canvasHeight;
		var doCenter = true;
		
		if(FQD.PrintProductType.isEnvelope() && hasSystemBG){
			var envBGRect = FQD.canvas.getEnvelopeBackgroundRect();
			imgWidth = envBGRect.width;
			imgHeight = envBGRect.height;
			left = config.canvasOrigin.x0 + envBGRect.left + envBGRect.width / 2;
			top = config.canvasOrigin.y0 + envBGRect.top + envBGRect.height / 2;
			scaleX = scaleY = 1;
			doCenter = false;
		}
		
		var img = new Image();
		img.onload = function() {
			var image = new fabric.Image(img);
			image.set({
				originX : 'center',
				originY : 'center',
				width:imgWidth,
		        height:imgHeight,
				left :left,
				top : top,
				scaleX:parseFloat(scaleX),
			    scaleY:parseFloat(scaleY),
			    originalWidth:originalWidth,
			    originalHeight:originalHeight,
				selectable: false,
		        evented : false,
		        alwaysNotselectable:true,
		        objectCaching: false,
		        filedescriptorid:FQD.imgLib.filedescriptorid,
				name : "bgElement",
				flipX:jQuery("#bgFlipX").prop("checked"),
		        flipY:jQuery("#bgFlipY").prop("checked"),
		        userUploaded: "true"
			});
			
			image.setCoords();
			if(doCenter)
				canvas.centerObject(image);
			canvas.add(image);
			image.sendToBack();
			
			if(checkLastScale){
				image.setScaleX(lastSX);
				image.setScaleY(lastSY);
			}
			
			var canvasArea = canvas.getItemByName("canvasArea");
			if(canvasArea){
				canvasArea.sendToBack();
			}
			canvas.renderAll();
			FQD.imgLib.disableEnableBgTools(image);
			FQD.undoManager.saveHistory(true);
			FQD.utility.unloadStoreDesign();
			FQD.elements.divLoadingQd.hide();
	    	FQD.elements.divLoaderContainer.hide();
		}
		img.onerror=function(){
			FQD.elements.divLoadingQd.hide();
	    	FQD.elements.divLoaderContainer.hide();
	    	customAlertBox("alert",resourcesData.frontBackCancel,resourcesData.ok,fqdInvalidImageUrl);
		}
		img.src = src;
		var srcarr = src.split("&imageEffectType=");
		if(srcarr.length > 1){
			$("#selBGEffects").val(srcarr[1]);
		}
		
	},
	
	disableEnableBgTools:function(bgImage){
		if(bgImage){
			jQuery("#divBgImageEffects, #removeBgImg, #BGEffects, #BgZoomProp, #zoomOutBgImg, #zoomInBgImg, #dvBgImgDirn").show();
			jQuery("#dvBgImgDirn").removeClass("disabled");

			var src;
			if(bgImage.src==""){
				src=bgImage.src;
			}else{
				if(bgImage.src){
					src=bgImage.src;
				}else{
					src= bgImage.getSrc();
				}
			}
		
			if(FQD.PrintProductType.isEnvelope() && FQD.canvas.hasSystemBackground(bgImage.filedescriptorid)){
				jQuery("#zoomOutBgImg, #zoomInBgImg, #dvBgImgDirn").hide();
				jQuery("#dvBgImgDirn").addClass("disabled");
			}
			
			var srcarr = src.split("&imageEffectType=");
			if(srcarr.length >1){
				jQuery("#selBGEffects").val(srcarr[1]);
			}else{
				jQuery("#selBGEffects").val("NONE");
			}
		
			// should be in the same order
			if(typeof flag == "object"){
				bgImage=flag;
			}
			if(bgImage && bgImage.flipX){
				jQuery("#bgFlipX").prop("checked",true);
			}else{
				jQuery("#bgFlipX").prop("checked",false);
			}
			if(bgImage && bgImage.flipY){
				jQuery("#bgFlipY").prop("checked",true);
			}else{
				jQuery("#bgFlipY").prop("checked",false);
			}
		}else {
			jQuery("#divBgImageEffects, #removeBgImg, #BGEffects, #BgZoomProp, #dvBgImgDirn").hide();
			jQuery("#dvBgImgDirn").addClass("disabled");
		}
	},
	
	setBgPosition: function(direction){
		var bg=FQD.canvas.pages[config.activeCanvas].getItemByName('bgElement');
		if(bg){
			var y= bg.top,
				x= bg.left;
			switch(direction){
				case "top":
					bg.top=y-10;
			    break;
				case "left":
					bg.left=x-10;
				break;
				case "middle":
					FQD.canvas.pages[config.activeCanvas].centerObject(bg);
				break;
				case "right":
					bg.left=x+10;
				break;
				case "bottom":
					bg.top=y+10;
				break;
			}
			FQD.canvas.pages[config.activeCanvas].renderAll();
			FQD.undoManager.saveHistory(true);
		}
	},
	removeBackgroundImage:function(){
		var bg=FQD.canvas.pages[config.activeCanvas].getItemByName('bgElement');
		if(bg){
			customAlertBox(resourcesData.confirm, resourcesData.frontBackCancel,resourcesData.remove,FQD.message.removeBgImage,function(result){
				if(result){
					if(FQD.undoManager.undoItems.length == 0 && FQD.undoManager.redoItems.length == 0){
						FQD.undoManager.saveHistory(true);
					}
					FQD.canvas.pages[config.activeCanvas].getItemByName('bgElement').remove();
					FQD.canvas.pages[config.activeCanvas].renderAll();
					FQD.elements.divContextMenu.hide();
					jQuery("#bgPropertiesContainer").children().hide();
					jQuery("#bgColorWithPickerProp").show();
					FQD.undoManager.saveHistory(true);
					
					FQD.utility.unloadStoreDesign();
				}
			});
		}
	},
	
	bgZoomIn:function(){
		var bgImage=FQD.canvas.pages[config.activeCanvas].getItemByName('bgElement');
		var scaleX=bgImage.scaleX;
		var scaleY=bgImage.scaleY;
		bgImage.setScaleX(scaleX*1.1);
		bgImage.setScaleY(scaleY*1.1);
		FQD.canvas.pages[config.activeCanvas].renderAll();
	},
	
	bgZoomOut:function(){
		var bgImage=FQD.canvas.pages[config.activeCanvas].getItemByName('bgElement');
		var scaleX=bgImage.scaleX;
		var scaleY=bgImage.scaleY;
		bgImage.setScaleX(scaleX*0.9090909);
		bgImage.setScaleY(scaleY*0.9090909);
		FQD.canvas.pages[config.activeCanvas].renderAll();
	},
	
	resetBgZoom:function(){
		var bgImage=FQD.canvas.pages[config.activeCanvas].getItemByName('bgElement');
		bgImage.setScaleX(1);
		bgImage.setScaleY(1);
		FQD.canvas.pages[config.activeCanvas].renderAll();
	},
	getProductCategories:function(){
		FQD.elements.divLoadingQd.show();
    	FQD.elements.divLoaderContainer.show();
		var url=FQD.imgLib.templateCetagoryUrl;
		if(config.foldingId){
			url=url+"&foldTypeId="+config.foldingId;
		}
		url=url+"&cid="+config.cid+"&random="+Math.random();
		jQuery.ajax({
			url: url,
			mimeType: 'text/plain; charset=x-user-defined',
			type:'GET',
			dataType: 'json',
			success: function(data){
				if(data){
					config.productDetails.templateCategory=data
					FQD.imgLib.loadCategory("template-list");
					FQD.imgLib.loadDefaultCategoryTemplate(true);
				}
				FQD.elements.divLoadingQd.hide();
		    	FQD.elements.divLoaderContainer.hide();
			},
			error:function(){
				FQD.elements.divLoadingQd.hide();
		    	FQD.elements.divLoaderContainer.hide();
			}
		});
	},
	
	loadDefaultCategoryTemplate:function(openEditor){
		if(config.templateCategoryLength && config.templateCategoryLength > 0){
			 var defaultSubCategoryElm,defalutCategoryElm;
			 var defaultTemplateCategory=document.getElementById(config.defaultTemplateCategory);
			 if(openEditor && jQuery("#themes").css("display") != "none"){
				 openEditorPanel(jQuery("#themes"));
			 }
			 if(config.defaultTemplateCategory && defaultTemplateCategory){
				     defalutCategoryElm = jQuery("#"+config.defaultTemplateCategory).parent().parent().prev("li.ulCategory"),
				 	 defaultSubCategoryElm =jQuery("#"+config.defaultTemplateCategory); 
			 	}else{
			 		 defaultSubCategoryElm = jQuery("#template-list ul li").eq(0).next("ul").find("li:first a"),
				 	 defalutCategoryElm = jQuery("#template-list ul li").eq(0);
			 }
			 FQD.imgLib.showHideCategory(defalutCategoryElm);
		 	 
			 if(defaultSubCategoryElm && defaultSubCategoryElm.length > 0)
				 FQD.imgLib.attachEvent(defaultSubCategoryElm);
		 }else{
			 animateLeftEditorMemu(false);
			 FQD.shapes.showEditProperties();
		 }
	},
	
	 loadCategory:function(cetId){
		    var data;
		    if(cetId=="template-list"){
		    	
		    	//data=config.productDetails.templateCategory;
		    	data=FQD.utility.sortCategory(config.productDetails.templateCategory);
		    }
		    
		    if(cetId=="clipart-list"){
		    	data=config.productDetails.clipartCategory;
		    }
		    
		    if(cetId=="background-list"){
		    	data=config.productDetails.backgroundCategory;
		    }
		    
	    	if(data == undefined || data.length == 0){
	    		if(cetId == "background-list"){
	    			jQuery("."+cetId).hide();
	    		}else{
	    			jQuery("."+cetId+"-menu").hide();
	    		}
		    	return;
	    	}else{
	    		jQuery("."+cetId).show();
	    		jQuery("."+cetId+"-menu").show();
	    	}
	    	
			var content="<ul class='categoryList'>";
				jQuery.each(data ,function(i,data){
					if(data.parentId == "undefined" || data.parentId == "" || data.parentId == null){
						data.parentId=0;
					}
					if(data.parentId == 0){
						content+='<li class="ulCategory" id="'+data.id+'" onclick="FQD.imgLib.showHideCategory(jQuery(this));">\
								  <a href="javascript:void(0)" rel="'+cetId+'" title="'+FQD.imgLib.decodeData(data.name)+'">'+(FQD.imgLib.decodeData(data.name)).toLowerCase() +'</a>\
								  <i class="fa fa-caret-left fr" aria-hidden="true"></i>\
								  </li>\
								  <ul class="categoryList"></ul>';
					}
				});
			content +="</ul>";
			jQuery("#"+cetId).html(content);
			if(data!=null){
				jQuery.each(data ,function(i,data){
				if(data.parentId != 0){
					var imageCount = "";
					if(data.imageCount){
						imageCount ='('+data.imageCount+')';
					}
					jQuery("li#"+data.parentId).next("ul").append(
							'<li class="ulCategory">\
							 <a href="javascript:void(0)" title="'+FQD.imgLib.decodeData(data.name)+'" onclick ="FQD.imgLib.attachEvent(jQuery(this));"rel="'+cetId+'" id="'+data.id+'" class="ulCategory">\
							 <i class="material-icons add-icon">add_circle_outline</i> '+(FQD.imgLib.decodeData(data.name)).toLowerCase()+'&nbsp;'+imageCount+'\
							 </a><ul class="category-item"></ul></li>');
				}
			});	
			}
	 },
	 decodeData:function(data){
		 var decodedData=decodeURIComponent(atob(data)).replace(/\+/g," ");
		 return decodedData;
	 },
	adjustCategoryTab:function(){
		var hasTemplateCategory=true;
		var hasClipartCategory=true;
		var hasBackgroundCategory=true;
		
		if(config.productDetails.templateCategory == undefined || config.productDetails.templateCategory.length==0){
			hasTemplateCategory=false;
    	}
		if(config.productDetails.clipartCategory == undefined || config.productDetails.clipartCategory.length==0){
			hasClipartCategory=false;
    	}
		if(config.productDetails.backgroundCategory == undefined || config.productDetails.backgroundCategory.length==0){
			hasBackgroundCategory=false;
    	}
		
		if(hasTemplateCategory && !hasBackgroundCategory &&  hasClipartCategory){
			$("#clipArtImages").css('top','155px')
		}
		if(hasBackgroundCategory && !hasTemplateCategory &&  !hasClipartCategory){
			$("#backgroundArt").css('top','0px');
		}
		if(hasBackgroundCategory && !hasTemplateCategory &&  hasClipartCategory){
			$("#backgroundArt").css('top','0px');
			$("#clipArtImages").css('top','155px');
		}
		if(hasClipartCategory && !hasTemplateCategory &&  !hasBackgroundCategory){
			$("#clipArtImages").css('top','0px');
		}

	},
	
	loadMoreData:function(id){
		$("#loadingQD").show();
		$("#loaderContainer").show();
		var isDataOver=false;
		var content='';
		var startIndex=FQD.imgLib.imageCount*28+1;
		var count=startIndex;
		var endIndex=startIndex+28;
		var category='backgroundImageCategoryId';
		var catId = "background-item";
		var width=FQD.imgLib.setThumbWidthAsPerNumber(config.showThumbnails),
		height=config.canvasHeight * width/config.canvasWidth;
       if(endIndex>config.backgroundCategoryImageCollections[id].length || startIndex > config.backgroundCategoryImageCollections[id].length){
    	   isDataOver=true;
       }
       if(endIndex>config.backgroundCategoryImageCollections[id].length){
    	   endIndex=config.backgroundCategoryImageCollections[id].length;
       }
       var arr=config.backgroundCategoryImageCollections[id].slice(startIndex,endIndex);
       jQuery.each(arr ,function(i,data){
    	   var id = category + (new Date().getTime()*Math.random()).toFixed(0);
			  content+="<li onmouseover='FQD.imgLib.showLargeImage(event,jQuery(this),"+height+");' ondblclick=FQD.imgLib.setSelectedImage(jQuery(this).find('img'),'previewsrc','selected');><img rel='"+catId+"' id='"+id+"' src='"+data.thumbnailUrl+
		    	 "' previewsrc='"+data.previewUrl+"' filedescriptorid='"+data.fileDescriptorId+"' width='"+width+"' height='"+height+"' originalWidth='"+data.actualWidth+"' originalHeight='"+data.actualHeight+"' draggable='true' ondragstart='FQD.imgLib.onDragStartHandler(event)' /></li>";
			  count++;
		});
       $('#'+id).parent().find(".imglib").append(content);
        
		/*var arr=config.backgroundDataCollections.slice(startIndex,startIndex+28);
		FQD.imgLib.imageCount++;*/
		

		if(isDataOver){
			$('#'+id).parent().find(".backgroundImageOptions").remove();
		}
		FQD.imgLib.imageCount++;
		jQuery("body").removeClass("waiting");
		$("#loadingQD").hide();
		$("#loaderContainer").hide();
	},
	
	
	loadAllData:function(id){
		$("#loadingQD").show();
		$("#loaderContainer").show();
		var content="<div><ul class='imglib'>";
		var count=1;
		var category='backgroundImageCategoryId';
		var catId = "background-item";
		var width=FQD.imgLib.setThumbWidthAsPerNumber(config.showThumbnails),
		height=config.canvasHeight * width/config.canvasWidth;
		jQuery.each(config.backgroundCategoryImageCollections[id] ,function(i,data){
			var id = category + (new Date().getTime()*Math.random()).toFixed(0);
			  content+="<li onmouseover='FQD.imgLib.showLargeImage(event,jQuery(this),"+height+");' ondblclick=FQD.imgLib.setSelectedImage(jQuery(this).find('img'),'previewsrc','selected');><img rel='"+catId+"' id='"+id+"' src='"+data.thumbnailUrl+
		    	 "' previewsrc='"+data.previewUrl+"' filedescriptorid='"+data.fileDescriptorId+"' width='"+width+"' height='"+height+"' originalWidth='"+data.actualWidth+"' originalHeight='"+data.actualHeight+"' draggable='true' ondragstart='FQD.imgLib.onDragStartHandler(event)' /></li>";
			  count++;
		});
		content=content+"</ul></div>";
		$('#'+id).parent().find(".imglib").html(content);
		jQuery("body").removeClass("waiting");
		$('#'+id).parent().find(".backgroundImageOptions").remove();
		$("#loadingQD").hide();
		$("#loaderContainer").hide();
	},
	setThumbWidthAsPerNumber:function(num){
		var w=0,bw=jQuery("#editor-panel-container").width();
		    w=(bw/num)-35;
		return w;
		
	},
	getImgData:function(jsonUrl, cetId, catId){
		$("#loadingQD").show();
		$("#loaderContainer").show();
		config.fetchCategoryUrl=jsonUrl;
		var dir = "images/";
		var fileextension = ".png";
		var random=Math.random();
		FQD.activity.resetKeepAliveTimer();
		jQuery.ajax({
			url: jsonUrl+cetId+"&cid="+config.cid+"&random="+random,
			mimeType: 'text/plain; charset=x-user-defined',
			type:'GET',
			dataType: 'json',
			success: function(data){
				if(catId === "background-item"){
					FQD.imgLib.imageCount=1;
					//config.backgroundDataCollections=data;
					config.backgroundCategoryImageCollections[cetId]=data;
					//document.getElementById("background-item").scrollTop=0;
				}
				var content="<div><ul class='imglib' style='display: inline-block;'>";
				var category='';
				var count=1;
				if(config.fetchCategoryUrl=="/OnlineDesignerAction?QDAction=9&clipArtImageCategoryId=")
					{
					category='clipArtImageCategoryId';
					}
				if(config.fetchCategoryUrl=="/OnlineDesignerAction?QDAction=8&backgroundImageCategoryId=")
					{
					 category='backgroundImageCategoryId';
					}
				jQuery.each(data ,function(i,data)
				{
						var id = category + (new Date().getTime()*Math.random()).toFixed(0);
						var width=FQD.imgLib.setThumbWidthAsPerNumber(config.showThumbnails),
						height=config.canvasHeight * width/config.canvasWidth;
						
						if(catId === "template-item"){
							if(data.previewUrl){
								if((data.previewUrl[0] && data.previewUrl[0].indexOf("*")!=-1) || (data.previewUrl[1] && data.previewUrl[1].indexOf("*")!=-1)){
									return;
								}
								content+="<li onmouseover='FQD.imgLib.showLargeImage(event,jQuery(this),"+height+");' ondblclick=FQD.templateDataTransfer.getTemplateJSON(this.id); id='"+data.id+"'>" +
										"<img rel='"+catId+"' id='"+id+"' src='"+urlPrefix+data.previewUrl[0]+"' src2='"+urlPrefix+data.previewUrl[1]+"' previewsrc='"+urlPrefix+data.previewUrl[0]+"' width='"+width+"'height='"+height+"' draggable='true' ondragstart='FQD.imgLib.onDragStartHandler(event)'/>" +
									  "</li>";
							}
						}else if(catId === "background-item") {
							if(data.previewUrl){
								if(count<29){
									content+="<li onmouseover='FQD.imgLib.showLargeImage(event,jQuery(this),"+height+");' ondblclick=FQD.imgLib.setSelectedImage(jQuery(this).find('img'),'previewsrc','selected');><img rel='"+catId+"' id='"+id+"' src='"+urlPrefix+data.thumbnailUrl+
					      		    	 "' previewsrc='"+urlPrefix+data.previewUrl+"' filedescriptorid='"+data.fileDescriptorId+"' width='"+width+"' height='"+height+"' originalWidth='"+data.actualWidth+"' originalHeight='"+data.actualHeight+"' draggable='true' ondragstart='FQD.imgLib.onDragStartHandler(event)' /></li>";
								}
							}
						}
						else{
							if(data.actualHeight>=data.actualWidth){
								  var aspectRatio=data.actualHeight/65;
								  var width=data.actualWidth/aspectRatio;
								  var marginWidth=65-width;
								  content+="<li onmouseover='FQD.imgLib.showLargeImage(event,jQuery(this),"+width+");' ondblclick=FQD.imgLib.setSelectedImage(jQuery(this).find('img'),'previewsrc','selected');><img rel='"+catId+"' id='"+id+"' src='"+urlPrefix+data.thumbnailUrl+"' previewsrc='"+urlPrefix+data.previewUrl+"' filedescriptorid='"+data.fileDescriptorId+"' width='"+width+"' height='65' originalWidth='"+data.actualWidth+"' originalHeight='"+data.actualHeight+"'  style='margin-left:"+marginWidth/2+"px;' draggable='true' ondragstart='FQD.imgLib.onDragStartHandler(event)' /></li>";
							}else{
								  var aspectRatio=data.actualWidth/65;
								  var height=data.actualHeight/aspectRatio;
								  var marginHeight=65-height;
								  content+="<li <li onmouseover='FQD.imgLib.showLargeImage(event,jQuery(this),"+height+");' ondblclick=FQD.imgLib.setSelectedImage(jQuery(this).find('img'),'previewsrc','selected');><img rel='"+catId+"' id='"+id+"' src='"+urlPrefix+data.thumbnailUrl+"' previewsrc='"+urlPrefix+data.previewUrl+"' filedescriptorid='"+data.fileDescriptorId+"' width='65' height='"+height+"' originalWidth='"+data.actualWidth+"' originalHeight='"+data.actualHeight+"' style='margin-top:"+marginHeight/2+"px;' draggable='true' ondragstart='FQD.imgLib.onDragStartHandler(event)' /></li>";
							}
						}
					count++;
				});
				if(catId === "background-item" && data.length>28){
					content=content+"</ul></div></ul><div class='backgroundImageOptions'><span onclick='FQD.imgLib.loadMoreData("+cetId+");'>Load More</span><span onclick='FQD.imgLib.loadAllData("+cetId+");'>Load All</span></div>";
				}else{
					content=content+"</ul></div></ul>";
				}
				content=content+"</div>";
				jQuery("#"+cetId).next(".category-item").html(content);
				jQuery("body").removeClass("waiting");
				if(!config.designLoadedFromOrderPage){
					$("#loadingQD").hide();
					$("#loaderContainer").hide();
				}
				else{
					delete config.designLoadedFromOrderPage;
				}
			}, 
			error: function(xhr,err){
				jQuery("#"+cetId).next(".category-item").html("readyState: "+xhr.readyState+"\nstatus: "+xhr.status);
				jQuery("body").removeClass("waiting");
				$("#loadingQD").hide();
				$("#loaderContainer").hide();
			},
			  xhrFields:{
			        withCredentials: true
			     }
		}); 
	},
	initTemplate:function(){
		jQuery("#background-list, #clipart-list").find("li:first").next("ul").show();
		jQuery("#background-list, #clipart-list").find("li:first").next("ul").find("a").trigger("click");
	},
	showHideCategory:function(that){
			if(that.next("ul").css("display")=="none"){
				that.next("ul").slideDown("fast");
				that.find("i").removeClass("fa-caret-left").addClass("fa-caret-down");
			}else{
				that.next("ul").slideUp("fast");
				that.find("i").removeClass("fa-caret-down").addClass("fa-caret-left");
			}
	},
	showHideSubCategory:function(that){
		var htm = that.html();
		that.html("add_circle_outline");
		if(htm == "add_circle_outline"){
			that.html("remove_circle_outline");
			that.parent().next("ul").find("div").slideDown("fast");
		}else{
			that.parent().next("ul").find("div").slideUp("fast");
		}
	},
	attachEvent:function(that){
		
				if(!that.hasClass("b") && !that.next("i").hasClass("fa")){
					that.parent().parent().find("a").removeClass("b");
					var id=that.attr("id"),
						parentId=that.attr("rel");
					$('#'+parentId+' .categoryList a').removeClass("b");
					that.addClass("b");
					FQD.activity.resetKeepAliveTimer();
					if(that.next("ul").html().length == 0){
						if(parentId == "template-list"){
							var url=FQD.imgLib.templateImgUrl;
							if(config.foldingId){
								var addFoldType="&foldTypeId="+config.foldingId+"&designerTemplateCategoryId";
								url=FQD.imgLib.templateImgUrl.replace("designerTemplateCategoryId",addFoldType);
							}
							FQD.imgLib.getImgData(url,id ,"template-item");
						}
						if(parentId == "background-list"){
							FQD.imgLib.getImgData(FQD.imgLib.bgImgUrl,id ,"background-item");
						}
						if(parentId == "clipart-list"){
							FQD.imgLib.getImgData(FQD.imgLib.clipArtImgUrl,id ,"clipart-item");
						}
					}
				}
				FQD.imgLib.showHideSubCategory(that.find("i"));
	 },
	 
	 onDragStartHandler:function(event,templateApplyOnActivePage,pageNo){
		 if(templateApplyOnActivePage){
			 config.templateOnActiveCanvas={};
			 config.templateOnActiveCanvas.templateApplyOnActivePage=templateApplyOnActivePage;
			 config.templateOnActiveCanvas.pageNo=pageNo;
		 }
		 config.dragItemId=event.target.id;
		 event.dataTransfer.setData("dragItemId", event.target.id);
	 },
	 
	showLargeImage:function(e,that,h){
		jQuery(".showThumbPreviewImage").remove();
		var img = that.find("img");
		var mousex = e.pageX,
        mousey = e.pageY,
		front= img.attr("previewsrc"),
		back=img.attr("src2");
		var id=that.attr("id");
		
		if(img.attr("rel") == "clipart-item"){
			h="auto";
		}else{
			h=h*2;
		}

		if(!config.previewThumbnailImgWidth){
			var img = new Image();
			img.onload = function() {
				if(h>250){
					if(img.width>=img.height){
						config.previewThumbnailImgWidth=img.width*(img.height/250)+50;
						
					}else{
						config.previewThumbnailImgWidth=img.width*(250/img.height)+50;
					}
				}else{
					if(img.width>=img.height){
						config.previewThumbnailImgWidth=img.width*(h/img.height)+50;
						
					}else{
						config.previewThumbnailImgWidth=img.width*(img.height/h)+50;
					}
				
				}

				
				var id1 = (new Date().getTime()*Math.random()).toFixed(0);
				var id2 =(new Date().getTime()*Math.random()).toFixed(0);
					var div ='<div class="showThumbPreviewImage" style="top:'+mousey+'px; left:'+mousex+'px">';
						div +='<div class="large-img"><div class="singlePageDubleclick">'+resourcesData.templateSinglePagedoubleclick+'</div><img id="'+id1+'" rel="template-single-page" src="'+front+'" height="'+h+'"  templateId="'+id+'" draggable="true" ondragstart="FQD.imgLib.onDragStartHandler(event,true,1)" ondblclick=FQD.templateDataTransfer.getTemplateJSON('+id+',true,1);></div>';
						if(config.pageNumber.length > 1 && back != undefined){
							div +='<div class="large-img"><div class="singlePageDubleclick">'+resourcesData.templateSinglePagedoubleclick+'</div><img id="'+id2+'" rel="template-single-page" src="'+back+'" height="'+h+'" templateId="'+id+'" draggable="true" ondragstart="FQD.imgLib.onDragStartHandler(event,true,2)" ondblclick=FQD.templateDataTransfer.getTemplateJSON('+id+',true,2);></div>';
						}
						div+='</div>';
				jQuery("#mid-container").append(div);
				jQuery(".showThumbPreviewImage").css("width",config.previewThumbnailImgWidth+"px");
				var ww=jQuery(document).width(),
	        	wh=jQuery(document).height(),
	        	th=jQuery(".showThumbPreviewImage").height();
		    	if(mousey > (wh-th)){
		    		mousey = e.pageY -th;
		    	}
				jQuery(".showThumbPreviewImage").css("top",mousey+"px").fadeIn();
			};
			img.src=front;
		}else{
			var id1 = (new Date().getTime()*Math.random()).toFixed(0);
			var id2 =(new Date().getTime()*Math.random()).toFixed(0);
				var div ='<div class="showThumbPreviewImage" style="top:'+mousey+'px; left:'+mousex+'px">';
					div +='<div class="large-img"><div class="singlePageDubleclick">'+resourcesData.templateSinglePagedoubleclick+'</div><img id="'+id1+'" rel="template-single-page" src="'+front+'" height="'+h+'"  templateId="'+id+'" draggable="true" ondragstart="FQD.imgLib.onDragStartHandler(event,true,1)" ondblclick=FQD.templateDataTransfer.getTemplateJSON('+id+',true,1);></div>';
					if(config.pageNumber.length > 1 && back != undefined){
						div +='<div class="large-img"><div class="singlePageDubleclick">'+resourcesData.templateSinglePagedoubleclick+'</div><img id="'+id2+'" rel="template-single-page" src="'+back+'" height="'+h+'" templateId="'+id+'" draggable="true" ondragstart="FQD.imgLib.onDragStartHandler(event,true,2)" ondblclick=FQD.templateDataTransfer.getTemplateJSON('+id+',true,2);></div>';
					}
					div+='</div>';
			jQuery("#mid-container").append(div);
			jQuery(".showThumbPreviewImage").css("width",config.previewThumbnailImgWidth+"px");
			var ww=jQuery(document).width(),
        	wh=jQuery(document).height(),
        	th=jQuery(".showThumbPreviewImage").height();
	    	if(mousey > (wh-th)){
	    		mousey = e.pageY -th;
	    	}
			jQuery(".showThumbPreviewImage").css("top",mousey+"px").fadeIn();
		}


		



	}
	 
}


