FQD.ruler = {};


FQD.ruler.changeUnit = function(unit,tick,changeUnit)
{
	if(changeUnit){
		config.changeUnit=true;
	}else{
		config.changeUnit=false;
	}
	config.unit=unit;
	config.tick=tick;
	jQuery('.canvas-container').ruler({
		unit: unit,
		tickMajor: tick,
		showLabel: true,
		arrowStyle:'arrow'
	});
	if(unit != "px"){
		var elm=jQuery("canvas#c"+config.activeCanvas).closest('.canvas-container');
		
		jQuery.each(elm.find(".top .major"),function(i){
			var left=jQuery(this).css("left");
			jQuery.each(jQuery(".canvas-container"),function(k){
				jQuery(this).find("div.top").find("div.major").eq(i).css("left",left);
			});
		});
		
		jQuery.each(elm.find(".left .major"),function(i){
			var left=jQuery(this).css("top");
			jQuery.each(jQuery(".canvas-container"),function(k){
				jQuery(this).find("div.left").find("div.major").eq(i).css("top",left);
			});
		});
	}
	
	jQuery(".top-arrow").css("margin-left", "-18px");
	jQuery(".left-arrow").css("margin-top", "-18px")
	
	FQD.utility.showXYCoordinates(FQD.canvas.getActiveObjects());
	
	var rulerMajorTopLeft = 0;
	if(jQuery(".top").find(".major").eq(1).css("left") != undefined)
		rulerMajorTopLeft = parseFloat((jQuery(".top").find(".major").eq(1).css("left")).replace("px"));
	if(rulerMajorTopLeft < 25 ){
		jQuery(".top,.left").find(".micro,.minor").remove();
		jQuery(".top,.left").find(".major").html("");
	}
	
	FQD.utility.setProductDimensions(unit,changeUnit);	
}

FQD.ruler.showHideRuler=function(show){
	if(show){
		jQuery(".ruler").show();
	}else{
		jQuery(".ruler").hide();
	}
}

FQD.ruler.addWraper=function(){
	var w=FQD.elements.divScroller.width(),
	h=FQD.elements.divScroller.height();
	rw=jQuery("div.top").height(),
	rh=jQuery("div.left").width(),
	bgColor=jQuery("#qd-wrapper").css("background-color");
	jQuery(".canvas-container").find("div.top").wrap( '<div class="ruler-wrap-top"style="background:'+bgColor+'"></div>');
	jQuery(".canvas-container").find("div.left").wrap( '<div class="ruler-wrap-left" style="background:'+bgColor+'"></div>');
	jQuery(".ruler-wrap-top").height(rh).width(w-19);
	jQuery(".ruler-wrap-left").width(rw).height(h-19);
	jQuery(".ef-ruler").append('<div class="ruler-corner" style="background:'+bgColor+'"></div>')
}

FQD.ruler.setRulerPan=function(x,y){
	var topRuler=jQuery(".ruler-wrap-top").find(".top"),
	    leftRuler=jQuery(".ruler-wrap-left").find(".left"),
	    marginLeft = parseFloat(topRuler.css("margin-left").replace("px",""));
	    marginTop = parseFloat(leftRuler.css("margin-top").replace("px",""));
	    topRuler.css("margin-left",marginLeft+x+"px");
	    leftRuler.css("margin-top",marginTop+y+"px");
}

