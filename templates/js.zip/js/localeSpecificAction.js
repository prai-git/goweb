
if(locale=="de_AT" || locale=="de_DE"){
	$("#qd-wrapper .edit-tools-panel .text-edit-tool .t-sub-headline").css("padding-left","9px");
	$("#qd-wrapper .edit-tools-panel .text-edit-tool .t-sub-headline").css("margin-top","-45px");
	
}