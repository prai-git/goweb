var numberOfUploadFiles;
(function() {
	var filesArray=[],filesFlag=true;
	function $id(id) {
		return document.getElementById(id);
	}
	function FileDragHover(e) {
		e.stopPropagation();
		e.preventDefault();
		if(e.target.id == "filedrag") e.target.className = (e.type == "dragover" ? "hover" : "");
	}

	function FileSelectHandler(e) {
		isSessionChanged(function(){
			FileSelectHandlerForDragDrop(e);
		});
		
	}
	function FileSelectHandlerForDragDrop(e) {
		FileDragHover(e);
		var filesList = e.target.files || e.dataTransfer.files;
		var files=[];
		for (var i = 0, f; f = filesList[i]; i++) {
				var isValid = checkValidFileNames(f.name);
				if(f.size > MAX_FILE_SIZE){
					gotError(fileSizeError);
				} 
			 	else if(!isValid) {
			 		gotError(invalidCharsInFileName);
			 	}
				else if(f.name.indexOf("%") >= 0){
			 		gotError(containPercentageCharacter);
			 	}
				else{
					files.push(f);
				}
		}
		for (var i = 0, f; f = files[i]; i++) {
			//File name cannot contain % (percentage) character
			if(hasValidFileExtention(f, true)){
			 		filesArray.push(f);
			 	}else{
			 		filesFlag=false;
			 		gotError(errorPrintImgTypeMessage);
			 		jQuery('input#fileselect').val(null);
			 	}
		}
		for (var i = 0; i < filesArray.length; i++) {
			UploadFile(filesArray[i],filesArray.length,i);
		}
		
	}
	function checkValidFileNames(fileName) {

		// remove backslash as, chrome returns full path of image
	 	fileName= fileName.replace('\f','');
	 	fileName= fileName.replace('\\','');
	 	 var specialCharPresent = /&#|&amp;#/g.test(fileName);
	 	 
	 	var isValid= validateIllegalChars(fileName);
	      if(specialCharPresent || !isValid) {
			 return false;
		 }
		 return true;
		
	}
	
	function validateIllegalChars(str) { 
		var isValid=checkForSpecialcharecters(str);
		if(!isValid){
			return false;
		}
	    var re1 = /[\u0009\u000A\u000D\u0020-\uD7FF\uE000-\uFFFD]/g;  // #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] 
	    var re2 = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g; // [#x10000-#x10FFFF]

	    var res = str.replace(re1, '').replace(re2, ''); // Should remove any valid character

	    if (!!res && res.length > 0) {  //## any remaining characters, means input str is not valid 
	        return false; 
	    }

	    return true; 
	} 
	function checkForSpecialcharecters(str){

		var validFilename=true;
		//var validFilename = /^[a-z0-9_.@()-]+\.[^.]+$/i.test(str);
		
		 if(str.search(/[<>'+\"\/;`%]/)>0){
			 validFilename=false;
		 }
		return validFilename;
	
	}
	function UploadFile(file,numberOfFiles,currentFile) {
				jQuery("#ajaxLoader").show();
		        var formdata = new FormData();
		        formdata.append("fileselect", file);
		        var xhr = new XMLHttpRequest();
		        
		        jQuery.ajax({
		        	mimeType: 'text/plain; charset=x-user-defined',
		        	type : 'post',
		    		url : '/UserImageJsonAction',
		    		data : {
		    			"requestCode" : 23,
		    			"info": "{ FileName: "+file.name+", FileType: "+file.type+", FileSize: "+file.size+"bytes }"
		    		}
		    	});
		        
		        xhr.withCredentials = true;
				var o = $id("progress");
				var progress = o.appendChild(document.createElement("p"));
				progress.appendChild(document.createTextNode(upload+" " + file.name));
	
				xhr.upload.addEventListener("progress", function(e) {
					var pc = parseInt(100 - (e.loaded / e.total * 100));
					progress.style.backgroundPosition = pc + "% 0";
				}, false);
				xhr.onreadystatechange = function(e) {
					if (xhr.readyState == 4) {
						if(xhr.status == 200){
							progress.className="success";
							jQuery(progress).remove();
							if(numberOfFiles-1==currentFile){
								isUploadProcessing(numberOfFiles);
								filesArray.length=0;
							}
						}else{
							progress.className="failure";
							jQuery("#ajaxLoader").hide();
							gotError(serverError);
						}
					}
				};
				xhr.open("POST", $id("upload").action, true);
				//xhr.setRequestHeader("X_FILENAME", file.name);
				xhr.setRequestHeader("totalNumberOfFiles", numberOfFiles);
				xhr.setRequestHeader("callFromModule", "FQD");
				xhr.send(formdata);
			    document.getElementById("fileselect").className="fileselect";
	}
	
	var responseMessage='<div id="responseMessage" class="loaderMessage">Uploading File</div>';
	jQuery("#fileUploadWrapper").append(responseMessage);
	function isUploadProcessing(numberOfFiles){
		numberOfUploadFiles=numberOfFiles;
		jQuery("#ajaxLoader").show();
		var myflag = false, myVar, setTime;
		var random=Math.random();
				  setTime=setInterval(function setTimmer(){
						jQuery.ajax({
							mimeType: 'text/plain; charset=x-user-defined',
							type: 'post',
					        url: myUploads.jsonUrl,
					        data: {"requestCode":9,"random":random} ,
					        dataType: 'json',
					        success: function (data) {
					        	jQuery("#responseMessage").html(data.responseMessage).fadeIn("fast");
					        	if(data.isProcessingComplete == true){
					        		clearInterval(setTime);
					        		myflag=true;
					        		myUploads.getSelectedImg("recentImages");
					        		if(numberOfFiles==1 && filesFlag && data.currentUploadFd != null && data.currentUploadFd != undefined ){
					        		
					        		}
					        		filesFlag=true;
					        		jQuery("#responseMessage").html("").hide();
					        		jQuery('input#fileselect').val(null);
					        		
					        		if(data.colorspace != undefined && (data.colorspace == "SRGB" || data.colorspace == "RGB"))
					        		{
					        			config.isRGBPopupOpen = true;
					        		}
					        	}
					        },
					        //timeout: 5000, // set timeout to 5 seconds
					        error:function(jqXHR, textStatus, errorThrown){
					        	clearInterval(setTime);
					        	console.log(textStatus, errorThrown);
					        	jQuery("#ajaxLoader").hide();
					        	myUploads.getSelectedImg("recentImages");
					        	gotError(serverError);
					        	jQuery('input#fileselect').val(null);
					        },
						    xhrFields:{
						        withCredentials: true
						     }
					 });
			} , 1000);
	}
	
	function Init() {
		var fileselect = $id("fileselect"),
			filedrag = $id("filedrag"),
			submitbutton = $id("submitbutton");
		//fileselect.addEventListener("change", FileSelectHandler, false);
		jQuery("body").delegate("#fileselect","change",FileSelectHandler);	
		var xhr = new XMLHttpRequest();
		if (xhr.upload) {
			setTimeout(function(){ 
				if(document.getElementById("filedrag"))document.getElementById("filedrag").addEventListener("dragover", FileDragHover, false);
				if(document.getElementById("filedrag"))document.getElementById("filedrag").addEventListener("dragleave", FileDragHover, false);
				if(document.getElementById("filedrag"))document.getElementById("filedrag").addEventListener("drop", FileSelectHandlerForDragDrop, false);
				if(document.getElementById("messages"))document.getElementById("messages").addEventListener("dragover", FileDragHover, false);
				if(document.getElementById("messages"))document.getElementById("messages").addEventListener("dragleave", FileDragHover, false);
				if(document.getElementById("messages"))document.getElementById("messages").addEventListener("drop", FileSelectHandler, false);
			}, 5000);

			filedrag.style.display = "block";
			submitbutton.style.display = "none";
		}
		
		document.getElementById("btnToShow").style.display="inline-block";
		document.getElementById("fileselect").className="fileselect";
		document.getElementById("fileselect").accept=printFileExtentions;
		jQuery("#fileselect").click(function(){
			jQuery("#filedrag").css("visibility","hidden");
		});
		jQuery(window,document).mouseenter(function(){
			jQuery("#filedrag").css("visibility","visible");
		});
	}
	if (window.File && window.FileList && window.FileReader) {
		Init();
	}else{
		document.getElementById("btnToShow").style.display="none";
		document.getElementById("fileselect").className="none";
		document.getElementById("fileselect").accept=printFileExtentions;
		document.getElementById("fileselect").style.opacity="10 !important";
		document.getElementById("fileselect").style.filter="alpha(opacity=100) !important";
		
		jQuery("#upload").prepend('<script src="'+resourceURL+'/common/htmlupload/js/jquery.form.min.js" type="text/javascript"></script>');
		jQuery("#upload").submit(function(){
			jQuery("#ajaxLoader").show();
			 jQuery(this).ajaxSubmit({ 
				 			success: afterSuccess
				 }); 
			 return false; 
		});
		function afterSuccess(e){
			isUploadProcessing(1);
		}
	}
	jQuery("#editor-panel-container").delegate("#upFiles","click", function(event) {
		if(!jQuery(this).hasClass("current")){
			myUploads.searchString="";
			myUploads.pageNumber=1;
			isSessionChanged(function(){
				myUploads.getSelectedImg("recentImages");
			});
			jQuery(document.getElementById("gotError")).remove();
		}
	});
	
		
		
})();


function manualProofFilesCheck(proofType){
	singleFileUploadOnManual();
}