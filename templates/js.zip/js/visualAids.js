FQD.visualAids={};
$('#gridWidth').val(resourcesData.gridWidth);
FQD.visualAids.showHideEveryThing=function(id,value){
	jQuery("#"+id).find("input[type='checkbox']").prop("checked",value);
	FQD.visualAids.showHideSafeZone(value);
	FQD.visualAids.showHideTrimZone(value);
	FQD.ruler.showHideRuler(value);
	FQD.visualAids.disableEnableSlider("#grid-slider",value);
	FQD.visualAids.drawGrid(config.gridSize,value);
	FQD.visualAids.showHideObjectProperties(value);
	FQD.visualAids.addScissors(value);
}

FQD.visualAids.showAndClose=function(id,action){
	if(action == "close"){
		jQuery("#"+id).removeClass('show-visual-aids').height(0).css("margin-top","0px");
	}else{
		if(config.visualAdHeight == 0){
			config.visualAdHeight = "auto";
			config.visualAdTop=560;
		}
		jQuery("#"+id).addClass('show-visual-aids').height(config.visualAdHeight).css("margin-top","-"+config.visualAdTop+"px");
	}
}

FQD.visualAids.showHideObjectProperties=function(show){
	if(show){
		jQuery("#objInfo").show();
	}else{
		jQuery("#objInfo").hide();
	}
	
}


FQD.visualAids.enableTransferTemplate=function(showTemplateDialog){
	config.transferTemplateDialog=showTemplateDialog;
	if(typeof Storage  != "undefined"){
		 sessionStorage.setItem('transferTemplateDialog', showTemplateDialog);
	 }
}


FQD.visualAids.autoZoom=function(auto){
	config.autoZoom=auto;
}
FQD.visualAids.showHideSafeZone=function(show){
	for(var i = 0; i < FQD.canvas.pages.length; i++){
		var canvas = FQD.canvas.pages[i];
		var sz = FQD.canvas.getSafeZone(i);
		if(sz != undefined)
			sz.visible = show;
		canvas.renderAll();
	}
}

FQD.visualAids.showHideTrimZone=function(show){
	for(var i = 0; i < FQD.canvas.pages.length; i++){
		var canvas = FQD.canvas.pages[i];
		var tz = FQD.canvas.getTrimZone(i);
		if(tz != undefined)
			tz.visible = show;
		canvas.renderAll();
	}
}

FQD.visualAids.setGridSlider=function(id,inp){
	
	jQuery(id).slider({
		range : "max",
		min : 20,
		max : 100,
		value : jQuery(inp).val(),
		disabled : true,
		slide : function(event, ui) {
			jQuery(inp).val(ui.value);
		},
		change : function(event, ui) {
			config.gridSize=ui.value;
				FQD.visualAids.drawGrid(ui.value,true);
		}
	});
	
}

FQD.visualAids.toggleZone=function(that){
	if(that.find("a").hasClass("hideZone")){
		that.find("a").removeClass("hideZone");
		jQuery("#btnTrim, #btnSafe").prop("checked",true);
		FQD.visualAids.showHideSafeZone(true);
		FQD.visualAids.showHideTrimZone(true);
	}else{
		that.find("a").addClass("hideZone");
		jQuery("#btnTrim, #btnSafe").prop("checked",false);
		FQD.visualAids.showHideSafeZone(false);
		FQD.visualAids.showHideTrimZone(false);
	}
	
}

FQD.visualAids.disableEnableSlider=function(id,flag){
	
	if(flag){
		jQuery(id).slider({disabled : false,});
	}else{
		jQuery(id).slider({disabled : true,});
	}
	
}


FQD.visualAids.drawGrid=function(grid,draw){
	FQD.canvas.pages.forEach(function(canvas){
		var grids =canvas.getItemsByName("grid"); 
		if(grids){
			grids.forEach(function(obj){
					canvas.remove(obj);
			});
		}
		if(!draw){
			return;
		}
	    	for (var i = 0; i < (config.canvasOrigin.width / grid); i++) {
	    			var left=config.canvasOrigin.x0+i*grid;
	    		  canvas.add(new fabric.Line([ i * grid, 0, i * grid, config.canvasOrigin.height], { 
	    			  	stroke: '#ccc', 
	    			  	strokeWidth: 0.5, 
	    			  	selectable: false, 
	    			  	top:config.canvasOrigin.y0,
	    			  	name:"grid",
	    			  	alwaysNotselectable:true,
	    			  	evented : false,
	    			  	id:"removeFromPreview",
	    			  	excludeFromExport:true,
	    		 	  	left:left 
	    		  		}));
	    		}
	    		for (var i = 0; i < (config.canvasOrigin.height / grid); i++) {		
	    			var top=top=config.canvasOrigin.y0+i*grid;
	    			canvas.add(new fabric.Line([ 0, i * grid, config.canvasOrigin.width, i * grid], { 
	    				stroke: '#ccc', 
	    				strokeWidth: 0.5, 
	    				selectable: false,
	    				id:"removeFromPreview",
	    				name:"grid",
	    				alwaysNotselectable:true,
	    				excludeFromExport:true,
	    				evented : false,
	    				top:top,
	    				left:config.canvasOrigin.x0 
	    			}))
	    		}
			
		canvas.renderAll();
	});
}

FQD.visualAids.enableImageWarnings=function(isShow){
	config.isImageWArnings = isShow;
	if(typeof Storage  != "undefined"){
		if(isShow){
			localStorage.setItem('isImageWArnings',isShow);
		}else{
			jQuery(".warning-msg").remove();
			localStorage.removeItem('isImageWArnings');
		}
	}
}

FQD.visualAids.fastDraftMode=function(mode){
	if(mode){
		config.isHDImage=false;
	}else{
		config.isHDImage=true;
	}
	var obj= FQD.canvas.pages[config.activeCanvas].getObjects();
	for (var i=0;i< obj.length ;i++){
		if(obj[i].type == "image"){
			FQD.elements.divLoadingQd.show();
			FQD.elements.divLoaderContainer.show();
			var img = new Image();
			img.onload = function() {
				FQD.elements.divLoadingQd.hide();
				FQD.elements.divLoaderContainer.hide();
			}
			img.onerror=function(){
				FQD.elements.divLoadingQd.hide();
		    	FQD.elements.divLoaderContainer.hide();
			}
			img.src=FQD.imgLib.updateHdImage(obj[i].getSrc());
		}
	}
	var i=0,length=FQD.canvas.pages.length;
	for (i; i < length ; i++) {
		var json=FQD.canvas.pages[i].toJSON(config.newProperties);
		FQD.undoManager.loadCanvasFromJSON(json,FQD.canvas.pages[i]);
	}
}

FQD.visualAids.hideInformationPopup=function(){
	FQD.elements.lockMessage.hide();
	FQD.elements.imgResizeWarning.hide();
}
FQD.visualAids.restoreDefaultsettings=function(){
	
	FQD.visualAids.showHideEveryThing('divCanvasMenu',false);
	config.transferTemplateDialog=false;
	FQD.visualAids.addScissors(false);
	if(!$('#btnRuler').prop('checked')){
		$('#btnRuler').click();
	}
	if(!$('#btnSafe').prop('checked')){
		$('#btnSafe').click();
	}
	if(!$('#btnTrim').prop('checked')){
		$('#btnTrim').click();
	}
	if($('#btnGrid').prop('checked')){
		$('#btnGrid').click();
	}
	if(!$('#btnWarn').prop('checked')){
		$('#btnWarn').click();
	}
	if(!$('#btnGuidelines').prop('checked')){
		$('#btnGuidelines').click();
	}
	if(!$('#auto-zoom').prop('checked')){
		$('#auto-zoom').click();
	}
	
	if($('#enableobjectProperties').prop('checked')){
		$('#enableobjectProperties').click();
	}
	if(locale=="en_GB"||locale=="de_DE"||locale=="de_AT"||locale=="fr_FR"||locale=="nl_NL"||locale=="en_IE"||locale=="nl_BE"){
		$("#MM").click();
	}else{
		$("#IN").click();
	}
	$('#gridWidth').val(resourcesData.gridWidth);
	FQD.visualAids.setGridSlider('#grid-slider','#gridWidth');
	FQD.visualAids.drawGrid(jQuery('#gridWidth').val(),false);

}

FQD.visualAids.applyChangedSetting = function(){
	FQD.visualAids.showHideSafeZone($('#btnSafe').prop('checked'));
	FQD.visualAids.showHideTrimZone($('#btnTrim').prop('checked'));
}

FQD.visualAids.addScissors=function(isChecked){

  if(FQD.PrintProductType.isRectangularProduct()){
	  if(isChecked){
		   for(var i=0;i<FQD.canvas.pages.length;i++){
				    var canvas=FQD.canvas.pages[i];
					var zoneGap = FQD.canvas.getCanvasZonesGap(0);
					var bleed_L = zoneGap.bleedZone.bleedLeft;
					var bleed_B = zoneGap.bleedZone.bleedBottom;
					var bleed_T = zoneGap.bleedZone.bleedTop;
					
					 var width=30;	
					 var height=24.1;

						    var intZoom=FQD.canvas.pages[0].getZoom();
						    var scaleFactor=1;
						    var factor=(intZoom-0.6);
						    factor=0.6-factor;
						    if(factor>0){
						    	scaleFactor=factor/0.6;
						    }
						    if(intZoom>=0.6){
						    	scaleFactor=(0.6/intZoom);
						    }
						    if(intZoom>1){
						    	scaleFactor=(0.6/intZoom)*1.3;
						    	
						    }
						   // scaleFactor=1;
						 var d=jQuery("#scissor").find("path").attr("d");
							var scissorRight = new fabric.Path(d, {
						        originX: 'left',
						        originY: 'top',
						        left: config.canvasOrigin.x0+bleed_L+config.canvasWidth*.2,
						        top: config.canvasOrigin.y0-(height*scaleFactor)/2+bleed_T,
						        fill: '#ff0000', 
						        width:width,
						        height:height,
						        id:"removeFromPreview",
						        selectable: false,
						        objectCaching:false,
						        excludeFromExport:true,
						        evented : false,
						        alwaysNotselectable:true,
						        name:"overlayElm"
							});

							var scissorLeft = new fabric.Path(d, {
						        originX: 'left',
						        originY: 'top',
						        left: config.canvasOrigin.x1-bleed_L-config.canvasWidth*.2,
						        top: config.canvasOrigin.y1-(height*scaleFactor)/2-bleed_B,
						        fill: '#ff0000', 
						        width:width,
						        height:height,
						        id:"removeFromPreview",
						        selectable: false,
						        objectCaching:false,
						        excludeFromExport:true,
						        evented : false,
						        alwaysNotselectable:true,
						        flipX:true,
						        name:"overlayElm"
							});
							scissorLeft.scaleX=scissorLeft.scaleX*scaleFactor;
							scissorLeft.scaleY=scissorLeft.scaleY*scaleFactor;
							scissorRight.scaleX=scissorRight.scaleX*scaleFactor;
							scissorRight.scaleY=scissorRight.scaleY*scaleFactor;
							config.scissorArr[i][0]=canvas;
							config.scissorArr[i][1]=scissorLeft;
							config.scissorArr[i][2]=scissorRight;
							canvas.add(scissorLeft);
					    	canvas.add(scissorRight);
					    	scissorRight.bringToFront();
					    	scissorLeft.bringToFront();
					    	canvas.renderAll();
						 
					// }
					 
				
				
				
			}
	   }else{
		   if(config.scissorArr[0].length>0){
			   config.scissorArr[0][0].remove(config.scissorArr[0][1]);
			   config.scissorArr[0][0].remove(config.scissorArr[0][2]);
			   config.scissorArr[0][0].renderAll();
		   }
		   if(config.scissorArr[1].length>0){
			   config.scissorArr[1][0].remove(config.scissorArr[1][1]);
			   config.scissorArr[1][0].remove(config.scissorArr[1][2]);
			   config.scissorArr[1][0].renderAll();
		   }
		   
	   }
  }
}
