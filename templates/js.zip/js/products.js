/*******************************************************************************
 * 
 * Responsible write condition to initialize application as per product type 
 * 
 * 
 ******************************************************************************/
FQD.products={};

FQD.products.hasTemplateOverlay = function(){
	return (config.productDetails.backgroundSwfName != "")? true: false;
}

FQD.products.getTemplateOverlayPath = function(pageNum)
{
	var oPath = config.productDetails.backgroundSwfName;
	
	if(FQD.PrintProductType.isDoorHanger())
		oPath += "_DOOR_HANGER";
	else if(FQD.PrintProductType.isFolder()){
		switch(config.pocketId)
		{
			case FQD.PrintProductType.POCKET_RIGHT:
				oPath += "-RIGHT_POCKET";
				break;
			case FQD.PrintProductType.POCKET_LEFT:
				oPath += "-LEFT_POCKET";
				break;
			case FQD.PrintProductType.POCKET_DOUBLE:
				oPath += "-DOUBLE_POCKET";
				break;
		}
	}
	
	if(pageNum == 1){
		oPath = oPath + "-FRONT";
	}else if(FQD.products.isFrontBackProduct() && pageNum == 2){
		oPath = oPath + "-BACK";
	}
	
	return oPath;
}

FQD.products.isFrontBackProduct = function(){
	if(FQD.PrintProductType.isSpecialShape() || 
			FQD.PrintProductType.isDoorHanger() ||
			FQD.PrintProductType.isRIPBusinessCard() ||
			FQD.PrintProductType.isYardSign() ||
			FQD.PrintProductType.isEventTicket() ||
			FQD.PrintProductType.isFolder() ||
			FQD.PrintProductType.isCDPackage() ||
			FQD.PrintProductType.isDVDPackage() ||
			FQD.PrintProductType.isGenericProduct()){
		return true;
	}
	return false;
}


FQD.products.getSinglePageData = function()
{
	if(config.productTypeId == FQD.PrintProductType.ROLL_LABEL){
		return FQD.products.getSpecialShapePageIcon(config.productShape);
	}
	else if(config.productOrientation == FQD.ApplicationConstants.VERTICAL){
		switch(config.productTypeId)
		{
			case FQD.PrintProductType.BANNER:
				return {frontOn:"Banner_Von.png", frontOff:"Banner_Voff.png"};
				break;
			case FQD.PrintProductType.BROCHURE:
				return {frontOn:"Brochures.png", frontOff:"Brochures_off.png"};
				break;
			case FQD.PrintProductType.BUSINESS_CARD:
				return {frontOn:"bc-vertical-front-only-on.png", frontOff:"bc-vertical-front-only-off.png"};
				break;
			case FQD.PrintProductType.ENVELOPE:
				if(config.productDetails.window != undefined){
					return {frontOn:"EnvelopeWithWindow.png", frontOff:"EnvelopeWithWindow.png"};
				}else{
					return {frontOn:"Envelope.png", frontOff:"Envelope.png"};
				}
				break;
			case FQD.PrintProductType.MINI_MENU:
				return {frontOn:"MiniMenu.png", frontOff:"MiniMenu.png"};
				break;
			case FQD.PrintProductType.NOTEPAD:
				return {frontOn:"Notepad_Von.png", frontOff:"Notepad_Voff.png"};
				break;
			case FQD.PrintProductType.POSTER:
				return {frontOn:"Poster_Von.png", frontOff:"Poster_Voff.png"};
				break;
			case FQD.PrintProductType.STICKER:
				return {frontOn:"Sticker_Von.png", frontOff:"Sticker_Voff.png"};
				break;
			case FQD.PrintProductType.TABLE_TENT:
				return {frontOn:"TableTent.png", frontOff:"TableTent.png"};
				break;
			case FQD.PrintProductType.WIDE_POSTER:
				return {frontOn:"PosterWide_Von.png", frontOff:"PosterWide_Voff.png"};
				break;
			case FQD.PrintProductType.WINDOW_CLING:
			case FQD.PrintProductType.WINDOW_DECAL:
				return {frontOn:"WindowCling_Von.png", frontOff:"WindowCling_Voff.png"};
				break;
			default:
				return {frontOn:"postcard-vertical-front-on.png", frontOff:"postcard-vertical-front-off.png"};
			break;
		}
	}else{
		switch(config.productTypeId)
		{
			case FQD.PrintProductType.BANNER:
				return {frontOn:"Banner_Hon.png", frontOff:"Banner_Hoff.png"};
				break;
			case FQD.PrintProductType.BROCHURE:
				return {frontOn:"Brochures.png", frontOff:"Brochures_off.png"};
				break;
			case FQD.PrintProductType.BUSINESS_CARD:
				return {frontOn:"front-only-on.png", frontOff:"front-only-off.png"};
				break;
			case FQD.PrintProductType.ENVELOPE:
				if(config.productDetails.window != undefined){
					return {frontOn:"EnvelopeWithWindow.png", frontOff:"EnvelopeWithWindow.png"};
				}else{
					return {frontOn:"Envelope.png", frontOff:"Envelope.png"};
				}
				break;
			case FQD.PrintProductType.MINI_MENU:
				return {frontOn:"MiniMenu.png", frontOff:"MiniMenu.png"};
				break;
			case FQD.PrintProductType.NOTEPAD:
				return {frontOn:"Notepad_Hon.png", frontOff:"Notepad_Hoff.png"};
				break;
			case FQD.PrintProductType.POSTER:
				return {frontOn:"Poster_Hon.png", frontOff:"Poster_Hoff.png"};
				break;
			case FQD.PrintProductType.STICKER:
				return {frontOn:"Sticker_Hon.png", frontOff:"Sticker_Hoff.png"};
				break;
			case FQD.PrintProductType.TABLE_TENT:
				return {frontOn:"TableTent.png", frontOff:"TableTent.png"};
				break;
			case FQD.PrintProductType.WIDE_POSTER:
				return {frontOn:"PosterWide_Hon.png", frontOff:"PosterWide_Hoff.png"};
				break;
			case FQD.PrintProductType.WINDOW_CLING:
			case FQD.PrintProductType.WINDOW_DECAL:
				return {frontOn:"WindowCling_Hon.png", frontOff:"WindowCling_Hoff.png"};
				break;
			default:
				return {frontOn:"postcard-horizontal-front-on.png", frontOff:"postcard-horizontal-front-off.png"};
			break;
		}
	}
}

FQD.products.getTwoPageData = function()
{
	if(config.productTypeId == FQD.PrintProductType.YARD_SIGN){
		return FQD.products.getYardSignPageIcon(config.productSizeId);
	}
	else if(config.productTypeId == FQD.PrintProductType.SPECIAL_SHAPE){
		return FQD.products.getSpecialShapePageIcon(config.productShape);
	}
	else if(config.productOrientation == FQD.ApplicationConstants.VERTICAL){
		switch(config.productTypeId)
		{
			case FQD.PrintProductType.BOOKMARK:
				return {frontOn:"Bookmark_Von.png", frontOff:"Bookmark_Voff.png", frontBackOn:"Bookmark2Sided_Von.png", frontBackOff:"Bookmark2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.BUSINESS_CARD:
				return {frontOn:"bc-vertical-front-only-on.png", frontOff:"bc-vertical-front-only-off.png", frontBackOn:"bc-vertical-front-back-on.png", frontBackOff:"bc-vertical-front-back-off.png"};
				break;
			case FQD.PrintProductType.CLUB_FLYER:
				return {frontOn:"ClubFlyer_Von.png", frontOff:"ClubFlyer_Voff.png", frontBackOn:"ClubFlyer2Sided_Von.png", frontBackOff:"ClubFlyer2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.COLLECTORS_CARD:
				return {frontOn:"CollectorCard_Von.png", frontOff:"CollectorCard_Voff.png", frontBackOn:"CollectorCard2Sided_Von.png", frontBackOff:"CollectorCard2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.DOOR_HANGER:
				return {frontOn:"DoorHanger-on.png", frontOff:"DoorHanger-off.png", frontBackOn:"DoorHanger2Sided-on.png", frontBackOff:"DoorHanger2Sided-off.png"};
				break;
			case FQD.PrintProductType.EVENT_TICKET:
				return {frontOn:"EventTicket_Von.png", frontOff:"EventTicket_Voff.png", frontBackOn:"EventTicket2Sided_Von.png", frontBackOff:"EventTicket2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.FLYER:
				return {frontOn:"Flyer_Von.png", frontOff:"Flyer_Voff.png", frontBackOn:"Flyer2Sided_Von.png", frontBackOff:"Flyer2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.FOLDER:
				return {frontOn:"Folder_on.png", frontOff:"Folder_off.png", frontBackOn:"Folder2Sided_on.png", frontBackOff:"Folder2Sided_off.png"};
				break;
			case FQD.PrintProductType.FOLDED_BUSINESS_CARD:
				return {frontOn:"FoldedBusinessCard_Hon.png", frontOff:"FoldedBusinessCard_Hoff.png", frontBackOn:"FoldedBusinessCard2Sided_Hon.png", frontBackOff:"FoldedBusinessCard2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.FOLDED_HANG_TAG:
				return {frontOn:"FoldedHangTag_on.png", frontOff:"FoldedHangTag_off.png", frontBackOn:"FoldedHangTag2Sided_on.png", frontBackOff:"FoldedHangTag2Sided_off.png"};
				break;
			case FQD.PrintProductType.GREETING_CARD:
				return {frontOn:"GreetingCard_Hon.png", frontOff:"GreetingCard_Hoff.png", frontBackOn:"GreetingCard2Sided_Hon.png", frontBackOff:"GreetingCard2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.HANG_TAG:
				return {frontOn:"HangTag-on.png", frontOff:"HangTag-off.png", frontBackOn:"HangTag2Sided-on.png", frontBackOff:"HangTag2Sided-off.png"};
				break;
			case FQD.PrintProductType.LETTERHEAD:
				return {frontOn:"Letterhead_Von.png", frontOff:"Letterhead_Voff.png", frontBackOn:"Letterhead2Sided_Von.png", frontBackOff:"Letterhead2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.POSTCARD:
				return {frontOn:"postcard-vertical-front-on.png", frontOff:"postcard-vertical-front-off.png", frontBackOn:"postcard-vertical-front-back-on.png", frontBackOff:"postcard-vertical-front-back-off.png"};
				break;
			case FQD.PrintProductType.RACKCARD:
				return {frontOn:"RackCard_Von.png", frontOff:"RackCard_Voff.png", frontBackOn:"RackCard2Sided_Von.png", frontBackOff:"RackCard2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.RIP_BUSINESS_CARD:
				return {frontOn:"RipBusinessCard_Von.png", frontOff:"RipBusinessCard_Voff.png", frontBackOn:"RipBusinessCard2Sided_Von.png", frontBackOff:"RipBusinessCard2Sided_Voff.png"};
				break;
			default:
				return {frontOn:"bc-vertical-front-only-on.png", frontOff:"bc-vertical-front-only-off.png", frontBackOn:"bc-vertical-front-back-on.png", frontBackOff:"bc-vertical-front-back-off.png"};
				break;
		}
	}else{
		switch(config.productTypeId)
		{
			case FQD.PrintProductType.BOOKMARK:
				return {frontOn:"Bookmark_Hon.png", frontOff:"Bookmark_Hoff.png", frontBackOn:"Bookmark2Sided_Hon.png", frontBackOff:"Bookmark2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.BUSINESS_CARD:
				return {frontOn:"front-only-on.png", frontOff:"front-only-off.png", frontBackOn:"front-back-on.png", frontBackOff:"front-back-off.png"};
				break;
			case FQD.PrintProductType.CLUB_FLYER:
				return {frontOn:"ClubFlyer_Hon.png", frontOff:"ClubFlyer_Hoff.png", frontBackOn:"ClubFlyer2Sided_Hon.png", frontBackOff:"ClubFlyer2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.COLLECTORS_CARD:
				return {frontOn:"CollectorCard_Hon.png", frontOff:"CollectorCard_Hoff.png", frontBackOn:"CollectorCard2Sided_Hon.png", frontBackOff:"CollectorCard2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.EVENT_TICKET:
				return {frontOn:"EventTicket_Hon.png", frontOff:"EventTicket_Hoff.png", frontBackOn:"EventTicket2Sided_Hon.png", frontBackOff:"EventTicket2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.FLYER:
				return {frontOn:"Flyer_Hon.png", frontOff:"Flyer_Hoff.png", frontBackOn:"Flyer2Sided_Hon.png", frontBackOff:"Flyer2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.FOLDER:
				return {frontOn:"Folder_on.png", frontOff:"Folder_off.png", frontBackOn:"Folder2Sided_on.png", frontBackOff:"Folder2Sided_off.png"};
				break;
			case FQD.PrintProductType.FOLDED_BUSINESS_CARD:
				return {frontOn:"FoldedBusinessCard_Von.png", frontOff:"FoldedBusinessCard_Voff.png", frontBackOn:"FoldedBusinessCard2Sided_Von.png", frontBackOff:"FoldedBusinessCard2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.FOLDED_HANG_TAG:
				return {frontOn:"FoldedHangTag_on.png", frontOff:"FoldedHangTag_off.png", frontBackOn:"FoldedHangTag2Sided_on.png", frontBackOff:"FoldedHangTag2Sided_off.png"};
				break;
			case FQD.PrintProductType.GREETING_CARD:
				return {frontOn:"GreetingCard_Von.png", frontOff:"GreetingCard_Voff.png", frontBackOn:"GreetingCard2Sided_Von.png", frontBackOff:"GreetingCard2Sided_Voff.png"};
				break;
			case FQD.PrintProductType.HANG_TAG:
				return {frontOn:"HangTag-on.png", frontOff:"HangTag-off.png", frontBackOn:"HangTag2Sided-on.png", frontBackOff:"HangTag2Sided-off.png"};
				break;
			case FQD.PrintProductType.LETTERHEAD:
				return {frontOn:"Letterhead_Hon.png", frontOff:"Letterhead_Hoff.png", frontBackOn:"Letterhead2Sided_Hon.png", frontBackOff:"Letterhead2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.RACKCARD:
				return {frontOn:"RackCard_Hon.png", frontOff:"RackCard_Hoff.png", frontBackOn:"RackCard2Sided_Hon.png", frontBackOff:"RackCard2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.RIP_BUSINESS_CARD:
				return {frontOn:"RipBusinessCard_Hon.png", frontOff:"RipBusinessCard_Hoff.png", frontBackOn:"RipBusinessCard2Sided_Hon.png", frontBackOff:"RipBusinessCard2Sided_Hoff.png"};
				break;
			case FQD.PrintProductType.POSTCARD:
				return {frontOn:"postcard-horizontal-front-on.png", frontOff:"postcard-horizontal-front-off.png", frontBackOn:"postcard-horizontal-front-back-on.png", frontBackOff:"postcard-horizontal-front-back-off.png"};
				break;
			default:
				return {frontOn:"front-only-on.png", frontOff:"front-only-off.png", frontBackOn:"front-back-on.png", frontBackOff:"front-back-off.png"};
				break;
		}
	}
}

FQD.products.getYardSignPageIcon=function(sizeID){
	switch(sizeID){
		case FQD.PrintProductType.YARD_SIGN_SQUARE:
			return {frontOn:"YardSignSquare-on.png", frontOff:"YardSignSquare-off.png", frontBackOn:"YardSignSquare2Sided-on.png", frontBackOff:"YardSignSquare2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_ARROW:
			return {frontOn:"YardSignArrow-on.png", frontOff:"YardSignArrow-off.png", frontBackOn:"YardSignArrow2Sided-on.png", frontBackOff:"YardSignArrow2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_CIRCLE:
			return {frontOn:"YardSignCircle-on.png", frontOff:"YardSignCircle-off.png", frontBackOn:"YardSignCircle2Sided-on.png", frontBackOff:"YardSignCircle2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_OVAL:
			return {frontOn:"YardSignOval-on.png", frontOff:"YardSignOval-off.png", frontBackOn:"YardSignOval2Sided-on.png", frontBackOff:"YardSignOval2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_OCTAGONE:
			return {frontOn:"YardSignOctagon-on.png", frontOff:"YardSignOctagon-off.png", frontBackOn:"YardSignOctagon2Sided-on.png", frontBackOff:"YardSignOctagon2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_STAR:
			return {frontOn:"YardSignStar-on.png", frontOff:"YardSignStar-off.png", frontBackOn:"YardSignStar2Sided-on.png", frontBackOff:"YardSignStar2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_HOUSE:
			return {frontOn:"YardSignHouse-on.png", frontOff:"YardSignHouse-off.png", frontBackOn:"YardSignHouse2Sided-on.png", frontBackOff:"YardSignHouse2Sided-off.png"};
			break;
		case FQD.PrintProductType.YARD_SIGN_APARTMENT:
			return {frontOn:"YardSignApartment-on.png", frontOff:"YardSignApartment-off.png", frontBackOn:"YardSignApartment2Sided-on.png", frontBackOff:"YardSignApartment2Sided-off.png"};
			break;
		default:
			if(config.productOrientation == FQD.ApplicationConstants.VERTICAL){
				return {frontOn:"YardSign-Von.png", frontOff:"YardSign-Voff.png", frontBackOn:"YardSign2Sided-Von.png", frontBackOff:"YardSign2Sided-Voff.png"};
			}else{
				return {frontOn:"YardSign-Hon.png", frontOff:"YardSign-Hoff.png", frontBackOn:"YardSign2Sided-Hon.png", frontBackOff:"YardSign2Sided-Hoff.png"};
			}
			break;
	}
}

FQD.products.getSpecialShapePageIcon=function(shapeID){
	if(config.productOrientation == FQD.ApplicationConstants.VERTICAL)
	{
		switch(shapeID){
			case FQD.PrintProductType.CIRCLE:
				return {frontOn:"SpecialShapeCircle-on.png", frontOff:"SpecialShapeCircle-off.png", frontBackOn:"SpecialShapeCircle2Sided-on.png", frontBackOff:"SpecialShapeCircle2Sided-off.png"};
				break;
			case FQD.PrintProductType.HALF_CIRCLE:
				return {frontOn:"SpecialShapeHalfCircle-Von.png", frontOff:"SpecialShapeHalfCircle-Voff.png", frontBackOn:"SpecialShapeHalfCircle2Sided-Von.png", frontBackOff:"SpecialShapeHalfCircle2Sided-Voff.png"};
				break;
			case FQD.PrintProductType.LEAF:
				return {frontOn:"SpecialShapeLeaf-Von.png", frontOff:"SpecialShapeLeaf-Voff.png", frontBackOn:"SpecialShapeLeaf2Sided-Von.png", frontBackOff:"SpecialShapeLeaf2Sided-Voff.png"};
				break;
			case FQD.PrintProductType.OVAL:
				return {frontOn:"SpecialShapeOval-Von.png", frontOff:"SpecialShapeOval-Voff.png", frontBackOn:"SpecialShapeOval2Sided-Von.png", frontBackOff:"SpecialShapeOval2Sided-Voff.png"};
				break;
			case FQD.PrintProductType.ROUNDED_RECTANGLE:
				return {frontOn:"SpecialShapeRoundedRectangle-Von.png", frontOff:"SpecialShapeRoundedRectangle-Voff.png", frontBackOn:"SpecialShapeRoundedRectangle2Sided-Von.png", frontBackOff:"SpecialShapeRoundedRectangle2Sided-Voff.png"};
				break;
			case FQD.PrintProductType.ROUNDED_SQUARE:
				return {frontOn:"SpecialShapeRoundedSquare-on.png", frontOff:"SpecialShapeRoundedSquare-off.png", frontBackOn:"SpecialShapeRoundedSquare2Sided-on.png", frontBackOff:"SpecialShapeRoundedSquare2Sided-off.png"};
				break;
			case FQD.PrintProductType.WINK:
				return {frontOn:"SpecialShapeWink-Von.png", frontOff:"SpecialShapeWink-Voff.png", frontBackOn:"SpecialShapeWink2Sided-Von.png", frontBackOff:"SpecialShapeWink2Sided-Voff.png"};
				break;
			case FQD.PrintProductType.SQUARE:
				return {frontOn:"SpecialShapeSquare-on.png", frontOff:"SpecialShapeSquare-off.png", frontBackOn:"SpecialShapeSquare2Sided-on.png", frontBackOff:"SpecialShapeSquare2Sided-off.png"};
				break;
			default:
				return {frontOn:"SpecialShapeRoundedRectangle-Von.png", frontOff:"SpecialShapeRoundedRectangle-Voff.png", frontBackOn:"SpecialShapeRoundedRectangle2Sided-Von.png", frontBackOff:"SpecialShapeRoundedRectangle2Sided-Voff.png"};
				break;
		}
	}
	else{
		switch(shapeID){
			case FQD.PrintProductType.CIRCLE:
				return {frontOn:"SpecialShapeCircle-on.png", frontOff:"SpecialShapeCircle-off.png", frontBackOn:"SpecialShapeCircle2Sided-on.png", frontBackOff:"SpecialShapeCircle2Sided-off.png"};
				break;
			case FQD.PrintProductType.HALF_CIRCLE:
				return {frontOn:"SpecialShapeHalfCircle-Hon.png", frontOff:"SpecialShapeHalfCircle-Hoff.png", frontBackOn:"SpecialShapeHalfCircle2Sided-Hon.png", frontBackOff:"SpecialShapeHalfCircle2Sided-Hoff.png"};
				break;
			case FQD.PrintProductType.LEAF:
				return {frontOn:"SpecialShapeLeaf-Hon.png", frontOff:"SpecialShapeLeaf-Hoff.png", frontBackOn:"SpecialShapeLeaf2Sided-Hon.png", frontBackOff:"SpecialShapeLeaf2Sided-Hoff.png"};
				break;
			case FQD.PrintProductType.OVAL:
				return {frontOn:"SpecialShapeOval-Hon.png", frontOff:"SpecialShapeOval-Hoff.png", frontBackOn:"SpecialShapeOval2Sided-Hon.png", frontBackOff:"SpecialShapeOval2Sided-Hoff.png"};
				break;
			case FQD.PrintProductType.ROUNDED_RECTANGLE:
				return {frontOn:"SpecialShapeRoundedRectangle-Hon.png", frontOff:"SpecialShapeRoundedRectangle-Hoff.png", frontBackOn:"SpecialShapeRoundedRectangle2Sided-Hon.png", frontBackOff:"SpecialShapeRoundedRectangle2Sided-Hoff.png"};
				break;
			case FQD.PrintProductType.ROUNDED_SQUARE:
				return {frontOn:"SpecialShapeRoundedSquare-on.png", frontOff:"SpecialShapeRoundedSquare-off.png", frontBackOn:"SpecialShapeRoundedSquare2Sided-on.png", frontBackOff:"SpecialShapeRoundedSquare2Sided-off.png"};
				break;
			case FQD.PrintProductType.WINK:
				return {frontOn:"SpecialShapeWink-Hon.png", frontOff:"SpecialShapeWink-Hoff.png", frontBackOn:"SpecialShapeWink2Sided-Hon.png", frontBackOff:"SpecialShapeWink2Sided-Hoff.png"};
				break;
			case FQD.PrintProductType.SQUARE:
				return {frontOn:"SpecialShapeSquare-on.png", frontOff:"SpecialShapeSquare-off.png", frontBackOn:"SpecialShapeSquare2Sided-on.png", frontBackOff:"SpecialShapeSquare2Sided-off.png"};
				break;
			case FQD.PrintProductType.STARBURST:
				return {frontOn:"SpecialShapeStarburst-on.png", frontOff:"SpecialShapeStarburst-off.png", frontBackOn:"SpecialShapeStarburst2Sided-on.png", frontBackOff:"SpecialShapeStarburst2Sided-off.png"};
				break;
			default:
				return {frontOn:"SpecialShapeRoundedRectangle-Hon.png", frontOff:"SpecialShapeRoundedRectangle-Hoff.png", frontBackOn:"SpecialShapeRoundedRectangle2Sided-Hon.png", frontBackOff:"SpecialShapeRoundedRectangle2Sided-Hoff.png"};
				break;
		}
	}
}


FQD.products.getFoldingOptionsData = function(foldId)
{
	switch(foldId)
	{
		case FQD.PrintProductType.ACCORDION_4PANEL:
			return {iconOn:"Accordion4PanelFold_on.png", iconOff:"Accordion4PanelFold_off.png"};
			break;
		case FQD.PrintProductType.ACCORDION_5PANEL:
			return {iconOn:"Accordion4PanelFold_on.png", iconOff:"Accordion4PanelFold_off.png"};
			break;
		case FQD.PrintProductType.CLOSED_GATE_FOLD:
			return {iconOn:"ClosedGateFold_on.png", iconOff:"ClosedGateFold_off.png"};
			break;
		case FQD.PrintProductType.DOUBLE_PARALLEL_FOLD:
			return {iconOn:"DoubleParallelFold_on.png", iconOff:"DoubleParallelFold_off.png"};
			break;
		case FQD.PrintProductType.DOUBLE_PARALLEL_REVERSE_FOLD:
			return {iconOn:"DoubleParallelReverseFold_on.png", iconOff:"DoubleParallelReverseFold_off.png"};
			break;
		case FQD.PrintProductType.HALF_FOLD:
			return {iconOn:"HalfFold_on.png", iconOff:"HalfFold_off.png"};
			break;
		case FQD.PrintProductType.HALF_FOLD_THEN_VERTICAL_HALF_FOLD:
			return {iconOn:"HalfFoldHalfFold_on.png", iconOff:"HalfFoldHalfFold_off.png"};
			break;
		case FQD.PrintProductType.HALF_FOLD_THEN_VERTICAL_TRI_FOLD:
			return {iconOn:"HalfFoldTriFold_on.png", iconOff:"HalfFoldTriFold_off.png"};
			break;
		case FQD.PrintProductType.OPEN_GATE_FOLD:
			return {iconOn:"OpenGateFold_on.png", iconOff:"OpenGateFold_off.png"};
			break;
		case FQD.PrintProductType.ROLL_FOLD_4PANEL:
			return {iconOn:"RollFold4Panel_on.png", iconOff:"RollFold4Panel_off.png"};
			break;
		case FQD.PrintProductType.ROLL_FOLD_5PANEL:
			return {iconOn:"RollFold5Panel_on.png", iconOff:"RollFold5Panel_off.png"};
			break;
		case FQD.PrintProductType.TRI_FOLD:
			return {iconOn:"TriFold_on.png", iconOff:"TriFold_off.png"};
			break;
		case FQD.PrintProductType.VERTICAL_HALF_FOLD:
			return {iconOn:"VerticalHalfFold_on.png", iconOff:"VerticalHalfFold_off.png"};
			break;
		case FQD.PrintProductType.Z_FOLD:
			return {iconOn:"ZFold_on.png", iconOff:"ZFold_off.png"};
			break;
	}
}

FQD.products.getHolePositionData = function(hid)
{
	switch(hid)
	{
		case FQD.PrintProductType.HOLE_POSITION_TOP_LEFT:
			return {iconOn:"HoleLeft-on.png", iconOff:"HoleLeft-off.png"};
			break;
		case FQD.PrintProductType.HOLE_POSITION_TOP_CENTER:
			return {iconOn:"HoleCenter-on.png", iconOff:"HoleCenter-off.png"};
			break;
		case FQD.PrintProductType.HOLE_POSITION_TOP_RIGHT:
			return {iconOn:"HoleRight-on.png", iconOff:"HoleRight-off.png"};
			break;
	}
}

FQD.products.getPerforationData = function(hid)
{
	if(config.productOrientation == FQD.ApplicationConstants.VERTICAL){
		switch(hid)
		{
			case FQD.PrintProductType.PERFORATION_ONLY:
				return {iconOn:"PerforationOnly_Von.png", iconOff:"PerforationOnly_Voff.png"};
				break;
			case FQD.PrintProductType.PERFORATION_AND_NUMBERING_FRONT_ONLY:
				return {iconOn:"PerforationAndNumberFront_Von.png", iconOff:"PerforationAndNumberFront_Voff.png"};
				break;
			case FQD.PrintProductType.PERFORATION_AND_NUMBERING_BACK_ONLY:
				return {iconOn:"PerforationAndNumberBack_Von.png", iconOff:"PerforationAndNumberBack_Voff.png"};
				break;
			case FQD.PrintProductType.NUMBERING_FRONT_ONLY:
				return {iconOn:"NumberingFront_Von.png", iconOff:"NumberingFront_Voff.png"};
				break;
			case FQD.PrintProductType.NUMBERING_BACK_ONLY:
				return {iconOn:"NumberingBack_Von.png", iconOff:"NumberingBack_Voff.png"};
				break;
		}
	}
	else{
		switch(hid)
		{
			case FQD.PrintProductType.PERFORATION_ONLY:
				return {iconOn:"PerforationOnly_Hon.png", iconOff:"PerforationOnly_Hoff.png"};
				break;
			case FQD.PrintProductType.PERFORATION_AND_NUMBERING_FRONT_ONLY:
				return {iconOn:"PerforationAndNumberFront_Hon.png", iconOff:"PerforationAndNumberFront_Hoff.png"};
				break;
			case FQD.PrintProductType.PERFORATION_AND_NUMBERING_BACK_ONLY:
				return {iconOn:"PerforationAndNumberBack_Hon.png", iconOff:"PerforationAndNumberBack_Hoff.png"};
				break;
			case FQD.PrintProductType.NUMBERING_FRONT_ONLY:
				return {iconOn:"NumberingFront_Hon.png", iconOff:"NumberingFront_Hoff.png"};
				break;
			case FQD.PrintProductType.NUMBERING_BACK_ONLY:
				return {iconOn:"NumberingBack_Hon.png", iconOff:"NumberingBack_Hoff.png"};
				break;
		}
	}
}

FQD.products.getNumberPositionData = function(hid)
{
	if(config.productOrientation == FQD.ApplicationConstants.VERTICAL){
		switch(hid)
		{
			case FQD.PrintProductType.NUMBERING_POSITION_TOP:
				return {iconOn:"NumberingPositionTop_Von.png", iconOff:"NumberingPositionTop_Voff.png"};
				break;
			case FQD.PrintProductType.NUMBERING_POSITION_CENTER:
				return {iconOn:"NumberingPositionCenter_Von.png", iconOff:"NumberingPositionCenter_Voff.png"};
				break;
			case FQD.PrintProductType.NUMBERING_POSITION_BOTTOM:
				return {iconOn:"NumberingPositionBottom_Von.png", iconOff:"NumberingPositionBottom_Voff.png"};
				break;
		}
	}
	else{
		switch(hid)
		{
		case FQD.PrintProductType.NUMBERING_POSITION_TOP:
			return {iconOn:"NumberingPositionTop_Hon.png", iconOff:"NumberingPositionTop_Hoff.png"};
			break;
		case FQD.PrintProductType.NUMBERING_POSITION_CENTER:
			return {iconOn:"NumberingPositionCenter_Hon.png", iconOff:"NumberingPositionCenter_Hoff.png"};
			break;
		case FQD.PrintProductType.NUMBERING_POSITION_BOTTOM:
			return {iconOn:"NumberingPositionBottom_Hon.png", iconOff:"NumberingPositionBottom_Hoff.png"};
			break;
		}
	}
}

FQD.products.getPocketData = function(pid)
{
	switch(pid)
	{
		case FQD.PrintProductType.POCKET_RIGHT:
			return {iconOn:"PocketRight_on.png", iconOff:"PocketRight_off.png", displayName:resourcesData.lbl_pocket_right};
			break;
		case FQD.PrintProductType.POCKET_LEFT:
			return {iconOn:"PocketLeft_on.png", iconOff:"PocketLeft_off.png", displayName:resourcesData.lbl_pocket_left};
			break;
		case FQD.PrintProductType.POCKET_DOUBLE:
			return {iconOn:"PocketBoth_on.png", iconOff:"PocketBoth_off.png", displayName:resourcesData.lbl_pocket_both};
			break;
	}
}

FQD.products.getSlitsData = function(sid)
{
	switch(sid)
	{
		case FQD.PrintProductType.SLIT_WITHOUT:
			return {iconOn:"SlitNone_on.png", iconOff:"SlitNone_off.png"};
			break;
		case FQD.PrintProductType.SLIT_BOTH_SIDES:
			return {iconOn:"SlitBoth_on.png", iconOff:"SlitBoth_off.png"};
			break;
		case FQD.PrintProductType.SLIT_LEFT_SIDE:
			return {iconOn:"SlitLeft_on.png", iconOff:"SlitLeft_off.png"};
			break;
		case FQD.PrintProductType.SLIT_RIGHT_SIDE:
			return {iconOn:"SlitRight_on.png", iconOff:"SlitRight_off.png"};
			break;
	}
}

FQD.products.getLabelForPageName = function()
{
	var frontString = resourcesData.lbl_page_front;
	var backString = resourcesData.lbl_page_back;
	
	if(FQD.PrintProductType.isFoldedProduct()){
		 frontString = resourcesData.lbl_page_outside;
		 backString = resourcesData.lbl_page_inside;
	}
	
	return {frontLbl:frontString, backLbl:backString};
}







